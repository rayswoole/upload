<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;

use App\Admin\Extend\Common;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Menu extends Base
{

    public function index(): void
    {
        $this->fetch();
    }


    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            if (isset($param['key'])) {
                $key = $param['key'];
                if (isset($key['searchName']) && $key['searchName']) {
                    $where[] = ['nav_name', 'like', "%{$key['searchName']}%"];
                }
            }
            $res = Db::name('nav')->where($where)->page($page, $limit)->select()->toArray();
            $count = Db::name('nav')->where($where)->count('*');
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => $count]);
        }
    }


    public function create()
    {
        $id = (int)$this->get('type_id');
        $arr = Db::name('nav')->select()->toArray();
        $data = Common::getInstance()->tree($arr, 0, 0, $result, 'nav_id', 'nav_pid', 'nav_name');
        $this->assign(['data' => $data, 'id' => $id]);
        $this->fetch();
    }

    public function edit()
    {
        $id = (int)$this->get('id');
        $res = Db::name('nav')->where(['nav_id' => $id])->find();
        if (!$res) {
            return Helper::responseJson(['error' => '未找到数据']);
        }
        $arr = Db::name('nav')->select()->toArray();
        $data = Common::getInstance()->tree($arr, 0, 0, $result, 'nav_id', 'nav_pid', 'nav_name');
        $this->assign(['edit' => $res, 'data' => $data]);
        $this->fetch();
    }

    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $data = [
                'nav_name' => trim($param['nav_name'], "/\\ \t\n\r\0\x0B"),
                'nav_pid' => (int)$param['nav_pid'],
                'nav_type' => (int)$param['nav_type'],
                'nav_scope' => (int)$param['nav_scope'],
                'nav_jumpurl' => trim($param['nav_jumpurl'], "/\\ \t\n\r\0\x0B"),
                'nav_mod' => 0,
                'nav_typeid' => 0,
                'nav_status' => (int)$param['nav_status']
            ];
            if (!empty($param['nav_id'])) {
                $data['nav_id'] = (int)$param['nav_id'];
            }
            $res = Helper::service('Nav')->saveNav($data);
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
        }
    }

    public function delete()
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $id_arr = explode(',', $id);
            $x = [];
            $msg = "";
            foreach ($id_arr as $k => $v) {
                $res = Db::name('nav')->where(['nav_pid' => $v])->find();
                if (!$res) {
                    $x[] = $v;
                } else {
                    $msg = " id为《{$v}》存在子级删除失败";
                }
            }
            $res = Helper::service('Nav')->deleteNav($x);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败' . $msg, 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
        }
    }

    public function update()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $field = $param['field'] ?? 'nav_status';
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $res = Helper::service('Nav')->saveNav([
                $field => $value,
                'nav_id' => $id
            ]);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
        }
    }

}