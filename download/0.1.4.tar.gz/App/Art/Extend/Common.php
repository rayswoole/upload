<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-13 18:23
 ** ----------------------------------------------------------------------
 **/

namespace App\Art\Extend;


class Common extends \App\Vod\Extend\Common
{
    public static function ray_filter_html($str): string
    {
        return strip_tags($str);
    }

    public static function tree($data, $pid, $level, &$res)
    {
        $items = array();
        foreach ($data as $v) {
            $items[$v['type_id']] = $v;
        }
        foreach ($items as $k => $v) {
            if ((int)$v['type_pid'] === (int)$pid) {
                $v['type_name'] = str_repeat(" ├─  ", $level) . $v['type_name'];
                $res[] = $v;
                Common::tree($items, $v['type_id'], $level + 1, $res);
            }
        }
        return $res;
    }
}