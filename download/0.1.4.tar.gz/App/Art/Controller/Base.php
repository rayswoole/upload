<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-13 18:41
 ** ----------------------------------------------------------------------
 **/

namespace App\Art\Controller;


use rayswoole\ReflectorClass;

class Base extends \App\Vod\Controller\Base
{
    protected function getAid()
    {
        $class = ReflectorClass::getInstance()->getShortName(static::class);
        $controllers = ['Index'=>20,'Type'=>21,'Show'=>22,'Search'=>23,'Detail'=>24];
        return $controllers[$class] ?? 0;
    }
}