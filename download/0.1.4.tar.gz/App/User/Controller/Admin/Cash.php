<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Controller\admin;

use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Cash extends Base
{

    public function index()
    {

        return $this->fetch();
    }

    /**
     * 提现列表
     * @return bool|null
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/11/5
     */
    public function read(): ?bool
    {
        if ($this->isAjax()) {
            $param = (array)$this->get();

            //$res = Helper::service('Cash')->getData($param);
            $page  = isset($param['page'])  ? (int)$param['page']  : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 10;
            $where = [];

            $order = 'cash_status';
            if (isset($param['key'])) {
                $key = $param['key'];
                if (isset($key['searchName']) && $key['searchName']) {
                    $v = $key['searchName'];
                    $where[] = ['cash_cashier','like',"%{$v}%"];
                }
            }

            $res = Db::name('user_cash')
                ->alias('c')
                ->leftJoin('user u','c.user_id=u.user_id')
                ->field('c.*,u.user_name')
                ->where($where)
                ->order($order,'ASC')
                ->limit($limit * ($page - 1),$limit)
                ->select()->toArray();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '站点列表',
                'count' => Db::name('user_cash')
                    ->alias('c')
                    ->leftJoin('user u','c.user_id=u.user_id')
                    ->field('c.*,u.user_name')
                    ->where($where)->count('cash_id'),
                'data' => $res
            ]);
        }
    }

    /**
     * @author zhou
     * @time 2020/7/25
     */
    public function create()
    {
        return $this->fetch();
    }

    /**
     * @return bool
     * @throws \EasySwoole\ORM\Exception\Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/7/25
     */
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();

            $res = Helper::service('cash')->saveCash($param);
            return Helper::responseJson($res);

        }
    }

    /**
     * 删除
     * @return bool
     * @throws \rayswoole\orm\db\exception\DbException
     * @author zhou
     * @time 2020/11/5
     */
    public function delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id=explode(',',$id);
            //$res = CashModel::create()->deleteData($id);
            $res = Db::name('user_cash')->delete($id);

            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'data' => []]);
            } else {
                return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
            }
        }
    }

    /**
     * @author zhou
     * @time 2020/7/25
     */
    public function edit()
    {
        $param = $this->get();
        if ($param['edit_id']) {

            //$res = CashModel::create()->getOneData([ 'cash_id' => intval($param['edit_id'])]);
            $res = Db::name('user_cash')->where([ 'cash_id' => intval($param['edit_id'])])->find();
            $this->assign(['data' => $res]);
        }
        return $this->fetch();
    }

    /**
     * @return bool
     * @throws \EasySwoole\Mysqli\Exception\Exception
     * @throws \EasySwoole\ORM\Exception\Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/7/25
     */
    public function update()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $edit_id = intval($param['edit_id']);
            //$param['site_info']=$this->session()->get('se_site_info');

            $res = Helper::service('Cash')->updateData($param, $edit_id);
            return Helper::responseJson($res);
        }
    }

    /**
     * 修改提现状态
     * @return bool
     * @throws \Throwable
     * @author zhou
     * @time 2020/7/25
     */
    public function update_field()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'cash_status';

           //查询出user_id  和site_id  同意提现则修改状态，不同意则返还积分
            //$userinfo=CashModel::create()->getOneData(['cash_id'=>$id]);
            $userinfo = Db::name('user_cash')->where(['cash_id'=>$id])->find();

            if ($userinfo['cash_status']!=2 && $value==2) {

                $uwhere=[
                    'user_id'=>$userinfo['user_id'],
                    'site_id'=>$userinfo['site_id'],
                ];

                //先查出旧的再修改
                $old_upoint = Db::name('user_upoint')->where($uwhere)->find();
                Db::name('user_upoint')
                    ->where($uwhere)
                    ->inc('upoint_available',$userinfo['cash_integral'])
                    ->inc('upoint_withdraw',$userinfo['cash_integral'])
                    ->inc('upoint_total',$userinfo['cash_integral'])
                    ->update();

                //拒绝后积分记录更新
                $annaldata=[
                    'user_id' =>$userinfo['user_id'],
                    'site_id' =>$userinfo['site_id'],
                    'point_id'=>$old_upoint['point_id'],
                    'annal_datatype' =>4, //提现不同意返还积分
                    'annal_bechange' =>$old_upoint['upoint_total'],
                    'annal_afchange' =>intval($old_upoint['upoint_total']+$userinfo['cash_integral']),
                    'annal_available'=>intval($old_upoint['upoint_available']+$userinfo['cash_integral']),
                    'annal_withdraw' =>intval($old_upoint['upoint_withdraw']+$userinfo['cash_integral'])
                ];
                Db::name('user_point_annal')->insert($annaldata);

            }

            $res = Db::name('user_cash')->where(['cash_id'=>$id])->update([$field => $value]);

            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '更新失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '更新成功', 'data' => []]);
        }
    }

}