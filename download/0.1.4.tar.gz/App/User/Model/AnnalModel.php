<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Model;


use rayswoole\orm\Model;

class AnnalModel extends Model
{
    protected $name = 'user_point_annal';
    protected $pk = 'annal_id';


    public function user(): \rayswoole\orm\model\relation\HasOne
    {
        return $this->hasOne('UserModel', 'user_id','user_id')->bind(['user_name','user_pid']);
    }

    public function point(): \rayswoole\orm\model\relation\HasOne
    {
        return $this->hasOne('PointModel', 'point_id','point_id')->bind(['point_name']);
    }


}