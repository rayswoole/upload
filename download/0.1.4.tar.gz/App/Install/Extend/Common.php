<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\Install\Extend;


use rayswoole\Service;
use rayswoole\utils\Validators;

class Common
{
    public static function parseSql(string $sql = '', array $prefix = []): array
    {
        $sql = trim($sql);
        if (empty($sql)) {
            return [];
        }
        $from = $to = '';
        $pure_sql = [];
        $c = false;
        if (!empty($prefix)) {
            [$to, $from] = [current($prefix), key($prefix)];
        }
        $sqlArr = explode("\n", str_replace(["\r\n", "\r"], "\n", $sql));
        foreach ($sqlArr as $value) {
            if ($value === '' || $value === 'BEGIN;' || $value === 'COMMIT;' || preg_match("/^(#|--)/", $value) || preg_match("/^\/\*(.*?)\*\//", $value)) {
                continue;
            }
            if (strpos($value, '/*') === 0) {
                $c = true;
                continue;
            }
            if (substr($value, -2) === '*/') {
                $c = false;
                continue;
            }
            if ($c) {
                continue;
            }
            if (!empty($from)) {
                $value = str_replace('`' . $from, '`' . $to, $value);
            }
            $pure_sql[] = $value;
        }
        $pure_sql = implode("\n", $pure_sql);
        $pure_sql = explode(";\n", $pure_sql);
        return $pure_sql;
    }

    public static function checkVar(array &$param, array $data): array
    {
        foreach ($data as $k => $v) {
            if (empty($param[$k]) && !is_numeric($param[$k])) {
                if (!($v[2] ?? false)) {
                    return ['status' => false, 'msg' => $v[1]];
                }
                continue;
            }
            if (false === Validators::is($param[$k], $v[0])) {
                return ['status' => false, 'msg' => $v[1]];
            }
        }
        return ['status' => true, 'msg' => '验证通过'];
    }

    public static function isInstall(bool $put = false):bool
    {
        $path = RAY_ROOT . "/App/Install/install.lock";
        clearstatcache(true, $path);
        if ($put){
            return fclose(fopen($path, 'a'));
        } else {
            return is_file($path);
        }
    }

}