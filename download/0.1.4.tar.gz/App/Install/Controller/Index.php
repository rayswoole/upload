<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\Install\Controller;


use App\Install\Extend\Common;
use EasySwoole\EasySwoole\Config;
use EasySwoole\EasySwoole\ServerManager;
use rayswoole\Helper;
use rayswoole\HttpController;
use rayswoole\orm\facade\Db;
use rayswoole\utils\Str;
use rayswoole\Vars;

class Index extends HttpController
{

    public function index()
    {
        if (Common::isInstall()) {
            $error = Vars::get('ERROR');
            if (!is_null($error)){
                return $this->isAjax() ? Helper::responseJson(['code'=>0, 'msg'=>$error, 'data'=>[]]) : Helper::responseHtml($error);
            } else {
                return Helper::responseHtml("你已经安装过了，请先删除 <b>/App/Install/install.lock</b> 文件,再刷新重试...");
            }
        }
        try {
            file_exists(RAY_ROOT.'/install.sh') && unlink(RAY_ROOT.'/install.sh');
            file_exists(RAY_ROOT.'/auto_install.json') && unlink(RAY_ROOT.'/auto_install.json');
            file_exists(RAY_ROOT.'/nginx.rewrite') && unlink(RAY_ROOT.'/nginx.rewrite');
        } catch (\Exception $exception) {};

        $data = $this->viewConfig();
        if (version_compare(PHP_VERSION, $data['hj']['php']['proposal'], '<=')) {
            $data['error'][] = 'PHP版本不得小于7.1';
            $data['hj']['php']['class'] = 'text_color_error';
        }
        foreach ($data['dir'] as $k => $v) {
            if (!is_writable(RAY_ROOT.ltrim($v['name'],'.'))) {
                $data['dir'][$k]['status'] = '不可写';
                $data['dir'][$k]['class'] = 'text_color_error';
                $data['error'][] = '文件< ' . $v['name'] . ' >不可写';
            }
        }
        foreach ($data['extend'] as $k => $v) {
            if (!extension_loaded($v['name'])) {
                $data['extend'][$k]['status'] = '不支持';
                $data['extend'][$k]['class'] = 'text_color_error';
                if (!isset($v['optional'])) {
                    $data['error'][] = '扩展 [ ' . $v['name'] . ' ] 不支持';
                }
            }
        }
        if (isset($data['error'])) {
            return Helper::responseHtml(implode('<br />', $data['error']));
        }
        $this->assign($data);
        return $this->fetch();
    }

    public function step1(): bool
    {
        if (Common::isInstall()) {
            return Helper::responseJson(['code' => 1, 'msg' => '你已经安装过了，请先删除 <b>Install/install.lock</b> 文件,再刷新重试...', 'data' => []]);
        }
        if ($this->isAjax()) {
            $param = $this->post();
            $validate = Common::checkVar($param, [
                'admin_name' => ['alchina:1..255', '管理员账号只能为\a-z\A-Z\0-9-_且长度不能超出255'],
                'admin_pass' => ['require:6..255', '管理员密码只能为\a-z\A-Z\0-9-_且长度不能小于6个字符且不能超出255'],
                'site_defaultadmin' => ['alchina:1..255', '后台路径只能为\a-z\A-Z\0-9-_且长度不能超出255']
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }
            $db = Config::getInstance()->getConf('db');
            $mysql = array_merge($db['connections']['mysql'], $param['connections']['mysql']);
            $pwd1 = trim($param['admin_pass']);
            $pwd2 = trim($param['admin_pass1']);
            if ($pwd1 !== $pwd2) {
                return Helper::responseJson(['code' => 1, 'msg' => '管理员密码两次输入不一致', 'data' => []]);
            }
            $dsn = "mysql:host={$mysql['hostname']};port={$mysql['hostport']}}";
            try {
                $pdo = new \PDO($dsn, $mysql['username'], $mysql['password']);
                $sql = "use {$mysql['database']}";
                $res = $pdo->exec($sql);
                if (false !== $res) {
                    $version = $pdo->query('select version() as version')->fetchColumn();
                    if (version_compare($version, '5.5.3', '<')){
                        throw new \PDOException('MYSQL版本过低，版本 >=5.6');
                    }
                    $res = $pdo->query("show tables");
                    if (!empty($res->fetch())) {
                        throw new \PDOException('数据库【' . $mysql['database'] . '】 已存在并且不为空，导入失败。');
                    }
                } else if ($pdo->errorCode() === '42000') {
                    $create = false;
                    if ($mysql['username'] === 'root'){
                        $sql = "CREATE DATABASE {$mysql['database']} DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;";
                        $create = $pdo->exec($sql);
                    }
                    if (!$create) {
                        throw new \PDOException('数据库【' . $mysql['database'] . '】 不存在，请先创建数据库或者使用root账号', 42000);
                    }
                }
                $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
                $sql_path = RAY_ROOT . "/install.sql";
                if (!file_exists($sql_path)) {
                    throw new \PDOException('未检测到数据库文件【' . $sql_path . '】');
                }
                $sql = file_get_contents($sql_path);
                $sqlData = Common::parseSql($sql, ['ray_' => $mysql['prefix']]);
                $pdo->exec('set names utf8');
                $pdo->exec("use {$mysql['database']}");
                foreach ($sqlData as $v) {
                    $pdo->exec($v);
                }
                $pre = $pdo->prepare("INSERT INTO `{$mysql['prefix']}admin` (`group`,`account`,`password`,`nickname`,`addtime`) VALUES (?,?,?,?,?)");
                $res = $pre->execute([1, trim($param['admin_name']), trim(password_hash($pwd1, PASSWORD_DEFAULT)), '超级管理员', time()]);
                if (!$res) {
                    throw new \PDOException('管理员账号创建失败');
                }
                $site = $pdo->query("select * from `{$mysql['prefix']}config` where `name` = 'site_defaultadmin'");
                $sql = !empty($site) ? "update `{$mysql['prefix']}config` set `val` = '{$param['site_defaultadmin']}' where `name` = 'site_defaultadmin'"
                    : "INSERT INTO `{$mysql['prefix']}config` (`name`,`group`,`val`,`type`) VALUES ('site_defaultadmin','site','{$param['site_defaultadmin']}',3)";
                $pdo->exec($sql);
                $this->assign([
                    'hostname' => $mysql['hostname'],
                    'username' => $mysql['username'],
                    'password' => $mysql['password'],
                    'database' => $mysql['database'],
                    'hostport' => $mysql['hostport'],
                    'prefix' => $mysql['prefix']
                ]);
                $content = $this->fetch('db_tpl', false);
                $content = "<?php\nreturn [\n" . $content . "\n];";
                file_put_contents(RAY_ROOT . '/Config/Db.php', $content);
                $pdo = null;
                $this->reboot();
                return Helper::responseJson(['code' => 0, 'msg' => '处理完成,请进行下一步', 'data' => []]);
            } catch (\PDOException $e) {
                $pdo = null;
                switch ($e->getCode()){
                    case 1045:
                        $message = '数据库账号或密码错误';
                        break;
                    case 2002:
                        $message = '数据库无法连接, IP或者端口填写错误';
                        break;
                    default:
                        $message = $e->getMessage();
                        break;
                }
                return Helper::responseJson(['code' => 1, 'msg' => $message, 'data' => [$e->getMessage()]]);
            }
        }
        return false;
    }

    public function step2(): bool
    {
        if (Common::isInstall()) {
            return Helper::responseJson(['code' => 1, 'msg' => '你已经安装过了，请先删除 <b>Install/install.lock</b> 文件,再刷新重试...', 'data' => []]);
        }
        if ($this->isAjax()) {
            $param = $this->post();
            $memcached = $param['memcached'];
            $def_drive = in_array($param['def_drive'], ['file', 'redis', 'memcache']) ? trim($param['def_drive']) : 'file';
            $redisStatus = $memStatus = 0;
            if (isset($param['redis']) && $redisStatus = $param['redis']['status']){
                if (!extension_loaded('redis')){
                    return Helper::responseJson(['code' => 1, 'msg' => 'phpredis扩展没有安装', 'data' => []]);
                }
                $redis = $param['redis'];
                $service = explode(',', $redis['service']);
                if (empty($service)) {
                    $redisStatus = 0;
                }
                foreach ($service as $k => $v) {
                    $arr = explode(':', $v);
                    $service[$k] = $arr[0] . ':' . $arr[1] ?? '6379';
                }
                $pool = array_map(function ($value) {
                    return (int)$value;
                }, $redis['pool']);
                if ($pool['min'] >= $pool['max']) {
                    return Helper::responseJson(['code' => 1, 'msg' => '最大连接数需要大于最小连接数', 'data' => []]);
                }
                $data = Config::getInstance()->getConf('redis');
                $pool = array_merge($data['pool'], $pool);
                if ($redisStatus) {
                    $serverStatus = false;
                    try {
                        $redisObj = new \Redis();
                        [$host, $port] = explode(':', $service[0]);
                        $serverStatus = $redisObj->connect($host, $port);
                        if ($serverStatus && !empty($redis['auth'])) {
                            $serverStatus = $redisObj->auth($redis['auth']);
                        }
                        $redisObj = null;
                    } catch (\Throwable $e) {
                        $redisObj = null;
                        return Helper::responseJson(['code' => 1, 'msg' => 'redis服务器无法连接：' . $e->getMessage(), 'data' => []]);
                    }
                    if (!$serverStatus) {
                        return Helper::responseJson(['code' => 1, 'msg' => 'redis服务器无法连接', 'data' => []]);
                    }
                }
                $this->assign([
                    'status' => $redisStatus,
                    'password' => $redis['auth'],
                    'server' => '\'' . implode(',', $service) . '\'',
                    'pool' => $pool
                ]);
                $content = $this->fetch('redis_tpl', false);
                $content = "<?php\nreturn [\n" . $content . "\n];";
                file_put_contents(RAY_ROOT . '/Config/Redis.php', $content);
            }

            if ($memStatus = $memcached['status']) {
                $data = Config::getInstance()->getConf('memcache');
                $service = $memcached['service'] ?: '127.0.0.1';
                $port = $memcached['port'] ?: 11211;
                $pool = array_map(function ($value) {
                    return (int)$value;
                }, $memcached['pool']);
                $pool = array_merge($data['pool'], $pool);
                if ($pool['min'] >= $pool['max']) {
                    return Helper::responseJson(['code' => 1, 'msg' => '最大连接数需要大于最小连接数', 'data' => []]);
                }
                $config = new \EasySwoole\Memcache\Config();
                $config->setHost($service)->setPort((int)$port);
                try {
                    $memcacheObj = new \EasySwoole\Memcache\Memcache($config);
                    $memcacheObj->connect();
                    $memcacheObj = null;
                    $config = null;
                } catch (\EasySwoole\Memcache\Exception\ConnectException $exception) {
                    $memcacheObj = null;
                    return Helper::responseJson(['code' => 1, 'msg' => 'memcached服务器无法链接：' . $exception->getMessage(), 'data' => []]);
                }
                $this->assign([
                    'status' => $memStatus,
                    'port' => (int)$port,
                    'server' => $service,
                    'pool' => $pool
                ]);
                $content = $this->fetch('memcached_tpl', false);
                $content = "<?php\nreturn [\n" . $content . "\n];";
                file_put_contents(RAY_ROOT . '/Config/Memcache.php', $content);
            }
            Db::name('Config')->where(['group' => 'system', 'name' => 'cache_mode'])->update(['val' => $def_drive]);
            Common::isInstall(true);
            $this->reboot();
            return Helper::responseJson(['code' => 0, 'msg' => '处理完成,请进行下一步', 'data' => [
                'admin' => Helper::url("admin@login/index"),
                'index' => Helper::url("vod@index/index")
            ]]);
        }
        return false;
    }

    private function viewConfig(): array
    {
        return [
            'hj' => [
                'php' => [
                    'name' => 'php',
                    'needed' => '>=7.1.0',
                    'proposal' => '>=7.2.0',
                    'status' => PHP_VERSION,
                    'class' => 'text_color_ok'
                ],
                'mysql' => [
                    'name' => 'mysql',
                    'needed' => '>5.5.3',
                    'proposal' => '>=5.7',
                    'status' => '未知'
                ],
                'upload' => [
                    'name' => '上传限制',
                    'needed' => ServerManager::getInstance()->getSwooleServer()->setting['http_parse_files'] ? '允许' : '不允许',
                    'proposal' => '2MB',
                    'status' => Str::formatBytes(ServerManager::getInstance()->getSwooleServer()->setting['package_max_length'])
                ]
            ],
            'dir' => [
                'config' => [
                    'name' => './Config',
                    'proposal' => '可写',
                    'status' => '可写',
                    'class' => 'text_color_ok'
                ],
                'runtime' => [
                    'name' => './Runtime',
                    'proposal' => '可写',
                    'status' => '可写',
                    'class' => 'text_color_ok'
                ],
                'config_php' => [
                    'name' => './App/Install',
                    'proposal' => '可写',
                    'status' => '可写',
                    'class' => 'text_color_ok'
                ],
                'upload' => [
                    'name' => './Public/static/upload',
                    'proposal' => '可写',
                    'status' => '可写',
                    'class' => 'text_color_ok'
                ]
            ],
            'extend' => [
                'pdo' => [
                    'name' => 'PDO',
                    'proposal' => '支持',
                    'status' => '支持',
                    'class' => 'text_color_ok'
                ],
                'pdo_mysql' => [
                    'name' => 'PDO_MYSQL',
                    'proposal' => '支持',
                    'status' => '支持',
                    'class' => 'text_color_ok'
                ],
                'redis' => [
                    'name' => 'Redis',
                    'proposal' => '可选【非必须】',
                    'optional' => true,
                    'status' => '支持',
                    'class' => 'text_color_ok'
                ]
            ]
        ];
    }

    public function ViewError(string $msg)
    {
        $this->assign([
            'msg' => $msg
        ]);
        return $this->fetch('error');
    }

}