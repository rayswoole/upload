<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Vod\Controller\Admin;

use App\Admin\Controller\Base;
use App\Vod\Service\VodService;
use rayswoole\orm\facade\Db;
use App\Vod\Extend\Common;
use rayswoole\Helper;
use voku\helper\HtmlDomParser;


class Custom extends Base
{

    public function index()
    {
        $this->fetch();
    }

    //显示
    public function custom_collect()
    {
        $param=$this->get();

        $id = (int)$this->get('custom_id');
        $res=Db::name('custom')->where(['custom_id'=>$id])->find();

        $isNext = 1;
        $page=$param['page'] ?? 1;
        if(strpos($res['custom_page'],'-')){
            $page_num=explode('-',$res['custom_page']);
            $page_count=$page_num[1];
        }else{
            $page_count=$res['custom_page'];
        }

        $result=$this->cust_data($res,$page,$page_count);

        if ($page >= $page_count) {
            $isNext = 0;
        }

        $this->assign('page_count',$page_count);
        $this->assign('page',$page);
        $this->assign('res',$result['msg']);
        $this->assign('custom_id',$id);
        $this->assign('isNext',$isNext);
        return $this->fetch();

    }

    //ku 123
    public function cust_data($res,$page,$page_count)
    {
        //$res=Db::name('custom')->where(['custom_id'=>$custom_id])->find();
        $detailPreg = $res['custom_list_url_label'];
        $res['custom_title']   = explode('[内容]',$res['custom_title']);
        $res['custom_remark']  = explode('[内容]',$res['custom_remark']);
        $res['custom_director']= explode('[内容]',$res['custom_director']);
        $res['custom_actor']   = explode('[内容]',$res['custom_actor']);
        $res['custom_class']   = explode('[内容]',$res['custom_class']);
        $res['custom_area']    = explode('[内容]',$res['custom_area']);
        $res['custom_lang']    = explode('[内容]',$res['custom_lang']);
        $res['custom_year']    = explode('[内容]',$res['custom_year']);
        $res['custom_duration']= explode('[内容]',$res['custom_duration']);
        $res['custom_pic']     = explode('[内容]',$res['custom_pic']);
        $res['custom_blurb']   = explode('[内容]',$res['custom_blurb']);
        $res['custom_play_url_info']=explode('[内容]',$res['custom_play_url_info']);
        $res['custom_play_url']=explode('[内容]',$res['custom_play_url']);

        //内容采集url
        $caijiurl=str_replace('(*)',$page,$res['custom_list_url']);

        //处理分类
        $res['type']=preg_replace('/[\t\r\n]+/','#', $res['custom_type']);
        $type_arr=explode('#',$res['type']);
        foreach ($type_arr as $k=>$v){
            $tkv=explode('=',$v);
            $type_class[]=$tkv['0']; //采集类型数组
            foreach ($tkv as $v){
                $type_bandding[$tkv['0']]=$v; //['喜剧'=>7] 类型健值对
            }
        }

        $str=Helper::simpleGet($caijiurl);
        $href=[];
        $arr=[];

        $detailPreg = str_replace('(*)','____', $detailPreg);
        $detailPreg = addcslashes($detailPreg,'\'\"\<\>\[\]\\\!\-\?\.\+\/\|\(\)');
        $detailPreg = str_replace('____','(.*?)',$detailPreg);
        preg_match_all('/'.$detailPreg.'/', $str['body'], $href);

        $msg=[];

        //处理页面数据 存入数据库
        foreach ($href[1] as $key=>$val) {
            //preg_match('/\d+/',$val,$num); //提取出detail页面id
            $detail_url=str_replace('(*)',$val,$res['custom_info_url']); //内容采集url

            $str = Helper::simpleGet($detail_url);  //url 需要处理
            $html = HtmlDomParser::str_get_html($str['body']);

            $arr['vod_class'] = $this->tsss($res['custom_class'][0], $res['custom_class'][1], $html);

            if(!in_array($arr['vod_class'],$type_class)){
                //$des = '<font color="red">分类未绑定，跳过err</font>';
            }else{
                $arr['type_id']=$type_bandding[$arr['vod_class']];
                $arr['vod_addtime']=time();

                $arr['vod_title']     = $this->tsss($res['custom_title'][0], $res['custom_title'][1], $html);
                $arr['vod_remarks']   = $this->tsss($res['custom_remark'][0], $res['custom_remark'][1], $html);
                $arr['vod_director']  = $this->tsss($res['custom_director'][0], $res['custom_director'][1], $html);
                $arr['vod_actor']     = $this->tsss($res['custom_actor'][0], $res['custom_actor'][1], $html);
                $arr['vod_class']     = $this->tsss($res['custom_class'][0], $res['custom_class'][1], $html);
                $arr['vod_area']      = $this->tsss($res['custom_area'][0], $res['custom_area'][1], $html);
                $arr['vod_lang']      = $this->tsss($res['custom_lang'][0], $res['custom_lang'][1], $html);
                $arr['vod_year']      = substr($this->tsss($res['custom_year'][0], $res['custom_year'][1], $html),0,4);
                $arr['vod_pic']       = $this->tsss($res['custom_pic'][0], $res['custom_pic'][1], $html);
                $arr['vod_blurb']     = $this->tsss($res['custom_blurb'][0], $res['custom_blurb'][1], $html);
                $arr['vod_content']   = $this->tsss($res['custom_blurb'][0], $res['custom_blurb'][1], $html);
                $arr['vod_status']   = 1;

                $arr['vod_play_url_info'] = $this->tsss($res['custom_play_url_info'][0], $res['custom_play_url_info'][1], $html);
                $start = addcslashes($res['custom_play_url'][0],'\'\"\<\>\[\]\\\!\-\?\.\+\/\|\(\)');
                $end   = addcslashes($res['custom_play_url'][1],'\'\"\<\>\[\]\\\!\-\?\.\+\/\|\(\)');
                preg_match_all('/'.$start.'(.*?)'.$end.'/',$arr['vod_play_url_info'],$matches);
                if (!isset($matches[1])){
                    continue;
                }
                $arr['vod_play_url']=implode('#',$matches[1]);

                $arr['vod_play_from']=$res['custom_play_from'];
                //处理演员名 和值
                $actor = Common::actorReplace($arr['vod_actor']);
                $arr['vod_actor']   = $actor['actor'];
                $arr['vod_actor_val']= $actor['actor_val'];

                $where = [];
                $where['vod_title'] = $arr['vod_title'];
                $info=Db::name("vod")->where($where)->find();
                if(!$info){
                    VodService::getInstance()->saveVod($arr);
                    $des = '<font color="green">新加入库，成功ok</font>';
                }else{
                    $db_vod_play_from = explode('$$$', $info['vod_play_from']);
                    $db_vod_play_url  = explode('$$$', $info['vod_play_url']);
                    $remote_vod_play_from = explode('$$$', $arr['vod_play_from']);
                    $remote_vod_play_url  = explode('$$$', $arr['vod_play_url']);
                    $changeTime = false;
                    foreach ($remote_vod_play_from as $key2=>$remote_from){
                        $index = array_search($remote_from, $db_vod_play_from);
                        if ($index === false){
                            $db_vod_play_from[] = $remote_vod_play_from[$key2];
                            $db_vod_play_url[] = $remote_vod_play_url[$key2];
                            $changeTime = true;
                        } else {
                            if (count(explode('#',$db_vod_play_url[$index])) !== count(explode('#',$remote_vod_play_url[$key2]))) {
                                $changeTime = true;
                            }
                            $db_vod_play_from[$index] = $remote_vod_play_from[$key2];
                            $db_vod_play_url[$index]  = $remote_vod_play_url[$key2];
                        }
                    }

                    $info['vod_remarks']   = $arr['vod_remarks'];
                    $info['vod_play_from'] = implode('$$$',$db_vod_play_from);
                    $info['vod_play_url']  = implode('$$$',$db_vod_play_url);
                    if ($changeTime){
                        $info['vod_addtime'] = time();
                    }
                    VodService::getInstance()->saveVod($info);
                    $des = '<font color="green">更新入库，成功ok</font>';
                }
                $msg[$key]= ($key + 1) .'、'. $arr['vod_title'] . "<font>" .$des .'</font>'.'' ;
            }

        }

        if($page>=$page_count){
            $des = '<font color="blue">数据采集完成</font>';
            array_push($msg,$des);
        }

        return ['msg'=>$msg];

    }

    //返回截取查找的内容
    public function tsss($start,$end,$string)
    {
        return trim(str_replace($start,' ',substr($string,strpos($string, $start),strpos($string, $end)-strpos($string, $start) )));

    }

    //读取采集列表
    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();

            $where[]= ['custom_mid','=',2];
            if (!empty($param['key']) && !empty($key['searchName'])) {
                $where[] = ['custom_name', 'like', "%{$key['searchName']}%"];
            }

            $data = Db::name('custom')->where($where)->order('custom_sort,custom_id','asc')->select()->toArray();

            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $data, 'count' => count($data)]);
        }
    }

    //新增采集页面
    public function create()
    {

        $this->fetch();
    }
    //编辑自己定义采集页面
    public function edit()
    {
        $id = (int)$this->get('edit_id');

        $res=Db::name('custom')->where(['custom_id'=>$id])->find();

        $this->assign(['data' => $res]);
        $this->fetch();
    }

    //保存新增和修改的数据
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();

            $data=[
                'custom_name' => trim($param['custom_name']),
                'custom_list_url' => trim($param['custom_list_url']),
                'custom_list_url_label' => trim($param['custom_list_url_label']),
                'custom_info_url' => trim($param['custom_info_url']),
                'custom_page' => trim($param['custom_page']),
                'custom_play_from' => trim($param['custom_play_from']),
                'custom_pic'  => trim($param['custom_pic']),
                'custom_type'  => trim($param['custom_type']),
                'custom_title' => trim($param['custom_title']),
                'custom_remark' => trim($param['custom_remark']),
                'custom_director' => trim($param['custom_director']),
                'custom_actor' => trim($param['custom_actor']),
                'custom_class' => trim($param['custom_class']),
                'custom_area' => trim($param['custom_area']),
                'custom_lang' => trim($param['custom_lang']),
                'custom_year' => trim($param['custom_year']),
                'custom_duration' => trim($param['custom_duration']),
                'custom_blurb' => trim($param['custom_blurb']),
                'custom_play_url' => trim($param['custom_play_url']),
                'custom_play_url_info' => trim($param['custom_play_url_info']),
            ];

            if(isset($param['custom_id'])!==''){
                $data['custom_id']=$param['custom_id'];
            }
            $res=Db::name('custom')->save($data);

            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
        }
    }

    //删除采集项
    public function delete()
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res= Db::name('custom')->delete($data);

            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
        }
    }


}