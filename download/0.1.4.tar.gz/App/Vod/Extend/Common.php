<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-16 14:43
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Extend;

use EasySwoole\Http\Message\Request;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\utils\Str;
use rayswoole\utils\Validators;
use rayswoole\session\Session;

class Common
{

    public function checkVar(array &$param, array $data): array
    {
        foreach ($data as $k => $v) {
            if (empty($param[$k]) && !is_numeric($param[$k])) {
                if (!($v[2] ?? false)) {
                    return ['status' => false, 'msg' => $v[1]];
                }
                continue;
            }
            if (false === Validators::is($param[$k], $v[0])) {
                return ['status' => false, 'msg' => $v[1]];
            }
        }
        return ['status' => true, 'msg' => '验证通过'];
    }

    public static function ray_param_url(): array
    {
        $param = Helper::getRequest();
        $data = [];
        $data['id'] = isset($param['id']) ? (int)$param['id'] : 0;
        $data['page'] = isset($param['page']) && $param['page'] >= 1 ? (int)$param['page'] : 1;
        $data['nid'] = isset($param['nid']) ? (int)$param['nid'] : 1;
        $data['by'] = !empty($param['by']) ? $param['by'] : 'time';
        $data['wd'] = htmlspecialchars(urldecode(trim($param['wd'] ?? '')));
        $data['class'] = htmlspecialchars(urldecode(trim($param['class'] ?? '')));
        $data['area'] = htmlspecialchars(urldecode(trim($param['area'] ?? '')));
        $data['year'] = htmlspecialchars(urldecode(trim($param['year'] ?? '')));
        $data['lang'] = htmlspecialchars(urldecode(trim($param['lang'] ?? '')));
        $data['actor'] = htmlspecialchars(urldecode(trim($param['actor'] ?? '')));
        $data['director'] = htmlspecialchars(urldecode(trim($param['director'] ?? '')));
        $data['letter'] = htmlspecialchars(urldecode(trim($param['letter'] ?? '')));
        $data['level'] = htmlspecialchars(urldecode(trim($param['level'] ?? '')));
        $data['director'] = htmlspecialchars(urldecode(trim($param['director'] ?? '')));
        $data['director'] = htmlspecialchars(urldecode(trim($param['director'] ?? '')));
        $data['letter'] = htmlspecialchars(urldecode(trim($param['letter'] ?? '')));

        $data['ajax'] = htmlspecialchars(urldecode(trim($param['ajax'] ?? '')));
        $data['tid'] = htmlspecialchars(urldecode(trim($param['tid'] ?? '')));
        $data['mid'] = htmlspecialchars(urldecode(trim($param['mid'] ?? '')));
        $data['rid'] = htmlspecialchars(urldecode(trim($param['rid'] ?? '')));
        $data['pid'] = htmlspecialchars(urldecode(trim($param['pid'] ?? '')));
        $data['sid'] = isset($param['sid']) ? (int)$param['sid'] : 1;
        $data['uid'] = htmlspecialchars(urldecode(trim($param['uid'] ?? '')));
        $data['score'] = htmlspecialchars(urldecode(trim($param['score'] ?? '')));
        $data['limit'] = htmlspecialchars(urldecode(trim($param['limit'] ?? '')));

        $data['ids'] = htmlspecialchars(urldecode(trim($param['ids'] ?? '')));
        $data['state'] = htmlspecialchars(urldecode(trim($param['state'] ?? '')));
        $data['file'] = htmlspecialchars(urldecode(trim($param['state'] ?? '')));
        $data['name'] =htmlspecialchars(urldecode(trim($param['state'] ?? '')));
        $data['url'] = htmlspecialchars(urldecode(trim($param['state'] ?? '')));
        $data['type'] = htmlspecialchars(urldecode(trim($param['state'] ?? '')));
        $data['sex'] = htmlspecialchars(urldecode(trim($param['sex'] ?? '')));
        $data['version'] = htmlspecialchars(urldecode(trim($param['version'] ?? '')));
        $data['blood'] = htmlspecialchars(urldecode(trim($param['blood'] ?? '')));
        $data['starsign'] = htmlspecialchars(urldecode(trim($param['starsign'] ?? '')));
        $data['tag'] = htmlspecialchars(urldecode(trim($param['tag'] ?? '')));
        $data['order'] = htmlspecialchars(urldecode(trim($param['order'] ?? '')));
        return $data;
    }

    public static function get_invite()
    {
        $params=Helper::request()->getRequestParam();
        if(isset($params['invite'])){
            $invite=['invite'=>$params['invite']];
            Helper::response()->setCookie('INVITE', Helper::enJson($invite), time() + 60 * 60);
            return true;
        }
    }

    //视频详情页面urll
    public static function ray_url_vod_detail($data)
    {
        return Helper::url('vod@detail/index',['id'=>$data['vod_id']]);
    }

    //视频类型url
    public static function ray_url_type($info,array $param = [], string $flag = 'type')
    {
        $info = is_object($info) ? json_decode(json_encode($info, 256), true) : (array)$info;
        if (isset($info['type_mid'])) {
            switch ($info['type_mid']) {
                case 5:
                case 1:
                    $tab = 'vod';
                    break;
                case 2 :
                    $tab = 'art';
                    break;
                case 8:
                    $tab = 'actor';
                    break;
                case 11:
                    $tab = 'website';
                    break;
                default:
                    $tab = 'vod';
            }
        } else {
            $tab = 'art';
        }
        if (empty($param['type_id'])) {
            $param['id'] = $info['type_id'] ?? 0;
        }
        ksort($param);

        $param=array_filter($param, function ($val){
            return !empty($val);
        });
        return Helper::url($tab.'@'.$flag.'/index', $param);
    }

    //图片url
    public static function ray_url_img($data){
        return $data;
        //return Helper::url('',['id'=>$data['type_id']]);
    }

    //视频播放url 处理
    public static function ray_url_vod_play($obj, $param = []): string
    {
        if (!isset($param['sid'])){
            $param['sid'] = 1;
        }
        if (!isset($param['nid'])){
            $param['nid'] = 1;
        }
        return Helper::url('vod@play/index', [
            'id' => $obj['vod_id'],
            'sid' => $param['sid'],
            'nid' => $param['nid']
        ]);
    }

    public static function ray_url_vod_down($data,$param = [])
    {
        $param = array_merge($data, $param);
        return Helper::url('vod/down', ['id' => $param['vod_id'], 'nid' => $param['nid'] ?? 1]);
    }

    public static function ray_url_topic_index()
    {
        return "";
    }

    public static function ray_url_actor_index()
    {
        return "";
    }

    public static function ray_filter_html($data)
    {
        return htmlspecialchars($data);
    }

    public static function defult($a)
    {
        return '';
    }

    //视频搜索
    public static function ray_url_search()
    {
        return "";
    }
    public static function ray_url($data, ...$args)
    {

        return Helper::url($data,...$args);
    }

    public static function ray_url_art_detail($data)
    {

        return Helper::url('art@detail/index', ['id' => $data['art_id']]);
    }

    public static function ray_substring(string $str, int $length = 12, int $start = 0): ?string
    {
        return Str::substr($str, $start, $length);
    }

    public static function ray_default(?string $str, ?string $default = null): ?string
    {
        return !empty($str) ? $str : $default;
    }

    public static  function ray_get_mid($controller)
    {
        $controller = strtolower($controller);
        $arr = ['vod' => 1, 'art' => 2, 'actor' => 8, 'website' => 11];
        return $arr[$controller] ?? 0;
    }

    public static function ray_url_page($url, $nowPage=1): string
    {
        if (empty($url)){
            return '';
        }
        $params = Helper::getRequest('','get');
        if ($nowPage == 1){
            unset($params['page']);
        } else {
            $params['page'] = $nowPage;
        }
        return Helper::url($url, $params);
    }

    public static  function ray_get_aid($controller, $action = '')
    {
        $controller = strtolower($controller);
        $action = strtolower($action);
        $key = $controller . '/' . $action;

        $arr = ['index' => 1, 'vod' => 10, 'art' => 20, 'website' => 110, 'comment' => 112];
        $res = $arr[$controller];
        $arr = [
            'type/index' => 11, 'show/index' => 12, 'search/index' => 13, 'detail/index' => 14, 'play/index' => 15, 'down/index' => 16, 'role/index' => 17,
            'art/type' => 21, 'art/show' => 22, 'art/search' => 23, 'art/detail' => 24,
            'actor/type' => 81, 'actor/show' => 82, 'actor/search' => 83, 'actor/detail' => 84,
            'website/type' => 111, 'website/show' => 112, 'website/search' => 113, 'website/detail' => 114,
        ];
        $res = $arr[$key] ?? $res;

        return $res;
    }

    public static function ray_friend_date($time): string
    {
        if (!$time) return false;
        $d = time() - (int)$time;
        $ld = $time - mktime(0, 0, 0, 0, 0, date('Y'));
        $md = $time - mktime(0, 0, 0, date('m'), 0, date('Y'));
        $byd = $time - mktime(0, 0, 0, date('m'), date('d') - 2, date('Y'));
        $yd = $time - mktime(0, 0, 0, date('m'), date('d') - 1, date('Y'));
        $dd = $time - mktime(0, 0, 0, date('m'), date('d'), date('Y'));
        $td = $time - mktime(0, 0, 0, date('m'), date('d') + 1, date('Y'));
        $atd = $time - mktime(0, 0, 0, date('m'), date('d') + 2, date('Y'));
        if ((int)$d === 0) {
            $date = '刚刚';
        } else {
            switch ($d) {
                case $d < $atd:
                    $date = date('Y年m月d日', $time);
                    break;
                case $d < $td:
                    $date = '后天' . date('H:i', $time);
                    break;
                case $d < 0:
                    $date = '明天' . date('H:i', $time);
                    break;
                case $d < 60:
                    $date = $d . '秒前';
                    break;
                case $d < 3600:
                    $date = floor($d / 60) . '分钟前';
                    break;
                case $d < $dd:
                    $date = floor($d / 3600) . '小时前';
                    break;
                case $d < $yd:
                    $date = '昨天' . date('H:i', $time);
                    break;
                case $d < $byd:
                    $date = '前天' . date('H:i', $time);
                    break;
                case $d < $md:
                    $date = date('m月d日 H:i', $time);
                    break;
                case $d < $ld:
                    $date = date('m月d日', $time);
                    break;
                default:
                    $date = date("Y年m月d日", $time);
                    break;
            }
        }
        return $date;
    }

    //视频更新统计
    public static function ray_data_count(int $tid = 0, string $range = 'all', string $flag = 'vod')
    {
        $where=[];
        $today = strtotime(date('Y-m-d'));
        if ($range=='today')
        {
            $where[]=['vod_addtime','>',$today];
        } else {
            $where[]=['vod_addtime','>',0];
        }

        $result=Db::name('vod')
            ->where($where)
            ->count();

        return $result ?? 0;
    }

    public static function ray_url_create(?string $str = null, string $type = 'actor', string $flag = 'vod', string $ac = 'search', string $sp = '&nbsp;'): string
    {
        if (!$str) {
            return '未知';
        }
        $res = [];
        $str = str_replace(array('/', '|', ',', '，', ' '), ',', $str);
        $arr = explode(',', $str);
        foreach ($arr as $k => $v) {
            if (empty($v)) {
                continue;
            }
            $url=Helper::url($flag . '/' . $ac, [$type => $v]);
            $res[$k] = '<a href="' . $url . '" target="_blank">' . $v . '</a>' . $sp;
        }

        return implode('', $res);
    }

    /**
     * 处理演员名字
     * @param $string
     * @return mixed
     * @author zhou
     * @time 2020/8/1
     */
    public static function actorReplace($string)
    {
        $string=htmlspecialchars($string);
        //替换成用，分割的字符串
        if (strpos($string,'/')) {
            $string=str_replace('/',',',$string);
        } else if (strpos($string,'|')){
            $string=str_replace('|',',',$string);
        }else if (strpos($string,'-')){
            $string=str_replace('-',',',$string);
        }else if (strpos($string,' ')){
            $string=str_replace(' ',',',$string);
        }else{
            $string;
        }
        //做成数组 组合成vod_actor_val
        $actor=explode(',',$string);
        $num=-1;
        for($i=0;$i<count($actor);$i++){
            $actor_val_arr[]=$num--;
        }
        $actor_val=implode(',',$actor_val_arr);

        return $data=[
            'actor'=>$string,
            'actor_val'=>$actor_val
        ];

    }

}