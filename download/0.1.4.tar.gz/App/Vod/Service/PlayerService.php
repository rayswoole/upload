<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Vod\Service;

use rayswoole\Service;
use rayswoole\orm\facade\Db;

class PlayerService extends Service
{
    //播放器列表
    public function getPlayerList():array
    {
        $list=Db::name('vod_player')
            ->where(['player_status'=>1])
            ->order('player_sort','DESC')
            ->column('*','player_from');;

        return $list;
    }

}