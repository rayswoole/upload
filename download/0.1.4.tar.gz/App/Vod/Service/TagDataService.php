<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-08-27 15:35
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Service;

use rayswoole\Helper;
use rayswoole\Service;
use rayswoole\orm\facade\Db;

class TagDataService extends Service
{
    private $container = array();




    public function tagTypeList(){


    }

    function get($key, $defaultValue = null)
    {
        if(isset($this->container[$key])){
            $obj = $this->container[$key]['obj'];
            $params = $this->container[$key]['params'];
            if(is_object($obj) || is_callable($obj)){
                return $obj;
            }else if(is_string($obj) && class_exists($obj)){
                try{
                    $this->container[$key]['obj'] = new $obj(...$params);
                    return $this->container[$key]['obj'];
                }catch (\Throwable $throwable){
                    throw $throwable;
                }
            }elseif(is_array($obj)){
                $keys = explode('.',$key);
                switch (count($keys)){
                    case 1:
                        return $obj;
                        break;
                    case 2:
                        return $obj[$keys[0]] ?? null;
                        break;
                    case 3:
                        return isset($obj[$keys[0]]) && isset($obj[$keys[0]][$keys[1]]) ? $obj[$keys[0]][$keys[1]] : null;
                        break;
                    default:
                        return $defaultValue ?? null;
                        break;
                }
            }else{
                return $obj;
            }
        }else{
            return $defaultValue ?? null;
        }
    }

    /**
     * 视频标签内容处理返回
     * @param $tag
     * @return array
     * @throws \Exception
     * @throws \Throwable
     * @throws \rayswoole\orm\db\exception\DataNotFoundException
     * @throws \rayswoole\orm\db\exception\DbException
     * @throws \rayswoole\orm\db\exception\ModelNotFoundException
     * @author zhou
     * @time 2020/9/14
     */
    public function tagVodList($tag):array
    {
        $param=json_decode($tag, true);

        $where = [];
        $page = !empty($param['page']) ? (int)$param['page'] : 1;
        $start = isset($param['start']) && is_numeric($param['start']) ? max(0, (int)$param['start'] - 1) : 0;
        $number = isset($param['num']) && is_numeric($param['num']) ? (int)$param['num'] : 0;

        // 指定分类信息
        if (!empty($param['type']) && $param['type'] !== 'all' && $param['type'] !== 'a') {
            $type = $param['type'];
            if ($type === 'current') {
                if ($info = $this->get('info')) {
                    if (isset($info['childs']) && !empty($info['childs'])) {
                        $type = [$info['type_id']] + array_keys($info['childs']);
                    } else {
                        $type = $info['type_id'];
                    }
                    $where['type_id'] = is_int($type) ? $type : [$type, 'in'];
                }
            } else {
                $typeTree = $this->get('typeTree');
                $typeList = $this->get('typeList');
                $type = explode(',', $type);
                $ids = [];
                foreach ($type as $_type) {
                    if (isset($typeList['data'][$_type])) {
                        $ids += [$_type];
                        if (($typeList['data'][$_type]['type_pid'] == 0) && !empty($typeTree[$_type]['childs'])) {
                            $ids += array_keys($typeTree[$_type]['childs']);
                        }
                    }
                }
                if (!empty($ids)) {
                    $where['type_id'] = [$ids, 'in'];
                }
            }
        }
        // 指定一组id
        if (!empty($param['ids']) && $ids = $param['ids'] !== 'all') {
            switch ($ids) {
                case is_string($ids):
                    $pid_arr = explode(',', $ids);
                    if ($pid_arr) {
                        $where['vod_id'] = [$pid_arr, 'in'];
                    }
                    break;
                case is_array($ids = json_decode($ids, true)):
                    if ($ids) {
                        $where['vod_id'] = [$ids, 'in'];
                    }
                    break;
            }
        }
        if (!empty($param['class'])) {
            $where['vod_class'] = $param['class'];
        }
        // 推荐等级
        if (!empty($param['level'])) {
            $level = $param['level'];
            if (is_string($level)) $w = explode(',', $level);
            elseif (is_array($level)) $w = $level;
            else $w = [1, 2, 3, 4, 5, 6, 7, 8, 9];
            $where['vod_star'] = [$w, 'in'];
        }
        // 指定地区
        if (!empty($param['area'])) {
            $where['vod_area'] = [explode(',', $param['area']), 'in'];
        }
        // 语言
        if (!empty($param['lang'])) {
            $where['vod_lang'] = [explode(',', $param['lang']), 'in'];
        }
        // 年份
        if (!empty($param['year'])) {
            $year = $param['year'];
            if (strlen($year) === 9) {
                $s = (int)substr($year, 0, 4);
                $e = (int)substr($year, 5, 4);
                $s1 = $s;
                $e1 = $e;
                if ($s > $e) {
                    $s1 = (int)$e;
                    $e1 = (int)$s;
                }
                $tmp = [];
                for ($i = $s1; $i <= $e1; $i++) {
                    $tmp[] = $i;
                }
                $y = implode(',', $tmp);
            } else {
                $y = $year;
            }
            $where['vod_year'] = [explode(',', $y), 'in'];
        }
        if (!empty($param['timeadd'])) {
            $w = (int)strtotime($param['timeadd']);
            $where['vod_addtime'] = [$w, '>'];
        }
        if (!empty($param['hitsday'])) {
            $hitsday = $param['hitsday'];
            if (is_array($hitsday)) {
                if (count($hitsday) > 1) {
                    $where['vod_hits_day'] = [$hitsday[0], $hitsday[1]];
                } else {
                    $where['vod_hits_day'] = [$hitsday[0], '>'];
                }
            } else {
                $t = explode(' ', $hitsday);
                if (count($t) > 1) {
                    $where['vod_hits_day'] = [$t[0], $t[1]];
                } else {
                    $where['vod_hits_day'] = [$t, '>'];
                }
            }
        }
        if (!empty($param['hitsweek'])) {
            $hitsweek = $param['hitsweek'];
            if (is_array($hitsweek)) {
                if (count($hitsweek) > 1) {
                    $where['vod_hits_week'] = [$hitsweek[0], $hitsweek[1]];
                } else {
                    $where['vod_hits_week'] = [$hitsweek[0], '>'];
                }
            } else {
                $t = explode(' ', $hitsweek);
                if (count($t) > 1) {
                    $where['vod_hits_week'] = [$t[0], $t[1]];
                } else {
                    $where['vod_hits_week'] = [$t, '>'];
                }
            }
        }
        if (!empty($param['hitsmonth'])) {
            $hitsmonth = $param['hitsmonth'];
            if (is_array($hitsmonth)) {
                if (count($hitsmonth) > 1) {
                    $where['vod_hits_month'] = [$hitsmonth[0], $hitsmonth[1]];
                } else {
                    $where['vod_hits_month'] = [$hitsmonth[0], '>'];
                }
            } else {
                $t = explode(' ', $hitsmonth);
                if (count($t) > 1) {
                    $where['vod_hits_month'] = [$t[0], $t[1]];
                } else {
                    $where['vod_hits_month'] = [$t, '>'];
                }
            }
        }
        if (!empty($param['hits'])) {
            $hits = $param['hits'];
            if (is_array($hits)) {
                if (count($hits) > 1) {
                    $where['vod_hits'] = [$hits[0], $hits[1]];
                } else {
                    $where['vod_hits'] = [$hits[0], '>'];
                }
            } else {
                $t = explode(' ', $hits);
                if (count($t) > 1) {
                    $where['vod_hits'] = [$t[0], $t[1]];
                } else {
                    $where['vod_hits'] = [$t, '>'];
                }
            }
        }

        //分页
        $paramUrl = Helper::request()->getRequestParam();

        $pageurl = !empty($param['pageurl']) ? $param['pageurl'] : 'vod/type';
        $wherelike=[];
        if (!empty($param['paging']) && $param['paging'] === 'yes') {
            // 分页，检测所有过来的接收值
            if (!empty($paramUrl['wd'])) {
                $wherelike[] = ['vod_title','like',"%".$paramUrl['wd']."%" ];
            }
            $param['by'] = !empty($paramUrl['by']) ? $paramUrl['by'] : $param['by'];
            $param['order'] = !empty($paramUrl['order']) ? $paramUrl['order'] : $param['order'];
            $page = !empty($paramUrl['page']) ? (int)$paramUrl['page'] : $page;
            // 推荐等级
            if (!empty($paramUrl['level'])) {
                $level = $paramUrl['level'];
                if (is_string($level)) $w = explode(',', $level);
                elseif (is_array($level)) $w = $level;
                else $w = [1, 2, 3, 4, 5, 6, 7, 8, 9];
                $where['vod_star'] = [$w, 'in'];
            }
            // 指定地区
            if (!empty($paramUrl['area'])) {
                $where['vod_area'] = [explode(',', $paramUrl['area']), 'in'];
            }
            // 语言
            if (!empty($paramUrl['lang'])) {
                $where['vod_lang'] = [explode(',', $paramUrl['lang']), 'in'];
            }
            if (!empty($paramUrl['class'])) {
                $where['vod_class'] = $paramUrl['class'];
            }
            // 年份
            if (!empty($paramUrl['year'])) {
                $year = $paramUrl['year'];
                if (strlen($year) === 9) {
                    $s = (int)substr($year, 0, 4);
                    $e = (int)substr($year, 5, 4);
                    $s1 = $s;
                    $e1 = $e;
                    if ($s > $e) {
                        $s1 = (int)$e;
                        $e1 = (int)$s;
                    }
                    $tmp = [];
                    for ($i = $s1; $i <= $e1; $i++) {
                        $tmp[] = $i;
                    }
                    $y = implode(',', $tmp);
                } else {
                    $y = $year;
                }
                $where['vod_year'] = [explode(',', $y), 'in'];
            }
            if (!empty($paramUrl['letter'])) {
                $where['vod_letter'] = $paramUrl['letter'];
            }
            if (!empty($paramUrl['actor'])) {
                $where['vod_actor'] = $paramUrl['actor'];
            }
            if (!empty($paramUrl['director'])) {
                $where['vod_director'] = $paramUrl['director'];
            }
            foreach ($where as $k => $v) {
                if (empty($v)) {
                    unset($where[$k]);
                }
            }
            $paramUrl['page'] = 'PAGELINK';
            if ($pageurl === 'vod/type' || $pageurl === 'vod/show') {
                $typeid = (int)Helper::request()->getRequestParam('type_id');
                $typeList = Helper::request()->getRequestParam('typeList');

                $typeInfo = $typeList['data'][$typeid] ?: [];
                $flag = $pageurl === 'vod/show' ? 'show' : 'type';
                //$pageurl = Common::ray_url_type($typeInfo, $paramUrl, $flag);
            } else {
                //$pageurl = Common::ray_url($pageurl, $paramUrl);
            }
        }


        $by = !empty($param['by']) && in_array($param['by'], ['id', 'sort', 'addtime', 'cid', 'hits', 'hits_day', 'hits_week', 'hits_month', 'star', 'pubdate', 'year']) ? $param['by'] : 'id';
        $order = !empty($param['order']) && in_array($param['order'], ['desc', 'asc']) ? strtoupper($param['order']) : 'DESC';
        if ($by === 'rnd') {
            $data_count = Db::name('vod')->where($where)->where($wherelike)->count('*');
            $page_total = floor($data_count / $param['num']) + 1;
            if ($data_count < $param['num']) {
                $param['num'] = $data_count;
            }
            $randi = @random_int(1, $page_total);
            $page = $randi;
            $by = 'hits_week';
            $order = 'desc';
        }
        $by = 'vod_' . $by;
        $where['vod_status'] = 1;
        $half = (int)abs(!empty($param['half']) ? $param['half'] : 0);
        //$cacheTime = isset($param['cachetime']) ? (int)$param['cachetime'] : null;

        $total = Db::name('vod')->where($where)->where($wherelike)->count();
        $field = !empty($param['field']) ? '*' : 'vod_id,type_id,vod_title,vod_letter,vod_star,vod_director,vod_actor,vod_actor_val,vod_total,vod_remarks,vod_score,vod_serial,vod_content,vod_duration,vod_pubdate,vod_class,vod_year,vod_area,vod_lang,vod_play_from,vod_play_server,vod_status,vod_hits,vod_hits_day,vod_hits_week,vod_hits_month,vod_color,vod_pic,vod_pic_thumb,vod_jumpurl,vod_jumpstatus,vod_sort,vod_addtime';

        //$resX = $this->getCacheList('VOD-MODEL-DATA', $where, $by, $order, $field, $page, $number, $start, $cacheTime)['data'];
        $result['page'] = $page;
        $result['pagecount'] = ceil($total / $number);
        //$result['pageurl'] = $pageurl;
        $result['half'] = $half;
        $result['limit'] = $number;
        $result['total'] = $total;
        //$result['data'] = $resX;

        //$page=self::ray_page_param($total,$number,$page,'vod/type',$half);

        $result['data']=Db::name('vod')
            ->where($where)
            ->where($wherelike)
            ->field($field)
            ->order($by,$order)
            ->limit(2)
            ->select()
            ->toArray();
        $result['page'] = $this->page_param($total,$number,$page,'index/index/aa',$half);

        return $result;

    }

    public function page_param($record_total, $page_size, $page_current, $page_url, $page_half = 5): array
    {
        $page_param = array();
        $page_num = array();

        if ($record_total === 0) {
            return ['record_total' => 0];
        }
        if (empty($page_half)) {
            $page_half = 5;
        }

        $page_param['record_total'] = $record_total;
        $page_param['page_current'] = $page_current;

        $page_total = $page_size > 0 ? ceil($record_total / $page_size) : 0;
        $page_param['page_total'] = $page_total;
        $page_param['page_sp'] = '_';

        $page_prev = $page_current - 1;
        if ($page_prev <= 0) {
            $page_prev = 1;
        }
        $page_next = $page_current + 1;
        if ($page_next > $page_total) {
            $page_next = $page_total;
        }
        $page_param['page_prev'] = $page_prev;
        $page_param['page_next'] = $page_next;

        if ($page_total <= $page_half) {
            for ($i = 1; $i <= $page_total; $i++) {
                $page_num[$i] = $i;
            }
        } else {
            $page_num_left = floor($page_half / 2);
            $page_num_right = $page_total - $page_half;

            if ($page_current <= $page_num_left) {
                for ($i = 1; $i <= $page_half; $i++) {
                    $page_num[$i] = $i;
                }
            } elseif ($page_current > $page_num_right) {
                for ($i = ($page_num_right + 1); $i <= $page_total; $i++) {
                    $page_num[$i] = $i;
                }
            } else {
                for ($i = ($page_current - $page_num_left); $i <= ($page_current + $page_num_left); $i++) {
                    $page_num[$i] = $i;
                }
            }
        }
        $page_param['page_num'] = $page_num;
        $page_param['page_url'] = Helper::url($page_url, ['pg'=>$this->request()->getQueryParam('pg')+1]+$this->request()->getQueryParams());
        return $page_param;
    }


}