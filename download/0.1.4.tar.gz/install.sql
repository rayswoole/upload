SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


DROP TABLE IF EXISTS `ray_actor`;
CREATE TABLE IF NOT EXISTS `ray_actor` (
  `actor_id` int(10) unsigned NOT NULL,
  `actor_name` varchar(255) NOT NULL DEFAULT '' COMMENT '演员名称',
  `actor_type_id` int(4) NOT NULL COMMENT '演员分类',
  `actor_en` varchar(255) NOT NULL DEFAULT '' COMMENT '演员英文名称',
  `actor_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '演员别名',
  `actor_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '审核状态',
  `actor_letter` char(1) NOT NULL DEFAULT '' COMMENT '首字母',
  `actor_sex` char(1) NOT NULL DEFAULT '' COMMENT '性别',
  `actor_color` varchar(6) NOT NULL DEFAULT '' COMMENT '文字颜色',
  `actor_pic` varchar(255) NOT NULL DEFAULT '' COMMENT '演员图片',
  `actor_blurb` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `actor_remarks` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `actor_area` varchar(20) NOT NULL DEFAULT '' COMMENT '地区',
  `actor_height` varchar(10) NOT NULL DEFAULT '' COMMENT '身高',
  `actor_weight` varchar(10) NOT NULL DEFAULT '' COMMENT '体重',
  `actor_cup` varchar(1) NOT NULL DEFAULT '' COMMENT '罩杯',
  `actor_bust` varchar(10) NOT NULL DEFAULT '' COMMENT '胸围',
  `actor_waist` varchar(10) NOT NULL DEFAULT '' COMMENT '腰围',
  `actor_hips` varchar(10) NOT NULL DEFAULT '' COMMENT '臀围',
  `actor_birthday` varchar(10) NOT NULL DEFAULT '' COMMENT '生日',
  `actor_place` varchar(20) NOT NULL DEFAULT '' COMMENT '出生地',
  `actor_blood` varchar(10) NOT NULL DEFAULT '' COMMENT '血型',
  `actor_starsign` varchar(10) NOT NULL DEFAULT '' COMMENT '星座',
  `actor_works` varchar(255) NOT NULL DEFAULT '' COMMENT '代表作',
  `actor_star` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '推荐等级',
  `actor_hits` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '总人其',
  `actor_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '日人气',
  `actor_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '周人气',
  `actor_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '月人气',
  `actor_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `actor_sort` int(10) unsigned NOT NULL COMMENT '排序',
  `actor_content` text NOT NULL COMMENT '内容',
  `actor_addtime` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='演员表';

DROP TABLE IF EXISTS `ray_actor_vod`;
CREATE TABLE IF NOT EXISTS `ray_actor_vod` (
  `id` int(11) NOT NULL,
  `actor_id` int(11) NOT NULL COMMENT '演员id',
  `vod_id` int(11) NOT NULL COMMENT '电影id',
  `actor_name` varchar(255) NOT NULL COMMENT '演员名',
  `vod_name` varchar(255) NOT NULL COMMENT '电影名'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='演员与视频映射表';

DROP TABLE IF EXISTS `ray_admin`;
CREATE TABLE IF NOT EXISTS `ray_admin` (
  `id` int(10) unsigned NOT NULL,
  `group` int(10) NOT NULL DEFAULT '1' COMMENT '分组',
  `account` varchar(255) NOT NULL DEFAULT '' COMMENT '账号',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  `nickname` varchar(255) NOT NULL DEFAULT '' COMMENT '昵称',
  `qq` varchar(255) NOT NULL DEFAULT '' COMMENT 'qq',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '邮箱',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '账号状态',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `logintime` int(10) DEFAULT '0' COMMENT '最后登陆时间'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `ray_ads`;
CREATE TABLE IF NOT EXISTS `ray_ads` (
  `ad_id` int(4) NOT NULL,
  `site_id` varchar(4) NOT NULL COMMENT '关联站点',
  `ad_title` varchar(255) NOT NULL COMMENT '广告名称',
  `ad_posit` varchar(100) NOT NULL COMMENT '广告位置',
  `ad_pic` varchar(255) NOT NULL COMMENT '广告图片一',
  `ad_pic2` varchar(255) NOT NULL COMMENT '广告图片二',
  `ad_pic3` varchar(255) NOT NULL COMMENT '广告图片三',
  `ad_words` varchar(255) NOT NULL COMMENT '广告文字一',
  `ad_words2` varchar(255) NOT NULL COMMENT '广告文字二',
  `ad_words3` varchar(255) NOT NULL COMMENT '广告文字三',
  `ad_jump_url` varchar(255) NOT NULL COMMENT '跳转链接',
  `ad_end_time` varchar(50) NOT NULL COMMENT '到期时间日期格式',
  `ad_status` tinyint(1) NOT NULL COMMENT '广告状态',
  `ad_sort` int(4) NOT NULL COMMENT '排序',
  `ad_addtime` int(10) NOT NULL COMMENT '添加时间',
  `ad_updatetime` int(10) NOT NULL COMMENT '修改时间'
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `ray_ads` (`ad_id`, `site_id`, `ad_title`, `ad_posit`, `ad_pic`, `ad_pic2`, `ad_pic3`, `ad_words`, `ad_words2`, `ad_words3`, `ad_jump_url`, `ad_end_time`, `ad_status`, `ad_sort`, `ad_addtime`, `ad_updatetime`) VALUES
(1, '1', 'CROCS', '顶部中间位', '/static/upload/advertising/image/60/93/6093bcfad284e0d12e846323189fddd5.png', '/static/upload/ads/image/2020-10-13/5f8583d42a36f3.62236173201908191566184481.jpg', '/static/upload/ads/image/2020-10-13/5f8583d6bdc965.724094643.jpg', '3', '4', '5', '', '2020-07-30', 1, 5, 1594108885, 0),
(12, '1', '大众', '顶部中间位', '/static/upload/advertising/image/89/26/89261c82150a11c2f6f3227c3766022d.png', '', '', '文字一内容', '文字二内容', '文字三内容', '', '2020-11-30', 1, 3, 0, 0),
(13, '1', '英雄联盟', '顶部中间位', '/static/upload/advertising/image/da/21/da216e3bae7890721f1247b408dff6ec.png', '', '', '文字一标题说明', '文字二seo优化altt', '文字三内容可根据需求自定', 'http://www.xxx.com', '2020-11-26', 1, 4, 0, 0),
(14, '1', 'CATALO', '顶部中间位', '/static/upload/advertising/image/11/4b/114b350fba0356dde5cdd8c39ba4b381.png', '', '', '11', '11', '1', '', '2020-11-30', 0, 0, 0, 0);

DROP TABLE IF EXISTS `ray_ad_posit`;
CREATE TABLE IF NOT EXISTS `ray_ad_posit` (
  `posit_id` int(4) NOT NULL,
  `posit_ssid` varchar(100) NOT NULL COMMENT '广告位标识',
  `posit_ad` varchar(100) NOT NULL COMMENT '广告位置名称',
  `posit_addtime` int(10) NOT NULL COMMENT '添加时间'
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

INSERT INTO `ray_ad_posit` (`posit_id`, `posit_ssid`, `posit_ad`, `posit_addtime`) VALUES
(7, 'slide', '幻灯片', 1605520330),
(12, 'center', '内容中部', 1605520278),
(13, 'top_center', '顶部中间位', 1605520233);

DROP TABLE IF EXISTS `ray_art`;
CREATE TABLE IF NOT EXISTS `ray_art` (
  `art_id` int(10) unsigned NOT NULL,
  `type_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属栏目',
  `art_title` varchar(255) NOT NULL DEFAULT '' COMMENT '文章标题',
  `art_sub` varchar(255) NOT NULL DEFAULT '' COMMENT '副标题',
  `art_star` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '推荐等级',
  `art_author` varchar(255) NOT NULL DEFAULT '' COMMENT '作者',
  `art_from` varchar(255) NOT NULL DEFAULT '' COMMENT '来源',
  `art_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '审核状态',
  `art_hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总人气',
  `art_hits_day` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日人气',
  `art_hits_week` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '周人气',
  `art_hits_month` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '月人气',
  `art_color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `art_content` mediumtext NOT NULL COMMENT '文章内容',
  `art_pic` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `art_pic_thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图',
  `art_blurb` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `art_jumpurl` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转地址',
  `art_jumpstatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '启用跳转',
  `art_sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `art_addtime` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间'
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COMMENT='文章表';

INSERT INTO `ray_art` (`art_id`, `type_id`, `art_title`, `art_sub`, `art_star`, `art_author`, `art_from`, `art_status`, `art_hits`, `art_hits_day`, `art_hits_week`, `art_hits_month`, `art_color`, `art_content`, `art_pic`, `art_pic_thumb`, `art_blurb`, `art_jumpurl`, `art_jumpstatus`, `art_sort`, `art_addtime`) VALUES
(1, 55, '本届纽约电影节9.25举行 《法式告别》担任开幕片', '', 1, 'admin', '网络', 0, 3564, 594, 1188, 1782, '#1c99f9', '<p><strong>1905电影网讯 </strong>日前，由<a href=\\"http://www.1905.com/mdb/star/5997/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"5997\\">米歇尔·菲佛</a>、<a href=\\"http://www.1905.com/mdb/star/2683729/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"2683729\\">卢卡斯·赫奇斯</a>、<a href=\\"http://www.1905.com/mdb/star/1413806/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"1413806\\">崔西·莱茨</a>主演的超现实喜剧片<a href=\\"https://www.1905.com/mdb/film/2253470/?fr=wwwfilm_news_xgdy_1_201411\\" target=\\"_blank\\">《法式告别》</a>宣布，将担任今年第58届纽约电影节的开幕片，这同时也是该片的世界首映。</p><p><br></p><p>本片由<a href=\\"http://www.1905.com/mdb/star/1340231/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"1340231\\">阿扎泽·雅各布斯</a>执导，改编自帕特里克·德维特的同名小说，讲述落魄的社交名媛与和她一起搬去巴黎的儿子，及已故丈夫（那只黑猫）之间的故事。菲佛饰演60岁的曼哈顿社交名媛弗朗西丝·普莱斯，赫奇斯饰演她没有人生方向的儿子马尔科姆，而她已故多年的丈夫富兰克林的化身——猫，将由莱茨担任配音。</p><p><br></p><p>影片在蒙特利尔和巴黎取景拍摄。索尼已在开拍前拿下了中国、美国、英国、德国、法国、意大利、日本等多国的发行权。北美有望在今年公映该片，但档期暂未公布。<br></p><p><br></p><p>据悉，本届纽约电影节将于9月25日开幕，受疫情影响，将以室外放映和线上放映相结合的方式举行。</p><p><img src=\\"/static/upload/art/image/d7/52/d752ebefae626ce6fb3c8dc82036011f.jpg\\" alt=\\"undefined\\"><br></p>', '/static/upload/article/image/2020-11-07/5fa649a4d873b0.79153162已过期.png', '/static/upload/article/thumb/2020-11-07/5fa649a7a2ed70.51480979已过期.png', '1905电影网讯 日前，由米歇尔·菲佛、卢卡斯·赫奇斯、崔西·莱茨主演的超现实喜剧片《法式告别》宣布，将担任今年第58届纽约电影节的开幕片，这同时也是该片的世界首映。', '', 0, 1, 1607150478),
(2, 59, '《极限父子》8月11日登陆院线 热血引燃暑期档', '', 1, '', '', 1, 3468, 578, 1156, 1734, '', '<p><strong>1905电影网讯&nbsp;</strong>电影<a href=\\"https://www.1905.com/mdb/film/2253859/?fr=mdbypk_zp\\" target=\\"_blank\\" class=\\"pl05 pr05\\" data-type=\\"picture\\" data-id=\\"2253859\\">《极限父子》</a>8月11日已登录全国各大院线，正式上映。片中拳拳到肉、燃爆街头的动作戏瞬间点燃了观众们的热情，而隐藏在动作戏背后的灵异事件、隐秘往事更是极大的引起了观众们走进电影院的欲望。观众们将在这个盛夏通过电影，领略最炙热的黑帮故事与父子深情。</p><p><br></p><p><img src=\\"https://image11.m1905.cn/uploadfile/2020/0812/20200812023244488186.jpg\\" title=\\"\\" alt=\\"\\" width=\\"660\\" vspace=\\"0\\" height=\\"440\\" border=\\"0\\"></p><p><br></p><p><strong>&nbsp;热血动作戏燃爆暑期档</strong></p><p><br></p><p>&nbsp;犀利挥舞着的棍棒，热血高声的呐喊，男主人公站在人群中以一敌百，气势丝毫没有败下阵来。凌厉的剪辑，连贯的节奏，片中的动作戏一招一式都透着“快、准、狠”。尽管被重重包围在人群中，主人公依然身形坚定，神情自如。似乎面前的危机对他来说只不过是小场面，分分钟就可以摆平。然而一个女人的出现却让场面上的局势出现逆转，她究竟是什么身份，又为何倒在了主人公的怀中，让他愧疚到难以自持？影片既展现了今夏暑期档荷尔蒙爆棚的动作戏，又为观众们留下了一个个难以破解的谜团。这背后到底藏着什么隐秘而深情的故事，还需要观众们走进电影院一探究竟。</p><p><br></p><p><img src=\\"https://image11.m1905.cn/uploadfile/2020/0812/20200812023244546582.jpg\\" title=\\"\\" alt=\\"\\" width=\\"660\\" vspace=\\"0\\" height=\\"440\\" border=\\"0\\"></p><p><br></p><p><strong>&nbsp;灵魂互换解开身世之谜</strong></p><p><br></p><p>&nbsp;一个神秘的宝盒，成为了影片中解开所有谜题的关键。原本它只是一个摆放在家中的普通木盒，儿子偶然的发现，引发了父子激烈的争抢。这一抢不要紧，居然抢走了对方的灵魂。父亲的灵魂穿越到儿子的身体中，从街头黑帮变成了街舞少年，儿子的灵魂则来到了父亲的身体中。从爆笑的乌龙事件，到命运女神的不断启迪，老爸慢慢了解到谁是身边真正关心自己的人，而儿子通过老爸的身体，逐渐挖掘出了母亲当年遇害的秘密。观众朋友们不妨也在家找找家中有没有这样同样落灰的盒子，在月黑风高的夜晚捧起它，也许你也会同主人公们一样，开启一段超越想象的异世界之旅。</p><p><br></p><p>&nbsp;《极限父子》由廖卫执导，赵凌、青婷编剧，<a href=\\"http://www.1905.com/mdb/star/3003325/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"3003325\\">李泰延</a>、<a href=\\"http://www.1905.com/mdb/star/3007611/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"3007611\\">李欣聪</a>、徐文浩、郑梦雪、&nbsp;彭博、袁骁、贺帅杰等主演。影片已于2020年8月11日全国公映！</p>', '/static/upload/article/image/2020-08-12/5f339d0633bec3.7322769220200812023244488186.jpg', '/static/upload/article/thumb/2020-08-12/5f339d09131666.8114332120200812023244488186.jpg', '1905电影网讯 电影《极限父子》8月11日已登录全国各大院线，正式上映。片中拳拳到肉、燃爆街头的动作戏瞬间点燃了观众们的热情，而隐藏在动作戏背后的灵异事件、隐秘往事更是极大的引起了观众们走进电影院的欲望。观众们将在这个盛夏通过电影，领略最炙热的黑帮故事与父子深情。', '', 0, 0, 1606210406),
(3, 55, '三毛电影侵权事件再升级 版权方:用法律途径维权', '', 1, '', '', 1, 3936, 656, 1312, 1968, '', '<p><strong>1905电影网讯 </strong>作家三毛的作品和传奇的经历影响了一代人，她的故事被搬上大银幕，是很多观众期待看到的。早前，三毛电影改编权所有方凤凰传奇影业曾发布正在筹备三毛电影《撒哈拉》的消息，备受期待。近日，却有另一部三毛电影突然闯入人们视野：由<a href=\\"http://www.1905.com/mdb/star/606/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"606\\">刘晓庆</a>监制、主演的电影《流浪的三毛》将于9月开机。</p><p>凤凰传奇影业第一时间同三毛家人、三毛作品版权独家代理公司联合发布声明，强调凤凰传奇影业是全球唯一获得三毛影视改编权的独家版权方，任何就三毛生平及三毛著作进行改编的影视作品均是严重侵权，侵权项目应立即停止融资、筹备、拍摄等行为。8月11日，该事件再度升级，凤凰传奇影业发布律师函，称侵权事件已安排律师团介入。</p><p>期间，有媒体联系到《流浪的三毛》制片人马力、《流浪的三毛》监制及主演刘晓庆方求证回应。马力表示，目前人在国外，不清楚具体情况。刘晓庆经纪人易先生则称，制片部门后续会处理此事，项目是确实存在的。两方均表示他们的初衷是出于对三毛的喜爱，目前情况还在沟通协调之中。</p><p><br></p><p>三毛家人此前在接受媒体采访时也表示，《流浪的三毛》这个项目是“无稽之谈”，并申明除了凤凰传奇影业，从未授权其他公司，并且在合约期间不会再授权别的公司拍摄三毛的生平电影，会委托北京的律师专门处理此事。</p><p><br></p>', '/static/upload/article/image/2020-08-12/5f339d819c7166.9947141234.png', '', '1905电影网讯 作家三毛的作品和传奇的经历影响了一代人，她的故事被搬上大银幕，是很多观众期待看到的。早前，三毛电影改编权所有方凤凰传奇影业曾发布正在筹备三毛电影《撒哈拉》的消息，备受期待。近日，却有另一部三毛电影突然闯入人们视野：由刘晓庆监制、主演的电影《流浪的三毛》将于9月开机。', '', 0, 0, 1606210410),
(4, 59, '新《绝地战警》曝硬核看点视频 史皇花式飙车漂移', '', 1, '', '', 1, 4326, 721, 1442, 2163, '', '<p>作为本周唯一的好莱坞新片，预售现正火爆进行中。电影由“史皇”<a href=\\"http://www.1905.com/mdb/star/1125/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"1125\\">威尔·史密斯</a>、<a href=\\"http://www.1905.com/mdb/star/4239/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"4239\\">马丁·劳伦斯</a>领衔主演，延续<a href=\\"http://www.1905.com/mdb/film/57383/\\" target=\\"_blank\\" class=\\"pl05 pr05\\" data-type=\\"picture\\" data-id=\\"57383\\">《变形金刚》</a>系列名导<a href=\\"http://www.1905.com/mdb/star/3350/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"3350\\">迈克尔·贝</a>爆炸美学风格，<a href=\\"http://www.1905.com/mdb/film/2120581/\\" target=\\"_blank\\" class=\\"pl05 pr05\\" data-type=\\"picture\\" data-id=\\"2120581\\">《加勒比海盗》</a>系列好莱坞金牌制片人<a href=\\"http://www.1905.com/mdb/star/1000986/\\" target=\\"_blank\\" data-type=\\"figure\\" data-id=\\"1000986\\">杰瑞·布鲁克海默</a>倾力加持，堪称暑期档最燃爆爽的好莱坞动作商业大片。</p><p><br></p><p><strong>2020年度全球票房冠军点燃暑期档&nbsp;</strong></p><p><strong>本周唯一好莱坞新片备受期待</strong></p><p><br></p><p>《绝地战警：疾速追击》电影自北美上映以来口碑便刷爆全网，CinemaScore观众评分为A等级，烂番茄最新的观众喜爱指数始终保持在96%以上，成为北美2020年开年至今烂番茄观众喜爱指数排名第一的电影。截止目前北美收获2.04亿美金票房，全球票房收获超4.19亿美金，不仅创下了动作喜剧类系列电影的全球票房新纪录，同时也是2020年开年至今全球及北美电影票房冠军</p>', '/static/upload/article/image/2020-08-12/5f339dc9465243.7790625320200812112325397038.jpg', '', '1905电影网讯 好莱坞动作警匪电影《绝地战警：疾速追击》将于8月14日全国上映，近日，片方发布一款风格新颖，剪辑节奏动感十足的硬核看点视频，花式飙车、火海逃生、硬刚直升机等硬核动作戏一应俱全。', '', 0, 0, 1606210414),
(5, 55, '纪念上映十周年！《盗梦空间》曝新版预告片海报', '', 1, '', '', 1, 3534, 589, 1178, 1767, '', '<p>8月12日，影片发布“奇境再续”版全新预告及海报，震撼再现失重激战、楼宇折叠、静态爆破等梦境奇观，时隔十年再看依旧令人瞠目结舌。最为惊喜的是，预告结尾还曝出诺兰最新力作《信条》的炸裂画面。</p><p><br></p><table align=\\"center\\" class=\\"layui-table\\"><tbody><tr class=\\"firstRow\\"><td><img src=\\"https://image11.m1905.cn/uploadfile/2020/0812/20200812104513375940.jpg\\"></td></tr><tr><td style=\\"text-align: center;\\"><span class=\\"table-img-alt\\">盗梦之旅惊险不断高能战斗场面频出</span></td></tr></tbody></table><p><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;《盗梦空间》“奇境再续”版海报唤醒人们对旋转走廊失重激战经典场面的记忆，而新曝光的预告更是瞬间带人们重回十年前颠覆想象的奇绝梦境。层层嵌套的梦中梦天马行空，就在筑梦师一念之间，楼宇街区顷刻翻转折叠，平地之上桥梁凭空而起。电影中高潮奇观层出不穷，很多令人至今仍念念不忘，前一秒还在街边咖啡馆聊天，后一秒沿街店铺静态爆炸，物品漫天喷射恍若烟花。</p>', '/static/upload/article/image/2020-08-12/5f339e20ec0a60.2057165020200812104513375940.jpg', '/static/upload/article/thumb/2020-08-12/5f339e233a3d45.3279280020200812104513375940.jpg', '1905电影网讯 传奇导演克里斯托弗·诺兰执导的科幻烧脑经典巨制《盗梦空间》即将于8月28日重映，这部高分神作十年后回归银幕，全面引爆粉丝及影迷狂欢。', '', 0, 0, 1606210421),
(6, 59, '影院上座率限制调宽至50% 上海成都等地已获通知', '', 1, '', '', 1, 4086, 681, 1362, 2043, '', '<p>近日有消息称，自本周末起，全国部分省市电影院上座率限制将放宽至50%，经多家媒体求证，成都的各大影院确认已经收到相关通知。随后，山东和上海也确认本周五起电影院的上座率限制将放宽至50%，并对此前规定的“影片时长超过两小时设置中场休息时间”作调整。</p><p><br></p><p>据悉，影院接到的具体通知内容为：从8月14日（本周五）起，一、影院上座率从30%提高到50%；二、观看片长超过两小时影片，无需中场暂停休息；三、适当延长场间休息时间，做好通风消毒；四、影院可以售卖饮品，但影院内禁止饮水和进食。</p><p><br></p><p>由此看来，观众可以一气呵成地完整观看即将上映的<a href=\\"http://www.1905.com/mdb/film/53013/\\" target=\\"_blank\\" class=\\"pl05 pr05\\" data-type=\\"picture\\" data-id=\\"53013\\">《哈利·波特与魔法石》</a>（152分钟）、<a href=\\"http://www.1905.com/mdb/film/2234131/\\" target=\\"_blank\\" class=\\"pl05 pr05\\" data-type=\\"picture\\" data-id=\\"2234131\\">《八佰》</a>（147分钟）等影片，这对于广大影迷来说无疑是一个好消息。</p>', '/static/upload/article/image/2020-08-12/5f339e6bd51e77.9716323320200812102244674292_watermark.jpg', '', '1905电影网讯 自7月20日电影院陆续复工起，影院一直严格遵循上座率维持在30%以下的规定。但随着越来越多的佳片定档，30%的上座率已经难以满足影院复工的热度与观众的观影热情。', '', 0, 0, 1606210428),
(7, 17, '《乔乔的异想世界》暖心治愈 用温情揭露残酷战争', '', 1, '', '', 1, 4992, 832, 1664, 2496, '', '<p>“战争题材影片+儿童视角”的叙事模式早已屡见不鲜，如<a href="http://www.1905.com/mdb/film/1971193/" target="_blank" class="pl05 pr05" data-type="picture" data-id="1971193">《美丽人生》</a><a href="http://www.1905.com/mdb/film/62907/" target="_blank" class="pl05 pr05" data-type="picture" data-id="62907">《穿条纹睡衣的男孩》</a>等。儿童视角往往是希望、善良和正义等的代名词，究其根本，无非是因为儿童的价值观尚未成型，他们做出的选择往往出于人性中善良的本能。因此，当儿童的纯真无邪与战争的伤痕累累相结合，往往能够强烈地表达对真善美的追求，以及对和平年代的珍视、对战争的反思与憎恶。</p><p><br></p><p>兔子作为一个符号化的形象，在《乔乔的异想世界》中起着突出人物性格、回扣故事主题的双重作用。从本片的英文名“Jojo\n \nRabbit”可以看出，兔子其实便象征着乔乔。当纳粹少年班班长用戏谑的语调布置杀死小兔子的任务时，乔乔选择将小兔子放生。这一情节是影片中第一次直接体现乔乔与纳粹党价值观的对立，凸显了乔乔人性中最纯真的善良。也正因为如此，乔乔被众人戏称为“乔乔兔”。这种象征，一直延续到后来乔乔与埃尔莎的关系中。乔乔在与埃尔莎相处的过程中，同样面临着“杀兔”的困境。两段相似的叙事，使得影片结构更加紧凑，主题得到由浅及深的升华。</p><p><br></p><p>乔乔有一个幻想的朋友希特勒，他与假想朋友之间的“友情”是贯穿全片的线索，不仅是剧情发展的主线，也是反映本片主旨的关键。两人的“友情”分为几个不同的阶段，从最初乔乔对元首的痴迷，到最后毅然与元首决裂，整个过程其实也是乔乔追求自由与爱，以及自我救赎的成长历程。这个幻想中的“朋友”，是他的人生导师、精神领袖，时时刻刻伴其左右，鼓励他，指引他，去做一些危险且疯狂的事情。</p><p><br></p><p><img src="https://image11.m1905.cn/uploadfile/2020/0811/20200811025809335040.jpg" title="" alt="" width="660" vspace="0" height="438" border="0"></p><p><br></p><p>法国精神分析学家雅克·拉康曾指出：“每一种混淆现实与想象的情况都能构成镜像体验，为个体与世界的想象关系提供了一个独特的视角，对于理解观众与影片的相互关系，观影心理机制和电影影像机制的相似性具有本质的意义。”其实，这位幻想中的“朋友”便是乔乔对欲望的投射。换句话说，幻想的出现是因为乔乔期盼生活中有一个男性的陪伴，来弥补他缺失的父爱，并教他如何成长为一个优秀的男人。影片最后，乔乔与这位“朋友”在某些问题上发生分歧，其实是因为乔乔已经具有了独立的价值观，有勇气挑战甚至推翻自己心目中父权的形象。这象征着乔乔的彻底成长。</p><p><br></p><p>在乔乔的成长过程中，两个女性角色起着举足轻重的作用，一个是由<a href="https://www.1905.com/mdb/star/1820/?fr=mdbypsy_zy" target="_blank">斯嘉丽·约翰逊</a>扮演的母亲罗西，另一个是充满张力的犹太女孩埃尔莎。母亲罗西是一位在战争期间失去丈夫和女儿的女性，温柔坚韧、乐观俏皮，用聪慧善良、勇敢无畏的品质引导着乔乔。当乔乔因意外在少年班中受挫，罗西便带着儿子在街边散步，在草坪中跳起象征自由的舞蹈。罗西会告诉乔乔爱的力量，也会在绞刑架前培养乔乔直面残酷现实的勇气，让他明白治愈残酷世界，唯有爱与包容。在乱世中，她有一颗温暖的心，教会儿子热爱并敬重生命，可谓开启乔乔内心世界的一把钥匙。</p><p><br></p><p>初识犹太女孩埃尔莎时，乔乔受到纳粹思潮的严重影响，对她有着很大的种族偏见。随着日复一日的朝夕相处，他们从争吵过招、斗智斗勇，慢慢转变为平等交谈、互诉心事。乔乔发现，埃尔莎的智慧、勇敢与自己的认知发生了冲突，甚至对她产生了爱慕之情。在那个纷乱的年代、孤独的童年，埃尔莎让乔乔无聊的生活多了一抹亮色。她的出现，使得乔乔对犹太人的态度发生根本改变，促使他形成了独立的价值观，是他探寻精神世界的一道云梯。</p><p><br></p><p>除人物塑造之外，本片在视听语言方面也颇有特色。影片中的色调，呈现出冷与暖两种不同的风格。当乔乔与母亲和朋友享受着亲情、友情带来的温暖时，影片的色调大多呈暖黄色，以中景和近景的景别来凸显人物内心的喜悦之情，渲染出温馨的氛围。而突出战争无情时，影片会呈现出灰蓝色调。</p><p><br></p><p>总而言之，《乔乔的异想世界》用儿童视角讲述了一个温情满满的少年成长故事。当乔乔放下种族偏见与埃尔莎互诉衷肠，当乔乔目睹了母亲的遭遇、经历过战火纷飞后，他彻底走出了幻想的世界，迎接他的是无比残酷的现实生活。但那又何妨？因为乔乔已经获得了思想上的自由。乔乔曾经问埃尔莎：“等你自由后你第一件事要做什么？”埃尔莎毫不犹豫地回答：“跳舞。”在影片的最后，阳光洒满大地，两人走到大街上跳起了舞。他们终于明白，这就是爱的感觉、自由的气息。（作者\n 郝一帆）</p>', '/static/upload/article/image/2020-08-12/5f339f194400e2.4241181720200811025809503460.jpg', '', '随着国内电影院的复工，荣获第92届奥斯卡金像奖最佳剧本改编奖的影片——《乔乔的异想世界》终于得以与观众见面。影片讲述了二战时期德国一个小男孩乔乔成长的心路历程，借助儿童视角来构建故事，并以喜剧形式展现了一个悲剧性的时代，传递出寒冬中一缕阳光的温暖力量。', '', 0, 0, 1597218587),
(8, 17, '《家乡》隐藏彩蛋！贵州村民成《唐探3》首批观众', '', 1, '', '', 1, 5076, 846, 1692, 2538, '', '<p><strong>1905电影网讯</strong> 8月11日，电影《我和我的家乡》单元故事《天上掉下个UFO》曝光预告片，该单元由<a href="http://www.1905.com/mdb/star/1052/" target="_blank" data-type="figure" data-id="1052">陈思诚</a>执导。预告片中，<a href="http://www.1905.com/mdb/star/553/" target="_blank" data-type="figure" data-id="553">王宝强</a>和<a href="http://www.1905.com/mdb/star/3029970/" target="_blank" data-type="figure" data-id="3029970">刘昊然</a>这对“唐探”侦探搭档化身记者组合重出江湖，因为贵州黔南阿福村突然出现的一架神秘UFO而“下乡探案”。昔日舅甥二人熟悉的“走路带风”，搭配背景中的<a href="http://www.1905.com/mdb/film/2244528/" target="_blank" class="pl05 pr05" data-type="picture" data-id="2244528">《唐人街探案3》</a>巨幅海报，令不少网友直呼“简直就是《家乡》与《唐探3》的梦幻联动！”</p><p>除此之外，细心的网友还发现了预告片中隐藏的另一处《唐探3》彩蛋。短片开场，一群贵州村民在广场观看露天电影，而投影中的影片龙标公映许可证显示的“第850号”正是电影《唐探3》！</p><p><br></p><p>除了“唐探组合”，作为主演之一的<a href="http://www.1905.com/mdb/star/1548/" target="_blank" data-type="figure" data-id="1548">黄渤</a>也在片中贡献了一贯扎实演技，令人忍俊不禁。再加上《走近科学》带来的回忆杀，一出爆笑土味科幻喜剧的雏形已现。</p>', '/static/upload/article/image/2020-08-12/5f33a307c348f4.43193371333.jpg', '', '1905电影网讯 8月11日，电影《我和我的家乡》单元故事《天上掉下个UFO》曝光预告片，该单元由陈思诚执导。预告片中，王宝强和刘昊然这对“唐探”侦探搭档化身记者组合重出江湖，因为贵州黔南阿福村突然出现的一架神秘UFO而“下乡探案”。昔日舅甥二人熟悉的“走路带风”，搭配背景中的《唐人街探案3》巨幅海报，令不少网友直呼“简直就是《家乡》与《唐探3》的梦幻联动！”', '', 0, 0, 1597219594);

DROP TABLE IF EXISTS `ray_art_recycle`;
CREATE TABLE IF NOT EXISTS `ray_art_recycle` (
  `art_id` int(10) unsigned NOT NULL,
  `type_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属栏目',
  `art_title` varchar(255) NOT NULL DEFAULT '' COMMENT '文章标题',
  `art_sub` varchar(255) NOT NULL DEFAULT '' COMMENT '副标题',
  `art_star` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '推荐等级',
  `art_author` varchar(255) NOT NULL DEFAULT '' COMMENT '作者',
  `art_from` varchar(255) NOT NULL DEFAULT '' COMMENT '来源',
  `art_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '审核状态',
  `art_hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总人气',
  `art_hits_day` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日人气',
  `art_hits_week` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '周人气',
  `art_hits_month` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '月人气',
  `art_color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `art_content` mediumtext NOT NULL COMMENT '文章内容',
  `art_pic` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `art_pic_thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图',
  `art_blurb` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `art_jumpurl` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转地址',
  `art_jumpstatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '启用跳转',
  `art_sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `art_addtime` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文章回收站表';

DROP TABLE IF EXISTS `ray_art_type`;
CREATE TABLE IF NOT EXISTS `ray_art_type` (
  `type_id` int(11) NOT NULL,
  `type_pid` int(11) NOT NULL DEFAULT '0',
  `type_name` varchar(255) NOT NULL COMMENT '栏目标题',
  `type_sort` int(10) DEFAULT '0' COMMENT '排序',
  `type_tpl_list` varchar(255) NOT NULL DEFAULT '' COMMENT '列表模板',
  `type_tpl_detail` varchar(255) NOT NULL DEFAULT '' COMMENT '内容模板',
  `type_logo` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  `type_title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `type_keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `type_description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `type_status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '分类状态'
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COMMENT='文章分类表';

INSERT INTO `ray_art_type` (`type_id`, `type_pid`, `type_name`, `type_sort`, `type_tpl_list`, `type_tpl_detail`, `type_logo`, `type_title`, `type_keywords`, `type_description`, `type_status`) VALUES
(55, 0, '栏目名称2', 1, '', '', '', '', '', '', 1),
(59, 55, '栏目名称2', 6, '', '', 'static/upload/column_logo/22/e2/22e2bc6821bc8482418d6c27500b18ba.jpg', '', '', '', 1);

DROP TABLE IF EXISTS `ray_comment`;
CREATE TABLE IF NOT EXISTS `ray_comment` (
  `comment_id` int(11) unsigned NOT NULL COMMENT '评论id',
  `user_id` int(11) unsigned NOT NULL COMMENT '评论用户id',
  `site_id` int(11) unsigned NOT NULL COMMENT '所属站点',
  `comment_pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属评论id,初次为0',
  `comment_mid` int(11) unsigned NOT NULL COMMENT '所属模块id [1:视频2：文章...]',
  `comment_rid` int(11) unsigned NOT NULL COMMENT '所属域id',
  `comment_content` text NOT NULL COMMENT '评论内容',
  `comment_status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '评论状态，1为显示，2为禁止显示',
  `comment_level` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '评论级别，评论级别,1为首级评论,其他为回复',
  `comment_reply_cid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '被回复的id ,一级评论默认为0',
  `comment_addtime` int(10) unsigned NOT NULL COMMENT '评论时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评论表';

DROP TABLE IF EXISTS `ray_config`;
CREATE TABLE IF NOT EXISTS `ray_config` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '名称',
  `group` varchar(40) NOT NULL DEFAULT '' COMMENT '组别',
  `val` text NOT NULL COMMENT '值',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '类型'
) ENGINE=MyISAM AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb4 COMMENT='系统全局配置表';

INSERT INTO `ray_config` (`id`, `name`, `group`, `val`, `type`) VALUES
(1, 'cachemode', 'system', 'redis', 0),
(37, 'cache_mode', 'system', 'file', 3),
(38, 'soft_del', 'system', '1', 1),
(43, 'content_filter', 'system', '43', 1),
(45, 'site_name', 'site', 'Ray7内容管理系统', 3),
(46, 'site_url', 'site', 'ray7.cc', 3),
(47, 'site_pc_url', 'site', '12', 1),
(48, 'site_wap_url', 'site', 'ray7.cc', 3),
(49, 'site_keywords', 'site', '短视频,搞笑视频,视频分享,免费视频,在线视频,预告片', 3),
(50, 'site_description', 'site', '提供最新最快的视频分享数据', 3),
(51, 'site_icp', 'site', '', 3),
(52, 'site_pc_template', 'site', 'shuang11', 3),
(53, 'site_wap_template', 'site', 'shuang11', 3),
(54, 'site_notice', 'site', '', 3),
(55, 'site_tj', 'site', '', 3),
(56, 'site_copyright', 'site', '', 3),
(57, 'site_status', 'site', '1', 1),
(58, 'site_close_msg', 'site', '测试12311', 3),
(59, 'site_sort', 'site', '122', 1),
(63, 'type', 'system', 'c', 3),
(65, 'vod_extend_class', 'vod', '22,123', 3),
(66, 'vod_extend_state', 'vod', '33', 1),
(67, 'vod_extend_version', 'vod', '流畅,高清,超清,4K', 3),
(68, 'vod_extend_area', 'vod', '大陆,香港,日韩,欧美', 3),
(69, 'vod_extend_lang', 'vod', '国语,英语,粤语,韩语,日语,法语,德语,其它', 3),
(70, 'vod_extend_year', 'vod', '2020,2019,2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2007,2006,2005,2004,2003,2002,2001,2000', 3),
(71, 'vod_extend_weekday', 'vod', '一,二,三,四,五,六,日', 3),
(72, 'actor_extend_area', 'vod', '大陆,香港,台湾,美国,韩国,日本,泰国,新加坡,马来西亚,印度,英国,法国,加拿大,西班牙,俄罗斯,其它', 3),
(79, 'vod_search_hot', 'vod', '变形金刚,火影忍者,复仇者联盟,战狼,红海行动', 3),
(80, 'vod_cache_sql', 'vod', '0', 1),
(81, 'vod_cache_search', 'vod', '0', 1),
(82, 'vod_cache_index', 'vod', '0', 1),
(83, 'vod_cache_type', 'vod', '0', 1),
(84, 'vod_cache_show', 'vod', '0', 1),
(85, 'vod_cache_detail', 'vod', '0', 1),
(86, 'vod_cache_play', 'vod', '0', 1),
(87, 'site_email', 'site', 'dev@ray7.cc', 3),
(88, 'art_cache_sql', 'art', '1', 1),
(89, 'art_cache_search', 'art', '1', 1),
(90, 'art_cache_index', 'art', '1', 1),
(91, 'art_cache_type', 'art', '1', 1),
(92, 'art_cache_show', 'art', '1', 1),
(93, 'art_cache_detail', 'art', '1', 1),
(119, 'service', 'sms', 'qt', 3),
(120, 'appid', 'sms', '', 3),
(121, 'appkey', 'sms', '', 3),
(122, 'autograph', 'sms', '', 3),
(123, 'reg_temp', 'sms', '', 3),
(124, 'bind_temp', 'sms', '', 3),
(125, 'ret_temp', 'sms', '', 3),
(126, 'tip_temp', 'sms', '', 3),
(127, 'server', 'email', 'smtp.163.com', 3),
(128, 'port', 'email', '465', 1),
(129, 'account', 'email', 'test', 3),
(130, 'pwd', 'email', 'uhabijvbalib', 3),
(131, 'nickname', 'email', '名称123', 3),
(132, 'art_search_btn', 'art', '1', 1),
(133, 'art_search', 'art', '名称,拼音', 3),
(134, 'vod_search_btn', 'vod', '1', 1),
(135, 'video_search', 'vod', '名称,拼音,副标题', 3),
(136, 'cache_sid', 'system', '1', 1),
(137, 'site_defaultapp', 'site', 'Vod', 3),
(138, 'vod_encryption', 'vod', '0', 1),
(139, 'is_savepic', 'vod', '0', 1),
(157, 'logo', 'site', '/logo.jpg', 3),
(158, 'art_rewrite_status', 'art', '1', 1),
(159, 'art_rewrite_overlap', 'art', '0', 1),
(160, 'art_rewrite_suffix', 'art', '.html', 3),
(161, 'art_rewrite_rules', 'art', '{"regx":{"index":["index_{page}"],"type":["type/id/{id}/page/{page}[/{s:.+}]","type/id/{id}[/{s:.+}]"],"show":["show/id/{id}/page/{page}[/{s:.+}]","show/id/{id}[/{s:.+}]"],"detail":["detail/{id}"],"search":["search/wd/{wd}/page/{page}[/{s:.+}]","search/wd/{wd}[/{s:.+}]"]},"controller":{"index":"index/index","type":"type/index","show":"show/index","detail":"detail/index","search":"search/index"}}', 4),
(162, 'vod_rewrite_status', 'vod', '0', 1),
(163, 'vod_rewrite_overlap', 'vod', '0', 1),
(164, 'vod_rewrite_suffix', 'vod', '.html', 3),
(165, 'vod_rewrite_rules', 'vod', '{"regx":{"index":["index_{page}"],"type":["list/id/{id}/page/{page}[/{s:.+}]","list/id/{id}[/{s:.+}]"],"show":["show/id/{id}/page/{page}[/{s:.+}]","show/id/{id}[/{s:.+}]"],"detail":["detail/{id}"],"play":["play/id/{id}/sid/{sid}/nid/{nid}"],"search":["search/wd/{wd}/page/{page}[/{s:.+}]","search/wd/{wd}[/{s:.+}]"]},"controller":{"index":"index/index","type":"type/index","show":"show/index","detail":"detail/index","play":"play/index","search":"search/index"}}', 4),
(166, 'site_defaultadmin', 'site', 'qadmin', 3);

DROP TABLE IF EXISTS `ray_link`;
CREATE TABLE IF NOT EXISTS `ray_link` (
  `link_id` smallint(6) unsigned NOT NULL,
  `link_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '链接类型（图片，文字）',
  `link_name` varchar(60) NOT NULL DEFAULT '' COMMENT '名称',
  `link_sort` smallint(6) NOT NULL DEFAULT '0' COMMENT '排序',
  `link_add_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `link_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
  `link_url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `link_logo` varchar(255) NOT NULL DEFAULT '' COMMENT '图片'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `ray_link` (`link_id`, `link_type`, `link_name`, `link_sort`, `link_add_time`, `link_time`, `link_url`, `link_logo`) VALUES
(1, 2, 'ray7内容管理系统', 1, 1607503964, 0, 'https://ray7.cc', '');

DROP TABLE IF EXISTS `ray_master_level`;
CREATE TABLE IF NOT EXISTS `ray_master_level` (
  `mlv_id` int(11) unsigned NOT NULL COMMENT '主键ID',
  `mlv_name` varchar(250) NOT NULL COMMENT '等级名称',
  `mlv_status` tinyint(2) unsigned NOT NULL COMMENT '等级状态1：启用0：禁用',
  `mlv_auth` varchar(255) NOT NULL COMMENT '权限',
  `mlv_addtime` int(10) unsigned NOT NULL COMMENT '添加时间'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='站长等级表';

INSERT INTO `ray_master_level` (`mlv_id`, `mlv_name`, `mlv_status`, `mlv_auth`, `mlv_addtime`) VALUES
(1, '测试等级', 1, '{"mlv_bui_numsite":"1","mlv_dis_defads":1,"mlv_gen_reccard":"1","mlv_user_lvlayer":"1","mlv_point_num":"1"}', 1594800587),
(2, '注册站长', 1, '{"mlv_bui_numsite":"1","mlv_dis_defads":1,"mlv_gen_reccard":"1","mlv_user_lvlayer":"1","mlv_point_num":"1"}', 1594800587);

DROP TABLE IF EXISTS `ray_nav`;
CREATE TABLE IF NOT EXISTS `ray_nav` (
  `nav_id` int(10) NOT NULL,
  `nav_name` varchar(250) NOT NULL DEFAULT '''''' COMMENT '名称',
  `nav_pid` int(10) NOT NULL DEFAULT '0' COMMENT '父id',
  `nav_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型0全部1上导航2下导航',
  `nav_scope` tinyint(1) NOT NULL DEFAULT '0' COMMENT '显示范围0全部1电脑2手机',
  `nav_mod` varchar(40) NOT NULL DEFAULT '' COMMENT '所属模块',
  `nav_typeid` int(10) NOT NULL DEFAULT '0' COMMENT '模块分类',
  `nav_jumpurl` varchar(255) NOT NULL DEFAULT '''''' COMMENT '跳转地址',
  `nav_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态'
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COMMENT='导航配置表';

INSERT INTO `ray_nav` (`nav_id`, `nav_name`, `nav_pid`, `nav_type`, `nav_scope`, `nav_mod`, `nav_typeid`, `nav_jumpurl`, `nav_status`) VALUES
(44, '栏目名称2', 0, 0, 0, '2', 59, '/art/index/show?class=%E6%A0%8F%E7%9B%AE%E5%90%8D%E7%A7%B02&id=59', 1),
(43, '栏目菜单5', 0, 0, 0, '2', 58, '/art/index/show?class=%E6%A0%8F%E7%9B%AE%E8%8F%9C%E5%8D%955&id=58', 1),
(52, '123', 0, 0, 0, '2', 63, '/art/index/type?id=63', 1),
(57, '1232', 0, 0, 0, '2', 67, '/art/index/type?id=67', 1),
(56, '123', 0, 0, 0, '2', 66, '/art/index/type?id=66', 1),
(60, '123', 0, 0, 0, '2', 28, '/vod/index/type?id=28', 1);

DROP TABLE IF EXISTS `ray_node`;
CREATE TABLE IF NOT EXISTS `ray_node` (
  `node_id` int(11) unsigned NOT NULL,
  `node_name` varchar(50) NOT NULL DEFAULT '' COMMENT '权限节点名称',
  `node_path` varchar(100) NOT NULL DEFAULT '''''' COMMENT '权限路径',
  `node_class` varchar(100) NOT NULL DEFAULT '''''' COMMENT '样式CLASS',
  `node_pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属上级',
  `node_description` varchar(200) NOT NULL DEFAULT '''''' COMMENT '描述信息',
  `node_mark` varchar(50) NOT NULL DEFAULT '''''' COMMENT '对应标识',
  `node_status` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '状态 1正常0未启用',
  `node_sort` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '排序',
  `node_position` tinyint(5) unsigned NOT NULL DEFAULT '1' COMMENT '菜单位置，1为左方,2为上方，3为不显示',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间'
) ENGINE=InnoDB AUTO_INCREMENT=220 DEFAULT CHARSET=utf8 COMMENT='权限菜单节点';

INSERT INTO `ray_node` (`node_id`, `node_name`, `node_path`, `node_class`, `node_pid`, `node_description`, `node_mark`, `node_status`, `node_sort`, `node_position`, `create_time`) VALUES
(6, '系统运行参数', '', '', 12, '系统管理节点', 'SHEZHI', 1, 3, 1, 1606795179),
(7, '缓存选择', 'system/index', '', 6, '系统基本参数节点', 'SHEZHI', 1, 7, 1, 1606807606),
(8, '短信配置', 'sms/index', '', 208, '短信配置节点', '', 1, 4, 1, 1606794786),
(10, '菜单管理', 'menu/index', '', 183, '菜单管理节点', '', 1, 0, 1, 1605498882),
(11, '基本设置', 'site/index', '', 208, '站点基本参数节点', 'SHEZHI', 1, 6, 1, 1606795087),
(12, '设置', '', '', 0, '顶部设置节点', 'SHEZHI', 1, 66, 2, 1604481001),
(15, '默认广告', 'ads/index', '', 74, '默认广告节点', 'SHEZHI', 1, 0, 1, 1604476492),
(16, '登录操作', 'login/index', '', 28, '登录操作', '', 1, 0, 3, 1600409518),
(17, '验证登录', 'login/check', '', 16, '验证登录节点', '', 1, 0, 3, 1600333488),
(18, '后台首页', 'index/index', '', 28, '后台首页节点', '', 1, 0, 3, 1600409529),
(19, '欢迎页面', 'index/welcome', '', 18, '欢迎页面节点', '', 1, 0, 3, 1600759182),
(28, '公共页面', '', '', 0, '基础页面', '', 1, 0, 3, 1600741351),
(29, '退出登录', 'login/loginout', '', 16, '退出登录', '', 1, 0, 3, 1600415262),
(40, '文章', '', '', 0, '文章顶部节点', 'pS8paTrMC7Oy', 1, 55, 2, 1604480997),
(41, '文章管理', 'art@admin/index/index', '', 40, '文章管理节点', 'pS8paTrMC7Oy', 1, 2, 1, 1607072959),
(42, '文章列表', 'art@admin/index/index', '', 41, '文章列表节点', 'pS8paTrMC7Oy', 1, 2, 1, 1601261831),
(43, '添加文章', 'art@admin/index/create', '', 41, '添加文章节点', 'pS8paTrMC7Oy', 1, 1, 1, 1601261896),
(44, '编辑文章', 'art@admin/index/edit', '', 42, '编辑文章节点', '', 1, 0, 3, 1601261914),
(45, '上传图片', 'art@admin/index/upload', '', 42, '上传图片节点', '', 1, 0, 3, 1601261942),
(46, '更新文章', 'art@admin/index/update', '', 42, '更新文章节点', '', 1, 0, 3, 1601261969),
(47, '删除文章', 'art@admin/index/delete', '', 42, '删除文章节点', '', 1, 0, 3, 1601261993),
(48, '保存文章', 'art@admin/index/save', '', 42, '保存文章节点', '', 1, 0, 3, 1601262025),
(49, '文章回收站', 'art@admin/index/recycle', '', 41, '文章回收站节点', 'pS8paTrMC7Oy', 1, 1, 1, 1601262090),
(50, '删除回收站文章', 'art@admin/index/recycle_delete', '', 49, '删除回收站文章节点', '', 1, 0, 3, 1601262119),
(51, '恢复文章', 'art@admin/indexrecovery', '', 49, '恢复文章节点', '', 1, 0, 3, 1601262145),
(52, '文章数据读取', 'art@admin/index/read', '', 42, '文章数据读取节点', '', 1, 0, 3, 1601262190),
(53, '栏目管理', 'art@admin/column/index', '', 40, '栏目管理节点', 'pS8paTrMC7Oy', 1, 1, 1, 1607072976),
(54, '读取栏目数据', 'art@admin/column/read', '', 60, '读取栏目数据节点', '', 1, 0, 3, 1601262476),
(55, '创建栏目', 'art@admin/column/create', '', 53, '创建栏目节点', '', 1, 0, 3, 1601262318),
(56, '编辑栏目', 'art@admin/column/edit', '', 60, '编辑栏目节点', '', 1, 0, 3, 1601262484),
(57, '保存栏目', 'art@admin/column/save', '', 60, '保存栏目节点', '', 1, 0, 3, 1601262488),
(58, '删除栏目', 'art@admin/column/delete', '', 60, '删除栏目节点', '', 1, 0, 3, 1601262492),
(59, '更新栏目', 'art@admin/column/update', '', 60, '更新栏目节点', '', 1, 0, 3, 1601262496),
(60, '栏目列表', 'art@admin/column/index', '', 53, '栏目列表节点', 'pS8paTrMC7Oy', 1, 0, 1, 1601262470),
(61, '视频', '', '', 0, '', '5ntdImAz73TE', 1, 22, 2, 1604481014),
(62, '视频管理', 'vod@admin/index/index', '', 61, '', '5ntdImAz73TE', 1, 2, 1, 1601275664),
(63, '视频列表', 'vod@admin/index/index', '', 62, '', '5ntdImAz73TE', 1, 0, 1, 1601275711),
(64, '添加视频', 'vod@admin/index/create', '', 62, '', '5ntdImAz73TE', 1, 0, 1, 1601275770),
(65, '视频回收站', 'vod@admin/index/recycle', '', 62, '', '5ntdImAz73TE', 1, 0, 1, 1601275965),
(66, '演员库', 'vod@admin/actor/index', '', 62, '', '5ntdImAz73TE', 1, 0, 1, 1601280772),
(67, '播放器管理', 'vod@admin/index/player_ist', '', 62, '', '5ntdImAz73TE', 1, 0, 1, 1601286053),
(69, '栏目管理', 'vod@admin/type/index', '', 62, '', '5ntdImAz73TE', 1, 0, 1, 1601351404),
(70, '采集', 'vod@admin/collect/index', '', 61, '', '5ntdImAz73TE', 1, 1, 1, 1604560724),
(71, '资源管理', 'vod@admin/collect/index', '', 70, '', '5ntdImAz73TE', 1, 0, 1, 1601433772),
(72, '添加资源', 'vod@admin/collect/create', '', 70, '', '5ntdImAz73TE', 1, 0, 1, 1601363866),
(73, '广告', '', '', 0, '', '广告管理', 1, 11, 2, 1604481030),
(74, '广告管理', 'ads@admin/index/index', '', 73, '', '广告管理', 1, 0, 1, 1602487942),
(75, '广告列表', 'ads@admin/index/index', '', 74, '', '广告管理', 1, 0, 1, 1602488233),
(76, '广告位管理', 'ads@admin/index/positindex', '', 74, '', '广告管理', 1, 0, 1, 1602490978),
(77, '充值卡', 'pay@admin/card/index', '', 88, '', '', 1, 0, 1, 1606447866),
(78, '友情链接', 'link/index', '', 89, '', '', 1, 0, 1, 1604476456),
(79, '会员等级', 'user@admin/level/index', '', 88, '', 'SHEZHI', 1, 2, 1, 1604476360),
(80, '积分设置', 'user@admin/point/index', '', 88, '', 'SHEZHI', 1, 0, 1, 1604476377),
(81, '在线升级', 'update/index', '', 6, '', 'SHEZHI', 1, 1, 1, 1604139100),
(85, '会员', '', '', 0, '后台管理界面会员按钮', 'TaP62c67Vt77', 1, 22, 2, 1604481025),
(87, '其他', '', '', 0, '后台管理界面其他', '0m4bweT7R9ai', 1, 1, 2, 1605521445),
(88, '会员管理', '', '', 85, '', 'TaP62c67Vt77', 1, 0, 1, 1604481085),
(89, '其他管理', '', '', 87, '', '0m4bweT7R9ai', 1, 0, 1, 1604481095),
(94, '管理列表', 'user@admin/index/index', '', 88, '', '', 1, 3, 1, 1604477951),
(95, '添加会员', 'user@admin/index/crate', '', 94, '', '', 1, 0, 3, 1604478350),
(96, '编辑会员', 'user@admin/index/edit', '', 94, '', '', 1, 0, 3, 1604478373),
(97, '数据读取', 'user@admin/index/read', '', 94, '', '', 1, 0, 3, 1604478369),
(98, '保存会员', 'user@admin/index/save', '', 94, '', '', 1, 0, 3, 1604478365),
(99, '更新会员', 'user@admin/index/update', '', 94, '', '', 1, 0, 3, 1604478362),
(100, '删除会员', 'user@admin/index/delete', '', 94, '', '', 1, 0, 3, 1604478358),
(101, '评论管理', 'comment@admin/index/index', '', 89, '', '', 1, 0, 1, 1604479323),
(102, '读取数据', 'comment@admin/index/read', '', 101, '', '', 1, 0, 3, 1604479578),
(103, '回复评论', 'comment@admin/index/reply', '', 101, '', '', 1, 0, 3, 1604479574),
(104, '预览评论', 'comment@admin/index/show', '', 101, '', '', 1, 0, 3, 1604479569),
(105, '删除评论', 'comment@admin/index/delete', '', 101, '', '', 1, 0, 3, 1604479601),
(119, '添加菜单', 'menu/create', '', 10, '', '', 1, 0, 3, 1604479999),
(120, '编辑菜单', 'menu/edit', '', 10, '', '', 1, 0, 3, 1604480017),
(121, '更新菜单', 'menu/update', '', 10, '', '', 1, 0, 3, 1604480036),
(122, '保存菜单', 'menu/save', '', 10, '', '', 1, 0, 3, 1604480059),
(123, '删除菜单', 'menu/delete', '', 10, '', '', 1, 0, 3, 1604480073),
(125, '保存数据', 'system/save', '', 7, '', '', 1, 0, 3, 1606807913),
(126, '保存站点基本设置', 'site/save', '', 11, '', '', 1, 0, 3, 1604482544),
(127, '积分流水', 'user@admin/annal/index', '', 88, '', '', 1, 0, 1, 1604482861),
(128, '读取数据', 'user@admin/annal/read', '', 127, '', '', 1, 0, 3, 1604482907),
(129, '删除记录', 'user@admin/annal/delete', '', 127, '', '', 1, 0, 3, 1604482928),
(130, '读取数据', 'user@admin/level/read', '', 79, '', '', 1, 0, 3, 1604483058),
(131, '创建等级', 'user@admin/level/create', '', 79, '', '', 1, 0, 3, 1604483086),
(132, '编辑等级', 'user@admin/level/edit', '', 79, '', '', 1, 0, 3, 1604483108),
(133, '保存等级', 'user@admin/level/save', '', 79, '', '', 1, 0, 3, 1604483132),
(134, '更新等级', 'user@admin/level/update', '', 79, '', '', 1, 0, 3, 1604483165),
(135, '删除等级', 'user@admin/level/delete', '', 79, '', '', 1, 0, 3, 1604483188),
(136, '读取数据', 'user@admin/point/read', '', 80, '', '', 1, 0, 3, 1604483497),
(137, '添加积分', 'user@admin/point/create', '', 80, '', '', 1, 0, 3, 1604483513),
(138, '编辑积分', 'user@admin/point/edit', '', 80, '', '', 1, 0, 3, 1604483549),
(139, '保存积分', 'user@admin/point/save', '', 80, '', '', 1, 0, 3, 1604483575),
(140, '更新积分', 'user@admin/point/update', '', 80, '', '', 1, 0, 3, 1604483627),
(141, '删除积分', 'user@admin/point/delete', '', 80, '', '', 1, 0, 3, 1604483645),
(142, '升级系统', 'update/update', '', 81, '', '', 1, 1, 3, 1604485901),
(143, '添加版本', 'version/create', '', 82, '', '', 1, 1, 3, 1604486043),
(144, '找回密码', 'login/setpassword', '', 16, '', '', 1, 0, 3, 1604486084),
(145, '修改版本', 'version/edit', '', 82, '', '', 1, 1, 3, 1604486089),
(146, '删除版本', 'version/delete', '', 82, '', '', 1, 1, 3, 1604486120),
(147, '保存密码', 'login/setpassword', '', 16, '', '', 1, 0, 3, 1604486185),
(148, '读取版本', 'version/read', '', 82, '', '', 1, 1, 3, 1604486120),
(149, '保存版本', 'version/save', '', 82, '', '', 1, 1, 3, 1604486130),
(150, '添加新闻', 'version/message_create', '', 83, '', '', 1, 1, 3, 1604486388),
(151, '上传文件', 'version/upload', '', 82, '', '', 1, 1, 3, 1604486471),
(152, '修改新闻', 'version/message_info', '', 83, '', '', 1, 1, 3, 1604486398),
(153, '删除新闻', 'version/message_delete', '', 83, '', '', 1, 1, 3, 1604486398),
(154, '添加广告', 'ads/index/create', '', 75, '', '', 1, 1, 3, 1604487027),
(155, '修改广告', 'ads/index/edit', '', 75, '', '', 1, 1, 3, 1604487027),
(156, '删除广告', 'ads/index/delete', '', 75, '', '', 1, 1, 3, 1604487047),
(157, '保存广告', 'ads/index/save', '', 75, '', '', 1, 1, 3, 1604487047),
(158, '读取广告', 'ads/index/read', '', 75, '', '', 1, 1, 3, 1604487047),
(159, '上传图片', 'ads/index/upload', '', 75, '', '', 1, 1, 3, 1604487047),
(160, '读取广告位', 'ads/index/positread', '', 76, '', '', 1, 1, 3, 1604487047),
(161, '添加广告位', 'ads/index/positinfo', '', 76, '', '', 1, 1, 3, 1604487147),
(162, '修改广告位', 'ads/index/positinfo', '', 76, '', '', 1, 1, 3, 1604487147),
(163, '保存广告位', 'ads/index/positsave', '', 76, '', '', 1, 1, 3, 1604487147),
(164, '删除广告位', 'ads/index/positdelete', '', 76, '', '', 1, 1, 3, 1604487147),
(165, '读取充值卡', 'pay@admin/card/read', '', 77, '', '', 1, 1, 3, 1606554683),
(166, '添加充值卡', 'pay@admin/card/create', '', 77, '', '', 1, 1, 3, 1606554697),
(167, '保存充值卡', 'pay@admin/card/save', '', 77, '', '', 1, 1, 3, 1606554710),
(168, '删除充值卡', 'pay@admin/card/delete', '', 77, '', '', 1, 1, 3, 1606554722),
(169, '修改充值卡', 'pay@admin/card/edit', '', 77, '', '', 1, 1, 3, 1606554740),
(170, '提现管理', 'user@admin/cash/index', '', 88, '', '', 1, 0, 1, 1604546489),
(171, '提现列表', 'user@admin/cash/read', '', 170, '', '', 1, 1, 3, 1604547133),
(172, '添加提现', 'user@admin/cash/create', '', 170, '', '', 1, 1, 3, 1604547133),
(173, '修改提现', 'user@admin/cash/edit', '', 170, '', '', 1, 1, 3, 1604547133),
(174, '保存提现', 'user@admin/cash/save', '', 170, '', '', 1, 1, 3, 1604547133),
(175, '删除提现', 'user@admin/cash/delete', '', 170, '', '', 1, 1, 3, 1604547133),
(176, '同意提现', 'user@admin/cash/update_field', '', 170, '', '', 1, 1, 3, 1604547133),
(177, '视频设置', 'vod@admin/setting/cache', '', 61, '', '5ntdImAz73TE', 1, 3, 1, 1605263614),
(178, '扩展设置', 'vod@admin/setting/extend', '', 177, '', '5ntdImAz73TE', 1, 2, 1, 1605085647),
(179, '缓存设置', 'vod@admin/setting/cache', '', 177, '', '5ntdImAz73TE', 1, 0, 1, 1605168840),
(180, '文章设置', 'art@admin/setting/cache', '', 40, '', 'pS8paTrMC7Oy', 1, 3, 1, 1605263656),
(181, '缓存设置', 'art@admin/setting/cache', '', 180, '', 'pS8paTrMC7Oy', 1, 3, 1, 1605263693),
(183, '权限设置', '', '', 12, '', 'SHEZHI', 1, 1, 1, 1605498824),
(184, '邮箱配置', 'email/index', '', 208, '', 'SHEZHI', 1, 5, 1, 1606795050),
(193, '搜索设置', 'vod@admin/setting/search', '', 177, '', '5ntdImAz73TE', 1, 10, 1, 1606113881),
(194, '搜索设置', 'art@admin/setting/search', '', 180, '', '', 1, 2, 1, 1606114498),
(195, '加密设置', 'vod@admin/setting/encryption', '', 177, '', '5ntdImAz73TE', 1, 0, 1, 1606115824),
(196, '采集设置', 'vod@admin/setting/collection', '', 177, '', '5ntdImAz73TE', 1, 0, 1, 1606115813),
(204, '伪静态', 'art@admin/setting/rewrite', '', 180, '文章伪静态节点', '', 1, 1, 1, 1606725187),
(208, '站点基本参数', '', '', 12, '站点基本参数节点', 'SHEZHI', 1, 2, 1, 1606794990),
(210, '数据库', 'database/index', '', 6, '', 'SHEZHI', 1, 6, 1, 1606807585),
(211, 'redis', 'redis/index', '', 6, '', 'SHEZHI', 1, 4, 1, 1606807345),
(212, 'memcache', 'memcache/index', '', 6, '', 'SHEZHI', 1, 5, 1, 1606807036),
(217, '伪静态', 'vod@admin/setting/rewrite', '', 177, '视频伪静态', '5ntdImAz73TE', 1, 0, 1, 1607050595);

DROP TABLE IF EXISTS `ray_pay_card`;
CREATE TABLE IF NOT EXISTS `ray_pay_card` (
  `card_id` int(10) unsigned NOT NULL,
  `site_id` int(10) DEFAULT NULL COMMENT '站点id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '使用人',
  `card_no` varchar(16) NOT NULL DEFAULT '' COMMENT '卡号',
  `card_pwd` varchar(8) NOT NULL DEFAULT '' COMMENT '密码',
  `card_money` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '金额面值',
  `card_points` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '送积分',
  `card_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '使用状态0未使用 1已使用',
  `card_addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `card_usertime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '使用时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `ray_pay_card_record`;
CREATE TABLE IF NOT EXISTS `ray_pay_card_record` (
  `record_id` int(10) NOT NULL,
  `site_id` int(10) NOT NULL COMMENT '站长id',
  `record_num` int(10) NOT NULL COMMENT '生成数量',
  `record_money` int(10) NOT NULL COMMENT '生成面值',
  `record_stat` int(10) NOT NULL COMMENT '充值卡激活量',
  `record_addtime` int(10) NOT NULL COMMENT '记录时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='充值卡生成记录表';

DROP TABLE IF EXISTS `ray_role`;
CREATE TABLE IF NOT EXISTS `ray_role` (
  `role_id` int(11) unsigned NOT NULL COMMENT '角色ID',
  `role_name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '角色名',
  `role_description` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '角色描述',
  `role_status` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '状态1正常0未启用',
  `role_sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序值'
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='用户角色';

INSERT INTO `ray_role` (`role_id`, `role_name`, `role_description`, `role_status`, `role_sort`) VALUES
(1, '超级管理员', '超级管理员，拥有所有权限', 1, 1);

DROP TABLE IF EXISTS `ray_role_menu`;
CREATE TABLE IF NOT EXISTS `ray_role_menu` (
  `id` int(11) unsigned NOT NULL,
  `role_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '角色编号',
  `node_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '权限菜单编号'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色权限对应表';

DROP TABLE IF EXISTS `ray_type`;
CREATE TABLE IF NOT EXISTS `ray_type` (
  `type_id` smallint(6) unsigned NOT NULL,
  `type_name` varchar(60) NOT NULL DEFAULT '',
  `type_en` varchar(60) NOT NULL DEFAULT '',
  `type_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_mid` smallint(6) unsigned NOT NULL DEFAULT '1',
  `type_pid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `type_tpl` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_list` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_detail` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_play` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_down` varchar(30) NOT NULL DEFAULT '',
  `type_keywords` varchar(255) NOT NULL DEFAULT '',
  `type_description` varchar(255) NOT NULL DEFAULT '',
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_union` varchar(255) NOT NULL DEFAULT '',
  `type_extend` text,
  `type_logo` varchar(255) NOT NULL DEFAULT '',
  `type_pic` varchar(255) NOT NULL DEFAULT '',
  `type_jumpurl` varchar(150) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `ray_type` (`type_id`, `type_name`, `type_en`, `type_sort`, `type_mid`, `type_pid`, `type_status`, `type_tpl`, `type_tpl_list`, `type_tpl_detail`, `type_tpl_play`, `type_tpl_down`, `type_keywords`, `type_description`, `type_title`, `type_union`, `type_extend`, `type_logo`, `type_pic`, `type_jumpurl`) VALUES
(1, '电影', '', 1, 1, 0, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '电影,电影大全,电影天堂,最新电影,好看的电影,电影排行榜', '为您提供更新电影、好看的电影排行榜及电影迅雷下载，免费在线观看伦理电影、动作片、喜剧片、爱情片、搞笑片等全新电影。', '电影', '', '{"class":"\\u559c\\u5267,\\u7231\\u60c5,\\u6050\\u6016,\\u52a8\\u4f5c,\\u79d1\\u5e7b,\\u5267\\u60c5,\\u6218\\u4e89,\\u8b66\\u532a,\\u72af\\u7f6a,\\u52a8\\u753b,\\u5947\\u5e7b,\\u6b66\\u4fa0,\\u5192\\u9669,\\u67aa\\u6218,\\u6050\\u6016,\\u60ac\\u7591,\\u60ca\\u609a,\\u7ecf\\u5178,\\u9752\\u6625,\\u6587\\u827a,\\u5fae\\u7535\\u5f71,\\u53e4\\u88c5,\\u5386\\u53f2,\\u8fd0\\u52a8,\\u519c\\u6751,\\u513f\\u7ae5,\\u7f51\\u7edc\\u7535\\u5f71","area":"\\u5927\\u9646,\\u9999\\u6e2f,\\u53f0\\u6e7e,\\u7f8e\\u56fd,\\u6cd5\\u56fd,\\u82f1\\u56fd,\\u65e5\\u672c,\\u97e9\\u56fd,\\u5fb7\\u56fd,\\u6cf0\\u56fd,\\u5370\\u5ea6,\\u610f\\u5927\\u5229,\\u897f\\u73ed\\u7259,\\u52a0\\u62ff\\u5927,\\u5176\\u4ed6","lang":"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u6cd5\\u8bed,\\u5fb7\\u8bed,\\u5176\\u5b83","year":"2018,2017,2016,2015,2014,2013,2012,2011,2010","star":"\\u738b\\u5b9d\\u5f3a,\\u9ec4\\u6e24,\\u5468\\u8fc5,\\u5468\\u51ac\\u96e8,\\u8303\\u51b0\\u51b0,\\u9648\\u5b66\\u51ac,\\u9648\\u4f1f\\u9706,\\u90ed\\u91c7\\u6d01,\\u9093\\u8d85,\\u6210\\u9f99,\\u845b\\u4f18,\\u6797\\u6b63\\u82f1,\\u5f20\\u5bb6\\u8f89,\\u6881\\u671d\\u4f1f,\\u5f90\\u5ce5,\\u90d1\\u607a,\\u5434\\u5f66\\u7956,\\u5218\\u5fb7\\u534e,\\u5468\\u661f\\u9a70,\\u6797\\u9752\\u971e,\\u5468\\u6da6\\u53d1,\\u674e\\u8fde\\u6770,\\u7504\\u5b50\\u4e39,\\u53e4\\u5929\\u4e50,\\u6d2a\\u91d1\\u5b9d,\\u59da\\u6668,\\u502a\\u59ae,\\u9ec4\\u6653\\u660e,\\u5f6d\\u4e8e\\u664f,\\u6c64\\u552f,\\u9648\\u5c0f\\u6625","director":"\\u51af\\u5c0f\\u521a,\\u5f20\\u827a\\u8c0b,\\u5434\\u5b87\\u68ee,\\u9648\\u51ef\\u6b4c,\\u5f90\\u514b,\\u738b\\u5bb6\\u536b,\\u59dc\\u6587,\\u5468\\u661f\\u9a70,\\u674e\\u5b89","state":"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e","version":"\\u9ad8\\u6e05\\u7248,\\u5267\\u573a\\u7248,\\u62a2\\u5148\\u7248,OVA,TV,\\u5f71\\u9662\\u7248"}', '/static/upload/column_logo/2020-11-21/5fb887a2b1af36.155503409.jpg', '', ''),
(2, '连续剧', 'lianxuju', 1, 1, 0, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '电视剧,最新电视剧,好看的电视剧,热播电视剧,电视剧在线观看', '为您提供2018新电视剧排行榜，韩国电视剧、泰国电视剧、香港TVB全新电视剧排行榜、好看的电视剧等热播电视剧排行榜，并提供免费高清电视剧下载及在线观看。', '电视剧', '', '{"class":"\\u53e4\\u88c5,\\u6218\\u4e89,\\u9752\\u6625\\u5076\\u50cf,\\u559c\\u5267,\\u5bb6\\u5ead,\\u72af\\u7f6a,\\u52a8\\u4f5c,\\u5947\\u5e7b,\\u5267\\u60c5,\\u5386\\u53f2,\\u7ecf\\u5178,\\u4e61\\u6751,\\u60c5\\u666f,\\u5546\\u6218,\\u7f51\\u5267,\\u5176\\u4ed6","area":"\\u5185\\u5730,\\u97e9\\u56fd,\\u9999\\u6e2f,\\u53f0\\u6e7e,\\u65e5\\u672c,\\u7f8e\\u56fd,\\u6cf0\\u56fd,\\u82f1\\u56fd,\\u65b0\\u52a0\\u5761,\\u5176\\u4ed6","lang":"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83","year":"2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2006,2005,2004","star":"\\u738b\\u5b9d\\u5f3a,\\u80e1\\u6b4c,\\u970d\\u5efa\\u534e,\\u8d75\\u4e3d\\u9896,\\u5218\\u6d9b,\\u5218\\u8bd7\\u8bd7,\\u9648\\u4f1f\\u9706,\\u5434\\u5947\\u9686,\\u9646\\u6bc5,\\u5510\\u5ae3,\\u5173\\u6653\\u5f64,\\u5b59\\u4fea,\\u674e\\u6613\\u5cf0,\\u5f20\\u7ff0,\\u674e\\u6668,\\u8303\\u51b0\\u51b0,\\u6797\\u5fc3\\u5982,\\u6587\\u7ae0,\\u9a6c\\u4f0a\\u740d,\\u4f5f\\u5927\\u4e3a,\\u5b59\\u7ea2\\u96f7,\\u9648\\u5efa\\u658c,\\u674e\\u5c0f\\u7490","director":"\\u5f20\\u7eaa\\u4e2d,\\u674e\\u5c11\\u7ea2,\\u5218\\u6c5f,\\u5b54\\u7b19,\\u5f20\\u9ece,\\u5eb7\\u6d2a\\u96f7,\\u9ad8\\u5e0c\\u5e0c,\\u80e1\\u73ab,\\u8d75\\u5b9d\\u521a,\\u90d1\\u6653\\u9f99","state":"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e","version":"\\u9ad8\\u6e05\\u7248,\\u5267\\u573a\\u7248,\\u62a2\\u5148\\u7248,OVA,TV,\\u5f71\\u9662\\u7248"}', '', '', ''),
(3, '综艺', 'zongyi', 1, 1, 0, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '综艺,综艺节目,最新综艺节目,综艺节目排行榜', '为您提供新综艺节目、好看的综艺节目排行榜，免费高清在线观看选秀、情感、访谈、搞笑、真人秀、脱口秀等热门综艺节目。', '综艺', '', '{"class":"\\u9009\\u79c0,\\u60c5\\u611f,\\u8bbf\\u8c08,\\u64ad\\u62a5,\\u65c5\\u6e38,\\u97f3\\u4e50,\\u7f8e\\u98df,\\u7eaa\\u5b9e,\\u66f2\\u827a,\\u751f\\u6d3b,\\u6e38\\u620f\\u4e92\\u52a8,\\u8d22\\u7ecf,\\u6c42\\u804c","area":"\\u5185\\u5730,\\u6e2f\\u53f0,\\u65e5\\u97e9,\\u6b27\\u7f8e","lang":"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83","year":"2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2007,2006,2005,2004","star":"\\u4f55\\u7085,\\u6c6a\\u6db5,\\u8c22\\u5a1c,\\u5468\\u7acb\\u6ce2,\\u9648\\u9c81\\u8c6b,\\u5b5f\\u975e,\\u674e\\u9759,\\u6731\\u519b,\\u6731\\u4e39,\\u534e\\u5c11,\\u90ed\\u5fb7\\u7eb2,\\u6768\\u6f9c","director":"","state":"","version":""}', '', '', ''),
(4, '动漫', 'dongman', 1, 1, 0, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '动漫,动漫大全,最新动漫,好看的动漫,日本动漫,动漫排行榜', '为您提供新动漫、好看的动漫排行榜，免费高清在线观看热血动漫、卡通动漫、新番动漫、百合动漫、搞笑动漫、国产动漫、动漫电影等热门动漫。', '动画片', '', '{"class":"\\u60c5\\u611f,\\u79d1\\u5e7b,\\u70ed\\u8840,\\u63a8\\u7406,\\u641e\\u7b11,\\u5192\\u9669,\\u841d\\u8389,\\u6821\\u56ed,\\u52a8\\u4f5c,\\u673a\\u6218,\\u8fd0\\u52a8,\\u6218\\u4e89,\\u5c11\\u5e74,\\u5c11\\u5973,\\u793e\\u4f1a,\\u539f\\u521b,\\u4eb2\\u5b50,\\u76ca\\u667a,\\u52b1\\u5fd7,\\u5176\\u4ed6","area":"\\u56fd\\u4ea7,\\u65e5\\u672c,\\u6b27\\u7f8e,\\u5176\\u4ed6","lang":"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83","year":"2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2007,2006,2005,2004","star":"","director":"","state":"","version":"TV\\u7248,\\u7535\\u5f71\\u7248,OVA\\u7248,\\u771f\\u4eba\\u7248"}', '', '', ''),
(5, '资讯', '', 0, 5, 0, 1, 'type.html', '', '', '', '', '', '', '', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(7, '喜剧片', '', 2, 1, 1, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的喜剧片,最新喜剧片,经典喜剧片,国语喜剧片电影', '2018最新喜剧片，好看的喜剧片大全和排行榜推荐，免费喜剧片在线观看和视频在线播放是由本网站整理和收录，欢迎喜剧片爱好者来到这里在线观看喜剧片', '好看的喜剧片-最新喜剧片-经典喜剧片-最新喜剧片推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(6, '动作片', 'dongzuopian', 1, 1, 1, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的动作片,最新动作片,经典动作片,国语动作片电影', '2018最新动作片，好看的动作片大全和排行榜推荐，免费动作片在线观看和视频在线播放是由本网站整理和收录，欢迎动作片爱好者来到这里在线观看动作片', '好看的动作片-最新动作片-经典动作片-最新动作片推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(8, '爱情片', 'aiqingpian', 3, 1, 1, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的爱情片,最新爱情片,经典爱情片,国语爱情片电影', '2018最新爱情片，好看的爱情片大全和排行榜推荐，免费爱情片在线观看和视频在线播放是由本网站整理和收录，欢迎爱情片爱好者来到这里在线观看爱情片', '好看的爱情片-最新爱情片-经典爱情片-最新爱情片推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(9, '科幻片', 'kehuanpian', 4, 1, 1, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的科幻片,最新科幻片,经典科幻片,国语科幻片电影', '2018最新科幻片，好看的科幻片大全和排行榜推荐，免费科幻片在线观看和视频在线播放是由本网站整理和收录，欢迎科幻片爱好者来到这里在线观看科幻片', '好看的科幻片-最新科幻片-经典科幻片-最新科幻片推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(10, '恐怖片', 'kongbupian', 5, 1, 1, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的恐怖片,最新恐怖片,经典恐怖片,国语恐怖片电影', '2018最新恐怖片，好看的恐怖片大全和排行榜推荐，免费恐怖片在线观看和视频在线播放是由本网站整理和收录，欢迎恐怖片爱好者来到这里在线观看恐怖片', '好看的恐怖片-最新恐怖片-经典恐怖片-最新恐怖片推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(11, '剧情片', 'juqingpian', 6, 1, 1, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的剧情片,最新剧情片,经典剧情片,国语剧情片电影', '2018最新剧情片，好看的剧情片大全和排行榜推荐，免费剧情片在线观看和视频在线播放是由本网站整理和收录，欢迎剧情片爱好者来到这里在线观看剧情片', '好看的剧情片-最新剧情片-经典剧情片-最新剧情片推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(12, '战争片', 'zhanzhengpian', 7, 1, 1, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的战争片,最新战争片,经典战争片,国语战争片电影', '2018最新战争片，好看的战争片大全和排行榜推荐，免费战争片在线观看和视频在线播放是由本网站整理和收录，欢迎战争片爱好者来到这里在线观看战争片', '好看的战争片-最新战争片-经典战争片-最新战争片推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(13, '国产剧', 'guochanju', 1, 1, 2, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的国产剧,最新国产剧,经典国产剧,国语国产剧电影', '2018最新国产剧，好看的国产剧大全和排行榜推荐，免费国产剧在线观看和视频在线播放是由本网站整理和收录，欢迎国产剧爱好者来到这里在线观看国产剧', '好看的国产剧-最新国产剧-经典国产剧-最新国产剧推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(14, '港台剧', 'gangtaiju', 2, 1, 2, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的港台剧,最新港台剧,经典港台剧,国语港台剧电影', '2018最新港台剧，好看的港台剧大全和排行榜推荐，免费港台剧在线观看和视频在线播放是由本网站整理和收录，欢迎港台剧爱好者来到这里在线观看港台剧', '好看的港台剧-最新港台剧-经典港台剧-最新港台剧推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(15, '日韩剧', 'rihanju', 3, 1, 2, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的日韩剧,最新日韩剧,经典日韩剧,国语日韩剧电影', '2018最新日韩剧，好看的日韩剧大全和排行榜推荐，免费日韩剧在线观看和视频在线播放是由本网站整理和收录，欢迎日韩剧爱好者来到这里在线观看日韩剧', '好看的日韩剧-最新日韩剧-经典日韩剧-最新日韩剧推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(16, '欧美剧', 'oumeiju', 4, 1, 2, 1, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的欧美剧,最新欧美剧,经典欧美剧,国语欧美剧电影', '2018最新欧美剧，好看的欧美剧大全和排行榜推荐，免费欧美剧在线观看和视频在线播放是由本网站整理和收录，欢迎欧美剧爱好者来到这里在线观看欧美剧', '好看的欧美剧-最新欧美剧-经典欧美剧-最新欧美剧推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(17, '公告', 'gonggao', 1, 2, 5, 1, 'type.html', 'show.html', 'detail.html', '', '', '最新公告-最新公告推荐', '2018最新公告，公布本站最新发展动态', '最新公告-最新公告推荐', '', '{"class":"","area":"","lang":"","year":"","star":"","director":"","state":"","version":""}', '', '', ''),
(18, '头条', 'toutiao', 2, 2, 5, 1, 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '', '', '', ''),
(21, '日本', 'riben', 1, 1, 4, 1, '', 'show.html', 'detail.html', '', '', '', '', '', '', NULL, '', '', ''),
(22, '大陆', 'dalu', 2, 1, 4, 1, '', 'show.html', 'detail.html', '', '', '', '', '', '', NULL, '', '', ''),
(23, '独播', 'dubo', 1, 1, 3, 1, '', 'show.html', 'detail.html', '', '', '', '', '', '', NULL, '', '', '');

DROP TABLE IF EXISTS `ray_user`;
CREATE TABLE IF NOT EXISTS `ray_user` (
  `user_id` int(11) unsigned NOT NULL COMMENT '主键ID',
  `site_id` int(11) NOT NULL DEFAULT '1' COMMENT '所属站点',
  `level_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '会员等级',
  `user_name` varchar(250) NOT NULL COMMENT '会员名称',
  `user_nickname` varchar(250) NOT NULL DEFAULT '''''' COMMENT '昵称',
  `user_passwd` varchar(250) NOT NULL COMMENT '会员密码',
  `user_pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级id-默认一级',
  `user_sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '性别-0女1男2未知',
  `user_email` varchar(50) NOT NULL DEFAULT '''''' COMMENT '邮箱',
  `user_phone` varchar(13) NOT NULL DEFAULT '''''' COMMENT '手机号',
  `user_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态-0禁用1启用',
  `user_expiretime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员到期时间',
  `user_issue_one` varchar(250) NOT NULL,
  `user_answer_one` varchar(250) NOT NULL,
  `user_lasttime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登陆时间',
  `user_deletetime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  `user_addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='会员信息表';

INSERT INTO `ray_user` (`user_id`, `site_id`, `level_id`, `user_name`, `user_nickname`, `user_passwd`, `user_pid`, `user_sex`, `user_email`, `user_phone`, `user_status`, `user_expiretime`, `user_issue_one`, `user_answer_one`, `user_lasttime`, `user_deletetime`, `user_addtime`) VALUES
(1, 1, 1, 'test123', 'test123', '$2y$10$Dt/IFTRKfl2eFfbli3xPaessPBd5LkhBq2/eOVfsvYuky/CfgHos.', 0, 1, '', '', 1, 1604851200, '', '', 1607505036, 0, 1607504798);

DROP TABLE IF EXISTS `ray_user_cash`;
CREATE TABLE IF NOT EXISTS `ray_user_cash` (
  `cash_id` int(11) unsigned NOT NULL COMMENT '主键ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '会员ID',
  `site_id` int(11) unsigned NOT NULL COMMENT '站点id',
  `cash_amount` decimal(10,2) NOT NULL COMMENT '提现金额',
  `cash_integral` int(11) unsigned NOT NULL COMMENT '所用积分',
  `cash_cashier` varchar(50) NOT NULL COMMENT '户名',
  `cash_account` varchar(50) NOT NULL COMMENT '提现账号',
  `cash_type` varchar(50) NOT NULL COMMENT '提现方式（微信，支付宝，银行卡）',
  `cash_backname` varchar(50) NOT NULL COMMENT '银行名称/支付宝/微信',
  `cash_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '提现状态-0未提现1已提现',
  `cash_addtime` int(10) unsigned NOT NULL COMMENT '提现时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='提现记录表';

DROP TABLE IF EXISTS `ray_user_level`;
CREATE TABLE IF NOT EXISTS `ray_user_level` (
  `level_id` int(11) unsigned NOT NULL COMMENT '主键ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '所属站点ID',
  `level_name` varchar(250) NOT NULL COMMENT '等级名称',
  `level_money` int(11) NOT NULL COMMENT '价格',
  `level_weekprice` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '周价格',
  `level_monthprice` int(11) unsigned NOT NULL COMMENT '月价格',
  `level_periodprice` int(11) unsigned NOT NULL COMMENT '季度价格',
  `level_yearprice` int(11) unsigned NOT NULL COMMENT '年度价格',
  `level_integral` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '等级默认积分',
  `level_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态-0禁用1启用',
  `level_addtime` int(10) NOT NULL COMMENT '添加时间'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='会员等级';

INSERT INTO `ray_user_level` (`level_id`, `site_id`, `level_name`, `level_money`, `level_weekprice`, `level_monthprice`, `level_periodprice`, `level_yearprice`, `level_integral`, `level_status`, `level_addtime`) VALUES
(1, 1, '默认会员', 0, 0, 0, 0, 0, 0, 1, 0);

DROP TABLE IF EXISTS `ray_user_point`;
CREATE TABLE IF NOT EXISTS `ray_user_point` (
  `point_id` int(11) unsigned NOT NULL COMMENT '主键ID',
  `site_id` int(11) unsigned NOT NULL COMMENT '站点id',
  `point_name` varchar(250) NOT NULL COMMENT '积分名称',
  `point_scale` varchar(20) NOT NULL COMMENT '兑换比例',
  `point_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态-0禁用1启用',
  `point_addtime` int(10) unsigned NOT NULL COMMENT '添加时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员积分表';

DROP TABLE IF EXISTS `ray_user_point_annal`;
CREATE TABLE IF NOT EXISTS `ray_user_point_annal` (
  `annal_id` int(11) unsigned NOT NULL COMMENT '主键ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '用户id',
  `site_id` int(11) unsigned NOT NULL COMMENT '站点id',
  `point_id` int(11) unsigned NOT NULL COMMENT '积分id',
  `annal_datatype` tinyint(1) unsigned NOT NULL COMMENT '数据类型-0初始化，根据配置表数据',
  `annal_bechange` int(11) unsigned NOT NULL COMMENT '变更前积分',
  `annal_afchange` int(11) unsigned NOT NULL COMMENT '变更后积分',
  `annal_available` int(11) unsigned NOT NULL COMMENT '可用积分',
  `annal_withdraw` int(11) unsigned NOT NULL COMMENT '可提现积分',
  `annal_addtime` int(10) unsigned NOT NULL COMMENT '添加时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户积分记录表';

DROP TABLE IF EXISTS `ray_user_role`;
CREATE TABLE IF NOT EXISTS `ray_user_role` (
  `id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL COMMENT '用户id',
  `role_id` int(11) unsigned NOT NULL COMMENT '角色id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户角色对应关系';

DROP TABLE IF EXISTS `ray_user_upoint`;
CREATE TABLE IF NOT EXISTS `ray_user_upoint` (
  `upoint_id` int(11) unsigned NOT NULL COMMENT '主键ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `level_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '所属等级',
  `point_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '积分ID',
  `site_id` int(11) unsigned NOT NULL COMMENT '站点ID',
  `upoint_total` int(11) NOT NULL DEFAULT '0' COMMENT '用户总积分',
  `upoint_available` int(11) NOT NULL DEFAULT '0' COMMENT '用户可用积分',
  `upoint_withdraw` int(11) NOT NULL DEFAULT '0' COMMENT '用户可提现积分',
  `upoint_addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户积分表';

DROP TABLE IF EXISTS `ray_vod`;
CREATE TABLE IF NOT EXISTS `ray_vod` (
  `vod_id` int(10) unsigned NOT NULL,
  `type_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属栏目',
  `vod_title` varchar(255) NOT NULL DEFAULT '' COMMENT '视频标题',
  `vod_letter` char(1) NOT NULL DEFAULT '' COMMENT '首字母',
  `vod_star` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '推荐等级',
  `vod_director` varchar(255) NOT NULL DEFAULT '' COMMENT '导演',
  `vod_actor` varchar(255) NOT NULL DEFAULT '' COMMENT '主演',
  `vod_actor_val` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '演员id',
  `vod_total` varchar(50) NOT NULL DEFAULT '0' COMMENT '总集数',
  `vod_remarks` varchar(255) NOT NULL COMMENT '更新动态',
  `vod_score` varchar(50) CHARACTER SET utf8 DEFAULT '0' COMMENT '评分',
  `vod_serial` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '连载数',
  `vod_duration` varchar(100) NOT NULL DEFAULT '' COMMENT '视频时长',
  `vod_pubdate` varchar(100) NOT NULL DEFAULT '' COMMENT '上映日期',
  `vod_class` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '影视类型',
  `vod_year` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '上映年份',
  `vod_area` varchar(50) NOT NULL DEFAULT '0' COMMENT '发行地区',
  `vod_lang` varchar(50) NOT NULL DEFAULT '0' COMMENT '语言',
  `vod_play_from` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '播放器类型',
  `vod_play_server` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '服务器',
  `vod_play_url` mediumtext CHARACTER SET utf8 NOT NULL COMMENT '播放url',
  `vod_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '审核状态',
  `vod_hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总人气',
  `vod_hits_day` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日人气',
  `vod_hits_week` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '周人气',
  `vod_hits_month` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '月人气',
  `vod_color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `vod_content` mediumtext NOT NULL COMMENT '剧情介绍',
  `vod_pic` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `vod_pic_thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图',
  `vod_blurb` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `vod_jumpurl` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转地址',
  `vod_jumpstatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '启用跳转',
  `vod_sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `vod_addtime` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频表';

DROP TABLE IF EXISTS `ray_vod_collect`;
CREATE TABLE IF NOT EXISTS `ray_vod_collect` (
  `collect_id` int(10) unsigned NOT NULL,
  `collect_name` varchar(30) NOT NULL DEFAULT '' COMMENT '资源名称',
  `collect_url` varchar(255) NOT NULL DEFAULT '' COMMENT '资源链接',
  `collect_type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '接口类型',
  `collect_mid` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '资源类型',
  `collect_appid` varchar(30) NOT NULL DEFAULT '',
  `collect_appkey` varchar(30) NOT NULL DEFAULT '',
  `collect_param` varchar(100) NOT NULL DEFAULT '' COMMENT '附加参数',
  `collect_filter` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '地址过滤',
  `collect_filter_from` varchar(255) NOT NULL DEFAULT '' COMMENT '过滤代码',
  `collect_opt` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '数据操作',
  `collect_timing_time` varchar(50) NOT NULL COMMENT '定时时间',
  `collect_timing_switch` int(10) NOT NULL DEFAULT '0' COMMENT '是否定时采集1是0 否',
  `collect_sort` int(11) NOT NULL COMMENT '排序'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `ray_vod_collect_type`;
CREATE TABLE IF NOT EXISTS `ray_vod_collect_type` (
  `id` int(11) unsigned NOT NULL,
  `type_key` varchar(255) NOT NULL COMMENT '绑定网址类型',
  `type_value` int(10) NOT NULL COMMENT '映射的类型值'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `ray_vod_player`;
CREATE TABLE IF NOT EXISTS `ray_vod_player` (
  `player_id` int(10) unsigned NOT NULL,
  `player_from` varchar(100) NOT NULL COMMENT '播放器标识',
  `player_name` varchar(100) NOT NULL COMMENT '播放器名称',
  `player_desc` varchar(100) NOT NULL COMMENT '备注',
  `player_parse` varchar(100) NOT NULL COMMENT '解析地址',
  `player_ps` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '解析状态0禁用 1启用',
  `player_sort` int(10) unsigned NOT NULL COMMENT '排序',
  `player_status` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '状态0禁用 1启用',
  `player_code` text NOT NULL COMMENT '播放器代码',
  `player_addtime` int(10) unsigned NOT NULL COMMENT '添加时间'
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='播放器代码表';

INSERT INTO `ray_vod_player` (`player_id`, `player_from`, `player_name`, `player_desc`, `player_parse`, `player_ps`, `player_sort`, `player_status`, `player_code`, `player_addtime`) VALUES
(1, '123kum3u8', '123kum3u8', '123ku', '', 0, 1, 1, '&lt;iframe border=&quot;0&quot; src=&quot;/static/player/dplayer/dplayer.html&quot; width=&quot;100%&quot; height=&quot;100%&quot; marginWidth=&quot;0&quot; frameSpacing=&quot;0&quot; marginHeight=&quot;0&quot; frameBorder=&quot;0&quot; scrolling=&quot;no&quot; vspale=&quot;0&quot; noResize&gt;&lt;/iframe&gt;\n', 1585825961),
(5, 'zuidam3u8', '最大1', '', '', 0, 99, 1, '&lt;iframe border=&quot;0&quot; src=&quot;/static/dplayer/dplayer.html&quot; width=&quot;100%&quot; height=&quot;100%&quot; marginWidth=&quot;0&quot; frameSpacing=&quot;0&quot; marginHeight=&quot;0&quot; frameBorder=&quot;0&quot; scrolling=&quot;no&quot; vspale=&quot;0&quot; noResize&gt;&lt;/iframe&gt;', 1585902428),
(6, 'zuidall', '最大2', '', '', 0, 99, 1, '&lt;iframe border=&quot;0&quot; src=&quot;/static/dplayer/dplayer.html&quot; width=&quot;100%&quot; height=&quot;100%&quot; marginWidth=&quot;0&quot; frameSpacing=&quot;0&quot; marginHeight=&quot;0&quot; frameBorder=&quot;0&quot; scrolling=&quot;no&quot; vspale=&quot;0&quot; noResize&gt;&lt;/iframe&gt;', 1585902428),
(7, 'ckm3u8', 'ok', '', '', 0, 0, 1, '&lt;iframe border=&quot;0&quot; src=&quot;/static/player/dplayer/dplayer.html&quot; width=&quot;100%&quot; height=&quot;100%&quot; marginWidth=&quot;0&quot; frameSpacing=&quot;0&quot; marginHeight=&quot;0&quot; frameBorder=&quot;0&quot; scrolling=&quot;no&quot; vspale=&quot;0&quot; noResize&gt;&lt;/iframe&gt;', 0),
(8, 'videojs', 'videojs-H5播放器', '', '', 0, 0, 1, '&lt;iframe border=&quot;0&quot; src=&quot;/static/player/videojs.html&quot; width=&quot;100%&quot; height=&quot;100%&quot; marginWidth=&quot;0&quot; frameSpacing=&quot;0&quot; marginHeight=&quot;0&quot; frameBorder=&quot;0&quot; scrolling=&quot;no&quot; vspale=&quot;0&quot; noResize&gt;&lt;/iframe&gt;', 0),
(9, 'swf', 'Flash文件', 'swf', '', 0, 0, 1, '&lt;embed type=&quot;application/x-shockwave-flash&quot; src=&quot;{$obj.player_info.url}&quot; id=&quot;Player&quot; bgcolor=&quot;#FFFFFF&quot; quality=&quot;high&quot; allowfullscreen=&quot;true&quot; allowNetworking=&quot;internal&quot; allowscriptaccess=&quot;never&quot; wmode=&quot;transparent&quot; menu=&quot;false&quot; always=&quot;false&quot;  pluginspage=&quot;http://www.macromedia.com/go/getflashplayer&quot; width=&quot;100%&quot; height=&quot;100%&quot; flashvars=&quot;&amp;SCALE=exactfit&quot;&gt;', 0),
(10, 'youku', '优酷视频', '', '', 0, 0, 1, '&lt;embed type=&quot;application/x-shockwave-flash&quot; src=&quot;http://static.youku.com/v1.0.0352/v/swf/loader.swf&quot; id=&quot;Player&quot; bgcolor=&quot;#FFFFFF&quot; quality=&quot;high&quot; allowfullscreen=&quot;true&quot; allowNetworking=&quot;internal&quot; allowscriptaccess=&quot;never&quot; wmode=&quot;transparent&quot; menu=&quot;false&quot; always=&quot;false&quot; flashvars=&quot;isShowRelatedVideo=false&amp;showAd=0&amp;show_pre=1&amp;show_next=1&amp;VideoIDS={$obj.player_info.url}&amp;isAutoPlay=true&amp;isDebug=false&amp;UserID=&amp;winType=adshow&amp;playMovie=true&amp;MMControl=false&amp;MMout=false&amp;RecordCode=1001,1002,1003,1004,1005,1006,2001,3001,3002,3003,3004,3005,3007,3008,9999&quot; pluginspage=&quot;http://www.macromedia.com/go/getflashplayer&quot; width=&quot;100%&quot; height=&quot;100%&quot;&gt;', 0),
(11, 'tudou', '土豆视频', 'tudoucom', '', 0, 0, 1, '&lt;embed type=&quot;application/x-shockwave-flash&quot; src=&quot;http://www.tudou.com/v/''+{$obj.player_info.url}+''/dW5pb25faWQ9MTAyMTk1XzEwMDAwMV8wMV8wMQ/&amp;videoClickNavigate=false&amp;withRecommendList=false&amp;withFirstFrame=false&amp;autoPlay=true/v.swf&quot; id=&quot;Player&quot; name=&quot;Player&quot; bgcolor=&quot;#FFFFFF&quot; quality=&quot;high&quot; allowfullscreen=&quot;true&quot; allowNetworking=&quot;internal&quot; allowscriptaccess=&quot;never&quot; wmode=&quot;transparent&quot; menu=&quot;false&quot; always=&quot;false&quot;  pluginspage=&quot;http://www.macromedia.com/go/getflashplayer&quot; width=&quot;100%&quot; height=&quot;100%&quot; flashvars=&quot;&quot;&gt;', 0),
(12, 'qq', '腾讯视频', '', '', 0, 0, 1, '&lt;embed type=&quot;application/x-shockwave-flash&quot; src=&quot;http://static.video.qq.com/TencentPlayer.swf?vid={$obj.player_info.url}&amp;auto=1&amp;outhost=http://cf.qq.com/&quot; id=&quot;Player&quot; bgcolor=&quot;#FFFFFF&quot; quality=&quot;high&quot; allowfullscreen=&quot;true&quot; allowNetworking=&quot;internal&quot; allowscriptaccess=&quot;never&quot; wmode=&quot;transparent&quot; menu=&quot;false&quot; always=&quot;false&quot;  pluginspage=&quot;http://www.macromedia.com/go/getflashplayer&quot; width=&quot;100%&quot; height=&quot;100%&quot; flashvars=&quot;&quot;&gt;', 0),
(13, 'sohu', '搜狐视频', '', '', 0, 0, 1, '&lt;embed type=&quot;application/x-shockwave-flash&quot; src=&quot;http://tv.sohu.com/upload/swf/20140928/PlayerShell.swf&quot; id=&quot;Player&quot; bgcolor=&quot;#FFFFFF&quot; quality=&quot;high&quot; allowfullscreen=&quot;true&quot; allowNetworking=&quot;internal&quot; allowscriptaccess=&quot;never&quot; wmode=&quot;transparent&quot; menu=&quot;false&quot; always=&quot;false&quot;  pluginspage=&quot;http://www.macromedia.com/go/getflashplayer&quot; width=&quot;100%&quot; height=&quot;100%&quot; flashvars=&quot;id={$obj.player_info.url}&amp;rewriteType=7&amp;topBar=1&amp;from=page&amp;autoplay=true&amp;shareBtn=1&amp;likeBtn=1&amp;topBarFull=1&amp;topBarNor=1&amp;sogouBtn=0&quot;&gt;', 0),
(15, 'letv', '乐视视频', '', '', 0, 0, 1, '&lt;embed type=&quot;application/x-shockwave-flash&quot; src=&quot;http://www.letv.com/player/x{$obj.player_info.url}.swf&quot; id=&quot;Player&quot; bgcolor=&quot;#FFFFFF&quot; quality=&quot;high&quot; allowfullscreen=&quot;true&quot; allowNetworking=&quot;internal&quot; allowscriptaccess=&quot;never&quot; wmode=&quot;transparent&quot; menu=&quot;false&quot; always=&quot;false&quot;  pluginspage=&quot;http://www.macromedia.com/go/getflashplayer&quot; width=&quot;100%&quot; height=&quot;100%&quot; flashvars=&quot;&quot;&gt;', 0),
(16, 'funshion', '风行视频', '', '', 0, 0, 1, '&lt;embed type=&quot;application/x-shockwave-flash&quot; src=&quot;http://static.funshion.com/market/p2p/vod/2014-9-26/FunPlayerUi_3.0.0.25.swf&quot; id=&quot;Player&quot; bgcolor=&quot;#FFFFFF&quot; quality=&quot;high&quot; allowfullscreen=&quot;true&quot; allowNetworking=&quot;internal&quot; allowscriptaccess=&quot;never&quot; wmode=&quot;transparent&quot; menu=&quot;false&quot; always=&quot;false&quot; flashvars=&quot;pauseAp=&amp;mediaAp=c_wb_1_lv&amp;userSeek=1&amp;type=movie&amp;partner=69&amp;funshionSetup=0&amp;start=1&amp;itemid={$obj.player_info.url}&amp;data=1&amp;startAd=0&amp;userMac=&amp;poster=&amp;stopUrl=&quot; pluginspage=&quot;http://www.macromedia.com/go/getflashplayer&quot; width=&quot;100%&quot; height=&quot;100%&quot;&gt;', 0),
(17, 'mgtv', '芒果tv', '', '', 0, 0, 1, '&lt;embed type=&quot;application/x-shockwave-flash&quot; src=&quot;//player.mgtv.com/mgtv_v5_main/main.swf?play_type=1&amp;video_id={$obj.player_info.url}&quot; id=&quot;Player&quot; bgcolor=&quot;#FFFFFF&quot; quality=&quot;high&quot; allowfullscreen=&quot;true&quot; allowScriptAccess=&quot;always&quot; flashvars=&quot;&quot; pluginspage=&quot;http://www.macromedia.com/go/getflashplayer&quot; width=&quot;100%&quot; height=&quot;100%&quot;&gt;', 0),
(18, 'pptv', 'pptv', '', '', 0, 0, 1, '&lt;embed type=&quot;application/x-shockwave-flash&quot; src=&quot;http://player.pptv.com/v/{$obj.player_info.url}.swf&quot; id=&quot;Player&quot; bgcolor=&quot;#FFFFFF&quot; quality=&quot;high&quot; allowfullscreen=&quot;true&quot; allowNetworking=&quot;internal&quot; allowscriptaccess=&quot;never&quot; wmode=&quot;transparent&quot; menu=&quot;false&quot; always=&quot;false&quot;  pluginspage=&quot;http://www.macromedia.com/go/getflashplayer&quot; width=&quot;100%&quot; height=&quot;100%&quot; flashvars=&quot;&quot;&gt;', 0),
(19, 'kuyun', 'OK播放器', '', '', 0, 0, 1, '&lt;iframe width=&quot;100%&quot; height=&quot;''+MacPlayer.Height+''&quot; src=&quot;{$obj.player_info.url}&quot; frameborder=&quot;0&quot; allowfullscreen&gt;&lt;/iframe&gt;', 0),
(20, 'iframe', 'iframe外链数据', '', '', 0, 0, 1, '&lt;iframe width=&quot;100%&quot; height=&quot;100%&quot; src=&quot;{$obj.player_info.url}&quot; frameborder=&quot;0&quot; border=&quot;0&quot; marginwidth=&quot;0&quot; marginheight=&quot;0&quot; scrolling=&quot;no&quot; allowfullscreen=&quot;allowfullscreen&quot; mozallowfullscreen=&quot;mozallowfullscreen&quot; msallowfullscreen=&quot;msallowfullscreen&quot; oallowfullscreen=&quot;oallowfullscreen&quot; webkitallowfullscreen=&quot;webkitallowfullscreen&quot;&gt;&lt;/iframe&gt;', 0),
(21, 'link', '外链数据', '', '', 0, 0, 1, 'top.location.href={$obj.player_info.url};', 0),
(22, 'dplayer', 'DPlayer-H5播放器', '', '', 0, 0, 1, '&lt;iframe border=&quot;0&quot; src=&quot;/static/player/dplayer/dplayer.html&quot; width=&quot;100%&quot; height=&quot;100%&quot; marginWidth=&quot;0&quot; frameSpacing=&quot;0&quot; marginHeight=&quot;0&quot; frameBorder=&quot;0&quot; scrolling=&quot;no&quot; vspale=&quot;0&quot; noResize&gt;&lt;/iframe&gt;', 0),
(23, 'ckplayer', 'ckplayer', '', '', 0, 0, 1, '&lt;iframe border=&quot;0&quot; src=&quot;/static/player/ckplayer/ckplayer.html&quot; width=&quot;100%&quot; height=&quot;100%&quot; marginWidth=&quot;0&quot; frameSpacing=&quot;0&quot; marginHeight=&quot;0&quot; frameBorder=&quot;0&quot; scrolling=&quot;no&quot; vspale=&quot;0&quot; noResize&gt;&lt;/iframe&gt;', 0);

DROP TABLE IF EXISTS `ray_vod_recycle`;
CREATE TABLE IF NOT EXISTS `ray_vod_recycle` (
  `vod_id` int(10) unsigned NOT NULL,
  `type_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属栏目',
  `vod_title` varchar(255) NOT NULL DEFAULT '' COMMENT '视频标题',
  `vod_letter` char(1) NOT NULL DEFAULT '' COMMENT '首字母',
  `vod_star` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '推荐等级',
  `vod_director` varchar(255) NOT NULL DEFAULT '' COMMENT '导演',
  `vod_actor` varchar(255) NOT NULL DEFAULT '' COMMENT '主演',
  `vod_actor_val` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '演员id',
  `vod_total` varchar(50) NOT NULL DEFAULT '0' COMMENT '总集数',
  `vod_remarks` varchar(255) NOT NULL COMMENT '更新动态',
  `vod_score` varchar(50) CHARACTER SET utf8 DEFAULT '0' COMMENT '评分',
  `vod_serial` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '连载数',
  `vod_duration` varchar(100) NOT NULL DEFAULT '' COMMENT '视频时长',
  `vod_pubdate` varchar(100) NOT NULL DEFAULT '' COMMENT '上映日期',
  `vod_class` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '影视类型',
  `vod_year` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '上映年份',
  `vod_area` varchar(50) NOT NULL DEFAULT '0' COMMENT '发行地区',
  `vod_lang` varchar(50) NOT NULL DEFAULT '0' COMMENT '语言',
  `vod_play_from` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '播放器类型',
  `vod_play_server` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '服务器',
  `vod_play_url` mediumtext CHARACTER SET utf8 NOT NULL COMMENT '播放url',
  `vod_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '审核状态',
  `vod_hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总人气',
  `vod_hits_day` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '日人气',
  `vod_hits_week` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '周人气',
  `vod_hits_month` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '月人气',
  `vod_color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `vod_content` mediumtext NOT NULL COMMENT '剧情介绍',
  `vod_pic` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `vod_pic_thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图',
  `vod_blurb` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `vod_jumpurl` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转地址',
  `vod_jumpstatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '启用跳转',
  `vod_sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `vod_addtime` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频表';

DROP TABLE IF EXISTS `ray_vod_type`;
CREATE TABLE IF NOT EXISTS `ray_vod_type` (
  `type_id` int(11) NOT NULL,
  `type_pid` int(11) NOT NULL DEFAULT '0',
  `type_sort` int(10) DEFAULT '0' COMMENT '排序',
  `type_tpl_list` varchar(255) NOT NULL DEFAULT '' COMMENT '列表模板',
  `type_tpl_detail` varchar(255) NOT NULL DEFAULT '' COMMENT '内容模板',
  `type_logo` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  `type_title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `type_keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `type_description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `type_status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '分类状态'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文章分类表';


ALTER TABLE `ray_actor`
  ADD PRIMARY KEY (`actor_id`);

ALTER TABLE `ray_actor_vod`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ray_admin`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ray_ads`
  ADD PRIMARY KEY (`ad_id`),
  ADD UNIQUE KEY `ad_id` (`ad_id`);

ALTER TABLE `ray_ad_posit`
  ADD PRIMARY KEY (`posit_id`);

ALTER TABLE `ray_art`
  ADD PRIMARY KEY (`art_id`),
  ADD KEY `art_hits_day` (`art_hits_day`),
  ADD KEY `art_hits_week` (`art_hits_week`),
  ADD KEY `art_hits_month` (`art_hits_month`),
  ADD KEY `art_front` (`art_sort`,`art_addtime`) USING BTREE,
  ADD KEY `art_hits` (`art_hits`) USING BTREE;

ALTER TABLE `ray_art_recycle`
  ADD PRIMARY KEY (`art_id`);

ALTER TABLE `ray_art_type`
  ADD PRIMARY KEY (`type_id`);

ALTER TABLE `ray_comment`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `comment_reply_cid` (`comment_reply_cid`),
  ADD KEY `site_id` (`site_id`),
  ADD KEY `comment_pid` (`comment_pid`);

ALTER TABLE `ray_config`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ray_link`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_sort` (`link_sort`) USING BTREE,
  ADD KEY `link_type` (`link_type`) USING BTREE,
  ADD KEY `link_add_time` (`link_add_time`),
  ADD KEY `link_time` (`link_time`);

ALTER TABLE `ray_master_level`
  ADD PRIMARY KEY (`mlv_id`);

ALTER TABLE `ray_nav`
  ADD PRIMARY KEY (`nav_id`),
  ADD UNIQUE KEY `id` (`nav_id`);

ALTER TABLE `ray_node`
  ADD PRIMARY KEY (`node_id`);

ALTER TABLE `ray_pay_card`
  ADD PRIMARY KEY (`card_id`),
  ADD KEY `user_id` (`user_id`) USING BTREE,
  ADD KEY `card_add_time` (`card_addtime`) USING BTREE,
  ADD KEY `card_use_time` (`card_usertime`) USING BTREE,
  ADD KEY `card_no` (`card_no`),
  ADD KEY `card_pwd` (`card_pwd`);

ALTER TABLE `ray_pay_card_record`
  ADD PRIMARY KEY (`record_id`);

ALTER TABLE `ray_role`
  ADD PRIMARY KEY (`role_id`),
  ADD KEY `idx_role` (`role_status`);

ALTER TABLE `ray_role_menu`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ray_type`
  ADD PRIMARY KEY (`type_id`),
  ADD KEY `type_sort` (`type_sort`) USING BTREE,
  ADD KEY `type_pid` (`type_pid`) USING BTREE,
  ADD KEY `type_name` (`type_name`) USING BTREE,
  ADD KEY `type_en` (`type_en`) USING BTREE,
  ADD KEY `type_mid` (`type_mid`) USING BTREE;

ALTER TABLE `ray_user`
  ADD PRIMARY KEY (`user_id`);

ALTER TABLE `ray_user_cash`
  ADD PRIMARY KEY (`cash_id`);

ALTER TABLE `ray_user_level`
  ADD PRIMARY KEY (`level_id`);

ALTER TABLE `ray_user_point`
  ADD PRIMARY KEY (`point_id`);

ALTER TABLE `ray_user_point_annal`
  ADD PRIMARY KEY (`annal_id`);

ALTER TABLE `ray_user_role`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ray_user_upoint`
  ADD PRIMARY KEY (`upoint_id`);

ALTER TABLE `ray_vod`
  ADD PRIMARY KEY (`vod_id`),
  ADD KEY `art_hits_day` (`vod_hits_day`),
  ADD KEY `art_hits_week` (`vod_hits_week`),
  ADD KEY `art_hits_month` (`vod_hits_month`),
  ADD KEY `art_front` (`vod_sort`,`vod_addtime`) USING BTREE,
  ADD KEY `art_hits` (`vod_hits`) USING BTREE;

ALTER TABLE `ray_vod_collect`
  ADD PRIMARY KEY (`collect_id`);

ALTER TABLE `ray_vod_collect_type`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ray_vod_player`
  ADD PRIMARY KEY (`player_id`);

ALTER TABLE `ray_vod_recycle`
  ADD PRIMARY KEY (`vod_id`),
  ADD KEY `art_hits_day` (`vod_hits_day`),
  ADD KEY `art_hits_week` (`vod_hits_week`),
  ADD KEY `art_hits_month` (`vod_hits_month`),
  ADD KEY `art_front` (`vod_sort`,`vod_addtime`) USING BTREE,
  ADD KEY `art_hits` (`vod_hits`) USING BTREE;

ALTER TABLE `ray_vod_type`
  ADD PRIMARY KEY (`type_id`);


ALTER TABLE `ray_actor`
  MODIFY `actor_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_actor_vod`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_admin`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
ALTER TABLE `ray_ads`
  MODIFY `ad_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
ALTER TABLE `ray_ad_posit`
  MODIFY `posit_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
ALTER TABLE `ray_art`
  MODIFY `art_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
ALTER TABLE `ray_art_recycle`
  MODIFY `art_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_art_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
ALTER TABLE `ray_comment`
  MODIFY `comment_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论id';
ALTER TABLE `ray_config`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=167;
ALTER TABLE `ray_link`
  MODIFY `link_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
ALTER TABLE `ray_master_level`
  MODIFY `mlv_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',AUTO_INCREMENT=3;
ALTER TABLE `ray_nav`
  MODIFY `nav_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
ALTER TABLE `ray_node`
  MODIFY `node_id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=220;
ALTER TABLE `ray_pay_card`
  MODIFY `card_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_pay_card_record`
  MODIFY `record_id` int(10) NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_role`
  MODIFY `role_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '角色ID',AUTO_INCREMENT=10;
ALTER TABLE `ray_role_menu`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_type`
  MODIFY `type_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
ALTER TABLE `ray_user`
  MODIFY `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',AUTO_INCREMENT=2;
ALTER TABLE `ray_user_cash`
  MODIFY `cash_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID';
ALTER TABLE `ray_user_level`
  MODIFY `level_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',AUTO_INCREMENT=2;
ALTER TABLE `ray_user_point`
  MODIFY `point_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID';
ALTER TABLE `ray_user_point_annal`
  MODIFY `annal_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID';
ALTER TABLE `ray_user_role`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_user_upoint`
  MODIFY `upoint_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID';
ALTER TABLE `ray_vod`
  MODIFY `vod_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_vod_collect`
  MODIFY `collect_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_vod_collect_type`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `ray_vod_player`
  MODIFY `player_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
ALTER TABLE `ray_vod_recycle`
  MODIFY `vod_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
