<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Art\Controller\Admin;

use App\Admin\Controller\Base;
use rayswoole\TaskManager;
use rayswoole\orm\facade\Db;
use App\Art\Extend\Common;
use rayswoole\Helper;
use voku\helper\HtmlDomParser;

class Custom extends Base
{

    public function index()
    {
        $this->fetch();
    }

    //返回截取查找的内容
    public function tsss($start,$end,$string)
    {
        return trim(str_replace($start,' ',substr($string,strpos($string, $start),strpos($string, $end)-strpos($string, $start) )));

    }

    //读取采集列表
    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $where = [];
            $where[]=['custom_mid','=',1];
            if (!empty($param['key']) && !empty($key['searchName'])) {
                $where[] = ['custom_name', 'like', "%{$key['searchName']}%"];
            }
            $data = Db::name('custom')->where($where)->order('custom_sort,custom_id','asc')->select()->toArray();
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $data, 'count' => count($data)]);
        }
    }

    //新增采集页面
    public function create()
    {

        $this->fetch();
    }
    //编辑自己定义采集页面
    public function edit()
    {
        $id = (int)$this->get('edit_id');

        $res=Db::name('custom')->where(['custom_id'=>$id])->find();

        $this->assign(['data' => $res]);
        $this->fetch();
    }

    //保存新增和修改的数据
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();

            $data=[
                'custom_name' => trim($param['custom_name']),
                'custom_list_url' => trim($param['custom_list_url']),
                'custom_list_url_label' => trim($param['custom_list_url_label']),
                'custom_info_url' => trim($param['custom_info_url']),
                'custom_page' => trim($param['custom_page']),
                'custom_play_from' => trim($param['custom_play_from']),
                'custom_pic'  => trim($param['custom_pic']),
                'custom_mid'  => trim($param['custom_mid']),
                'custom_type'  => trim($param['custom_type']),
                'custom_title' => trim($param['custom_title']),
                'custom_remark' => trim($param['custom_remark']),
                'custom_director' => trim($param['custom_director']),
                'custom_actor' => trim($param['custom_actor']),
                'custom_class' => trim($param['custom_class']),
                'custom_area' => trim($param['custom_area']),
                'custom_lang' => trim($param['custom_lang']),
                'custom_year' => trim($param['custom_year']),
                'custom_duration' => trim($param['custom_duration']),
                'custom_blurb' => trim($param['custom_blurb']),
                'custom_content' => trim($param['custom_content']),
                'custom_content_not' => trim($param['custom_content_not']),
                'custom_play_url' => trim($param['custom_play_url']),
                'custom_play_url_info' => trim($param['custom_play_url_info']),
            ];

            if(isset($param['custom_id'])!==''){
                $data['custom_id']=$param['custom_id'];
            }
            $res=Db::name('custom')->save($data);

            if ($res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '保存失败', 'data' => []]);
        }
    }

    /*
  * [updateField 字段值更新]
  * @method POST
  * @author C.
  * @time 2020/2/3 上午2:18
  */
    public function update_file()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'vod_status';
            $res = Db::name('custom')->update([
                $field => $value, 'custom_id'=>$id
            ]);
            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '更新失败', 'result' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '更新成功', 'result' => []]);
        }
    }
    //删除采集项
    public function delete()
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res= Db::name('custom')->delete($data);

            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '删除成功', 'data' => []]);
        }
    }

    //显示采集进度
    public function custom_collect()
    {
        $param=$this->get();
        $id = (int)$this->get('custom_id');
        $res=Db::name('custom')->where(['custom_id'=>$id])->find();

        $isNext = 1;
        $page=$param['page'] ?? 1;
        if(strpos($res['custom_page'],'-')){
            $page_num=explode('-',$res['custom_page']);
            $page_count=$page_num[1];
        }else{
            $page_count=$res['custom_page'];
        }

        $result=$this->artCollect($res,$page,$page_count);

        if ($page >= $page_count) {
            $isNext = 0;
        }

        $this->assign('page_count',$page_count);
        $this->assign('page',$page);
        $this->assign('res',$result['msg']);
        $this->assign('custom_id',$id);
        $this->assign('isNext',$isNext);
        return $this->fetch();

    }

    //采集数据
    public function artCollect($res,$page,$page_count)
    {
        //下载图片保留目录
        $path = '/static/upload/art/image/';
        $date = date("Y-m-d", time());
        $dir = RAY_ROOT . '/Public' . $path . $date . '/';

        $caijiurl=str_replace('(*)',$page,$res['custom_list_url']);
        $data=Helper::simpleHttp($caijiurl);
        if($data['code']!==200){
            return '采集出错了！';
        }
        $html = HtmlDomParser::str_get_html($data['body']);

        $arr=[];
        $href=[];
        $msg=[];
        foreach ($html->find($res['custom_list_url_label']) as $k=>$li) {
            $href[$k]['href']=$li->findOne($res['custom_info_url'])->href;
            $arr[$k]['art_pic']=$li->findOne($res['custom_pic'])->src;

            $data2=Helper::simpleHttp($href[$k]['href']);
            if($data2['code']!==200){
                return '采集出错了！';
            }
            $content = HtmlDomParser::str_get_html($data2['body']);
            //$content = HtmlDomParser::file_get_html($href[$k]['href']);
            $arr[$k]['art_title']=$content->findOne($res['custom_title'])->text;
            $arr[$k]['art_from']=$content->findOne($res['custom_remark'])->text; //custom_remark
            $arr[$k]['art_content']=str_replace($res['custom_content_not'],'',$content->findOne($res['custom_content'])->html);
            $arr[$k]['art_blurb']=Common::ray_substring(strip_tags($arr[$k]['art_content']),100,0);

            $arr[$k]['art_from']=$res['custom_remark'];
            $arr[$k]['type_id']=$res['custom_type'];
            $arr[$k]['art_addtime']=time();

            $info=Db::name("art")->where('art_title','=',$arr[$k]['art_title'])->find();
            if($info){
                $des=$arr[$k]['art_title'].'<font color="red">内容重复，跳过采集</font>';
                unset($arr[$k]);
            }else{
                $des='<font color="blue">新加入库，成功ok</font>';
            }
            if(isset($arr)){
                $msg[$k]= ($k + 1) .'、'. $arr[$k]['art_title'] . "<font>" .$des .'</font>'.'' ;
            }

        }

        if(is_array($arr)){
            Db::name('art')->insertAll($arr);

            foreach ($arr as $k=>$v){
                $result['pic']=$v['art_pic'];
                $result['art_title']=$v['art_title'];
                $result['dir']=$dir;
                $result['path']=$path;
                //异步保存图片
                $this->imageAsync($result);
            }

        }

        if($page>=$page_count){
            $des = '<font color="blue">数据采集完成</font>';
            array_push($msg,$des);
        }
        return ['msg'=>$msg];
    }



    //异步处理采集图片
    function imageAsync(array $arr)
    {
        TaskManager::getInstance()->async(static function () use ($arr){
            usleep(3000);
            $res=Common::getImage($arr['pic'],$arr['dir'],$arr['path']);
            if($res['code']==1){
                Db::name('art')->where(['art_title'=>$arr['art_title']])->update(['art_pic'=>$res['save_path']]);
            }
        });
    }





}