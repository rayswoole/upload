<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\Admin\Service;


use App\Admin\Model\AdminModel;
use rayswoole\Helper;
use rayswoole\Service;
use rayswoole\session\Session;

class AdminService extends Service
{

    public function getUser(array $where): ?array
    {
        $adminModel = new AdminModel();
        if ($res = $adminModel->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }


    public function login($user, $pwd): array
    {
        $user = $this->getUser(['account' => $user]);
        if ($user) {
            if (!password_verify($pwd, $user['password'])) {
                return ['code' => 0, 'msg' => '账户或密码错误', 'data' => []];
            }
            if (!$user['status']) {
                return ['code' => 0, 'msg' => '账号已被停用', 'data' => []];
            }
            $this->upUser((int)$user['id'], [
                'logintime' => time()
            ]);
            $role_id = Helper::service('UserRole')->getUserRole($user['id']);
            Session::set('id', $user['id']);
            Session::set('account', $user['account']);
            Session::set('nickname', $user['nickname']);
            Session::set('group', $user['group']);
            Session::set('role_id', $role_id[(int)$user['id']]);
            Session::flush();
            return ['code' => 1, 'msg' => '登录成功', 'data' => [
                'url' => Helper::url('index/index')
            ]];
        }
        return ['code' => 0, 'msg' => '用户不存在', 'data' => []];
    }

    public function checkPwd($pwd, $pwd2): array
    {
        if (false === $pwd || false === $pwd2) {
            return ['code' => 0, 'msg' => '密码验证失败', 'data' => []];
        }
        if ($pwd !== $pwd2) {
            return ['code' => 0, 'msg' => '两次密码不一样', 'data' => []];
        }
        $session = Session::all();
        if (empty($session['id'])) {
            return ['code' => 0, 'msg' => '未找到账号ID', 'data' => []];
        }
        $res = $this->upUser((int)$session['id'], [
            "password" => trim(password_hash($pwd, PASSWORD_DEFAULT))
        ]);
        if ($res) {
            Session::clear();
            return ['code' => 1, 'msg' => '修改成功,请重新登陆', 'data' => ['url' => Helper::url('/login/index')]];
        }
        return ['code' => 0, 'msg' => '修改失败,请稍后重试', 'data' => []];
    }

    public function upUser(int $id, array $data): bool
    {
        $res = AdminModel::find($id);
        foreach ($data as $k => $v) {
            $res->$k = $v;
        }
        return $res->save();
    }

    public function saveAdmin(array $data): bool
    {
        $model = new AdminModel();
        if (!empty($data['admin_id'])) {
            $model = $model->find($data['admin_id']);
        }
        return $model->save($data);
    }

}