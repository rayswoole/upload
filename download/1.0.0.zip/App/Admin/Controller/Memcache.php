<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;

use EasySwoole\EasySwoole\Config;
use rayswoole\Helper;

class Memcache extends Base
{
    public function index(): void
    {
        $data = Config::getInstance()->getConf('memcache');
        $this->assign($data);
        $this->fetch();
    }


    public function save(): ?bool
    {
        if ($this->isAjax()) {
            $data = Config::getInstance()->getConf('memcache');

            $status = $this->post('status',0);
            $server = $this->post('server',0);
            $port = (int)$this->post('port',0);
            $pool = $this->post('pool');
            $pool = array_map(function ($value){
                return (int)$value;
            }, $pool);

            $pool = array_merge($data['pool'], $pool);
            if ($pool['min']>=$pool['max']){
                return Helper::responseJson(['code' => 0, 'msg' => '最大连接数需要大于最小连接数', 'data' => []]);
            }

            if ($status == 1){
                $config = new \EasySwoole\Memcache\Config();
                $config->setHost($server)->setPort($port);
                $memcacheObj = new \EasySwoole\Memcache\Memcache($config);
                try {
                    $memcacheObj->connect();
                } catch (\EasySwoole\Memcache\Exception\ConnectException $exception){
                    return Helper::responseJson(['code' => 0,'msg' => $exception->getMessage()]);
                } finally {
                    $memcacheObj = null;
                    $config = null;
                }
            }

            $this->assign([
                'status'=>$status,
                'port'=>$port,
                'server'=>$server,
                'pool'=>$pool
            ]);
            $content = $this->fetch('tpl',false);
            $content  ="<?php\nreturn [\n".$content."\n];";
            file_put_contents(RAY_ROOT.'/Config/Memcache.php',$content);
            return Helper::responseJson(['code' => 1, 'msg' => '保存成功, 点击右上角【重启服务】使得配置生效', 'data' => []]);
        }
    }
}