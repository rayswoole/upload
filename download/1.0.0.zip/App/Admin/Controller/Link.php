<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;

use App\Admin\Service\ConfigService;
use rayswoole\orm\facade\Db;
use rayswoole\Helper;
use App\Vod\Extend\Upload;

class Link extends Base
{
    public function index(): void
    {
        $data = ConfigService::getInstance()->get('site');
        $this->assign($data);
        $skin = ConfigService::getInstance()->getDirarr();
        $this->assign(['temarry' => $skin]);
        $this->fetch();
    }

    public function create()
    {

        $this->fetch();
    }

    public function edit()
    {
        $param = $this->get('edit_id',0,'intval');

        $res=Db::name('link')->where(['link_id'=>$param])->find();

        if (!$res) {
            return false;
        }
        $this->assign(['data' => $res]);
        return $this->fetch();
    }

    public function read(): ?bool
    {
        if ($this->isAjax()) {
            $param = (array)$this->get();
            $page = isset($param['page']) ? intval($param['page']) : 1;
            $limit = isset($param['limit']) ? intval($param['limit']) : 10;
            $where = [];
            $by = 'link_id';

            if (isset($param['link_name']) && $param['link_name']) {
                $v = $param['link_name'];
                $where[] = ['link_name', 'like',"%{$v}%"];
            }
            $res=Db::name('link')->where($where)->order($by,'DESC')->limit(($page-1)*$limit,$limit)->select()->toArray();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '友链列表',
                'count' => count($res),
                'data' => $res
            ]);
        }
    }


    public function save(): ?bool
    {
        if ($this->isAjax()) {
            $param = $this->post();
            if (!$str = $this->post('link_name','','required')) {
                return  Helper::responseJson(['code' => 1, 'msg' => '标题不能为空或多于20个字', 'data' => []]);
            }
            $data = [
                "link_name" => htmlspecialchars($param['link_name']),
                "link_url" => htmlspecialchars(trim($param['link_url'])),
                "link_logo" => htmlspecialchars($param['link_logo']),
                "link_type" => htmlspecialchars($param['link_type']),
                "link_add_time" => time(),
                "link_sort" => intval($param['link_sort']),
            ];
            if (isset($param['edit_id'])) {
                $data['link_id']=$param['edit_id'];
            }

            $res = Db::name('link')->save($data);

            if ($res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存成功', 'data' => []]);
            } else {
                return Helper::responseJson(['code' => 0, 'msg' => '保存失败', 'data' => []]);
            }

        }
    }

    public function delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id=explode(',',$id);

            $res = Db::name('link')->delete($id);

            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除失败', 'result' => $res]);
            } else {
                return Helper::responseJson(['code' => 1, 'msg' => '删除成功', 'result' => $res]);
            }
        }
    }

    public function update_field()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? '';

            $res = Db::name('link')->update([
                $field => $value,'link_id'=>$id,'ad_addtime'=>time()
            ]);

            if (!$res) {
                return  Helper::responseJson(['code' => 0, 'msg' => '更新失败', 'result' => []]);
            }else{
                return  Helper::responseJson(['code' => 1, 'msg' => '更新成功', 'result' => []]);
            }

        }
    }


    /*
    * [upload 上传文件]
    * @method POST
    * @author C.
    * @date 2020/1/18 上午10:42
    */
    public function upload()
    {
        $param = $this->request()->getRequestParam();
        $field = 'image';
        $path = '/Public/static/upload/link/image/';
        if ($param) {
            switch ($param['type']) {
                case 'image':
                    $field = 'image';
                    $path = '/static/upload/link/image/';
                    break;
                case 'thumb':
                    $field = 'thumb';
                    $path = '/static/upload/link/thumb/';
                    break;
            }
        }
        $config = [
            'field' => $field,
            'notExistenceMsg' => '请选择要上传的图片',
            'size' => [
                'ext' => 1024 * 1024 * 5,
                'msg' => '图片不能大于5M'
            ],
            'type' => [
                'mediaType' => ['png', 'peng', 'jpg', 'jpeg', 'gif', 'jpeg', 'pem', 'ico'],
                'msg' => '文件类型不正确！'
            ],
            'path' => $path,
        ];
        $res = Upload::getInstance($this->request())->setConfig($config)->upload();
        return Helper::responseJson(['code' => $res['code'], 'msg' => $res['msg'], 'data' => $res['result']]);

    }

}