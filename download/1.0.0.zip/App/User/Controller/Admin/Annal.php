<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\User\Controller\Admin;


use App\User\Model\AnnalModel;
use App\User\Model\UserModel;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Annal extends Base
{

    public function index()
    {
        $userList = Db::name('user')->field('user_id,user_name')->select()->toArray();
        $this->assign([
            'userlist' => $userList
        ]);
        $this->fetch();
    }

    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $field = !empty($param['field']) ? $param['field'] : 'annal_id';
            $order = !empty($param['field']) ? $param['order'] : 'desc';
            $where = [];
            if (!empty($param['key'])) {
                $key = $param['key'];
                if (isset($key['time']) && $key['time'] && $t = $this->getTime($key['time'])) {
                    $where[] = ['a.annal_addtime', '>=', $t];
                }
                if (isset($key['user_id']) && $key['user_id']) {
                    $where[] = ['a.user_id', '=', (int)$key['user_id']];
                }
                if (isset($key['annal_datatype']) && $key['annal_datatype']) {
                    $where[] = ['a.annal_datatype', '=', (int)$key['annal_datatype']];
                }
            }
            $res = Db::name('user_point_annal')->alias('a')
                ->field('a.*,u.user_id,u.user_name,p.point_name')
                ->join('user u', 'a.user_id = u.user_id')
                ->join('user_point p', 'a.point_id = p.point_id')
                ->where('u.user_name <> "" ')
                ->where($where)->order($field, $order)->page($page, $limit)
                ->select()->toArray();
            $count = Db::name('user_point_annal')->alias('a')
                ->join('user u', 'a.user_id = u.user_id')
                ->where('u.user_name <> "" ')->where($where)->count();
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => $count]);
        }
    }

    public function delete()
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res = Helper::service('Annal')->deleteAnnal($data);
            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '删除成功', 'data' => []]);
        }
    }

    public function getTime($v)
    {
        $arr = ["-1 day", "-3 day", "-7 day", "-30 day", "-90 day",];
        return strtotime($arr[(int)$v - 1]);
    }
}