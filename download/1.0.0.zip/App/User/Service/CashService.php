<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Service;

use rayswoole\Helper;
use rayswoole\Service;
use rayswoole\orm\facade\Db;

class CashService extends Service
{

    //获取列表
    public function getData($param)
    {
        $page = isset($param['page']) ? (int)$param['page'] : 1;
        $limit = isset($param['limit']) ? (int)$param['limit'] : 10;
        $where = [];

        $order = 'cash_status';
        if (isset($param['key'])) {
            $key = $param['key'];
            if (isset($key['searchName']) && $key['searchName']) {
                $v = $key['searchName'];
                $where[] = ['cash_cashier','like',"%{$v}%"];
                //$where['site_id'] = ["%{$v}%", 'like', 'or'];
            }
        }

        $res = Db::name('user_cash')
            ->alias('c')
            ->leftJoin('user u','c.user_id=u.user_id')
            ->field('c.*,u.user_name')
            ->where($where)
            ->order($order,'ASC')
            ->limit($limit * ($page - 1),$limit)
            ->select()->toArray();

        return [
            'code' => 1,
            'msg' => '站点列表',
            'count' => count($res),
            'data' => $res
        ];

    }


///** [getList 获取列表数据]
    public function getList($where, ?string $by = null, ?string $order = 'ASC', string $field = '*', int $page = 1, int $limit = 999, int $start = 0): array
    {
        $res = $this->field($field);
        if ($by) {
            $res->order($by, $order);
        }
        if ($limit !== 0) {
            $limit = $limit ?: 20;
            $page = $limit * ($page - 1) + $start;
            $res->limit($page, $limit);
        }
        if (isset($where['indexBy'])) {
            $indexby = $where['indexBy'];
            unset($where['indexBy']);
            $dataX = $res->where($where)->indexBy($indexby);
        } else {
            $dataX = $res->select($where);
        }
        $data = [
            'count' => 0,
            'data' => $dataX,
        ];
        return $data;
    }

    //新增
    public function saveCash(array $param): array
    {
        $data = [
            "user_id"   => htmlspecialchars($param['user_id']),
            "cash_type" => htmlspecialchars($param['cash_type']),
            "cash_amount"   => htmlspecialchars($param['cash_amount']),
            "cash_integral" => htmlspecialchars($param['cash_integral']),
            "cash_cashier"  => htmlspecialchars($param['cash_cashier']),
            "cash_account"  => htmlspecialchars($param['cash_account']),
            "cash_backname" => htmlspecialchars($param['cash_backname']),
            "cash_status"   => isset($param['cash_status']) ?? 0,
        ];

        $res = Db::name('user_cash')->data($data)->save();

        if (!(bool)$res) {
            return ['code' => 0, 'msg' => '修改失败', 'result' => []];
        }
        return ['code' => 1, 'msg' => '修改成功', 'result' => []];
    }


    //修改
    public function updateData(array $param, $id)
    {

        $data = [
            "user_id"       => htmlspecialchars($param['user_id']),
            "cash_amount"   => htmlspecialchars($param['cash_amount']),
            "cash_integral" => htmlspecialchars($param['cash_integral']),
            "cash_cashier"  => htmlspecialchars($param['cash_cashier']),
            "cash_account"  => htmlspecialchars($param['cash_account']),
            "cash_backname" => htmlspecialchars($param['cash_backname']),
            "cash_status"   => $param['cash_status'],
        ];

        $where = [
            'cash_id' => $id
        ];
        if (is_array($id)) {
            $where = $id;
        }
        $res = Db::name('user_cash')->where($where)->update($data);
        if (!(bool)$res) {
            return ['code' => 0, 'msg' => '修改失败', 'result' => []];
        }
        return ['code' => 1, 'msg' => '修改成功', 'result' => []];

    }

    /**
     * 提现操作接口
     * 数据[user_id('用户id'),cash_integral('提现积分'),cash_type('提现方式')，cash_account（账号），cash_cashier（账户名，cash_backname（银行名））]
     * @param $param
     * @return bool
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/24
     */
    public function userCashSave($param){

        //判断现有积分是否够
        $where=['user_id'=>$param['user_id'],'p.point_id'=>1];
        $res = Helper::service('Point')->getUpoint($where);
        $isdraw=$res['upoint_withdraw']-$param['cash_integral'];

        if($isdraw<0){
            return ['code' => 1, 'msg' => '积分不够', 'data' => []];
        }

        //金额保留两位小数
        $cash_amount = number_format($param['cash_integral'] / $param['dscale'], 2);
        $data = [
            "user_id" => $param['user_id'],
            "cash_amount" => $cash_amount,
            "cash_account" => $param['cash_account'],
            "cash_type" => $param['cash_type'],
            "cash_integral" => $param['cash_integral'],
            "cash_cashier" => $param['cash_cashier'],
            "cash_backname" => $param['cash_backname'] ?? 0,
        ];
        //保存信息到cash 提现记录表
        Db::name('user_cash')->insert($data);

        $upoint = Helper::service('Point')->cashDownPoint($param);

        return $upoint;

    }










}