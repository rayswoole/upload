<?php


namespace App\User\Service;


use rayswoole\Helper;

class TagLibService extends \App\Vod\Service\TagLibService
{

    public function tagUser($tag): array
    {
        $tags = json_decode($tag, true);
        $target = !empty($tags['target']) && in_array($tags['target'], ['black', 'self']) ? $tags['target'] : 'alert';
        $classID = $tags['classId'] ?? '';
        $target = "{'login': '" . $target . "','registered':'" . $target . "'}";
        return [
            "<script>login.showBtn('" . $classID . "',$target);</script>\r\n"
        ];
    }

}