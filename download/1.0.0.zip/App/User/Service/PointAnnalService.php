<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Service;

use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class PointAnnalService extends Service
{

    //添加insert
    public function insertPointAnnal($data):bool
    {
        $res = Db::name('user_point_annal')->insert($data);

        return $res;
    }




}