<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-08-27 18:28
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Cron;


use App\Vod\Service\CollectService;
use rayswoole\TaskManager;
use rayswoole\CronTab;
use rayswoole\file\facade\File;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Vars;

class CollectCron extends CronTab
{

    function run(int $taskId, int $workerIndex)
    {
        $data = Db::name('vod_collect')->where('collect_timing_switch','=',1)->select();
        if (!$data){
            return;
        }
        foreach ($data->toArray() as $_data) {
            $timingTime = is_numeric($_data['collect_timing_time']) ? '*/'.$_data['collect_timing_time'] : $_data['collect_timing_time'];
            $timestamp = \Cron\CronExpression::factory('0 '.$timingTime.' * * *')->getNextRunDate()->getTimestamp();

            $runKey = 'vod_cron_collect_'.$_data['collect_id'];
            $runTime = File::getInstance()->get($runKey);
            if ($runTime != $timestamp){//当时间不等的时候，表示采集到点并且给出了下一个更新时间
                File::getInstance()->set($runKey, $timestamp);
                TaskManager::getInstance()->async(function () use ($_data){
                    $params = array(
                        'param'=>Helper::enJson([
                            'type'=>$_data['collect_type'],
                            'cjurl'=>$_data['collect_url'],
                            'ac'=>'videolist',
                            'h'=>24,
                            'cjflag'=>md5(urlencode($_data['collect_url']))
                        ]),
                        'page'=>0,
                    );
                    while (true) {
                        $params['page']++;
                        $data = CollectService::getInstance()->vod($params);
                        if (!isset($data['code']) || !isset($data['pagecount']) || $data['code'] != 1){
                            break;
                        }
                        $save_pic = Vars::get('vod.is_savepic',0);
                        CollectService::getInstance()->vod_data($data,'',$params['page'], $save_pic);
                        if ($params['page'] >= $data['pagecount']) {
                            break;
                        }
                    }
                });
            }
        }
    }

    function onException(\Throwable $throwable, int $taskId, int $workerIndex)
    {
        echo $throwable->getMessage();
    }
}