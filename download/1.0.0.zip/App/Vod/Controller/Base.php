<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Vod\Controller;


use rayswoole\Context;
use rayswoole\Helper;
use rayswoole\HookManager;
use rayswoole\HttpController;
use App\Vod\Extend\Upload;
use rayswoole\ReflectorClass;
use rayswoole\Vars;

class Base extends HttpController
{
    protected $classSpace = 'Index';
    protected $className = 'index';
    protected $actionName = 'index';
    public $template = null;
    protected $siteConfig = [];

    protected function onRequest(?string $action): ?bool
    {
        $error = Vars::get('ERROR');
        if (!is_null($error)) {
            $this->isAjax() ? Helper::responseJson(['code'=>0, 'msg'=>$error],500) : Helper::responseHtml($error,500);
            return false;
        }
        $this->siteConfig = array_merge(Vars::get('site'), Vars::get('vod'), Vars::get('art'));
        $this->siteConfig['config'] = Vars::get('system');

        //查找邀请码
        if ($invite = $this->param('invite')){
            $this->response()->setCookie('INVITE', Helper::enJson(['invite'=>$invite]), time()+(3600*24*30));
        }
        $isMobile = $this->isMobile();
        if ($isMobile || Helper::getRequest('HTTP_HOST','server') == Vars::get('site.site_wap_url')) {
            $this->siteConfig['template'] = $this->siteConfig['site_wap_template'];
            $this->siteConfig['path_html'] = $this->siteConfig['site_wap_tempath'] ?? 'html';
        } else {
            $this->siteConfig['template'] = $this->siteConfig['site_pc_template'];
            $this->siteConfig['path_html'] = $this->siteConfig['site_pc_tempath'] ?? 'html';
        }
        $this->siteConfig['path'] = '/';
        $this->siteConfig['path_tpl'] = '/skin/' . $this->siteConfig['template'] . '/';
        $this->siteConfig['mid'] = 1;
        $this->siteConfig['aid'] = $this->getAid();
        $this->siteConfig['mob_status'] = $isMobile ? 1 : 0;
        $this->siteConfig['type_id'] = 0;
        $this->siteConfig['type_pid'] = 0;

        //兼容苹果10的模板标签
        $this->siteConfig['art_extend_class'] = '';
        $this->siteConfig['search_hot'] = $this->siteConfig['vod_search_hot'];
        $this->siteConfig['vod_extend_state'] = '';
        $this->siteConfig['vod_extend_version'] = '';
        $this->siteConfig['vod_extend_weekday'] = '';

        //hook siteConfigInit
        $this->siteConfig = HookManager::getInstance()->trigger('Vod','siteConfigInit',$this->siteConfig);

        return true;
    }

    protected function getAid()
    {
        $class = ReflectorClass::getInstance()->getShortName(static::class);
        $controllers = ['Index'=>10,'Type'=>11,'Show'=>12,'Search'=>13,'Detail'=>14,'Play'=>15,'Down'=>16];
        return $controllers[$class] ?? 0;
    }

    protected function uploadFile(array $config): array
    {
        return Upload::getInstance($this->request())->setConfig($config)->upload();
    }

    protected function fetch(string $file = '', bool $output = true, array $config = []):?string
    {
        Context::set('raycms', $this->siteConfig);
        $this->assign(['raycms'=>$this->siteConfig]);
        return parent::fetch($file, $output);
    }

    //获取模板路径
    protected function getViewPath(): string
    {
        return 'Public/skin/' . $this->siteConfig['template'] . '/' . $this->siteConfig['path_html'] . '/';
    }
}