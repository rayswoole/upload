'use strict';
var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (e) {
    return typeof e
} : function (e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
};
!function (win) {

    const re = function re() {
        this.o = [];
        this.v = [];
    };

    re.prototype.init = function () {
        this.time = '201912310860';
        this._tabUrlHash();
        $('.xxx .top_nav').on('click', '.x', function (e) {
            const xg = xadmin.get_cate_data(), d = $(this).data('open');
            $('.left-nav').animate({width: '220px'}, 100);
            $('.page-content').animate({left: $(window).width() < 768 ? '0px' : '220px'}, 100);
            $('.left-nav i').css('font-size', '14px');
            $('.left-nav cite,.left-nav .nav_right').show();
            if ($(window).width() < 768) {
                $('.page-content-bg').show();
            }
            if (d !== '') {
                $('.left-nav #nav').children('div').slideUp();
                if (!$('.left-nav #nav').find('div[data-en=' + d + ']').stop(true, true).slideDown().children('li').hasClass('open')) {
                    $('.left-nav #nav').find('div[data-en=' + d + ']').eq(0).slideDown();
                    $('.left-nav #nav').find('div[data-en=' + d + ']').eq(0).children('li').children('.sub-menu').slideDown();
                }
                cre._setTopNavData({
                    key: 'topnav',
                    value: $('.xxx .top_nav .x').index($(this))
                });
            }
            e.stopPropagation();
        });
        if ($.isEmptyObject(cre._getTopNavData())) {
            $('.xxx .top_nav .x:first-child').click();
            cre._setTopNavData({
                key: 'topnav',
                value: 0
            });
        }
        this.button._init();
    };

    /**
     * 只作为初始化覆盖$.ajax
     * 必须传入load=true，才能显示加载层，避免全局污染
     * @private
     */
    re.prototype._initAjax = function () {
        let ajax = $.ajax, _t = this;
        $.ajax = function (opt, conf) {
            opt = $.extend({}, {
                url: '', data: {}, async: true, headers: {}, type: 'post', dataType: 'json',
                beforeSend: function (e) {
                }, success: function (e) {
                }, error: function (e, m) {
                }
            }, opt), conf = $.extend({}, {
                time: 3 * 1000,
                msg: '正在处理数据中...',
            }, conf);
            const success = opt.success, error = opt.error, beforeSend = opt.beforeSend;
            opt.success = opt.load ? function (e) {
                setTimeout(function () {
                    _t.loadclose();
                    success(e)
                }, conf.time);
            } : opt.success, opt.error = opt.load ? function (e, m) {
                setTimeout(function () {
                    _t.loadclose();
                    error(e, m);
                }, conf.time);
            } : opt.error, opt.beforeSend = opt.load ? function (e) {
                _t.load(conf.msg);
                beforeSend(e);
            } : opt.beforeSend, delete opt.load;
            return ajax(opt)
        };
    };

    // 获取请求参数
    re.prototype.urlParam = function (val) {
        let name, value, str = location.href, num = str.indexOf("?"), param = [];
        str = str.substr(num + 1);
        const arr = str.split("&");
        for (let i = 0; i < arr.length; i++) {
            num = arr[i].indexOf("=");
            if (num > 0) {
                name = arr[i].substring(0, num);
                value = arr[i].substr(num + 1);
                param[name] = value;
            }
        }
        return param[val] ? param[val] : param;
    };

    // 是否为PC端
    re.prototype.isPC = function () {
        const userAgent = navigator.userAgent.toLowerCase()
            , ipad = userAgent.match(/ipad/i) === "ipad"
            , iphone = userAgent.match(/iphone os/i) === "iphone os"
            , midP = userAgent.match(/midp/i) === "midp"
            , rv = userAgent.match(/rv:1.2.3.4/i) === "rv:1.2.3.4"
            , ucWeb = userAgent.match(/ucweb/i) === "ucweb"
            , android = userAgent.match(/android/i) === "android"
            , winCe = userAgent.match(/windows ce/i) === "windows ce"
            , winMobile = userAgent.match(/windows mobile/i) === "windows mobile";
        return !(ipad || iphone || midP || rv || ucWeb || android || winCe || winMobile);
    };

    // 允许环境
    re.prototype.envType = function () {
        let u = navigator.userAgent
            , isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1
            , isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
        if (isAndroid) {
            return 'android';
        } else if (isiOS) {
            return 'ios';
        } else {
            return 'win';
        }
    };

    // 检测是微信还是支付宝
    re.prototype.isAlipayOrWechat = function () {
        let payEnv = '';
        if (/MicroMessenger/.test(window.navigator.userAgent)) {
            payEnv = 'weixin';
        } else if (/AlipayClient/.test(window.navigator.userAgent)) {
            payEnv = 'alipay';
        } else {
            payEnv = 'others';
        }
        return payEnv;
    };

    // 转义html标签
    re.prototype.htmlEncode = function (str) {
        if (str.length === 0) return "";
        return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/ /g, "&nbsp;").replace(/\'/g, "&#39;").replace(/\"/g, "&quot;");
    };

    // 还原html标签
    re.prototype.htmlDecode = function (str) {
        if (str.length === 0) return "";
        return str.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ").replace(/&#39;/g, "\'").replace(/&quot;/g, "\"");
    };

    // 是否为数字类型
    re.prototype.isDigit = function (val) {
        const preg = /^[0-9]*$/;
        return !(preg.exec(val) == null || val === "");
    };

    // 加入收藏夹
    re.prototype.addFavorite = function (url, title) {
        url = url || window.location;
        title = title || document.title;
        const ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf("360se") > -1) {
            alert("由于360浏览器功能限制，请按 Ctrl+D 手动收藏！");
        } else if (ua.indexOf("msie 8") > -1) {
            window.external.AddToFavoritesBar(url, title);
        } else if (document.all) {
            try {
                window.external.addFavorite(url, title);
            } catch (e) {
                alert('您的浏览器不支持,请按 Ctrl+D 手动收藏!2');
            }
        } else if (window.sidebar) {
            window.sidebar.addPanel(title, url, "");
        } else {
            alert('您的浏览器不支持,请按 Ctrl+D 手动收藏!');
        }
    };

    // 去除左右字符
    re.prototype.trim = {
        ltrim: function (str) {
            const reg_str = /^\s*/g;
            return str.replace(reg_str, "");
        },
        rtrim: function (str, r) {
            const reg_str = /\s*$/g;
            return str.replace(reg_str, "");
        },
        strim: function (str) {
            const reg_str = /(^\s*)|(\s*$)/g;
            return str.replace(reg_str, "");
        }
    };

    // 验证域名
    re.prototype.checkDomain = function (val) {
        const reg = /^([\w\u4e00-\u9fa5\-\*]{1,100}\.){1,4}([\w\u4e00-\u9fa5\-]{1,24}|[\w\u4e00-\u9fa5\-]{1,24}\.[\w\u4e00-\u9fa5\-]{1,24})$/;
        return reg.test(val);
    };

    // 渲染表格
    re.prototype.renderTable = function (opt) {
        opt.cols[0].unshift({type: 'checkbox', fixed: 'left', align: 'center', width: 50});
        opt = $.extend({}, {
            elem: '#DataTable', url: '', title: '数据表格',
            totalRow: false, loading: true,
            id: this.randomStr(), even: true, skin: 'nob', page: true,
            cols: [[{}]], limit: 20,
            height: 'full-' + ($(parent).height() - $(document).height() + 15 + Math.floor($('#DataTable').parent().parent().offset().top))
        }, opt);
        this.elem = layui.table.render(opt);
        this._tableSortEvent();
        return this.elem;
    };

    // 获取数据表格ID
    re.prototype.getTableId = function () {
        return this.elem.config.id;
    };

    // 表格排序
    re.prototype._tableSortEvent = function () {
        const _t = this;
        this.tableToolEvent('sort(' + $(this.elem.config.elem).attr('lay-filter') + ')', function (obj) {
            _t.elem.reload({
                initSort: obj
                , where: {
                    field: obj.field
                    , order: obj.type
                }
            });
        });
        return !0;
    };

    /**
     * 表格行内事件,无需自行写ifk
     * cre.tableToolEvent('tool(elem)',{
     *     create : function(){},
     *     edit : function(){},
     *     ...
     * })
     * @param elem 绑定元素
     * @param even 事件对象|函数
     * @returns {*}
     */
    re.prototype.tableToolEvent = function (elem, even) {
        return layui.table.on(elem, function (obj) {
            const data = obj.data,
                event = obj.event;
            _typeof(even) === 'function' ? even.call(this, obj) : even[event] ? even[event].call(this, data) : '';
        });
    };

    // 文件上传
    re.prototype.upload = function (opt) {
        let _t = this, done = '', l = null, d = null, uploadElem = '', bef = '', err = '';
        opt = $.extend({}, {
            elem: "#image",
            field: 'image',
            data: {},
            url: "",
            accept: 'image',
            exts: '',
            previewImg: '#uploadPreviewImg',
            errorReload: true,
            errorElem: '#uploadElem',
            load: true,
            loadHtml: '<i class="layui-icon layui-anim layui-anim-rotate layui-anim-loop">&#xe63d;</i><span>正在上传中，请稍后</span>',
            loadDisGlobal: false,
            delayed: 1,
            done: function (e, a, i) {
            }
        }, opt);
        const defH = $(opt.elem).html(), upLoad = {
            l: function () {
                $(opt.elem).html(opt.loadHtml), (!(opt.loadDisGlobal) || ($("input[type=button]").attr("disabled", "disabled").addClass('isUpDis'), $("button").attr("disabled", "disabled").addClass('isUpDis'))), $(opt.elem).attr("disabled", "disabled").addClass('isUpDis');
            },
            d: function () {
                $(opt.elem).html(defH), (!(opt.loadDisGlobal) || $("input[type=button]").attr("disabled", false).removeClass('isUpDis'), $("button").attr("disabled", false).removeClass('isUpDis')), $(opt.elem).attr("disabled", false).removeClass('isUpDis');
            }
        };
        done = opt.done, bef = opt.before, err = opt.error;
        opt.load ? l = upLoad.l : (l = new Function(), opt.delayed = .5);
        d = upLoad.d;
        !(opt.exts.length < 1) || (opt.exts = (opt.accept !== 'image') ? 'zip|rar|7z|tar.gz|gz|doc|docx|xlsx|txt|sql|xml|html|xhtml' : 'png|peng|jpg|jpeg|gif|pem|ico');
        opt.before = (opt.accept === 'image') ? (_typeof(bef) === 'function' ? function (e) {
            return l(), bef(e);
        } : function (e) {
            e.preview(function (index, file, result) {
                $(opt.previewImg).attr('src', result);
            }), l();
        }) : _typeof(bef) === 'function' ? function (e) {
            return l(), bef(e);
        } : function () {
            return l();
        };
        opt.done = function (e, a, i) {
            setTimeout(function () {
                return d(), done(e, a, i);
            }, parseInt(opt.delayed) * 1000);
        };
        opt.error = _typeof(err) !== 'function' ? function (o, z) {
            return d(), !(opt.errorReload && opt.errorElem) || (uploadElem = $(opt.errorElem),
                uploadElem.html('<span style="color: #FF5722; line-height: 35px; display: inline-block">上传失败</span> <a class="layui-btn layui-btn-xs error-reload">重试</a>'),
                uploadElem.children('.error-reload').on('click', function () {
                    _t.o[opt.errorElem].upload();
                }));
        } : function (o, z) {
            return d(), err(o, z);
        };
        return _t.o[opt.errorElem] = layui.upload.render(opt);
    };

    // 表单提交事件
    re.prototype.submit = function (opt) {
        const _t = this;
        opt = $.extend({}, {
            elem: '',
            url: '',
            data: {},
            verify: {},
            type: 'post',
            loadType: 'alert',
            loadHtml: '<i class="layui-icon layui-anim layui-anim-rotate layui-anim-loop">&#xe63d;</i><span>正在处理数据，请稍后</span>',
            loadDisGlobal: false,
            success: function (e) {
                console.log(e);
            }
        }, opt);
        let reg = /\w+\(([\w]+)\)/i,
            elem = $('button[lay-filter="' + reg.exec(opt.elem)[1] + '"]');
        const defH = elem.html(), load = {
            l: function () {
                elem.html(opt.loadHtml), (!(opt.loadDisGlobal) || ($("input[type=button]").attr("disabled", "disabled").addClass('isUpDis'), $("button").attr("disabled", "disabled").addClass('isUpDis'))), elem.attr("disabled", "disabled").addClass('isUpDis');
            },
            d: function () {
                elem.html(defH), (!(opt.loadDisGlobal) || $("input[type=button]").attr("disabled", false).removeClass('isUpDis'), $("button").attr("disabled", false).removeClass('isUpDis')), elem.attr("disabled", false).removeClass('isUpDis');
            }
        };
        (Object.keys(opt.verify).length <= 0) || layui.form.verify(opt.verify);
        return layui.form.on(opt.elem, function (d) {
            !(opt.loadType === 'button') || load.l();
            opt.data = Object.keys(opt.data).length > 0 ? opt.data : d.field;
            const l = opt.loadType === 'alert';
            opt.type === 'post' ? _t.post(opt.url, opt.data, function (e) {
                load.d();
                opt.success(e);
            }, l) : _t.get(opt.url, opt.data, function (e) {
                load.d();
                opt.success(e);
            }, l);
            return !1;
        });
    };

    // 按钮事件，按钮友好显示加载状态
    re.prototype.button = {
        _init: function (opt) {
            opt = Object.assign({
                elem: 'rayBtn',
                load: true,
                loadHtml: '<i class="layui-icon layui-anim layui-anim-rotate layui-anim-loop">&#xe63d;</i><span>程序正在处理，请稍后</span>',
                loadDisGlobal: false,
                delayed: .5
            }, opt);
            let c = document.getElementsByClassName(opt.elem), i = 0, l = '', d = '', _t = this, t = {
                l: function (e) {
                    (e.innerHTML = opt.loadHtml), (!(opt.loadDisGlobal) || (document.getElementsByTagName('button').setAttribute("disabled", "disabled"))), e.setAttribute("disabled", "disabled");
                }, d: function (e, d) {
                    (e.innerHTML = d), (!(opt.loadDisGlobal) || (document.getElementsByTagName('button').removeAttribute("disabled"))), e.removeAttribute("disabled");
                }
            };
            for (; i < c.length; i++) {
                let elem = c[i], def = elem.innerHTML, e = elem.getAttribute('id') || elem.getAttribute('event');
                d = t.d, (opt.load ? l = t.l : (l = new Function(), opt.delayed = .5));
                def = def || '';
                elem.addEventListener('click', function () {
                    l(elem);
                    setTimeout(function () {
                        d(elem, def);
                        !(cre.v[e]) || cre.v[e].call(this, elem);
                    }, opt.delayed * 1000);
                }, false);
            }
            return !0;
        },
        on: function (event) {
            if (Object.keys(event).length <= 0) return !0;
            Object.keys(event).forEach(function (i) {
                cre.v[i] = event[i];
            });
        }
    };

    // 富文本编辑起
    re.prototype.layedit = function (opt) {
        opt = $.extend({}, {
            elem: 'details',
            url: '',
            accept: 'image',
            acceptMime: 'image/*',
            exts: 'jpg|png|gif|bmp|jpeg',
            size: '10240',
            field: 'image',
            devmode: true,
            hide: true,
            type: 'post',
            data: {},
            default: 'javascript',
            tool: [
                'code', 'strong', 'italic', 'underline', 'del', 'addhr', '|', 'fontFomatt', 'colorpicker', 'face'
                , '|', 'left', 'center', 'right', '|', 'link', 'unlink', 'image', 'anchors'
                , '|'
            ],
            height: 366
        }, opt);
        return layui.layedit.build(opt.elem, {
            uploadImage: {
                url: opt.url,
                accept: opt.accept,
                acceptMime: opt.acceptMime,
                exts: opt.exts,
                size: opt.size,
                field: opt.field,
                data: opt.data,
                type: opt.type
            }
            , devmode: opt.devmode
            , codeConfig: {
                hide: opt.hide,
                default: opt.default
            }
            , tool: opt.tool
            , height: opt.height
        })
    };

    // 生成随机字符串
    re.prototype.randomStr = function (len) {
        len = len || 16;
        let char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', str = '', maxLen = char.length;
        for (let i = 0; i < len; i++) {
            str += char.charAt(Math.floor(Math.random() * maxLen));
        }
        return str;
    };

    // cookie
    re.prototype.cookie = {
        set: function set(key, val, path, expires) {
            const i = new Date;
            path = path || "/", expires = expires || 1, i.setTime(i.getTime() + 60 * expires * 60 * 1e3),
                document.cookie = key + "=" + escape(val) + ";path=" + path + (null === expires ? "" : "; expires=" + i.toUTCString())
        },
        get: function get(key) {
            const t = new RegExp("(^| )" + key + "=([^;]*)(;|$)");
            return document.cookie.match(t) ? unescape(document.cookie.match(t)[2]) : null
        },
        del: function del(key) {
            return this.setCookie(key, "", "/", 0), !0;
        }
    };


    /**
     * 快速发起post请求
     * @param url 请求地址
     * @param data 请求参数
     * @param suc 成功回调
     * @param opt
     */
    re.prototype.post = function (url, data, suc, opt) {
        const _t = this;
        let load = opt, to = 800;
        if (_typeof(opt) === "object") {
            opt.timeout = opt.timeout < 1000 ? 1000 : parseInt(opt.timeout);
            opt = Object.assign({
                load: true,
                timeout: 1000
            }, opt);
            load = opt.load;
            to = opt.timeout;
        }
        !(false !== load) || this.load(null, true);
        $.ajax({
            url: url, data: data, async: true, type: 'post', dataType: "json",
            success: function success(e) {
                setTimeout(function () {
                    _t.loadclose(true);
                    if (e.code < 1) {
                        _t.alert(e.msg, {}, true);
                    } else {
                        _t.msg(e.msg, {
                            time: 800
                        }, true);
                        !(window.name && parent.layer.getFrameIndex(window.name)) || _t.fclose();
                    }
                    suc(e);
                }, to);
            },
            error: function error(e, m) {
                _t.loadclose(true);
                _t.alert('远程服务器异常', {}, true);
            }
        });
    };

    /**
     * 快速发起get请求
     * @param url 请求地址
     * @param data 请求参数
     * @param suc 成功回调
     * @param opt
     */
    re.prototype.get = function (url, data, suc, opt) {
        const _t = this;
        let load = opt, to = 800;
        if (_typeof(opt) === "object") {
            opt.timeout = opt.timeout < 1000 ? 1000 : parseInt(opt.timeout);
            opt = Object.assign({
                load: true,
                timeout: 1000
            }, opt);
            load = opt.load;
            to = opt.timeout;
        }
        !(false !== load) || this.load(null, true);
        $.ajax({
            url: url, data: data, async: true, type: 'get', dataType: "json",
            success: function success(e, s) {
                setTimeout(function () {
                    _t.loadclose(true);
                    if (e.code < 1) {
                        _t.alert(e.msg, {}, true);
                    } else {
                        _t.msg(e.msg, {
                            time: 800
                        }, true);
                        !(window.name && parent.layer.getFrameIndex(window.name)) || _t.fclose();
                    }
                    suc(e);
                }, to)
            },
            error: function error(e, m) {
                _t.loadclose(true);
                _t.alert('远程服务器异常', {}, true);
            }
        });
    };

    // 时间戳转日期
    re.prototype.timeFormat = function (time) {
        if (time === 0) return time;
        var n = new Date(time * 1000);
        var y = n.getFullYear();
        var mon = n.getMonth() + 1;
        var d = n.getDate().toString().length === 1 ? '0' + n.getDate().toString() : n.getDate();
        var h = n.getHours().toString().length === 1 ? '0' + n.getHours().toString() : n.getHours();
        var m = n.getMinutes().toString().length === 1 ? '0' + n.getMinutes().toString() : n.getMinutes();
        var s = n.getSeconds().toString().length === 1 ? '0' + n.getSeconds().toString() : n.getSeconds();
        return y + "-" + mon + "-" + d + "   " + h + ":" + m + ":" + s;
    };


    /**
     * 友好显示时间戳区间之差
     * @param {number} s 开始时间
     * @param {number} e 结束时间
     * @param [format=d-h-m-s]
     * @returns {string}
     */
    re.prototype.timeToDay = function (s, e, format) {
        if (e < s) return '结束时间不能小于开始时间';
        let m = '',
            f = '';
        s = new Date(s).getTime();
        e = new Date(e).getTime();
        format = format || 'd-h-m-s';
        const mss = e - s;
        if (isNaN(mss)) return '时间格式不合法';
        const xx = {
            d: function d() {
                return parseInt(mss / (1000 * 60 * 60 * 24)) + " 天 ";
            },
            h: function h() {
                return parseInt(mss % (1000 * 60 * 60 * 24) / (1000 * 60 * 60)) + " 小时 ";
            },
            m: function m() {
                return parseInt(mss % (1000 * 60 * 60) / (1000 * 60)) + " 分钟 ";
            },
            s: function s() {
                return mss % (1000 * 60) / 1000 + " 秒 ";
            }
        };
        f = format.split('-');
        try {
            $.each(f, function (i, a) {
                if (a != '') {
                    m += xx[a].call(this);
                }
            });
            return m;
        } catch (e) {
            console.log(e.message);
        }
    };

    // 加载层
    re.prototype.load = function (msg, parent) {
        msg = msg || "<i class='layui-icon layui-anim layui-anim-rotate layui-anim-loop'>&#xe63d;</i><p>正在提交程序中...</p>";
        this.index_msg = this.msg(msg, {
            time: 0,
            anim: 5,
        }, parent);
    };

    // 关闭加载层
    re.prototype.loadclose = function (parent, name) {
        name = name || this.index_msg;
        return parent ? (window.parent.layer.close(name), layer.close(name)) : layer.close(name);
    };

    // 关闭所有层
    re.prototype.loadcloseAll = function (parent) {
        return parent ? (parent.layer.closeAll(), layer.closeAll()) : layer.closeAll();
    };

    // 弹出层
    re.prototype.open = function (title, content, type, width, height, endBack, isFul, parent) {
        title = title || !1, type = type || 2, content = content || "404.html",
            width = ((width > window.innerWidth ? '' : width) || .9 * window.innerWidth) ,
            height = ((height > window.innerHeight ? '' : height) || window.innerHeight - 50),
            endBack = endBack || function () {
            };
        const alt = parent ? window.parent.layer.open : layer.open;
        let index = alt({
            type: type,
            area: [width + "px", height === 'auto' ? 'auto' : height + "px"],
            fixed: false,
            maxmin: false,
            shadeClose: !1,
            shade: .1,
            title: title,
            content: content,
            scrollbar: false,
            end: function (e) {
                endBack(e)
            }
        });
        isFul && layer.full(index)
    };

    // 快捷弹出iframe框，默认根据父级弹出
    re.prototype.iframe = function (title, content, endBack, ifFul) {
        let w = parent.window.innerWidth * .7, h = parent.window.innerHeight * .8;
        endBack = _typeof(endBack) === "function" ? endBack : new Function();
        return this.open(title, content, 2, w, h, endBack, ifFul, true);
    };

    // 消息框
    re.prototype.msg = function (msg, opt, parent) {
        let alt = parent ? window.parent.layer.msg : layer.msg;
        opt = $.extend({}, {
            time: 0,
            shade: .1,
            type: 1,
            anim: 5,
            scrollbar: false,
            zIndex: this.time
        }, opt);
        return alt(msg, opt);
    };

    // 提示框
    re.prototype.alert = function (msg, opt, parent) {
        let alt = parent ? window.parent.layer.alert : layer.alert;
        opt = $.extend({}, {
            skin: 'layui-layer-lan'
            , title: '错误提示'
            , closeBtn: 0
            , shade: .1
            , anim: 5,
            btn: ['确定']
        }, opt);
        alt(msg, opt);
    };

    // 对话框
    re.prototype.confirm = function (msg, opt, endBack, parent) {
        let alt = (parent !== false) ? window.parent.layer.alert : layer.alert, _t = this;
        opt = $.extend({}, {
            btn: ['是的', '点错了'],
            title: '消息提示'
        }, opt);
        alt(msg, opt, function (e) {
            _t.loadclose((parent !== false), e);
            endBack(e);
        });
    };

    // 关闭父级弹出层
    re.prototype.fclose = function () {
        parent.layer.close(parent.layer.getFrameIndex(window.name));
    };

    // url信息
    re.prototype.url = {
        'path': function () {
            return win.location.pathname;
        },
        'domain': function () {
            return win.location.origin;
        }
    };

    // 用户token
    re.prototype.userToken = function () {
        if (this.cookie.get('ULTOKEN') !== undefined && this.cookie.get('ULTOKEN') !== null) {
            return !!JSON.parse(this.cookie.get('ULTOKEN')).token ? JSON.parse(this.cookie.get('ULTOKEN')).token : undefined;
        }
    };

    // 用户名
    re.prototype.userName = function () {
        if (this.cookie.get('ULTOKEN') !== null && this.cookie.get('ULTOKEN') !== undefined) {
            return !!JSON.parse(this.cookie.get('ULTOKEN')).user_name ? JSON.parse(this.cookie.get('ULTOKEN')).user_name : undefined;
        }
    };

    // 登录按钮
    re.prototype.loginBtn = function (name) {
        if (!name) return false;
        if ($.cookie !== undefined && this.userToken()) {
            $(name).html('<a href="javascript:;" class="username">' + this.userName() + '</a>\n                <dl class="layui-nav-child">\n                    <dd>\n                        <a href="/user/index/userinfo">个人信息</a></dd>\n                    <dd>\n                        <a href="/user/login/loginout">切换帐号</a></dd>\n                    <dd>\n                        <a href="/user/login/loginout">退出</a></dd>\n                </dl>\n            </li>');
        }
        return true;
    };

    // 禁止回车提交
    re.prototype.disEnter = function () {
        $(document).keydown(function (event) {
            if (event.keyCode === 13) {
                return false;
            }
        });
    };

    // 脚本
    re.prototype.getScript = {
        isInclude: function isInclude(name) {
            var js = /js$/i.test(name);
            var es = document.getElementsByTagName(js ? 'script' : 'link');
            for (var i = 0; i < es.length; i++) {
                if (es[i][js ? 'src' : 'href'].indexOf(name) !== -1) return true;
            }
            return false;
        },
        load: function load(n, c) {
            if (!this.isInclude(n)) {
                c = c || new Function();
                $.ajax({
                    url: n, async: false, dataType: "script", cache: true,
                    success: function success(se) {
                        return c(se);
                    }
                });
            }
        }
    };

    // 二维码
    re.prototype.QRcode = {
        get: function get(cn, text, w, h, cd, cl, le) {
            try {
                cre.getScript.load('/static/js/qrcode.min.js');
                this.qrcode_test = text;
                return this.qrcode = new QRCode(cn, {
                    text: text,
                    width: w || 128,
                    height: h || 128,
                    colorDark: cd || "#000000",
                    colorLight: cl || "#ffffff",
                    correctLevel: le || QRCode.CorrectLevel.H
                });
            } catch (e) {
                layui.layer.msg(e.message);
            }
        },
        reload: function reload() {
            null != this.qrcode && this.qrcode.makeCode(this.qrcode_test + (-1 !== this.qrcode_test.indexOf("?") ? "&" : "?&") + "_t=" + (new Date).getTime());
        }
    };


    // 生成缓存名称
    re.prototype._layuiDataName = function () {
        return 'topazx' + cre.url.path().replace(/(^\/)|(\/$)/g, "").split('/')[0];
    };

    // 设置导航缓存数据
    re.prototype._setTopNavData = function (data) {
        if (data != null) {
            layui.data(this._layuiDataName(), data);
        }
    };

    // 读取导航缓存数据
    re.prototype._getTopNavData = function () {
        return layui.data(this._layuiDataName());
    };

    // 删除数据
    re.prototype._delTopNavData = function (id) {
        id = id | 'topnav';
        if (typeof id != "undefined") {
            layui.data(this._layuiDataName(), {
                key: id,
                remove: true
            });
        } else {
            layui.data(this._layuiDataName(), null);
        }
    };

    // tab地址hash
    re.prototype._tabUrlHash = function () {
        const layId = location.hash.replace(/^#urlHash=/, ''),
            parentLayId = parent.location.hash.replace(/^#parentUrlHash=/, ''), _t = this;
        layui.element.tabChange('test', layId.split('_')[0]);
        layui.element.on('tab(test)', function (elem) {
            location.hash = 'urlHash=' + $(this).attr('lay-id') + '_' + _t.randomStr();
        });
        layui.element.tabChange('test', parentLayId.split('_')[0]);
        layui.element.on('tab(test)', function (elem) {
            parent.location.hash = 'parentUrlHash=' + $(this).attr('lay-id') + '_' + _t.randomStr();
        });
    };

    // 结束执行
    re.prototype.end = function () {
        const top_list = this._getTopNavData();
        $.each(top_list, function (i, v) {
            if (_typeof(top_list[i]) !== undefined) {
                layui.jquery('.xxx .top_nav .x').eq(top_list[i]).click();
            }
        });
    };


    /******************** 丢弃方法 ********************/

    /**
     * @deprecated
     */
    re.prototype.xpost = function (u, x, b, c, e) {
        $.ajax({
            url: u, data: x, async: true, type: 'post', dataType: "json", load: true,
            beforeSend: function beforeSend(be) {
                b(be);
            },
            success: function success(se) {
                c(se);
            },
            error: function error(er) {
                e(er);
            }
        });
    };

    /**
     * @deprecated
     */
    re.prototype.xget = function (u, x, b, c, e) {
        $.ajax({
            url: u, data: x, async: true, type: 'get', dataType: "json",
            beforeSend: function beforeSend(be) {
                b(be);
            },
            success: function success(se) {
                c(se);
            },
            error: function error(er) {
                e(er);
            }
        });
    };

    /**
     * @deprecated
     */
    re.prototype.usertoken = function () {
    };

    /**
     * @deprecated
     */
    re.prototype.username = function () {
    };


    win.cre = new re();

}(window);

layui.use(['layer', 'element', 'jquery'], function () {
    if (_typeof(window.$) === "undefined" || _typeof(window.$) !== "function") {
        window.$ = layui.jquery;
    }
    window.layer = layui.layer;
    // 初始化
    cre.init();
    // 结束执行
    cre.end();
});

