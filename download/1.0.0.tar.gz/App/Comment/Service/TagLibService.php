<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\Comment\Service;


use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class TagLibService extends \App\Vod\Service\TagLibService
{

    public function tagComment($tag): array
    {
        $tags = json_decode($tag, true);
        $param = Helper::getRequest();
        $order = $tags['order'] ?: 'desc';
        $by = $tags['by'] ?: 'comment_addtime';
        $start = (int)abs($tags['start'] ?? 0);
        $num = (int)abs($tags['num'] ?? 20);
        $pid = !empty($tags['pid']) ? (int)abs($tags['pid']) : 0;
        $uid = (int)abs($tags['uid'] ?? 0);
        $reply_num = (int)abs($tags['reply'] ?? 3);
        $rid = (int)abs($tags['rid'] ?? 0);
        $mid = (int)abs($tags['mid'] ?? 0);

        if (empty($rid)) {
            $rid = $param['rid'] ?? 0;
        }
        if (empty($mid)) {
            $mid = $param['mid'] ?? 0;
        }

        $where = [
            'c.comment_status' => 1,
            'c.comment_pid' => $pid,
            'c.comment_mid' => $mid,
            'c.comment_rid' => $rid,
        ];

        if ($uid > 0) {
            $where['c.user_id'] = $uid;
        }
        $resModel = Db::getInstance()->table('ray_comment')->alias('c')->field('c.*,u.user_name')
            ->join('ray_user u', 'c.user_id = u.user_id', 'left')
            ->where($where)
            ->order($by, $order);

        $count = $resModel->count();

        if (!empty($num) || !empty($start)) {
            $resModel->page($start, $num);
        }
        $res = $resModel->select()->toArray();
        foreach ($res as $k => $v) {
            $w = [
                'comment_pid' => $v['comment_id'],
                'comment_status' => 1,
                'comment_level' => 2,
                'comment_mid' => $mid,
                'comment_rid' => $rid,
            ];
            $replyModel = Db::getInstance()->table('ray_comment')->alias('c')->field('c.*,u.user_name')
                ->join('ray_user u', 'c.user_id = u.user_id', 'left')
                ->order($by, 'asc');

            if ($reply_num > 0) {
                $replyModel->limit($reply_num);
            }

            $reply_res = $replyModel->where($w)->select()->toArray();
            $reply_count = Db::getInstance()->table('ray_comment')->where($w)->count();
            foreach ($reply_res as $reply_k => $reply_v) {
                $reply_res[$reply_k]['reply_name'] = empty($reply = Helper::service('Comment')->getReplyName($reply_v['comment_reply_cid'])) ? '无' : ($reply['user_name'] ?: '系统');;
            }
            $res[$k]['reply'] = $reply_res;
            $res[$k]['reply_count'] = $reply_count;
        }
        return $res;
    }

}