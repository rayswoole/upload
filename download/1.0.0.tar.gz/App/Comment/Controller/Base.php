<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Comment\Controller;


use rayswoole\Helper;
use rayswoole\HttpController;
use rayswoole\Vars;

class Base extends HttpController
{
    protected function onRequest(?string $action): ?bool
    {
        $status = Vars::get('site.site_gbook_status');
        if (!$status) {
            $this->isAjax() ? Helper::responseJson(['code'=>0,'msg'=>'留言本已关闭']) : Helper::responseHtml('留言本已关闭');
            return false;
        }
        return true;
    }

}