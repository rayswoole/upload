<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\Comment\Controller;


use App\Comment\Extend\Common;
use rayswoole\Helper;

class Index extends Base
{

    public function index()
    {
        $param = $this->get();

        $this->assign(['rid' => (int)($param['rid'] ?? 0), 'mid' => (int)($param['mid'] ?? 0),'mode' => $param['mode'] ?? 'white']);
        $this->fetch();
    }

    public function new()
    {
        $this->fetch();
    }

    public function read(): bool
    {
        if ($this->isAjax()) {
            $param = $this->param();
            $res = Helper::service('Comment')->viewComment($param);
            return Helper::responseJson($res);
        }
        return false;
    }

    public function save(): ?bool
    {
        if ($this->isAjax()) {
            $data = $this->post();
            $cookie = Common::checkCookie();
            if (empty($cookie)) {
                return Helper::responseJson(['code' => 1, 'msg' => '未找到用户信息,请先重新登录', 'data' => []]);
            }
            $param = [
                'user_id' => (int)$cookie['user_id'],
                'comment_pid' => 0,
                'comment_mid' => (int)$data['comment_mid'],
                'comment_rid' => (int)$data['comment_rid'],
                'comment_content' => trim(htmlspecialchars($data['content'])),
                'comment_status' => 1,
                'comment_level' => 1,
                'comment_reply_cid' => 0,
                'comment_addtime' => time(),
            ];
            $param = array_merge($data, $param);
            $res = Helper::service('Comment')->replyComment($param);
            if ($res) {
                return Helper::responseJson($res);
            }
            return Helper::responseJson($res);

        }
        return false;
    }

    public function delete(): ?bool
    {
        if ($this->isAjax()) {
            $param = $this->post('c_id');
            $cookie = Common::checkCookie();
            if (empty($cookie)) {
                return Helper::responseJson(['code' => 0, 'msg' => '未找到用户信息,请先重新登录', 'data' => []]);
            }
            $res = Helper::service('Comment')->deleteComment($param);
            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '删除成功', 'data' => []]);
        }
        return false;
    }
}