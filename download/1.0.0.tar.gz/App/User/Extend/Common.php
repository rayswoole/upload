<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Extend;


use EasySwoole\EasySwoole\ServerManager;
use rayswoole\Helper;
use rayswoole\Service;
use rayswoole\utils\Crypt;
use rayswoole\utils\Validators;

class Common
{
    public static function checkVar(array &$param, array $data): array
    {
        foreach ($data as $k => $v) {
            if (empty($param[$k]) && !is_numeric($param[$k])) {
                if (!($v[2] ?? false)) {
                    return ['status' => false, 'msg' => $v[1]];
                }
                continue;
            }
            if (false === Validators::is($param[$k], $v[0])) {
                return ['status' => false, 'msg' => $v[1]];
            }
        }
        return ['status' => true, 'msg' => '验证通过'];
    }

    public static function checkCookie(): array
    {
        $token_a = (($c = json_decode(Helper::request()->getCookieParams('ULTOKEN'), true)) ? $c : json_decode(Helper::request()->getHeaderLine('token'), true));
        $token = $token_a['token'] ?? '';
        $username = $token_a['user_name'] ?? '';
        $ip = self::ray_get_client_ip();
        if ($token && $ip && $username) {
            $token_decrypt = Crypt::opensslDecode($token);
            $token_decrypt_res = explode('_', $token_decrypt);
            $token_decrypt_res_count = count($token_decrypt_res);
            if ($token_decrypt_res_count !== 5) {
                return [];
            }
            $token_time = $token_decrypt_res[$token_decrypt_res_count - 1];
            $token_ip = $token_decrypt_res[$token_decrypt_res_count - 2];
            if ($token_ip === $ip && ($token_time + 60 * 60) > time()) {
                return [
                    'user_id' => $token_decrypt_res[0],
                    'site_id' => $token_decrypt_res[1],
                    'level_id' => $token_decrypt_res[2],
                    'user_name' => $username
                ];
            }
        }
        return [];
    }

    public static function ray_get_client_ip(): string
    {
        $ip = ServerManager::getInstance()->getSwooleServer()->connection_info(Helper::request()->getSwooleRequest()->fd)['remote_ip'];
        if ($ip === '127.0.0.1') {
            $ip = Helper::request()->getHeaders()['x-real-ip'][0];
        }
        return $ip;
    }


    public static function ray_get_domain(bool $full = false, bool $root = false): string
    {
        $scheme = Helper::request()->getUri()->getScheme() . '://';
        $path = Helper::request()->getUri()->getHost();
        if ($root) {
            return self::getRootDomain($path);
        }
        if ($full) {
            $path = $scheme . $path;
            if ($port = Helper::request()->getUri()->getPort()) {
                $path .= chr(58) . $port;
            }
        }
        return $path;
    }

    public static function tree($data, $pid, $level, &$res)
    {
        $items = array();
        foreach ($data as $v) {
            $items[$v['user_id']] = $v;
        }
        foreach ($items as $k => $v) {
            if ((int)$v['user_pid'] === (int)$pid) {
                $v['user_name'] = str_repeat(" ├─  ", $level) . $v['user_name'];
                $res[] = $v;
                self::tree($items, $v['user_id'], $level + 1, $res);
            }
        }
        return $res;
    }












}