<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Model;


use rayswoole\orm\Model;
use rayswoole\orm\model\concern\SoftDelete;

class UserModel extends Model
{

    use SoftDelete;
    protected $name = 'user';
    protected $pk = 'user_id';

    protected $deleteTime = 'user_deletetime';
    protected $defaultSoftDelete = 0;


    public function level(): \rayswoole\orm\model\relation\HasOne
    {
        return $this->hasOne('LevelModel', 'level_id', 'level_id')->bind(['level_name']);
    }

    public static function onAfterDelete(Model $model)
    {
        self::update(['user_pid' => $model->toArray()['user_pid']], ['user_pid' => $model->toArray()['user_id']]);
    }
}