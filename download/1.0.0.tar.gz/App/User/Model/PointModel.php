<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Model;


use rayswoole\orm\Model;

class PointModel extends Model
{

    protected $name = 'user_point';
    protected $pk = 'point_id';


    public function site(): \rayswoole\orm\model\relation\HasOne
    {
        return $this->hasOne('SiteModel', 'site_id', 'site_id')->bind(['site_name']);
    }
}