<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Service;


use rayswoole\Helper;
use rayswoole\Service;
use rayswoole\orm\facade\Db;

class CardService extends Service
{


    /**
     * @param array $param
     * @字段 user_id(用户id) card_no（卡号）， card_pwd（卡密）
     * @return array
     * @throws \rayswoole\orm\db\exception\DataNotFoundException
     * @throws \rayswoole\orm\db\exception\DbException
     * @throws \rayswoole\orm\db\exception\ModelNotFoundException
     * @author zhou
     * @time 2020/10/24
     */
    //充值卡兑换
    public function cardAction(array $param):array
    {
        //检查卡号密码和站点是否对应
        $where=[
            //'site_id'=>$param['session']['site_id'],
            'card_no'=>$param['card_no'],
            'card_pwd'=>$param['card_pwd'],
            'card_status' => 0
        ];
        $iscard = Db::name('pay_card')->where($where)->find();

        if (!$iscard) {
            return ['code' => 0, 'msg' => '卡号或密码错误', 'result' => []];
        }
        //信息正确操作积分
        //1,积分增加 总积分和充值积分两个
        $upwhere=[
            'user_id'=>$param['user_id'],
            'point_id'=>1
        ];
        $old_upoint = Db::name('user_upoint')->where($upwhere)->find();

        $addpoint=intval($iscard['card_money']+$iscard['card_points']);
        $updata=[
            'upoint_total'      =>$old_upoint['upoint_total']+$addpoint,
            'upoint_available'  =>$old_upoint['upoint_available']+$addpoint,
            'upoint_withdraw'   =>$old_upoint['upoint_withdraw']+$iscard['card_money'],
        ];

        Helper::service('Point')->saveUpoint($updata,$upwhere);

        //2,积分日志记录
        $annaldata=[
            'user_id'=>$param['user_id'],
            //'site_id'=>$param['session']['site_id'],
            'point_id'=>$old_upoint['point_id'],
            'annal_datatype'=>2,
            'annal_bechange'=>$old_upoint['upoint_total'],
            'annal_afchange'=>intval($old_upoint['upoint_total']+$addpoint),
            'annal_available'=>intval($old_upoint['upoint_available']+$addpoint),
            'annal_withdraw'=>intval($old_upoint['upoint_withdraw']+$iscard['card_money'])
        ];

        Helper::service('PointAnnal')->insertPointAnnal($annaldata);

        //3,修改卡密码状态为已售出
        $res = Db::name('pay_card')->update(['card_status' => 1,'user_id'=>$param['user_id'],'card_id'=>$iscard['card_id'],'card_usertime'=>time()]);

        if ($res) {
            return ['code' => 1, 'msg' => '充值成功', 'result' => []];
        } else {
            return ['code' => 0, 'msg' => '出错了，请联系管理员', 'result' => []];
        }


    }










}