<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\User\Service;


use App\User\Extend\Common;
use App\User\Model\UserModel;
use rayswoole\Cache;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Service;
use rayswoole\utils\Crypt;

class UserService extends Service
{

    public function userList($where, $order = "user_id asc", $page = 0, $limit = 20): array
    {
        $model = new UserModel();
        if ($page > 0) {
            $data = $model->with(['level'])->where($where)->order($order)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->with(['level'])->where($where)->order($order)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    public function getUserTree(): ?array
    {
        $model = new UserModel();
        $this->tree($model->select()->toArray(), 0, 0, $res);
        return $res;
    }

    public function getUser($where): array
    {
        $model = new UserModel();
        if ($res = $model->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    public function columnType(): array
    {
        return Db::table('information_schema.columns')
            ->where('table_name', 'ray_user')
            ->column('column_name,data_type', 'column_name');
    }

    public function tree($data, $pid, $level, &$res)
    {
        $items = array();
        foreach ($data as $v) {
            $items[$v['user_id']] = $v;
        }
        foreach ($items as $k => $v) {
            if ($v['user_pid'] === $pid) {
                $v['user_name'] = str_repeat(" ├─  ", $level) . $v['user_name'];
                $res[] = $v;
                $this->tree($items, $v['user_id'], $level + 1, $res);
            }
        }
        return $res;
    }

    /**
     * 注册
     * @param array $param
     * @return array
     * @throws \EasySwoole\ORM\Exception\Exception
     * @throws \Throwable
     */
    public function saveRegister(array $param): array
    {
        if (Helper::request()->getCookieParams('INVITE')) {
            $session_invite = Helper::deJson(Helper::request()->getCookieParams('INVITE'));//获取INVITE 推广id
        } else {
            $session_invite['invite'] = 0;
        }

        $data = [
            'user_pid' => $session_invite['invite'],
            'user_name' => htmlspecialchars($param['user_name']),
            'user_sex' => (int)$param['user_sex'],
            'user_nickname' => htmlspecialchars($param['user_nickname']),
            'user_email' => htmlspecialchars($param['user_email']),
            'user_phone' => htmlspecialchars($param['user_phone']),
        ];

        $has = Db::name('user')->where(['user_name' => $param['user_name']])->find();

        if ($has) {
            return ['code' => 1, 'msg' => '用户名已注册', 'result' => []];
        }
        $data['user_passwd'] = password_hash($param['user_passwd'], PASSWORD_DEFAULT);
        $res = Db::name('user')->insert($data);

        if (!(bool)$res) {
            return ['code' => 1, 'msg' => '保存失败', 'result' => []];
        }
        return ['code' => 0, 'msg' => '保存成功', 'result' => ['url' => '/user/index/login']];
    }


    public function saveUser(array $data): bool
    {
        $model = new UserModel();
        if (!empty($data['user_id'])) {
            $model = $model->find($data['user_id']);
        }
        return $model->save($data);
    }

    public function deleteUser($data): bool
    {
        return UserModel::destroy($data);
    }


    public function login($user, $pwd, $type = 'json')
    {
        $user = $this->getUser(['user_name' => $user]);
        if ($user) {
            if (!password_verify($pwd, $user['user_passwd'])) {
                return ['code' => 0, 'msg' => '账户或密码错误', 'data' => []];
            }
            if (!$user['user_status']) {
                return ['code' => 0, 'msg' => '账号已被停用', 'data' => []];
            }
            $this->saveUser([
                'user_id' => (int)$user['user_id'],
                'user_lasttime' => time()
            ]);

            $sitewhere['site_id'] = $user['site_id'];
            $siteconfig = Helper::service('WebSite')->getWebSite($sitewhere);
            Cache::getInstance()->set('siteconfig', $siteconfig);
            $ip = Common::ray_get_client_ip();
            $cookie = Crypt::opensslEncode("{$user['user_id']}_{$user['site_id']}_{$user['level_id']}_{$ip}_" . time());
            $ut = [
                'token' => $cookie,
                'user_name' => $user['user_name'],
                'user_id' => $user['user_id']
            ];
            if ($type !== 'jsonp') {
                $this->response()->setCookie('ULTOKEN', Helper::enJson($ut), time() + 60 * 60);
            }
            return ['code' => 1, 'msg' => '登录成功', 'data' => ['url' => '/user/index/userinfo', 'info' => $ut]];
        }
        return ['code' => 0, 'msg' => '用户不存在', 'data' => []];
    }

    public function subUser(int $uid = 0)
    {
        if (!$item = Cache::getInstance()->get('subuserlist')) {
            $item = [];
            $data = $this->userList(['user_deletetime' => 0])['data'];
            foreach ($data as $k => $v) {
                $item[$v['user_id']] = $v;
            }
            foreach ($item as $k => $v) {
                $item[$k]['childsid'] = $this->getTeamMem($data, $v['user_id']);
            }
            Cache::getInstance()->set('subuserlist', $item, 3600);
        }
        return $item[$uid] ?? [];
    }

    public function getTeamMem($members, $mid): array
    {
        $Teams = array();
        $mids = array($mid);
        do {
            $othermids = array();
            $state = false;
            foreach ($mids as $valueone) {
                foreach ($members as $key => $valuetwo) {
                    if ($valuetwo['user_pid'] === $valueone) {
                        $Teams[] = $valuetwo['user_id'];
                        $othermids[] = $valuetwo['user_id'];
                        $state = true;
                    }
                }
            }
            $mids = $othermids;
        } while ($state === true);
        return $Teams;
    }

    //修改会员级别和时间
    public function updateLevel($param): bool
    {
        //增加会员时间
        switch ($param['levelprice']) {
            case 'level_weekprice';
                $addtime = 24 * 60 * 60;
                break;
            case 'level_monthprice';
                $addtime = 30 * 24 * 60 * 60;
                break;
            case 'level_periodprice';
                $addtime = 3 * 30 * 24 * 60 * 60;
                break;
            case 'level_yearprice';
                $addtime = 12 * 30 * 24 * 60 * 60;
                break;
        }
        $res = Db::name('user')
            ->inc('user_expiretime', $addtime)
            ->update(['level_id' => intval($param['level_id']), 'user_id' => $param['user_id']]);

        return (bool)$res;
    }


}