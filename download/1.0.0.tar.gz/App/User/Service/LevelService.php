<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Service;


use App\User\Model\LevelModel;
use rayswoole\orm\facade\Db;
use rayswoole\Service;
use rayswoole\Helper;

class LevelService extends Service
{

    //会员列表
    public function levelList($where, $order = "level_id asc", $page = 0, $limit = 20): array
    {
        $model = new LevelModel();
        if ($page > 0) {
            $data = $model->where($where)->order($order)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->where($where)->order($order)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    //获取会员
    public function getLevel($where): array
    {
        $model = new LevelModel();
        if ($res = $model->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    //会员
    public function columnType(): array
    {
        return Db::getInstance()->table('information_schema.columns')
            ->where('table_name', 'ray_user_level')
            ->column('column_name,data_type', 'column_name');
    }

    public function saveLevel(array $data): bool
    {
        $model = new LevelModel();
        if (!empty($data['level_id'])) {
            $model = $model->find($data['level_id']);
        }
        return $model->save($data);
    }

    public function deleteLevel($data): bool
    {
        return LevelModel::destroy($data);
    }


    /**
     * 数据[user_id('用户id')，level_id（会员积分id）,levelprice(会员类型月会员，年会员)]
     * @param $param
     * @return mixed
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/24
     */
    public function activeLevel($param)
    {

        //调整user表会员级别 和时间
        Helper::service('User')->updateLevel($param);

        //减upoint表 “upoint_withdraw”积分
        $upoint = Helper::service('Point')->exchangUpoint($param);

        return $upoint;

    }























}