<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Controller;


use rayswoole\Helper;

class Promote extends Base
{

    public function index(): void
    {
        $session = \App\User\Extend\Common::checkCookie();
        $this->assign(['user_id' => $session['user_id'] ?? 0]);
        $this->fetch();
    }

    public function sublist(): bool
    {
        $session = \App\User\Extend\Common::checkCookie();
        if ($this->isAjax()) {
            if (empty($session['user_id'])) {
                return Helper::responseJson(['msg' => '未找到数据']);
            }
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            $where[] = ['user_pid', '=', $session['user_id']];
            $where[] = ['user_deletetime', '=', 0];
            $order = 'user_id';
            $res = Helper::service('User')->userList($where, $order, $page, $limit);
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res['data'], 'count' => $res['count']]);
        }
        $this->assign([
            'subNum' => !empty($session['user_id']) ? Helper::service('User')->userList([
                'user_pid' => $session['user_id'],
                'user_deletetime' => 0
            ])['count'] : 0
        ]);
        $this->fetch();
        return false;
    }

    public function detail(): ?bool
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $session = \App\User\Extend\Common::checkCookie();
            if (empty($session)) {
                return Helper::responseJson(['msg' => '未找到数据']);
            }
            $child_id = Helper::service('User')->subUser((int)$session['user_id']);
            $child_id['childsid'][] = $session['user_id'];
            $where = [];
            $where[] = ['user_id', 'in', $child_id['childsid']];
            $where[] = ['annal_datatype', '=', 1];
            $order = 'annal_addtime';
            $res = Helper::service('Annal')->annalList($where, $order, $page, $limit);
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res['data'], 'count' => $res['count']]);
        }
        $this->fetch();
        return false;
    }

}