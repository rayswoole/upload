<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\User\Controller\Admin;


use App\User\Extend\Common;
use App\User\Model\UserModel;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Index extends Base
{

    public function index(): void
    {
        $user_id = $this->get('user_id', '');
        $this->assign([
            'user_id' => $user_id
        ]);
        $this->fetch();
    }

    public function read(): bool
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $field = !empty($param['field']) ? $param['field'] : 'user_id';
            $order = !empty($param['field']) ? $param['order'] : 'desc';
            $where = [];
            $where[] = ['user_deletetime', '=', 0];
            if (!empty($param['uid'])) {
                $where[] = ['user_pid', '=', (int)$param['uid']];
            }
            if (!empty($param['key'])) {
                $key = $param['key'];
                if (!empty($key['searchName'])) {
                    $where[] = ['user_name', 'like', "%{$key['searchName']}%"];
                }
            }
            $res = (new UserModel())->withJoin(['level'])->where($where)->order($field, $order)->page($page, $limit)->select()->toArray();
            $count = (new UserModel())->where($where)->count('*');
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => $count]);
        }
        return false;
    }

    public function create(): void
    {
        $user = Common::tree((new UserModel())->select()->toArray(), 0, 0, $result);
        $level = Db::name('user_level')->select()->toArray();
        $user_id = $this->get('id', '-1');
        $this->assign(['userList' => $user, 'levelList' => $level, 'user_id' => $user_id]);
        $this->fetch();
    }

    public function edit(): bool
    {
        $id = (int)$this->get('id');
        $res = (new UserModel())->where(['user_id' => $id])->find();
        if (!$res) {
            return Helper::responseJson(['msg' => '未找到数据']);
        }
        $user = Common::tree((new UserModel())->select()->toArray(), 0, 0, $result);
        $level = Db::name('user_level')->select()->toArray();
        $this->assign(['edit' => $res, 'userList' => $user, 'levelList' => $level]);
        $this->fetch();
        return false;
    }

    public function save(): bool
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $validate = Common::checkVar($param, [
                'user_name' => ['alchina:1..255', '名称只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符'],
                'user_nickname' => ['alchina:1..255', '昵称只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符', true],
                'user_passwd' => ['alchina:6..255', '密码只能为\a-z\A-Z\0-9-_且长度不能小于6-255个字符', true],
                //'user_email' => ['email', '邮箱地址不正确,例如:xxx@163.com'],
                //'user_phone' => ['digit:11..11', '号码格式错误,例如:18166668888']
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 0, 'msg' => $validate['msg'], 'data' => []]);
            }
            foreach ($param as $k => $v) {
                $param[$k] = trim($v);
            }
            $param['user_addtime'] = time();
            if (isset($param['user_id']) && $param['user_id']) {
                if (!empty($param['user_passwd'])) {
                    $param['user_passwd'] = password_hash($param['user_passwd'], PASSWORD_DEFAULT);
                } else {
                    unset($param['user_passwd']);
                }
            } else {
                $param['user_passwd'] = password_hash($param['user_passwd'], PASSWORD_DEFAULT);
            }

            $res = Helper::service('User')->saveUser($param);
            if ($res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '保存失败', 'data' => []]);
        }
        return false;
    }


    public function update(): bool
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $field = $param['field'] ?? 'user_status';
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $res = Helper::service('User')->saveUser([
                $field => $value,
                'user_id' => $id
            ]);
            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存成功', 'data' => []]);
        }
        return false;
    }

    public function delete(): bool
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res = Helper::service('User')->deleteUser($data);
            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '删除成功', 'data' => []]);
        }
        return false;
    }

}