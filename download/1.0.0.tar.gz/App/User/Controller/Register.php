<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Controller;

use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use App\User\Extend\Common;

class Register extends Base
{

    /*
     * @method GET
     * @author
     * @date
     */
    public function index()
    {

        return $this->fetch();
    }



    public function register()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $session = \App\User\Extend\Common::checkCookie();

            //字段校验
            $validate = Common::checkVar($param, [
                'user_name'      => ['alchina:1..255', '账号只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符'],
                'user_passwd'    => ['alnum:1..20', '账号只能为数字和字母且长度不能超出20个字符'],
                'user_nickname'  => ['alchina:1..8', '昵称只能为中文\a-z\A-Z\0-9-_且长度不能超出8个字符'],
                'user_phone'     => ['int:11', '电话号码为11位'],
                'user_email'     => ['email', '邮箱格式不正确'],
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }

            $res = Helper::service('Register')->saveRegister($param);

            return Helper::responseJson($res);
        }
        $this->fetch('index');
    }

    /**
     * 找回密码
     */
    public function findpass()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $data = [
                "user_name" => htmlspecialchars($param['user_name']),
                "user_issue_one" => htmlspecialchars($param['user_issue_one']),
                "user_answer_one" => htmlspecialchars($param['user_answer_one']),
            ];
            $res = Helper::service('Register')->checkAccount($data);

            if (!empty($res['user_id'])) {
                return Helper::responseJson(['code' => 0, 'msg' => '成功', 'data' => ['user_id' => $res['user_id']]]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '账号或答案错误', 'data' => []]);
        }
        $this->fetch();
    }

    /**
     * 修改密码
     */
    public function setpassword()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            if ($param['password'] !== $param['password2']) {
                return Helper::responseJson(['code' => 1, 'msg' => '两次密码不一致', 'data' => []]);
            }
            if (empty($param["edit_id"])) {
                return Helper::responseJson(['code' => 1, 'msg' => 'id错误', 'data' => []]);
            }
            $data = [
                "user_passwd" => htmlspecialchars(password_hash($param['password'], PASSWORD_DEFAULT)),
                "user_id" => (int)$param['edit_id']
            ];
            $res = Db::name('user')->save($data);
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '修改成功,请重新登陆', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存失败，请刷新重试', 'data' => []]);
        }
        $param = $this->get();
        if ($param['id']) {
            $this->assign(['edit_id' => $param['id']]);
        }
        $this->fetch();
    }


}