<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Index\Controller;

use rayswoole\HttpController;

class Index extends HttpController
{
    public function index()
    {
        $this->fetch();
    }

    public function return404()
    {
        $this->response()->withStatus(404);
        $this->response()->withHeader('Content-type', 'text/html;charset=utf-8');
        if (file_exists(RAY_ROOT.'/404.html')) {
            $this->response()->write(file_get_contents(RAY_ROOT.'/404.html'));
        } else {
            $this->fetch();
        }
    }

    public function return403()
    {
        $this->response()->withStatus(403);
        $this->response()->withHeader('Content-type', 'text/html;charset=utf-8');
        $this->response()->write('Permission denied');
    }
}