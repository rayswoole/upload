<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Art\Service;


use App\Admin\Service\NavService;
use App\Art\Model\ColumnModel;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class ColumnService extends Service
{

    public function columnList($where, $page = 0, $limit = 20): array
    {
        $model = new ColumnModel();
        if ($page > 0) {
            $data = $model->where($where)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->where($where)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    public function getColumnTree(): ?array
    {
        $model = new ColumnModel();
        $this->tree($model->select()->toArray(), 0, 0, $res);
        return $res;
    }

    public function getColumn($where): array
    {
        $model = new ColumnModel();
        if ($res = $model->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    public function columnType(): array
    {
        return Db::table('information_schema.columns')
            ->where('table_name', 'ray_art_type')
            ->column('column_name,data_type', 'column_name');
    }

    public function tree($data, $pid, $level, &$res)
    {
        $items = array();
        foreach ($data as $v) {
            $items[$v['type_id']] = $v;
        }
        foreach ($items as $k => $v) {
            if ($v['type_pid'] === $pid) {
                $v['type_name'] = str_repeat(" ├─  ", $level) . $v['type_name'];
                $res[] = $v;
                $this->tree($items, $v['type_id'], $level + 1, $res);
            }
        }
        return $res;
    }

    public function saveColumn(array $data): bool
    {
        $model = new ColumnModel();
        if (!empty($data['type_id'])) {
            $model = $model->find($data['type_id']);
        }
        $res = $model->save($data);
        if ($res) {
            if ((!empty($data['type_nav'])) && 1 === (int)$data['type_nav'] && empty($data['type_id'])) {
                $url = ['art/index/type', 'art/index/show'];
                $param = [['id' => $model->type_id], ['class' => $data['type_name'], 'id' => $model->type_id]];
                Helper::service('Nav', 'Admin')->saveNav([
                    'nav_name' => $data['type_name'],
                    'nav_jumpurl' => Helper::url(((int)$data['type_pid'] > 0 ? $url[1] : $url[0]), ((int)$data['type_pid'] > 0 ? $param[1] : $param[0])),
                    'nav_typeid' => $model->type_id,
                    'nav_mod' => 2 // 视频1 文章2
                ]);
            }
            return true;
        }
        return false;
    }

    public function deleteColumn($data): bool
    {
        return ColumnModel::destroy($data);
    }

}