<?php
return array (
  '' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'index/index',
  ),
  'index_{page}' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'index/index',
  ),
  'list/id/{id}/page/{page}[/{s:.+}]' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'type/index',
  ),
  'list/id/{id}[/{s:.+}]' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'type/index',
  ),
  'show/id/{id}/page/{page}[/{s:.+}]' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'show/index',
  ),
  'show/id/{id}[/{s:.+}]' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'show/index',
  ),
  'detail/{id}' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'detail/index',
  ),
  'play/id/{id}/sid/{sid}/nid/{nid}' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'play/index',
  ),
  'search/wd/{wd}/page/{page}[/{s:.+}]' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'search/index',
  ),
  'search/wd/{wd}[/{s:.+}]' => 
  array (
    0 => 
    array (
      0 => 'GET',
      1 => 'POST',
    ),
    1 => 'search/index',
  ),
);