<?php
// +----------------------------------------------------------------------
// | 实例页面
// | @Date 2020/1/3 下午6:22
// +----------------------------------------------------------------------

namespace App\Vod\Controller\Admin;

use App\Admin\Controller\Base;
use App\Admin\Service\ConfigService;
use App\Vod\Extend\Upload;
use App\Vod\Service\TypeService;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Actor extends Base
{
    /*
     * [index 渲染首页]
     * @method GET.5566
     * @author C.
     * @date 2020/1/3 下午6:19
     */
    public function index()
    {
        //电影类型
        $type_tree=TypeService::getInstance()->get();

        //地区，语言，年代分类
        $config=ConfigService::getInstance()->get('vod') ?? [];
        $arr_type['area']=explode(',',$config['vod_extend_area']['val']);
        $arr_type['lang']=explode(',',$config['vod_extend_lang']['val']);
        $arr_type['year']=explode(',',$config['vod_extend_year']['val']);
        // 渲染页面
        $this->assign(['type_tree'=>$type_tree,'arr_type'=>$arr_type]);
        $this->fetch();
    }

    /*
     * [create 渲染创建页面]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:19
     */
    public function create()
    {
        //电影类型
        $type_tree=TypeService::getInstance()->get();
        $this->assign(['type_tree'=>$type_tree]);
        $this->fetch();
    }

    /*
     * [edit 渲染编辑页]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:19
     */
    public function edit()
    {
        $param = $this->get();

        $res=Db::name('actor')->where(['actor_id' => intval($param['edit_id'])])->find();
        if (!$res) {
            // 没有数据跳转到错误页面
            return false;
        }
        //电影类型
        $type_tree=TypeService::getInstance()->get();

        $this->assign(['actor_data' => $res,'type_tree'=>$type_tree]);
        $this->fetch();
    }


    /*
     * [delete 删除数据]
     * @method POST
     * @author C.
     * @date 2020/1/3 下午6:18
     */
    public function delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id= explode(',',$id);

            $res=Db::name('actor')->delete($id);

            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除失败', 'result' => $res]);
            } else {
                return Helper::responseJson(['code' => 1, 'msg' => '删除成功', 'result' => $res]);
            }
        }
    }

    /*
     * [save 新增保存数据]
     * @method POST
     * @author C.
     * @date 2020/1/3 下午6:18
     */
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            //字段校验
            $validate = Helper::service('Vod')->checkVar($param, [
                'actor_name'   => ['alchina:1..20', '名字长度不能超出20个字符'],
                'actor_alias'  => ['alchina:1..20', '别名长度不能超出20个字符', true],
                'actor_en'     => ['alchina:1..20', '英文名长度不能超出20个字符', true],
                'actor_letter' => ['alpha:..1', '首字母只能为单个字符', true],
                'actor_area'   => ['alchina:1..20', '地区长度不能超出20个字符', true],
                'actor_place'  => ['alchina:1..20', '出生地长度不能超出20个字符', true],
                'actor_height' => ['number:1..300', '身高只能为数字', true],
                'actor_weight' => ['number:1..300', '体重只能为数字', true],
                'actor_cup'    => ['alnum:1..20', '罩杯只能为数字和字母', true],
                'actor_bust'   => ['alnum:1..20', '胸围只能为数字和字母', true],
                'actor_waist'  => ['alnum:1..20', '腰围只能为数字和字母', true],
                'actor_hips'   => ['aldas:1..20', '臀围只能为数字和字母', true],
                'actor_blood'  => ['alpha :1..20', '血型只能为字母', true],
                'actor_starsign'  => ['alchina :1..20', '星座长度不能超出20个字符', true],
                'actor_works'     => ['alchina :1..50', '星座长度不能超出50个字符', true],
                'actor_blurb'     => ['alchina :1..300', '简介长度不能超出300个字符', true],
                'actor_remarks'   => ['alchina :1..300', '备注长度不能超出300个字符', true],
                'actor_sort' => ['number:1..999999999', '排序只能为数字,且长度不能超出999999999', true],
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }

            $data = [
                "actor_name"    => htmlspecialchars($param['actor_name']),
                "actor_en"      => htmlspecialchars($param['actor_en']),
                "actor_alias"   => htmlspecialchars($param['actor_alias']),
                "actor_star"   =>  $param['actor_star'],
                "actor_type_id" => htmlspecialchars($param['actor_type_id']),
                "actor_letter"  => htmlspecialchars($param['actor_letter']),
                "actor_sex"     => htmlspecialchars($param['actor_sex']),
                "actor_area"    => htmlspecialchars($param['actor_area']),
                "actor_birthday" => htmlspecialchars($param['actor_birthday']),
                "actor_place"   => htmlspecialchars($param['actor_place']),
                "actor_height"  => intval($param['actor_height']),
                "actor_weight"  => intval($param['actor_weight']),
                "actor_cup"     => intval($param['actor_cup']),
                "actor_bust"    => intval($param['actor_bust']),
                "actor_waist"   => intval($param['actor_waist']),
                "actor_hips"    => intval($param['actor_hips']),
                "actor_blood"   => htmlspecialchars($param['actor_blood']),
                "actor_starsign" => htmlspecialchars($param['actor_starsign']),
                "actor_works"   => htmlspecialchars($param['actor_works']),
                "actor_pic"     => htmlspecialchars($param['actor_pic']),
                "actor_blurb"   => htmlspecialchars($param['actor_blurb']),
                "actor_status"  => isset($param['actor_status']) ? 1 : 0,
                "actor_remarks" => htmlspecialchars($param['actor_remarks']),
                "actor_hits"    => intval($param['actor_hits']),
                "actor_hits_month"  => intval($param['actor_hits_month']),
                "actor_hits_week"   => intval($param['actor_hits_week']),
                "actor_hits_day"    => intval($param['actor_hits_day']),
                "actor_content"     => htmlspecialchars($param['actor_content']),
                "actor_sort"        => intval($param['actor_sort']),
                "actor_addtime"    => time()
            ];
            $res=Db::name('actor')->save($data);

            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存失败', 'result' => []]);
            }
                return Helper::responseJson(['code' => 1, 'msg' => '保存成功', 'result' => []]);

        }

    }

    /*
     * [read 读取数据]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:17
     */
    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? intval($param['page']) : 1;
            $limit = isset($param['limit']) ? intval($param['limit']) : 10;

            $db = Db::name('actor');
            $by = 'actor_sort,actor_id';

            if (isset($param['key'])) {
                $key = (array)json_decode($param['key']);

                if (isset($key['actor_type_id']) && $key['actor_type_id']!=='') {
                    $db->where('actor_type_id','=',$key['actor_type_id']);
                }if (isset($key['actor_area']) && $key['actor_area']!=='') {
                    $db->where('actor_area','=',$key['actor_area']);
                }
                if (isset($key['actor_star']) && $key['actor_star']!=='') {
                    $db->where('actor_star','=',$key['actor_star']);
                }
                if (isset($key['actor_sex']) && $key['actor_sex']!=='') {
                    $db->where('actor_sex','=',$key['actor_sex']);
                }
                if (isset($key['actor_status']) && $key['actor_status']!=='') {
                    $db->where('actor_status','=',$key['actor_status']);
                }
                if (isset($key['actor_name']) && $key['actor_name']!=='') {
                    $v = $key['actor_name'];
                    $db->where('actor_name','like',"%{$v}%");
                }
            }
            $db->order($by, 'DESC');
            $count = $db->count('actor_id');
            $data = [];
            if ($count > 0){
                $data = $db->limit(($page-1)*$limit,$limit)->select()->toArray();
            }

            return Helper::responseJson([
                'code' => 0,
                'msg' => '演员列表',
                'count' => $count,
                'data' => $data
            ]);
        }
    }

    /*
     * [update 更新数据]
     * @method POST
     * @author C.
     * @date 2020/1/3 下午6:17
     */
    public function update()
    {
        if ($this->isAjax()) {
            $param = $this->post();

            //字段校验
            $validate = Helper::service('Vod')->checkVar($param, [
                'actor_name'   => ['alchina:1..20', '名字长度不能超出20个字符'],
                'actor_alias'  => ['alchina:1..20', '别名长度不能超出20个字符', true],
                'actor_en'     => ['alchina:1..20', '英文名长度不能超出20个字符', true],
                'actor_letter' => ['alpha:..1', '首字母只能为单个字符', true],
                'actor_area'   => ['alchina:1..20', '地区长度不能超出20个字符', true],
                'actor_place'  => ['alchina:1..20', '出生地长度不能超出20个字符', true],
                'actor_height' => ['number:1..300', '身高只能为数字', true],
                'actor_weight' => ['number:1..300', '体重只能为数字', true],
                'actor_cup'    => ['alnum:1..20', '罩杯只能为数字和字母', true],
                'actor_bust'   => ['alnum:1..20', '胸围只能为数字和字母', true],
                'actor_waist'  => ['alnum:1..20', '腰围只能为数字和字母', true],
                'actor_hips'   => ['aldas:1..20', '臀围只能为数字和字母', true],
                'actor_blood'  => ['alpha :1..20', '血型只能为字母', true],
                'actor_starsign'  => ['alchina :1..20', '星座长度不能超出20个字符', true],
                'actor_works'     => ['alchina :1..50', '星座长度不能超出50个字符', true],
                'actor_blurb'     => ['alchina :1..300', '简介长度不能超出300个字符', true],
                'actor_remarks'   => ['alchina :1..300', '备注长度不能超出300个字符', true],
                'actor_sort' => ['number:1..999999999', '排序只能为数字,且长度不能超出999999999', true],
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 0, 'msg' => $validate['msg'], 'data' => []]);
            }

            $data = [
                "actor_id"      => intval($param['actor_id']),
                "actor_name"    => htmlspecialchars($param['actor_name']),
                "actor_type_id" => htmlspecialchars($param['actor_type_id']),
                "actor_en"      => htmlspecialchars($param['actor_en']),
                "actor_alias"   => htmlspecialchars($param['actor_alias']),
                "actor_star"   =>  $param['actor_star'],
                "actor_letter"  => htmlspecialchars($param['actor_letter']),
                "actor_sex"     => htmlspecialchars($param['actor_sex']),
                "actor_area"    => htmlspecialchars($param['actor_area']),
                "actor_birthday" => htmlspecialchars($param['actor_birthday']),
                "actor_place"    => htmlspecialchars($param['actor_place']),
                "actor_height"   => intval($param['actor_height']),
                "actor_weight"   => intval($param['actor_weight']),
                "actor_cup"      => intval($param['actor_cup']),
                "actor_bust"     => intval($param['actor_bust']),
                "actor_waist"    => intval($param['actor_waist']),
                "actor_hips"     => intval($param['actor_hips']),
                "actor_blood"    => htmlspecialchars($param['actor_blood']),
                "actor_starsign" => htmlspecialchars($param['actor_starsign']),
                "actor_works"    => htmlspecialchars($param['actor_works']),
                "actor_pic"      => htmlspecialchars($param['actor_pic']),
                "actor_blurb"    => htmlspecialchars($param['actor_blurb']),
                "actor_status"   => isset($param['actor_status']) ? 1 : 0,
                "actor_remarks"  => htmlspecialchars($param['actor_remarks']),
                "actor_hits"     => intval($param['actor_hits']),
                "actor_hits_month" => intval($param['actor_hits_month']),
                "actor_hits_week"  => intval($param['actor_hits_week']),
                "actor_hits_day"   => intval($param['actor_hits_day']),
                "actor_content"    => htmlspecialchars($param['actor_content']),
                "actor_sort"       => intval($param['actor_sort']),
                "actor_addtime"    => time()
            ];
            $res=Db::name('actor')->save($data);
            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存失败', 'result' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存成功', 'result' => []]);
        }
    }
    /*
       * [updateField 字段值更新]
       * @method POST
       * @author C.
       * @time 2020/2/3 上午2:18
       */
    public function update_file()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'actor_status';
            $res = Db::name('actor')->update([
                $field => $value,'actor_id'=>$id
            ]);

            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '更新失败', 'result' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '更新成功', 'result' => []]);

        }
    }


    /*
        * [upload 上传文件]
        * @method POST
        * @author C.
        * @date 2020/1/18 上午10:42
        */
    public function upload()
    {
        $param = $this->request()->getRequestParam();
        $field = 'image';
        $path = '/Public/static/upload/actor/image/';
        if ($param) {
            switch ($param['type']) {
                case 'image':
                    $field = 'image';
                    $path = '/static/upload/actor/image/';
                    break;
                case 'thumb':
                    $field = 'thumb';
                    $path = '/static/upload/actor/thumb/';
                    break;
            }
        }
        $config = [
            'field' => $field,
            'notExistenceMsg' => '请选择要上传的图片',
            'size' => [
                'ext' => 1024 * 1024 * 5,
                'msg' => '图片不能大于5M'
            ],
            'type' => [
                'mediaType' => ['png', 'peng', 'jpg', 'jpeg', 'gif', 'jpeg', 'pem', 'ico'],
                'msg' => '文件类型不正确！'
            ],
            'path' => $path,
        ];
        //$res = $this->uploadFile($config);
        $res = Upload::getInstance($this->request())->setConfig($config)->upload();
        return Helper::responseJson(['code' => $res['code'], 'msg' => $res['msg'], 'data' => $res['result']]);
    }

    /**
     * @return bool
     * @throws \EasySwoole\ORM\Exception\Exception
     * @author zhou
     * @time 2020/7/30
     */
    public function actorApi()
    {
        $param=$this->post();
        if (isset($param['actorname'])) {
            $v = $param['actorname'];
            $where['actor_name'] = ["%{$v}%", 'like'];
        }
        $where['actor_status']=1;
        $result=ActorModel::create()->getDataAll($where,'actor_sort');

        return $this->returnJson($result);


    }

}