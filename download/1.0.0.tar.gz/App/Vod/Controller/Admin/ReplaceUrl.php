<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Controller\Admin;

use App\Admin\Controller\Base;
use App\Vod\Extend\Common;
use EasySwoole\EasySwoole\Task\TaskManager;
use rayswoole\orm\facade\Db;
use App\Admin\Service\ConfigService;
use rayswoole\Helper;

class ReplaceUrl extends Base
{

    public function index()
    {
        if ($this->isPost()) {
            $data = $this->post('config');
            $data = array_map(function ($value) {
                return trim($value);
            }, $data);
            ConfigService::getInstance()->update('site', $data);
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功,请点击右上角 “重启服务” 使配置生效', 'data' => []]);
        } else {
            $today_time = strtotime(date('Y-m-d 00:00:00',time()));
            //全部
            $data = Db::name('vod')->where('vod_pic','like','%http%')->select()->toArray();
            //当天
            $today = Db::name('vod')
                    ->where('vod_pic','like','%http%')
                    ->where('vod_addtime','>',$today_time)
                    ->select()->toArray();
            $this->assign(['total'=>count($data),'today'=>count($today)]);
            $this->fetch();
        }

    }


    //下载远程图片
    public function replace()
    {
        $param=$this->get();
        $path = '/static/upload/vod/image/';
        $date = date("Y-m-d", time());
        $dir = RAY_ROOT . '/Public' . $path . $date . '/';

        $db=Db::name('vod')->field('vod_id,vod_pic')->where('vod_pic','like','http%');
        //查出视频id
        $today = strtotime(date('Y-m-d 00:00:00',time()));
        if($param['ac']=='today'){
            $db->where('vod_addtime','>',$today);
        }
        $data=$db->select()->toArray();
        if($data){
            $this->imageAsync($data,$dir,$path);
            $msg='图片异步下载，程序已执行,可关闭该页面';
        }else{
            $msg='无远程图片下载，请关闭该页面';
        }
        $this->assign(['msg'=>$msg]);
        $this->fetch();
    }

    //异步处理采集图片
    function imageAsync(array $data,$dir,$path)
    {
        TaskManager::getInstance()->async(function () use ($data,$dir,$path){
            foreach ($data as $key => $val){
                $res=Common::getImage($val['vod_pic'],$dir,$path);
                if($res['code']==1){
                    Db::name('vod')->where(['vod_id'=>$val['vod_id']])->update(['vod_pic'=>$res['save_path']]);
                }
                usleep(1000);
            }

        });
    }

}