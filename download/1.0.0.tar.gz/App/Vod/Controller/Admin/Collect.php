<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Vod\Controller\Admin;

use App\Admin\Controller\Base;
use rayswoole\Cache;
use rayswoole\orm\facade\Db;
use App\Vod\Service\CollectService;
use rayswoole\Helper;
use GuzzleHttp\Client;
use rayswoole\Vars;

class Collect extends Base
{
    /*
       * [index 渲染首页]
       * @method GET
       * @author C.
       * @date 2020/1/3 下午6:19
       */
    public function index()
    {
        // 渲染页面
        $this->fetch();
    }

    /*
     * [rule 采集规则]
     * @Method GET
     * @author C.
     * @date 2020/1/10 下午12:00
     */
    public function rule()
    {
        $this->fetch();
    }

    /*
     * [create 渲染创建页面]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:19
     */
    public function create()
    {
        $this->fetch();
    }

    /*
     * [edit 渲染编辑页]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:19
     */
    public function edit()
    {
        $param = $this->get('edit_id',0,'intval');

        $res=Db::name('vod_collect')->where(['collect_id'=>$param])->find();

        if (!$res) {
            return false;
        }
        $this->assign(['collect' => $res]);
        $this->fetch();
    }

    /*
     * [delete 删除数据]
     * @method POST
     * @author C.
     * @date 2020/1/3 下午6:18
     */
    public function delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id=explode(',',$id);

            $res = Db::name('vod_collect')->delete($id);

            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除失败', 'result' => $res]);
            } else {
                return Helper::responseJson(['code' => 1, 'msg' => '删除成功', 'result' => $res]);
            }
        }
    }

    /*
     * [save 新增保存数据]
     * @method POST
     * @author C.
     * @date 2020/1/3 下午6:18
     */
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();

            //字段校验
            $validate = Helper::service('Vod')->checkVar($param, [
                'collect_name' => ['alchina:1..20', '任务名称不能超出20个字符'],
                'collect_url'  => ['url', '接口地址不正确'],
                'collect_sort' => ['number:1..999999999', '排序只能为数字,且长度不能超出999999999', true],
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 0, 'msg' => $validate['msg'], 'data' => []]);
            }

            $data = [
                "collect_name"  => htmlspecialchars($param['collect_name']),
                "collect_url"   => htmlspecialchars(trim($param['collect_url'])),
                "collect_param" => htmlspecialchars($param['collect_param']),
                "collect_type"  => htmlspecialchars($param['collect_type']),
                "collect_mid"   => htmlspecialchars($param['collect_mid']),
                "collect_opt"   => intval($param['collect_opt']),
                "collect_sort"  => intval($param['collect_sort']),
                "collect_timing_switch" => intval($param['collect_timing_switch']),
                "collect_timing_time"   => htmlspecialchars($param['collect_timing_time']),
            ];

            if (!empty($param['collect_id'])) {
                $data['collect_id']=$param['collect_id'];
            }

            $res = Db::name('vod_collect')->save($data);

            if ($res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存成功,请点击右上角 “重启服务” 使配置生效', 'result' => []]);
            }else{
                return Helper::responseJson(['code' => 0, 'msg' => '保存失败', 'result' => []]);
            }

        }
    }

    /*
     * [read 读取数据]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:17
     */
    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? intval($param['page']) : 1;
            $limit = isset($param['limit']) ? intval($param['limit']) : 10;
            $where = [];
            $by = 'collect_id';

            if (isset($param['collect_name']) && $param['collect_name']) {
                $v = $param['collect_name'];
                $where[] = ['collect_name','like',"%{$v}%"];
            }
            $res=Db::name('vod_collect')->where($where)->order($by,'DESC')->limit(($page-1)*$limit,$limit)->select()->toArray();

            if (!empty($res)){
                foreach ($res as $_k=>$data){
                    $res[$_k]['collect_enurl'] = urlencode($data['collect_url']);
                }
            }

            return Helper::responseJson([
                'code' => 0,
                'msg'  => '采集列表',
                'count'=> Db::name('vod_collect')->where($where)->count('collect_id'),
                'data' => $res
            ]);
        }
    }


    /**
     * [updateField 字段值更新]
     * @return bool
     *time 2020/7/25
     */
    public function update_file()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'collect_status';

            $res=Db::name('vod_collect')->where(['collect_id'=>$id])->save([$field => $value]);
            if ($res) {
                return Helper::responseJson(['code' => 1, 'msg' => '更新成功', 'result' => []]);
            }else{
                return Helper::responseJson(['code' => 0, 'msg' => '更新失败', 'result' => []]);
            }
        }
    }

    /**
     * 查询分类绑定
     *time 2020/7/25
     */
    public function select()
    {
        $param = $this->get();

        $page = isset($param['page']) ? intval($param['page']) : 1;
        $limit = isset($param['limit']) ? intval($param['limit']) : 20;
        $flag = $param['cjflag'];
        $typeId = intval($param['type_id']);

        $data = Db::name('vod_collect_type')->where(['type_key'=>$flag.'_'.$typeId])->find();

        if (!$data){
            $data = ['id'=>0,'type_key'=>'','type_value'=>0];
        }

        $where = ['type_mid'=>1];
        $ordey = 'type_id';
        $mid=1;

        $type_tree = [];
        $result=Db::name('type')->where($where)->order($ordey,'DESC')->limit(($page-1)*$limit,$limit)->select()->toArray();

        if ($result){
            $type_tree = CollectService::getInstance()->ray_list_to_tree($result,'type_id','type_pid');
        }

        $this->assign(['type_tree'=>$type_tree,'mid'=>$mid,'cjflag'=>$flag,'type_id'=>$typeId,'data'=>$data]);
        return $this->fetch();
    }

    /**
     * 绑定映射
     */
    public function bind_type()
    {
        //$param =$this->request()->getRequestParam();

        $id        = $this->post('id',0,'intval');
        $typeId    = $this->post('type_id',0,'intval');
        $typeKey   = $this->post('type_key','','');
        $typeValue = $this->post('type_value',0,'intval');

        if (!$typeId || $typeValue < 0){
            return Helper::responseJson(['code' => 0, 'msg' => '先选择分类', 'result' => []]);
        }

        $data=[
            "type_key"=>$typeKey.'_'.$typeId,
            "type_value"=>$typeValue
        ];

        //取消绑定
        if($typeValue==0){
            Db::name('vod_collect_type')->where(['type_key'=>$data['type_key']])->delete();
        }else{
            if ($id>0){
                Db::name('vod_collect_type')->where(['id'=>$id])->save($data);
            } else {
                Db::name('vod_collect_type')->save($data);
            }
        }
        return Helper::responseJson(['code' => 1, 'msg' => '绑定成功', 'result' => []]);
    }

    /**
     * 采集页面
     * type=1 json ; type=2 xml
     */
    public function collect()
    {
        $param = $this->get();
        $page = isset($param['page']) ? intval($param['page']) : 1;

        //本地分类数组
        $local_type= Db::name('type')->where(['type_mid' => 1])->column('type_name','type_id');

        $url_param = [];
        $url                 = $param['cjurl'];
        $url_param['ac']     = $param['ac'];
        $url_param['cjurl']  = $param['cjurl'];
        $url_param['cjflag'] = $param['cjflag'];
        $url_param['pg']     = is_numeric($page) ? $page : '';
        $url_param['h']      = $param['h'];
        $url_param['ids']    = $param['ids'];
        $url_param['wd']     = $param['wd'];
        $url_param['type']   = $param['type'];
        $cjflag              = $param['cjflag'];

        if($param['ac']!='list'){
            $url_param['ac'] = 'videolist';
        }
        if(strpos($url,'?')===false){
            $url .='?';
        }
        else{
            $url .='&';
        }
        $url.= http_build_query($url_param);
        //发起一个简单get请求
        //$client = new Client();

        $response = Helper::simpleHttp($url);
        $data = $response['body'];
        /*$response = $client->request('GET', $url);
        $data     = $response->getBody()->getContents();*/

        if(empty($response)){
            return ['code'=>1001, 'msg'=>'连接API资源库失败，通常为服务器网络不稳定或禁用了采集'];
        }
        //1json;2 xml
        if ($param['type']==1) {
            $xml = json_decode($data, true);
            $limit=$xml['limit'];
        } elseif ($param['type']==2){
            $xml  = @simplexml_load_string($data);

            $limit=$xml->list->attributes()->pagesize;
        }
        //已绑定的数据
        $where[]=['type_key', 'like',"%{$cjflag}%"];
        $b_type_key_val= Db::name('vod_collect_type')->where($where)->order('type_value','ASC')->column('type_key','type_value');
        $b_type_key    = array_flip($b_type_key_val); //交换数组中的键和值

        $cjflag=$param['cjflag'];
        //分类列表
        $array_type = [];
        $key=0;

        if($param['ac'] == 'list'){
            if($param['type']==1) {//json
                foreach($xml['class'] as $ty){
                    $array_type[$key]['type_id']   = (string)$ty['type_id'];
                    $array_type[$key]['type_name'] = (string)$ty['type_name'];
                    if(in_array($cjflag.'_'.$array_type[$key]['type_id'],$b_type_key_val)){
                        $l_key=$b_type_key[$cjflag.'_'.$array_type[$key]['type_id']];
                        $array_type[$key]['isbind']=1;
                        $array_type[$key]['local_type_name']=$local_type[$l_key];
                    }else{
                        $array_type[$key]['isbind']=0;
                    }
                    $key++;
                }
            }elseif ($param['type']==2){//xml
                foreach($xml->class->ty as $ty){
                    $array_type[$key]['type_id']   = (string)$ty->attributes()->id;
                    $array_type[$key]['type_name'] = (string)$ty;
                    if(in_array($cjflag.'_'.$array_type[$key]['type_id'],$b_type_key_val)){
                        $l_key=$b_type_key[$cjflag.'_'.$array_type[$key]['type_id']];
                        $array_type[$key]['isbind']=1;
                        $array_type[$key]['local_type_name']=$local_type[$l_key];
                    }else{
                        $array_type[$key]['isbind']=0;
                    }
                    $key++;
                }
            }

        }
        $param=json_encode($param);
        $res = ['code'=>1, 'msg'=>'xml','limit'=>$limit, 'typeList'=>$array_type,'param'=>$param,'cjflag'=>$cjflag,'cjurl'=>http_build_query($url_param)];
        $this->assign($res);

        return $this->fetch();
    }

    /**
     * 采集数据列表
     */
    public function collect_read()
    {
        $params = $this->request()->getRequestParam();
        $wd=isset($params['wd']) ? $params['wd'] : ''; //搜索词

        if($wd){
            $info           =json_decode($params['param'],true);
            $info['wd']     =$wd;
            $params['param']=json_encode($info);
        }

        $data=CollectService::getInstance()->vod($params);

        return Helper::responseJson([
            'code'  => 0,
            'msg'   => '采集列表',
            'count' => $data['count'] ?? 0,
            'data'  => $data['list'] ?? []
        ]);
    }

    //采集数据
    public function collect_video(){
        $params = $this->get();
        $cache = Cache::getInstance();

        $url                 = $params['cjurl'];
        $url_param['cjflag'] = $params['cjflag'];
        $url_param['pg']     = isset($params['pg']) ? (int)$params['pg'] : 1;
        $url_param['h']     = isset($params['h']) ? trim($params['h']) : 24;
        $url_param['type']   = $params['type'];
        $url_param['ac']     = 'videolist';
        $url_param['ids']    = isset($params['ids']) ? trim($params['ids']) : '';
        $cjurl = $url."?".http_build_query($url_param);
        $url_param['cjurl']  = $url;
        $this->assign($url_param);

        $infos['param']=json_encode($url_param);
        //参数处理返回数据
        $data = CollectService::getInstance()->vod($infos);

        $isNext = 1;
        if ($data['code'] == 1 && isset($data['pagecount']) && !empty($data['list'])) {
            //查配置是否同步图片到本地
            $save_pic = Vars::get('vod.is_savepic',0);

            $res = CollectService::getInstance()->vod_data($data,$url_param['cjflag'],$url_param['pg']+1,$save_pic);
            if($params['type']==1){
                $page_count=$data['pagecount'];
            }else{
                $page_count=$data['count'];
            }
            if ($url_param['pg'] == 1){
                $cache->set($url.'_page_count', $page_count);
            }
        } else {
            $page_count = $url_param['pg'] != 1 ? $cache->get($url.'_page_count',0) : 0;
            $res = array('msg'=>[]);
        }

        $this->assign('page_count',$page_count);
        $this->assign('res',$res['msg']);

        if ($url_param['pg'] >= $page_count) {
            $isNext = 0;
        }
        $this->assign('isNext',$isNext);
        return $this->fetch();

    }

}