<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Vod\Controller;


use App\Vod\Extend\Common;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Share extends Base
{

    public function posters(){
        //判断
        $session = \App\User\Extend\Common::checkCookie();

        $params=$this->get();
        if(!isset($params['id'])){
            return ['code'=>0,'msg'=>'没有找到影片'];
        }
        //获取域名  ?invite=4
        $server=$this->request()->getUri();
        $http_type=$server->getScheme();
        $host=$server->getHost();
        $domain=$http_type.'://'.$host;
        if(isset($session['user_id'])){
            $url=$domain.Helper::url('vod@detail/index',['id'=>$params['id'],'invite'=>$session['user_id']]);
        }else{
            $url=$domain.Helper::url('vod@detail/index',['id'=>$params['id']]);
        }

        $res= Db::name('vod')->where(['vod_id'=>$params['id']])->find();

         $this->assign(['data'=>$res,'url'=>$url]);
         return $this->fetch('/');
    }





    public function index()
    {
        $param = Common::ray_param_url();
        $key = 'html_vod@index/index/page/'.$param['page'];
        if ($this->siteConfig['vod_cache_index'] > 10 && $html = Cache::getInstance()->get($key)){
            return Helper::responseHtml($html);
        }
        Context::set('obj',null);
        Context::set('param',$param);
        $html = $this->fetch('index/index', false);
        if ($this->siteConfig['vod_cache_index'] > 10){
            Cache::getInstance()->set($key, $html, $this->siteConfig['vod_cache_index']);
        }
        return Helper::responseHtml($html);
    }
}