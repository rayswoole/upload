<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Vod\Controller;


use App\Vod\Extend\Common;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;

class Index extends Base
{
    public function index()
    {
        $param = Common::ray_param_url();
        $key = 'html_vod@index/index/page/'.$param['page'];
        if ($this->siteConfig['vod_cache_index'] > 10 && $html = Cache::getInstance()->get($key)){
            return Helper::responseHtml($html);
        }
        Context::set('obj',null);
        Context::set('param',$param);
        $html = $this->fetch('index/index', false);
        if ($this->siteConfig['vod_cache_index'] > 10){
            Cache::getInstance()->set($key, $html, $this->siteConfig['vod_cache_index']);
        }
        return Helper::responseHtml($html);
    }
}