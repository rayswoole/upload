<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-10 18:12
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Controller;


use App\Vod\Extend\Common;
use App\Vod\Service\VodService;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;

class Play extends Base
{
    public function index()
    {
        $param = Common::ray_param_url();
        $key = 'html_vod@play/index/id/'.$param['id'];
        if ($this->siteConfig['vod_cache_play'] > 10 && $html = Cache::getInstance()->get($key)){
            return Helper::responseHtml($html);
        }

        Context::set('param',$param);
        $info = VodService::getInstance()->get($param['id']);
        if (!$info){
            return Helper::responseRedirect('vod@index/index');
        }
        $player = '';
        $info['player_info'] = [];
        $info['player_info']['flag'] = 'play';
        $info['player_info']['encrypt'] = 0;
        $info['player_info']['trysee'] = 0;
        $info['player_info']['points'] = 0;
        $info['player_info']['link'] = Common::ray_url_vod_play($info, ['sid'=>$param['sid'],'nid'=>$param['nid']]);
        $info['player_info']['url'] = '';
        $info['player_info']['url_next'] = '';
        $info['player_info']['link_pre'] = '';
        $info['player_info']['link_next'] = '';

        if (isset($info['vod_play_list'][$param['sid']])){
            if ($param['nid'] <= 1) {
                $info['player_info']['link_pre'] = Common::ray_url_vod_play($info, ['sid'=>$param['sid'],'nid' => $param['nid']]);
            } else {
                $info['player_info']['link_pre'] = Common::ray_url_vod_play($info, ['sid'=>$param['sid'],'nid' => $param['nid'] - 1]);
            }
            if ($param['nid'] == $info['vod_play_list'][$param['sid']]['url_count']) {
                $info['player_info']['link_next'] = Common::ray_url_vod_play($info, ['sid'=>$param['sid'],'nid' => $param['nid']]);
            } else {
                $info['player_info']['link_next'] = Common::ray_url_vod_play($info, ['sid'=>$param['sid'],'nid' => $param['nid'] + 1]);
            }
            $player = htmlspecialchars_decode($info['vod_play_list'][$param['sid']]['player_info']['player_code']);
            $info['player_info']['url'] = $info['vod_play_list'][$param['sid']]['urls'][$param['nid']]['url'];
            $info['player_info']['parseurl'] = $info['vod_play_list'][$param['sid']]['player_info']['player_parse'];
            if (isset($info['vod_play_list'][$param['sid']]['urls'][$param['nid']+1])){
                $info['player_info']['url_next'] = $info['vod_play_list'][$param['sid']]['urls'][$param['nid']+1]['url'];
            }
        }
        Context::set('obj',$info);
        $this->assign([
            'obj' => $info,
            'param' => $param,
            'player_data' => '<script type="text/javascript">var data=' . Helper::enJson($info['player_info']) . '</script>',
            'player_js' => $player]);

        $html = $this->fetch('vod/play', false);
        if ($this->siteConfig['vod_cache_play'] > 10){
            Cache::getInstance()->set($key, $html, $this->siteConfig['vod_cache_play']);
        }
        return Helper::responseHtml($html);

    }
}