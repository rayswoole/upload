<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-10 18:11
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Controller;


use App\Vod\Extend\Common;
use App\Vod\Service\VodService;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Detail extends Base
{
    public function index()
    {
        $param = Common::ray_param_url();
        $key = 'html_vod@detail/index/id/'.$param['id'];
        if ($this->siteConfig['vod_cache_detail'] > 10 && $html = Cache::getInstance()->get($key)){
            return Helper::responseHtml($html);
        }

        $obj = VodService::getInstance()->get($param['id']);
        if (!$obj){
            $obj = array(
                'vod_id'=>0,
                'type_id'=>0,
                'vod_title'=>'',
                'vod_letter'=>'',
                'vod_star'=>0,
                'vod_director'=>'',
                'vod_actor'=>'',
                'vod_actor_val'=>'',
                'vod_total'=>0,
                'vod_remarks'=>'',
                'vod_score'=>0,
                'vod_serial'=>0,
                'vod_duration'=>'',
                'vod_pubdate'=>'',
                'vod_class'=>'',
                'vod_year'=>'',
                'vod_area'=>'',
                'vod_lang'=>'',
                'vod_play_from'=>'',
                'vod_play_server'=>'',
                'vod_play_url'=>'',
                'vod_status'=>0,
                'vod_hits'=>0,
                'vod_hits_day'=>0,
                'vod_hits_week'=>0,
                'vod_hits_month'=>0,
                'vod_color'=>'',
                'vod_content'=>'',
                'vod_pic'=>'',
                'vod_pic_thumb'=>'',
                'vod_blurb'=>'',
                'vod_jumpurl'=>'',
                'vod_jumpstatus'=>0,
                'vod_sort'=>0,
                'vod_addtime'=>time(),
                'vod_play_list'=>[],
                'type' => array(
                    'type_id'=>0,
                    'type_name'=>'',
                    'type_en'=>'',
                    'type_sort'=>0,
                    'type_mid'=>1,
                    'type_pid'=>0,
                    'type_status'=>0,
                    'type_tpl'=>'',
                    'type_tpl_list'=>'',
                    'type_tpl_detail'=>'',
                    'type_tpl_play'=>'',
                    'type_tpl_down'=>'',
                    'type_keywords'=>'',
                    'type_description'=>'',
                    'type_title'=>'',
                    'type_union'=>'',
                    'type_extend'=>'',
                    'type_logo'=>'',
                    'type_pic'=>'',
                    'type_jumpurl'=>''
                )
            );
        }

        Context::set('obj',$obj);
        Context::set('param',$param);

        $this->assign([
            'param' => $param,
            'obj' => $obj
        ]);

        $html = $this->fetch('vod/detail', false);
        if ($this->siteConfig['vod_cache_detail'] > 10){
            Cache::getInstance()->set($key, $html, $this->siteConfig['vod_cache_detail']);
        }
        return Helper::responseHtml($html);
    }

    protected function afterAction(?string $actionName): void
    {
        if ($actionName !== 'index') {
            return;
        }
        $obj = Context::get('obj');
        if (!is_null($obj)){
            Db::name('vod')->where('vod_id','=',$obj['vod_id'])
                ->inc('vod_hits',1)
                ->inc('vod_hits_day',1)
                ->inc('vod_hits_week',1)
                ->inc('vod_hits_month',1)->update();
        }
    }
}