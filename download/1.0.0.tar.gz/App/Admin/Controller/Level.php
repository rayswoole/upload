<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;

use rayswoole\orm\facade\Db;
use rayswoole\Helper;
use rayswoole\Service;

class Level extends Base
{


    public function index()
    {
        return $this->fetch();
    }

    /**
     * @return bool|null
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/22
     */
    public function read(): ?bool
    {
        if ($this->isAjax()) {
            $param = (array)$this->get();

            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 10;
            $where = [];

            if (isset($param['key'])) {
                $key = $param['key'];
                if (isset($key['searchName']) && $key['searchName']) {
                    $v = $key['searchName'];
                    $where[] = ['level_name', 'like', "%{$v}%"];
                }
            }
            $res = Db::name('user_level')
                ->where($where)
                ->limit($limit * ($page - 1),$limit)
                ->order('level_id','asc')
                ->select()->toArray();

            return Helper::responseJson ([
                'code' => 0,
                'msg' => '等级列表',
                'count' => count($res),
                'data' => $res
            ]);
        }
    }

    /**
     * @author zhou
     * @time 2020/7/25
     */
    public function create()
    {
        $param = $this->get();

        $edit_id=isset($param['edit_id']) ? $param['edit_id'] :"";
        if ($edit_id) {
            $res = Db::name('user_level')->where(['level_id' => intval($param['edit_id'])])->find();
            $this->assign(['data' => $res]);
        } else {
            $this->assign(['data' => '']);
        }

        return $this->fetch();
    }

    /**
     * @return bool
     * @throws \rayswoole\orm\db\exception\DbException
     * @author zhou
     * @time 2020/10/22
     */
    public function delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];

            if ($id!=1) {
                $res = Db::name('user_level')->delete($id);
            } else {
                //普通会员不可删除
                return Helper::responseJson(['code' => 1, 'msg' => '该项不可删除', 'data' => []]);
            }

            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'data' => []]);
            } else {
                return Helper::responseJson(['code' => 1, 'msg' => '删除成功', 'data' => []]);
            }
        }
    }

    public function edit(): void
    {

    }

    /**
     * 保存修改
     * @return mixed
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/22
     */
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();

            $res = Helper::service('Level')->saveLevel($param);
            return Helper::responseJson($res);
        }
    }

/*
 * [updateField 字段值更新]
 * @method POST
 * @author C.
 * @time 2020/2/3 上午2:18
 */
    public function update_field()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'level_status';

            $res = Db::name('user_level')->where(['level_id'=>$id])->update([$field => $value]);

            if (!$res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除失败', 'data' => []]);
            }
                return Helper::responseJson(['code' => 1, 'msg' => '更新成功', 'data' => []]);

        }
    }
















}