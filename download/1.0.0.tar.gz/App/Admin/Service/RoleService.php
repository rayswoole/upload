<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Service;


use App\Admin\Model\RoleModel;
use rayswoole\Helper;
use rayswoole\Service;

class RoleService extends Service
{

    public function getRole($where): array
    {
        $model = new RoleModel();
        if ($res = $model->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    public function getRoleList($where, $page, $limit): array
    {
        $model = new RoleModel();
        $data = $model->where($where)->page($page, $limit)->select()->toArray();
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    public function saveRole(array $data): bool
    {
        $model = new RoleModel();
        if (!empty($data['role_id'])) {
            if ((int)$data['role_id'] === 1) {
                $data['role_status'] = 1;
            }
            $model = $model->find($data['role_id']);
        }
        $res = $model->save($data);
        if ($res) {
            if (!empty($data['auth'])) {
                $save = [];
                $id = (int)$model->role_id;
                foreach ($data['auth'] as $v) {
                    if (empty($v)) {
                        continue;
                    }
                    $save[] = ['role_id' => $id, 'node_id' => (int)$v];
                }
                Helper::service('RoleMenu')->deleteRmenu(['role_id' => $id]);
                Helper::service('RoleMenu')->saveRmenu($save);
            }
            return true;
        }
        return false;

    }

    public function deleteRole($data): bool
    {
        $item = [];
        foreach ($data as $v) {
            if ((int)$v === 1) {
                continue;
            }
            $item[] = $v;
        }
        $res = RoleModel::destroy($item);
        if ($res) {
            foreach ($item as $k => $v) {
                Helper::service('RoleMenu')->deleteRmenu([
                    'role_id' => (int)$v
                ]);
            }
            return true;
        }
        return false;
    }
}