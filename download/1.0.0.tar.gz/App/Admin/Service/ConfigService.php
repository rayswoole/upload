<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-23 10:52
 ** ----------------------------------------------------------------------
 **/

namespace App\Admin\Service;

use App\Admin\Model\ConfigModel;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class ConfigService extends Service
{
    public function get($group, $key = '')
    {
        //支持system.xx这样的传值
        if (strpos($group, '.') > 0) {
            [$group, $key] = explode('.', $group, 2);
        }
        $reault = Db::name('Config')->where(['group' => $group])->select()->toArray();
        if (empty($reault)) {
            return null;
        }
        $data = [];
        foreach ($reault as $_result) {
            switch ($_result['type']) {
                case 1:
                    $_result['val'] = intval($_result['val']);
                    break;
                case 2:
                    $_result['val'] = floatval($_result['val']);
                    break;
                case 3:
                    break;
                case 4:
                    $_result['val'] = Helper::deJson($_result['val']);
                    break;
                case 5:
                    $_result['val'] = \Opis\Closure\unserialize($_result['val']);
                    break;
            }
            $data[$_result['name']] = $_result;
        }
        if ($key !== '') {
            return $data[$key] ?? null;
        } else {
            return $data;
        }
    }

    public function add($group, $data, $key = '')
    {
        if ($key !== '') {
            $type = 0;
            switch (gettype($data)) {
                case 'integer':
                    $type = 1;
                    break;
                case 'double':
                    $type = 2;
                    break;
                case 'string':
                    $type = is_numeric($data) ? (strpos($data, '.')!==false ? 2 : 1) : 3;
                    break;
                case 'array':
                    $type = 4;
                    $data = Helper::enJson($data);
                    break;
                case 'object':
                    $type = 5;
                    $data = \Opis\Closure\serialize($data);
                    break;
            }
            return Db::name('Config')->insert([
                'name' => $key,
                'group' => $group,
                'val' => $data,
                'type' => $type
            ]) ? true : false;
        }
        if (is_array($data)) {
            foreach ($data as $_key => $_data) {
                $this->add($group, $_data, $_key);
            }
            return true;
        }
        return false;
    }

    public function update($group, $data, $key = '')
    {
        if ($key !== '') {
            $type = 0;
            switch (gettype($data)) {
                case 'integer':
                    $type = 1;
                    break;
                case 'double':
                    $type = 2;
                    break;
                case 'string':
                    $type = is_numeric($data) ? (strpos($data, '.')!==false ? 2 : 1) : 3;
                    break;
                case 'array':
                    $type = 4;
                    $data = Helper::enJson($data);
                    break;
                case 'object':
                    $type = 5;
                    $data = \Opis\Closure\serialize($data);
                    break;
            }
            $where = is_numeric($key) ? ['id' => $key] : [
                'name' => $key,
                'group' => $group,
            ];
            return Db::name('Config')->where($where)->update([
                'val' => $data,
                'type' => $type
            ]) ? true : false;
        }

        $all = $this->get($group);
        foreach ($data as $_key => $_data) {
            if (isset($all[$_key])) {
                $this->update($group, $_data, $all[$_key]['id']);
            } else {
                $this->add($group, $_data, $_key);
            }
        }
        return true;
    }

    public function reset()
    {

    }

    public function getDirarr()
    {
        $path = RAY_ROOT . '/Public/skin/';
        $temp = array_diff(scanDir($path), array('..', '.'));
        foreach ($temp as $k => $v) {
            if (strpos($v, '.')) {
                unset($temp[$k]);
            }
        }
        return $temp;
    }
}