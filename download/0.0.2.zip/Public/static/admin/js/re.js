'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
    return typeof obj;
} : function (obj) {
    return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};

!function (win) {

    var _this = '';
    var re = function re() {
    };
    re.prototype.init = function () {
        this.time = '201912310860';
        _this = this;
    };
    re.prototype.xpost = function (u, x, b, c, e) {
        $.ajax({
            url: u, data: x, async: true, type: 'post', dataType: "json",
            beforeSend: function beforeSend(be) {
                b(be);
            },
            success: function success(se) {
                c(se);
            },
            error: function error(er) {
                e(er);
            }
        });
    };
    re.prototype.xget = function (u, x, b, c, e) {
        $.ajax({
            url: u, data: x, async: true, type: 'get', dataType: "json",
            beforeSend: function beforeSend(be) {
                b(be);
            },
            success: function success(se) {
                c(se);
            },
            error: function error(er) {
                e(er);
            }
        });
    };
    re.prototype.xtimeFormat = function (tt) {
        if (tt === 0) return tt;
        var n = new Date(tt * 1000);
        var y = n.getFullYear();
        var mon = n.getMonth() + 1;
        var d = n.getDate().toString().length === 1 ? '0' + n.getDate().toString() : n.getDate();
        var h = n.getHours().toString().length === 1 ? '0' + n.getHours().toString() : n.getHours();
        var m = n.getMinutes().toString().length === 1 ? '0' + n.getMinutes().toString() : n.getMinutes();
        var s = n.getSeconds().toString().length === 1 ? '0' + n.getSeconds().toString() : n.getSeconds();
        return y + "-" + mon + "-" + d + "   " + h + ":" + m + ":" + s;
    };
    re.prototype.xtimeToDay = function (s, e, format) {
        if (e < s) return '结束时间不能小于开始时间';
        var m = '',
            f = '';
        s = new Date(s).getTime();
        e = new Date(e).getTime();
        format = format || 'd-h-m-s';
        var mss = e - s;
        if (isNaN(mss)) return '时间格式不合法';
        var xx = {
            d: function d() {
                return parseInt(mss / (1000 * 60 * 60 * 24)) + " 天 ";
            },
            h: function h() {
                return parseInt(mss % (1000 * 60 * 60 * 24) / (1000 * 60 * 60)) + " 小时 ";
            },
            m: function m() {
                return parseInt(mss % (1000 * 60 * 60) / (1000 * 60)) + " 分钟 ";
            },
            s: function s() {
                return mss % (1000 * 60) / 1000 + " 秒 ";
            }
        };
        f = format.split('-');
        try {
            $.each(f, function (i, a) {
                if (a != '') {
                    m += xx[a].call(this);
                }
            });
            return m;
        } catch (e) {
            console.log(e.message);
        }
    };
    re.prototype.load = function (msg) {
        msg = msg || '正在提交程序中...';
        this.index_msg = layer.msg("<i class='layui-icon'>&#xe63d;</i><p>" + msg + "</p>", {
            time: this.time,
            shade: .6,
            type: 1,
            scrollbar: false
        });
    };
    re.prototype.loadclose = function () {
        layer.close(this.index_msg);
    };
    re.prototype.fclose = function () {
        var index = parent.layer.getFrameIndex(window.name);
        parent.layer.close(index);
    };

    re.prototype.url = {
        'path': function () {
            return win.location.pathname;
        },
        'domain': function () {
            return win.location.origin;
        }
    };

    re.prototype.layuiDataName = function () {
        return 'topazx' + cre.url.path().replace(/(^\/)|(\/$)/g, "").split('/')[0];
    };

    re.prototype.set_top_nav_data = function (data) {
        if (data != null) {
            layui.data(this.layuiDataName(), data);
        }
    };
    re.prototype.get_top_nav_data = function () {
        return layui.data(this.layuiDataName());
    };
    re.prototype.del_top_nav_data = function (id) {
        id = id | 'topnav';
        if (typeof id != "undefined") {
            layui.data(this.layuiDataName(), {
                key: id,
                remove: true
            });
        } else {
            layui.data(this.layuiDataName(), null);
        }
    };

    re.prototype.cookie = {
        'init': function () {
            if (_typeof($.cookie) === undefined || $.cookie === undefined) {
                cre.getScript.load('/static/js/jquery.cookie.js');
            }
        },
        'set': function set(n, v, t) {
            this.init();
            if (!n) {
                return $.cookie(n, v, {expires: t});
            }
        },
        'get': function get(n) {
            this.init();
            return $.cookie(n);
        },
        'del': function del(n) {
            this.init();
            return $.removeCookie(n);
        }
    };

    re.prototype.usertoken = function () {
        if (this.cookie.get('ULTOKEN') !== undefined) {
            return !!JSON.parse(this.cookie.get('ULTOKEN')).token ? JSON.parse(this.cookie.get('ULTOKEN')).token : undefined;
        }
    };

    re.prototype.username = function () {
        if (this.cookie.get('ULTOKEN') !== undefined) {
            return !!JSON.parse(this.cookie.get('ULTOKEN')).user_name ? JSON.parse(this.cookie.get('ULTOKEN')).user_name : undefined;
        }
    };

    re.prototype.loginbtn = function (name) {
        if (!name) return false;
        if ($.cookie !== undefined && this.usertoken()) {
            $(name).html('<a href="javascript:;" class="username">' + this.username() + '</a>\n                <dl class="layui-nav-child">\n                    <dd>\n                        <a href="/user/index/userinfo">个人信息</a></dd>\n                    <dd>\n                        <a href="/user/login/loginout">切换帐号</a></dd>\n                    <dd>\n                        <a href="/user/login/loginout">退出</a></dd>\n                </dl>\n            </li>');
        }
        return true;
    };

    re.prototype.getScript = {
        'isInclude': function isInclude(name) {
            var js = /js$/i.test(name);
            var es = document.getElementsByTagName(js ? 'script' : 'link');
            for (var i = 0; i < es.length; i++) {
                if (es[i][js ? 'src' : 'href'].indexOf(name) !== -1) return true;
            }
            return false;
        },
        'load': function load(n, c) {
            if (!this.isInclude(n)) {
                c = c || new Function();
                $.ajax({
                    url: n, async: false, dataType: "script", cache: true,
                    success: function success(se) {
                        return c(se);
                    }
                });
            }
        }
    };

    re.prototype.QRcode = {
        'get': function get(cn, text, w, h, cd, cl, le) {
            try {
                cre.getScript.load('/static/js/qrcode.min.js');
                this.qrcode_test = text;
                return this.qrcode = new QRCode(cn, {
                    text: text,
                    width: w || 128,
                    height: h || 128,
                    colorDark: cd || "#000000",
                    colorLight: cl || "#ffffff",
                    correctLevel: le || QRCode.CorrectLevel.H
                });
            } catch (e) {
                layui.layer.msg(e.message);
            }
        },
        'reload': function reload() {
            null != this.qrcode && this.qrcode.makeCode(this.qrcode_test + (-1 !== this.qrcode_test.indexOf("?") ? "&" : "?&") + "_t=" + (new Date).getTime());
        }
    };

    re.prototype.comment = {
        facePath: [{faceName: "微笑", facePath: "/static/admin/face/0.gif"}, {
            faceName: "撇嘴",
            facePath: "/static/admin/face/1.gif"
        }, {faceName: "色", facePath: "/static/admin/face/2.gif"}, {
            faceName: "发呆",
            facePath: "/static/admin/face/3.gif"
        }, {faceName: "得意", facePath: "/static/admin/face/4.gif"}, {
            faceName: "流泪",
            facePath: "/static/admin/face/5.gif"
        }, {faceName: "害羞", facePath: "/static/admin/face/6.gif"}, {
            faceName: "闭嘴",
            facePath: "/static/admin/face/7.gif"
        }, {faceName: "大哭", facePath: "/static/admin/face/9.gif"}, {
            faceName: "尴尬",
            facePath: "/static/admin/face/10.gif"
        }, {faceName: "发怒", facePath: "/static/admin/face/11.gif"}, {
            faceName: "调皮",
            facePath: "/static/admin/face/12.gif"
        }, {faceName: "龇牙", facePath: "/static/admin/face/13.gif"}, {
            faceName: "惊讶",
            facePath: "/static/admin/face/14.gif"
        }, {faceName: "难过", facePath: "/static/admin/face/15.gif"}, {
            faceName: "酷",
            facePath: "/static/admin/face/16.gif"
        }, {faceName: "冷汗", facePath: "/static/admin/face/17.gif"}, {
            faceName: "抓狂",
            facePath: "/static/admin/face/18.gif"
        }, {faceName: "吐", facePath: "/static/admin/face/19.gif"}, {
            faceName: "偷笑",
            facePath: "/static/admin/face/20.gif"
        }, {faceName: "可爱", facePath: "/static/admin/face/21.gif"}, {
            faceName: "白眼",
            facePath: "/static/admin/face/22.gif"
        }, {faceName: "傲慢", facePath: "/static/admin/face/23.gif"}, {
            faceName: "饥饿",
            facePath: "/static/admin/face/24.gif"
        }, {faceName: "困", facePath: "/static/admin/face/25.gif"}, {
            faceName: "惊恐",
            facePath: "/static/admin/face/26.gif"
        }, {faceName: "流汗", facePath: "/static/admin/face/27.gif"}, {
            faceName: "憨笑",
            facePath: "/static/admin/face/28.gif"
        }, {faceName: "大兵", facePath: "/static/admin/face/29.gif"}, {
            faceName: "奋斗",
            facePath: "/static/admin/face/30.gif"
        }, {faceName: "咒骂", facePath: "/static/admin/face/31.gif"}, {
            faceName: "疑问",
            facePath: "/static/admin/face/32.gif"
        }, {faceName: "嘘", facePath: "/static/admin/face/33.gif"}, {
            faceName: "晕",
            facePath: "/static/admin/face/34.gif"
        }, {faceName: "折磨", facePath: "/static/admin/face/35.gif"}, {
            faceName: "衰",
            facePath: "/static/admin/face/36.gif"
        }, {faceName: "骷髅", facePath: "/static/admin/face/37.gif"}, {
            faceName: "敲打",
            facePath: "/static/admin/face/38.gif"
        }, {faceName: "再见", facePath: "/static/admin/face/39.gif"}, {
            faceName: "擦汗",
            facePath: "/static/admin/face/40.gif"
        }],
        config: {
            url: {
                delete: "/comment/index/delete",
                reply: "/comment/index/save",
                message: "/comment/index/save",
                reply_more: "/comment/index/read",
                message_more: "/comment/index/read"
            },
            user: {
                id: 0,
                name: 0,
                token: "",
                avatar: "/static/images/face.png",
                unloginClickBtn: function unloginClickBtn() {
                    return layui.layer.msg("请先登录...")
                }
            },
            message_init_num: 3,
            reply_init_num: 2,
            message_load_num: 3,
            reply_load_num: 2,
            skin: "skin_write",
            comment_mid: 0,
            comment_rid: 0,
            comment_sid: 0,
            parseData: function parseData(e) {
                return {code: e.code, msg: e.msg, result: e.data}
            }
        },
        init: function init(e) {
            var a = !1;
            this.merge(e), this.config.user.name = this.isEmpty(this.config.user.name) ? cre.username() : this.config.user.name, this.config.user.token = this.isEmpty(this.config.user.token) ? cre.usertoken() : this.config.user.token, console.log(this.config), $(".skin").removeClass().addClass(this.config.skin), $(".ly_box .Input_text").focusout(function () {
                $(this).parent().css("border-color", "#cccccc"), $(this).parent().css("box-shadow", "none"), $(this).parent().css("-moz-box-shadow", "none"), $(this).parent().css("-webkit-box-shadow", "none")
            }), $(".ly_box .Input_text").focus(function () {
                $(this).parent().css("border-color", "rgba(19,105,172,.75)"), $(this).parent().css("box-shadow", "0 0 3px rgba(19,105,192,.5)"), $(this).parent().css("-moz-box-shadow", "0 0 3px rgba(241,39,232,.5)"), $(this).parent().css("-webkit-box-shadow", "0 0 3px rgba(19,105,252,3)")
            }), $(document).on("click", ".imgBtn", function () {
                var e = $(this).parent().siblings(".faceDiv");
                if (!1 === a) {
                    if (a = !0, $(this).parent().prev().animate({marginTop: "-115px"}, 300), 0 == e.children().length) {
                        for (var n = 0; n < cre.comment.facePath.length; n++) e.append('<img title="' + cre.comment.facePath[n].faceName + '" src=' + cre.comment.facePath[n].facePath + " />");
                        $(this).parent().siblings(".faceDiv").children("img").click(function () {
                            a = !1, $(this).parent().animate({marginTop: "50px"}, 300), cre.comment.insertAtCursor($(this).parent().siblings(".Input_text")[0], "[" + $(this).attr("title") + "]")
                        })
                    }
                } else a = !1, $(this).parent().prev().animate({marginTop: "50px"}, 300)
            }), cre.comment.islogin() || ($(".ly_btn").removeClass("ly_btn").addClass("ly_btn_un").html("请先登录"), $(".ly_btn_un").on("click", function () {
                return cre.comment.config.user.unloginClickBtn()
            })), this.comments.init(), this.del.init(), this.more.init(), this.reload()
        },
        show: function show() {
            $("#ray_comment").html("");
            var e = $("#ray_comment").data("mid"), n = $("#ray_comment").data("rid"), a = $("#ray_comment").data("sid");
            return cre.comment.isEmpty(e) || cre.comment.isEmpty(n) ? (layui.layer.msg("模块id[mid]或关联id[rid]不能为空"), !1) : cre.comment.isEmpty(a) ? (layui.layer.msg("站点id不能为空"), !1) : void $("#ray_comment").html("<iframe src='/comment/index?mid=" + e + "&rid=" + n + "&sid=" + a + '\' width="100%" height=\'100%\' frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="yes" allowtransparency="yes"></iframe>')
        },
        EmoticonConversion: function EmoticonConversion(a) {
            if (void 0 !== a) {
                var t, c, i, m = a.match(/\[(.*?)\]/g);
                if (null != m && "" !== m) for (var s = 0; s < m.length; s++) i = m[s].replace(/(^\[)|(\]$)/g, ""), $.each(this.facePath, function (e, n) {
                    n.faceName === i && (t = window.location.origin + "/" + n.facePath, c = '<img src="' + t + '" height="22" width="22" />', a = a.replace(m[s], c))
                })
            }
            return a
        },
        insertAtCursor: function insertAtCursor(e, n) {
            var a, t, c;
            document.selection ? (e.focus(), sel = document.selection.createRange(), sel.text = n, sel.select()) : e.selectionStart || "0" == e.selectionStart ? (a = e.selectionStart, t = e.selectionEnd, c = e.scrollTop, e.value = e.value.substring(0, a) + n + e.value.substring(t, e.value.length), 0 < c && (e.scrollTop = c), e.focus(), e.selectionStart = a + n.length, e.selectionEnd = a + n.length) : (e.value += n, e.focus())
        },
        del: {
            init: function init() {
                $(document).on("mouseenter mouseleave", ".comment_date_or_hf_c", function (e) {
                    "mouseenter" === e.type ? !$(this).children(".c_hf").children(".del").hasClass("c_hide") && cre.comment.islogin() && $(this).find(".del").show() : "mouseleave" === e.type && $(this).find(".del").hide()
                }), this.submit()
            }, submit: function submit() {
                $(document).on("click", ".del", function () {
                    var a = $(this).data("cid");
                    $.ajax({
                        url: cre.comment.config.url["delete"],
                        type: 'post',
                        data: {c_id: a, time: (new Date).getTime()},
                        headers: cre.comment.config.headers || {token: cre.comment.config.user.token},
                        dataType: "json",
                        success: function (e) {
                            var n = e;
                            if ("function" == typeof cre.comment.config.parseData && (e = cre.comment.config.parseData(e), n.code !== e.code)) return layer.msg("状态码有误"), !1;
                            0 === e.code && $(".c_hf_" + a).remove(), layer.msg(e.msg)
                        },
                        error: function (e, n) {
                            layer.msg("接口请求异常: " + n)
                        }
                    })
                })
            }
        },
        comments: {
            hf_num: 0, init: function init() {
                this.comment_load(cre.comment.config.message_load_num, 1, cre.comment.config.reply_load_num, 1), this.reply_show(), this.reply_submit(), this.message_submit()
            }, reply_show: function reply_show() {
                var t = !0;
                $(document).on("click", ".com", function () {
                    return cre.comment.islogin() ? (t ? (t = !1, e = $(this).data("cid"), n = $(this).data("mname"), a = $(this).data("pid"), $(".hf_box").remove(), 0 < $(this).parents(".comment_date_or_hf_c").siblings(".Input_Box").length ? $(this).parents(".comment_date_or_hf_c").siblings(".Input_Box").remove() : $(this).parents(".comment_date_or_hf").append('<div class="Input_Box hf_box">\n<textarea class="Input_text"></textarea>\n<div class="faceDiv"></div>\n<div class="Input_Foot">\n<a class="imgBtn" href="javascript:void(0);"></a>\n<a class="postBtn hf_btn" data-cid="' + e + '" data-mname="' + n + '" data-pid="' + a + '">确定</a>\n</div>\n</div>')) : (t = !0, $(this).parents(".comment_date_or_hf_c").siblings(".Input_Box").remove()), !0) : cre.comment.config.user.unloginClickBtn();
                    var e, n, a
                })
            }, reply_submit: function reply_submit() {
                $(document).on("click", ".hf_btn", function () {
                    if (cre.comment.islogin) {
                        var e = cre.comment.EmoticonConversion($(this).parent(".Input_Foot").siblings(".Input_text").val()),
                            n = $(this).data("cid"), a = $(this).data("mname"), t = cre.comment.config.user.id,
                            c = (cre.comment.config.user.name, $(this).data("pid")),
                            i = $(this).parents().siblings(".hf_main").children(".hf_text");
                        return i.length <= 0 && (i = $(this).parents().siblings(".hf").parent(".hf_text")), "" !== e && $.ajax({
                            url: cre.comment.config.url.reply,
                            type: 'post',
                            data: {
                                comment_id: n,
                                comment_pid: c,
                                reply: !0,
                                user_id: t,
                                content: e,
                                comment_mid: cre.comment.config.comment_mid,
                                comment_rid: cre.comment.config.comment_rid,
                                time: (new Date).getTime()
                            },
                            headers: cre.comment.config.headers || {token: cre.comment.config.user.token},
                            dataType: "json",
                            success: function (e) {
                                var n = e;
                                if ("function" == typeof cre.comment.config.parseData && (e = cre.comment.config.parseData(e), n.code !== e.code)) return layui.layer.msg("状态码有误"), !1;
                                console.log(e);
                                0 === e.code ? i.append(' <div class="hf c_btn c_hf_' + e.result.comment_id + '">\n<div class="comment_text">\n<span class="name">@' + e.result.username + '<span style="color: #333333;margin: 0 1px;">回复</span>@' + a + '：</span>\n<span class="text">' + cre.comment.decodeEntities(e.result.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + cre.xtimeFormat(e.result.comment_addtime) + '</span>\n<span class="c_hf">\n<a class="del" data-cid="' + e.result.comment_id + '" data-mname="' + e.result.username + '">删除</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>') : layui.layer.msg(e.msg)
                            },
                            error: function (e, n) {
                                layui.layer.msg("接口请求异常: " + n)
                            }
                        }), $(this).parent(".Input_Foot").siblings(".Input_text").val(""), $(document).find(".hf_box").remove(), !0
                    }
                    return cre.comment.config.user.unloginClickBtn()
                })
            }, message_submit: function message_submit() {
                $(".ly_btn").on("click", function () {
                    var a = $(this).parent(".Input_Foot").siblings(".Input_text"),
                        e = cre.comment.EmoticonConversion(a.val()), n = cre.comment.config.user.id,
                        t = (cre.comment.config.user.name, cre.comment.config.user.avatar),
                        c = $(this).parents(".ly_box").siblings(".comment_list");
                    return "" !== e && $.ajax({
                        url: cre.comment.config.url.message,
                        type: 'post',
                        data: {
                            user_id: n,
                            content: e,
                            comment_mid: cre.comment.config.comment_mid,
                            comment_rid: cre.comment.config.comment_rid,
                            time: (new Date).getTime()
                        },
                        headers: cre.comment.config.headers || {token: cre.comment.config.user.token},
                        dataType: "json",
                        success: function (e) {
                            var n = e;
                            if ("function" == typeof cre.comment.config.parseData && (e = cre.comment.config.parseData(e), n.code !== e.code)) return layui.layer.msg("状态码有误"), !1;
                            console.log(e);
                            0 === e.code ? (c.prepend('<div class="comment_list_i c_hf_' + e.result.comment_id + '">\n<div class="comment_face_img comment_list_i_left">\n<img src="' + t + '" alt="用户头像信息">\n</div>\n<div class="comment_list_i_right">\n<div class="ly_main">\n<div class="ly c_btn">\n<div class="comment_text">\n<span class="name">@' + e.result.username + '：</span>\n<span class="text">' + cre.comment.decodeEntities(e.result.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + cre.xtimeFormat(e.result.comment_addtime) + '</span>\n<span class="c_hf">\n<a class="del" data-cid="' + e.result.comment_id + '" data-mname="' + e.result.username + '">删除</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>\n</div>\n<div class="hf_main">\n<div class="hf_text">\n</div>\n</div>\n</div>\n<div class="_clear"></div>\n</div>'), a.val("")) : layui.layer.msg(e.msg)
                        },
                        error: function (e, n) {
                            layui.layer.msg("接口请求异常: " + n)
                        }
                    }), !0
                })
            }, comment_load: function comment_load(e, n, a, t) {
                var c = $(".comment_list"), i = (cre.comment.config.user.id, cre.comment.config.user.name);
                return console.log("sid:"), console.log(cre.comment.config.comment_sid), $.ajax({
                    url: cre.comment.config.url.message_more,
                    data: {
                        msg_limit: e,
                        msg_page: n,
                        reply_limit: a,
                        reply_page: t,
                        comment_mid: cre.comment.config.comment_mid,
                        comment_rid: cre.comment.config.comment_rid,
                        comment_sid: cre.comment.config.comment_sid,
                        time: (new Date).getTime()
                    },
                    headers: cre.comment.config.headers || {token: cre.comment.config.user.token},
                    dataType: "json",
                    success: function (e) {
                        var a, n = e;
                        if ("function" == typeof cre.comment.config.parseData && (e = cre.comment.config.parseData(e), n.code !== e.code)) return layui.layer.msg("状态码有误"), !1;
                        0 === e.code ? (a = "", cre.comment.isEmpty(e.result) ? $(".ly_more").removeClass("ly_more").addClass("reload_html").html("无更多数据...点击刷新页面") : $.each(e.result, function (e, n) {
                            a += '<div class="comment_list_i c_hf_' + n.comment_id + '">\n<div class="comment_face_img comment_list_i_left">\n<img src="' + (n.avatar ? n.avatar : "/static/images/face.png") + '" alt="用户头像信息">\n</div>\n<div class="comment_list_i_right">\n<div class="ly_main">\n<div class="ly c_btn">\n<div class="comment_text">\n<span class="name">@' + (0 === n.user_id ? "系统" : n.user_name) + '：</span>\n<span class="text">' + cre.comment.decodeEntities(n.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + cre.xtimeFormat(n.comment_addtime) + '</span>\n<span class="c_hf" >\n<a class="del ' + (i !== n.user_name ? "c_hide" : "c_show") + '" data-cid="' + n.comment_id + '" data-mname="' + n.user_name + '" data-pid="' + n.comment_id + '">删除</a>\n<a class="com ' + (i !== n.user_name ? "c_show" : "c_hide") + '" data-cid="' + n.comment_id + '" data-mname="' + n.user_name + '" data-pid="' + n.comment_id + '">回复</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>\n</div>\n<div class="hf_main">\n<div class="hf_text">\n', cre.comment.isEmpty(n.reply) || $.each(n.reply, function (e, n) {
                                a += '<div class="hf c_btn c_hf_' + n.comment_id + '">\n<div class="comment_text">\n<span class="name">@' + (0 === n.user_id ? "系统" : n.user_name) + '<span style="color: #333333;margin: 0 1px;">回复</span>@' + n.reply_name + '：</span>\n<span class="text">' + cre.comment.decodeEntities(n.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + cre.xtimeFormat(n.comment_addtime) + '</span>\n<span class="c_hf">\n<a class="del ' + (i !== n.user_name ? "c_hide" : "c_show") + '" data-cid="' + n.comment_id + '" data-mname="' + n.user_name + '" data-pid="' + n.comment_pid + '">删除</a>\n<a class="com ' + (i !== n.user_name ? "c_show" : "c_hide") + '" data-cid="' + n.comment_id + '" data-mname="' + n.user_name + '" data-pid="' + n.comment_pid + '">回复</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>'
                            }), a += '</div>\n<div class="hf_more more ' + (1 <= n.reply_count - cre.comment.config.reply_init_num ? "c_show" : "c_hide") + " more_" + n.comment_id + '" data-cid="' + n.comment_id + '" data-reply_len="' + n.reply_count + '">\n<span>查看更多</span>\n</div></div>\n</div>\n<div class="_clear"></div>\n</div>'
                        }), c.append(a)) : layui.layer.msg(e.msg)
                    },
                    error: function (e, n) {
                        layui.layer.msg("接口请求异常: " + n)
                    }
                }), !0
            }
        },
        more: {
            replypage: 1, messagepage: 1, _rt: 0, init: function init() {
                this.reply_more(cre.comment.config.reply_init_num), this.message_more(cre.comment.config.message_in1it_num)
            }, reply_more: function reply_more() {
                $(document).on("click", ".hf_more", function () {
                    var c = $(this).siblings(".hf_text"),
                        i = (cre.comment.config.user.id, cre.comment.config.user.name),
                        e = $(this).data("cid");
                    return cre.comment.more._rt !== e && (cre.comment.more.replypage = c.children(".c_btn").length / cre.comment.config.reply_load_num), cre.comment.more._rt = e, cre.comment.more.replypage += 1, $.ajax({
                        url: cre.comment.config.url.message_more,
                        data: {
                            comment_id: e,
                            reply_limit: cre.comment.config.reply_load_num,
                            reply_page: cre.comment.more.replypage,
                            comment_mid: cre.comment.config.comment_mid,
                            comment_rid: cre.comment.config.comment_rid,
                            comment_sid: cre.comment.config.comment_sid,
                            time: (new Date).getTime()
                        },
                        headers: cre.comment.config.headers || {token: cre.comment.config.user.token},
                        dataType: "json",
                        success: function (e) {
                            var n = e;
                            if ("function" == typeof cre.comment.config.parseData && (e = cre.comment.config.parseData(e), n.code !== e.code)) return layui.layer.msg("状态码有误"), !1;
                            var a, t = "";
                            0 === e.code ? (cre.comment.isEmpty(e.result[0].reply) ? --cre.comment.more.replypage : ($.each(e.result[0].reply, function (e, n) {
                                t += '<div class="hf c_btn c_hf_' + n.comment_id + '">\n<div class="comment_text">\n<span class="name">@' + (0 === n.user_id ? "系统" : n.user_name) + '<span style="color: #333333;margin: 0 1px;">回复</span>@' + n.reply_name + '：</span>\n<span class="text">' + cre.comment.decodeEntities(n.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + cre.xtimeFormat(n.comment_addtime) + '</span>\n<span class="c_hf">\n<a class="del ' + (i !== n.user_name ? "c_hide" : "c_show") + '" data-cid="' + n.comment_id + '" data-mname="' + n.user_name + '" data-pid="' + n.comment_pid + '">删除</a>\n<a class="com ' + (i !== n.user_name ? "c_show" : "c_hide") + '" data-cid="' + n.comment_id + '" data-mname="' + n.user_name + '" data-pid="' + n.comment_pid + '">回复</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>'
                            }), c.append(t)), a = c.children(".c_btn").length, e.result[0].reply_count - a < 1 && (e.result[0].comment_id, $(".more_" + e.result[0].comment_id).addClass("c_hide"))) : layui.layer.msg(e.msg)
                        },
                        error: function (e, n) {
                            layui.layer.msg("接口请求异常: " + n)
                        }
                    }), !0
                })
            }, message_more: function message_more() {
                $(".ly_more").on("click", function () {
                    $(this).siblings(".comment_list");
                    var e = cre.comment.more.messagepage += 1;
                    return cre.comment.comments.comment_load(cre.comment.config.message_load_num, e, cre.comment.config.reply_load_num, 0), !0
                })
            }
        },
        isEmpty: function isEmpty(e) {
            return !(e !== undefined && null != e && "" !== e && e && $.trim(e) && 0 !== e.length)
        },
        islogin: function islogin() {
            return !this.isEmpty(this.config.user.name) && !this.isEmpty(this.config.user.token)
        },
        decodeEntities: function decodeEntities(e) {
            var n = document.createElement("textarea");
            return n.innerHTML = e, n.value
        },
        reload: function reload() {
            $(document).on("click", ".reload_html", function () {
                //window.location.reload()
            })
        },
        merge: function merge(a) {
            return $.each(a, function (e, n) {
                cre.comment.config[e] instanceof Object ? $.extend(cre.comment.config[e], a[e]) : cre.comment.config[e] = a[e]
            }), cre.comment.config
        }
    };


    re.prototype.end = function () {
        var top_list = this.get_top_nav_data();
        $.each(top_list, function (i, v) {
            if (_typeof(top_list[i]) !== undefined) {
                layui.jquery('.xxx .top_nav .x').eq(top_list[i]).click();
            }
        });
    };

    win.cre = new re();
}(window);

layui.use(['layer', 'element', 'jquery'], function () {
    var element = layui.element,
        layer = layui.layer;
    cre.init();
    // var $ = cre.$;
    $('.xxx .top_nav').on('click', '.x', function (e) {
        var xg = xadmin.get_cate_data();
        var d = $(this).data('open');

        $('.left-nav').animate({width: '220px'}, 100);
        $('.page-content').animate({left: $(window).width() < 768 ? '0px' : '220px'}, 100);
        $('.left-nav i').css('font-size', '14px');
        $('.left-nav cite,.left-nav .nav_right').show();
        if ($(window).width() < 768) {
            $('.page-content-bg').show();
        }

        if (d !== '') {
            $('.left-nav #nav').children('div').slideUp();
            if (!$('.left-nav #nav').find('div[data-en=' + d + ']').stop(true, true).slideDown().children('li').hasClass('open')) {
                $('.left-nav #nav').find('div[data-en=' + d + ']').eq(0).slideDown();
                $('.left-nav #nav').find('div[data-en=' + d + ']').eq(0).children('li').children('.sub-menu').slideDown();
            }
            cre.set_top_nav_data({
                key: 'topnav',
                value: $('.xxx .top_nav .x').index($(this))
            });
        }
        e.stopPropagation();
    });

    if ($.isEmptyObject(cre.get_top_nav_data())) {
        $('.xxx .top_nav .x:first-child').click();
        cre.set_top_nav_data({
            key: 'topnav',
            value: 0
        });
    }
    (function () {
        var layid = location.hash.replace(/^#urlhash=/, '');
        var layidx = parent.location.hash.replace(/^#urlhashx=/, '');
        element.tabChange('test', layid.split('_')[0]);
        element.on('tab(test)', function (elem) {
            location.hash = 'urlhash=' + $(this).attr('lay-id') + '_' + new Date().getTime();
        });
        element.tabChange('test', layidx.split('_')[0]);
        element.on('tab(test)', function (elem) {
            parent.location.hash = 'urlhashx=' + $(this).attr('lay-id') + '_' + new Date().getTime();
        });
    })();
    cre.end();
});