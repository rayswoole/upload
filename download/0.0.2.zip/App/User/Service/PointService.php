<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Service;

use App\User\Model\PointModel;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class PointService extends Service
{

    public function pointList($where, $order = "point_id asc", $page = 0, $limit = 20): array
    {
        $model = new PointModel();
        if ($page > 0) {
            $data = $model->where($where)->order($order)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->where($where)->order($order)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }


    public function getPoint($where): array
    {
        $model = new PointModel();
        if ($res = $model->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    public function columnType(): array
    {
        return Db::getInstance()->table('information_schema.columns')
            ->where('table_name', 'ray_user_point')
            ->column('column_name,data_type', 'column_name');
    }

    public function savePoint(array $data): bool
    {
        $model = new PointModel();
        if (!empty($data['point_id'])) {
            $model = $model->find($data['point_id']);
        }
        return $model->save($data);
    }

    public function deletePoint($data): bool
    {
        return PointModel::destroy($data);
    }


    //用户积分操作 upoint 表相关操作
    public function saveUpoint(array $data,$where='') :bool
    {

        $res = Db::name('user_upoint')->where($where)->save($data);

        return $res;
    }

    /**
     * 获取积分
     * @param $where
     * @param string $field
     * @param string $order
     * @return array
     * @throws \rayswoole\orm\db\exception\DataNotFoundException
     * @throws \rayswoole\orm\db\exception\DbException
     * @throws \rayswoole\orm\db\exception\ModelNotFoundException
     * @author zhou
     * @time 2020/10/24
     */

    public function getUpoint($where,$field='*',$order='up.upoint_id ASC'): array
    {
        $res = Db::name('user_upoint')->alias('up')
            ->field($field)
            ->join('user_point p', 'up.point_id = p.point_id')
            ->where($where)
            ->order($order)
            ->find();
        if($res){
            return $res;
        }else{
            return [];
        }
    }







    /**
     * 提现积分操作
     */
    public function cashDownPoint($param): array
    {
        $uwhere = [
            'user_id' => $param['user_id'],
            'point_id'=>1
        ];
        //查询出数据库现有多少积分
        $old_upoint = Db::name('user_upoint')->where($uwhere)->find();
        $new_point = intval($old_upoint['upoint_withdraw'] - $param['cash_integral']);

        if ($new_point < 0) {
            return ['code' => 1, 'msg' => '积分不够', 'result' => []];
        }
        $new_upoint_withdraw = intval($old_upoint['upoint_withdraw'] - $param['cash_integral']);
        if ($new_upoint_withdraw < 0) {
            $new_upoint_withdraw = 0;
        };
        $udata = [
            'upoint_id'         => $old_upoint['upoint_id'],
            'upoint_available' => $new_point,
            'upoint_withdraw' => $new_upoint_withdraw,
            'upoint_total' => intval($old_upoint['upoint_total'] - $param['cash_integral']),
        ];
        //$dowres = $this->update($udata, ['upoint_id' => $old_upoint['upoint_id']]);
        $this->saveUpoint($udata);

        //2,添加积分变动 积分记录
        $annaldata=[
            'user_id'=>$param['user_id'],
            //'site_id'=>$param['site_id'],
            'point_id'=>$old_upoint['point_id'],
            'annal_datatype'=>3,
            'annal_bechange'=>$old_upoint['upoint_total'],
            'annal_afchange'=>intval($old_upoint['upoint_total']-$param['cash_integral']),
            'annal_available'=>intval($old_upoint['upoint_available']-$param['cash_integral']),
            'annal_withdraw'=>intval($old_upoint['upoint_withdraw']-$param['cash_integral'])
        ];
        $annal_res= Helper::service('PointAnnal')->insertPointAnnal($annaldata);

        if ($annal_res) {
            return ['code' => 1, 'msg' => '请求已发送', 'result' => []];
        }
    }



    /**
     * 积分操作
     * @param $param
     * @return array
     * @throws \Throwable
     */
    public function exchangUpoint($param): array
    {
        //1,修改积分表 level_id, upoint_withdraw,upoint_total
        $uwhere = [
            'user_id' => $param['user_id'],
        ];
        //查询升级积分价格
        $levelwhere['level_id'] = $param['level_id'];
        $price = Db::name('user_level')->where($levelwhere)->find();
        $delprice = $price[$param['levelprice']];

        $old_upoint = Db::name('user_upoint')->where($uwhere)->find();

        $new_point = intval($old_upoint['upoint_available'] - $delprice);
        $new_upoint_withdraw = intval($old_upoint['upoint_withdraw'] - $delprice);
        if ($new_upoint_withdraw < 0) {
            $new_upoint_withdraw = 0;
        };
        if ($new_point < 0) {
            return ['code' => 1, 'msg' => '积分不够', 'result' => []];
        }
        $udata = [
            'upoint_id' => $old_upoint['upoint_id'],
            'level_id' => intval($param['level_id']),
            'upoint_available' => intval($old_upoint['upoint_available'] - $delprice),
            'upoint_withdraw' => $new_upoint_withdraw,
            'upoint_total' => intval($old_upoint['upoint_total'] - $delprice),
        ];
        //Db::name('user_upoint')->update($udata);
        $this->saveUpoint($udata);

        //添加积分变动 积分记录表
        //2,积分日志记录
        $annaldata = [
            'user_id' => $param['user_id'],
            //'site_id' => $param['site_id'],
            'point_id' => $old_upoint['point_id'],
            'annal_datatype' => 3,
            'annal_bechange' => $old_upoint['upoint_total'],
            'annal_afchange' => intval($old_upoint['upoint_total'] - $delprice),
            'annal_available' => intval($old_upoint['upoint_available'] - $delprice),
            'annal_withdraw' => intval($old_upoint['upoint_withdraw'] - $delprice)
        ];
        //$annal_res = Db::name('user_point_annal')->insert($annaldata);
        $annal_res = Helper::service('PointAnnal')->insertPointAnnal($annaldata);

        if ($annal_res) {
            return ['code' => 0, 'msg' => '兑换成功', 'result' => []];
        } else {
            return ['code' => 1, 'msg' => '出错了，请联系管理员', 'result' => []];
        }

    }

    /**
     * 积分相互兑换接口
     * @param $param [user_id(用户id),point_id(要兑换的积分id),point_id2(兑换成的积分id),exchange_num（兑换数量） ]
     * @return array
     * @throws \Exception
     * @throws \Throwable
     * @throws \rayswoole\orm\db\exception\DataNotFoundException
     * @throws \rayswoole\orm\db\exception\DbException
     * @throws \rayswoole\orm\db\exception\ModelNotFoundException
     * @author zhou
     * @time 2020/10/24
     */
    public function swapUpoint($param)
    {
        $where1=[
            'up.point_id'=>$param['point_id'],
            'up.user_id'=>$param['user_id'],
            //'up.site_id'=>$param['session']['site_id'],
        ];
        $where2=[
            'up.point_id'=>$param['point_id2'],
            'up.user_id'=>$param['user_id'],
            //'up.site_id'=>$param['session']['site_id'],
        ];
        $info =$this->getUpoint($where1);
        $info2=$this->getUpoint($where2);

        //判断可用积分是否够兑换
        if ($info['upoint_available'] > $param['exchange_num']) {
            //1,减掉积分 加到 兑换的积分上
            if ($info['upoint_withdraw']>intval($param['exchange_num'])) {
                $withdraw=$info['upoint_withdraw']-intval($param['exchange_num']);
            } else {
                $withdraw=0;
            }
            $udata1 = [
                'upoint_id'        => $info['upoint_id'],
                'upoint_total'     => $info['upoint_total']-intval($param['exchange_num']),
                'upoint_available' => $info['upoint_available']-intval($param['exchange_num']),
                'upoint_withdraw'  => $withdraw,
            ];

            Db::name('user_upoint')->save($udata1);
            //2,积分二加上减掉的积分  可提现积分不增加
            $udata2 = [
                'upoint_id'        => $info2['upoint_id'],
                'upoint_total'     => $info2['upoint_total']+intval($param['exchange_num']),
                'upoint_available' => $info2['upoint_available']+intval($param['exchange_num']),
            ];
            Db::name('user_upoint')->save($udata2);
            //$res2=$this->update($udata2, ['upoint_id'=>$info2['upoint_id']]);

            //3,添加积分记录
            $annaldata1=[
                'user_id'=>$param['user_id'],
                //'site_id'=>$param['session']['site_id'],
                'point_id'=>$param['point_id'],
                'annal_datatype'=>5, //积分兑换操作
                'annal_bechange'=>$info['upoint_total'],
                'annal_afchange'=>intval($info['upoint_total']-$param['exchange_num']),
                'annal_available'=>intval($info['upoint_available']-$param['exchange_num']),
                'annal_withdraw'=>intval($info['upoint_withdraw']-$param['exchange_num'])
            ];
            $annaldata2=[
                'user_id'=>$param['user_id'],
                //'site_id'=>$param['session']['site_id'],
                'point_id'=>$param['point_id2'],
                'annal_datatype'=>5, //积分兑换操作
                'annal_bechange'=>$info2['upoint_total'],
                'annal_afchange'=>intval($info2['upoint_total']+$param['exchange_num']),
                'annal_available'=>intval($info2['upoint_available']+$param['exchange_num']),
                'annal_withdraw'=>intval($info2['upoint_withdraw']+$param['exchange_num'])
            ];
            //$annal_res= Db::name('user_point_annal')->save($annaldata1);
            //$annal_res2= Db::name('user_point_annal')->save($annaldata2);

            $annal_res  = Helper::service('PointAnnal')->insertPointAnnal($annaldata1);
            $annal_res2 = Helper::service('PointAnnal')->insertPointAnnal($annaldata2);
        } else {
            return ['code'=>1,'msg'=>'可用积分不足','data'=>''];
        }
        if ($annal_res2) {
            return ['code'=>0,'msg'=>'已兑换','data'=>''];
        }


    }


}