<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Service;


use App\Admin\Model\RoleMenuModel;
use rayswoole\Service;

class RoleMenuService extends Service
{

    public function saveRmenu(array $data): bool
    {
        $model = new RoleMenuModel();
        $res = $model->saveAll($data);
        return $res ? true : false;
    }

    public function deleteRmenu($where): bool
    {
        $model = new RoleMenuModel();
        return $model->where($where)->delete();
    }

    public function getRmenu($role_id): array
    {
        $model = new RoleMenuModel();
        return $model->where([
            'role_id' => $role_id
        ])->column('node_id');
    }
}