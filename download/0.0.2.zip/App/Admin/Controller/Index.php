<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;

use EasySwoole\Component\Di;
use EasySwoole\Component\Process\Manager;
use EasySwoole\EasySwoole\Config;
use EasySwoole\EasySwoole\ServerManager;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\utils\Str;
use rayswoole\Vars;

class Index extends Base
{

    public function index(): void
    {
        $this->fetch();
    }

    public function welcome(): void
    {
        $stats = ServerManager::getInstance()->getSwooleServer()->stats();
        $this->assign('stats',$stats);
        $process = Manager::getInstance()->info();
        asort($process);
        foreach ($process as $_k=>$_process){
            $process[$_k]['memoryPeakUsage'] = Str::formatBytes($process[$_k]['memoryPeakUsage']);
            $process[$_k]['memoryUsage'] = Str::formatBytes($process[$_k]['memoryUsage']);
        }
        $this->assign('process',$process);

        $version=Config::getInstance()->getConf('App_Admin.version');
        $this->assign('version',$version);

        $server = Helper::getRequest('','server');
        $version = Db::getInstance()->query('select version() as v limit 1');

        $this->assign([
            //'center_api'=>Di::getInstance()->get('CENTER_API'),
            //todo center_api
            'center_api'=>Vars::get('CENTER_API'),
            'system' =>php_uname('s'),  //操作系统
            'phpmod' =>php_sapi_name(),
            'server_info'=>php_uname('s').php_uname('r'),  //服务器版本
            'swoole_version' =>swoole_version(),
            'server_addr'    =>$server['http_x_real_ip'],
            'username'  =>'YYY',
            'phpinfo'   =>PHP_VERSION, //获取php版本及运行环境
            'sql_info'=> $version[0]['v'],

            'last_login_time'=>date('Y-m-d'),
            'vod_num'   =>0,
            'artic_num' =>0,
            'site_num'  =>0,
            'user_num'  =>0,
            'ads_num'   =>0,
            'master_num'=>0,
        ]);
        $this->fetch();
    }


}