<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;


use App\Admin\Service\ConfigService;
use App\Admin\Extend\Upload;
use EasySwoole\EasySwoole\Config;
use rayswoole\Helper;
use rayswoole\Vars;

class Site extends Base
{
    public function index(): void
    {
        $apps = Config::getInstance()->getConf('Apps');
        for ($i=0; $i<count($apps); $i++){
            if ($apps[$i] == 'Admin' || $apps[$i] == 'Ads' || $apps[$i] == 'Comment' || $apps[$i] == 'Install'
                || $apps[$i] == 'Pay' || $apps[$i] == 'User') {
                unset($apps[$i]);
            }
        }
        $this->assign(['apps' => $apps]);
        $data = ConfigService::getInstance()->get('site');
        $this->assign($data);
        $skin = ConfigService::getInstance()->getDirarr();
        $this->assign(['temarry' => $skin]);
        $this->fetch();
    }


    public function save(): ?bool
    {
        if ($this->isAjax()) {
            $param = $this->post('site');
            $status = ['on' => 1, 'off' => 0];
            $update = array_map(function ($value) use ($status) {
                $value = trim(is_array($value) ? implode(',', $value) : $value);
                return $status[$value] ?? $value;
            }, $param);
            ConfigService::getInstance()->update('site', $update);

            $adminUrl = '';
            if ($update['site_defaultadmin'] !== Vars::get('site.site_defaultadmin')) {
                Vars::set('site.site_defaultadmin', $update['site_defaultadmin']);
                $adminUrl = Helper::url('admin@index/index');
            }
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功,请点击右上角【重启服务】让配置生效', 'url' => $adminUrl]);
        }
    }

    public function upload(): bool
    {
        $config = [
            'field' => 'image',
            'path' => '/',
            'rule' => '',
            'fileName' => 'logo'
        ];
        $res = Upload::getInstance($this->request())->setConfig($config)->upload();
        return Helper::responseJson(['code' => $res['code'], 'msg' => $res['msg'], 'data' => $res['result']]);
    }
}