<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-16 14:37
 ** ----------------------------------------------------------------------
 **/

namespace App\Zhanqun\Extend;


use rayswoole\Helper;

class Common extends \App\Art\Extend\Common
{
    public static function ray_url_type($info,array $param = [], string $flag = 'type')
    {
        $info = is_object($info) ? json_decode(json_encode($info, 256), true) : (array)$info;
        if (isset($info['type_mid'])) {
            switch ($info['type_mid']) {
                case 5:
                case 1:
                    $tab = 'zhanqun';
                    break;
                case 2 :
                    $tab = 'art';
                    break;
                case 8:
                    $tab = 'actor';
                    break;
                case 11:
                    $tab = 'website';
                    break;
                default:
                    $tab = 'zhanqun';
            }
        } else {
            $tab = 'art';
        }
        if (empty($param['type_id'])) {
            $param['id'] = $info['type_id'] ?? 0;
        }
        ksort($param);

        $param=array_filter($param, function ($val){
            return !empty($val);
        });
        return Helper::url($tab.'@'.$flag.'/index', $param);
    }

    public static function ray_url_vod_detail($data)
    {
        return Helper::url('zhanqun@detail/index',['id'=>$data['vod_id']]);
    }

    public static function ray_url_vod_play($obj, $param = []): string
    {
        if (!isset($param['sid'])){
            $param['sid'] = 1;
        }
        if (!isset($param['nid'])){
            $param['nid'] = 1;
        }
        return Helper::url('zhanqun@play/index', [
            'id' => $obj['vod_id'],
            'sid' => $param['sid'],
            'nid' => $param['nid']
        ]);
    }
}