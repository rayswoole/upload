<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-16 14:26
 ** ----------------------------------------------------------------------
 **/

namespace App\Zhanqun\Controller;


use App\Zhanqun\Extend\All;

class Search extends \App\Vod\Controller\Search
{
    use All;
}