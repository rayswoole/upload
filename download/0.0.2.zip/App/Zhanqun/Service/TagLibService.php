<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-11
 ** ----------------------------------------------------------------------
 **/

namespace App\Zhanqun\Service;


use App\Zhanqun\Extend\Common;
use rayswoole\Context;
use rayswoole\Helper;

class TagLibService extends \App\Art\Service\TagLibService
{
    public function tagArea($tag)
    {
        $result = Helper::service('Config','Admin')->get('site.vod_extend_area');
        $data = explode(',',$result['val']);
        if (empty($data)){
            return [];
        }
        if (isset($tag['order']) && $tag['order'] === 'desc'){
            $data = array_reverse($data);
        }
        if (isset($tag['num']) && is_numeric($tag['num'])){
            $data = array_slice($data, 0, $tag['num']);
        }
        $obj = Context::get('obj');
        $param = Context::get('param');
        $return = [];
        foreach ($data as $_data)
        {
            $return[] = array(
                'area_name'=>$_data,
                'area_link'=>Common::ray_url_type($obj,['area'=>$_data,'lang'=>$param['lang'],'year'=>$param['year'],'class'=>$param['class'],'by'=>$param['by'] ],'show')
            );
        }
        return $return;
    }


    public function tagClass($tag)
    {
        $result = Helper::service('Config','Admin')->get('site.vod_extend_class');
        $data = explode(',',$result['val']);
        if (empty($data)){
            return [];
        }
        if (isset($tag['order']) && $tag['order'] === 'desc'){
            $data = array_reverse($data);
        }
        if (isset($tag['num']) && is_numeric($tag['num'])){
            $data = array_slice($data, 0, $tag['num']);
        }
        $obj = Context::get('obj');
        $param = Context::get('param');
        $return = [];
        foreach ($data as $_data)
        {
            $return[] = array(
                'class_name'=>$_data,
                'class_link'=>Common::ray_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'class'=>$_data,'by'=>$param['by'] ],'show')
            );
        }
        return $return;
    }


    public function tagLang($tag)
    {
        $result = Helper::service('Config','Admin')->get('site.vod_extend_lang');
        $data = explode(',',$result['val']);
        if (empty($data)){
            return [];
        }
        if (isset($tag['order']) && $tag['order'] === 'desc'){
            $data = array_reverse($data);
        }
        if (isset($tag['num']) && is_numeric($tag['num'])){
            $data = array_slice($data, 0, $tag['num']);
        }
        $obj = Context::get('obj');
        $param = Context::get('param');
        $return = [];
        foreach ($data as $_data)
        {
            $return[] = array(
                'lang_name'=>$_data,
                'lang_link'=>Common::ray_url_type($obj,['area'=>$param['area'],'lang'=>$_data,'year'=>$param['year'],'class'=>$param['class'],'by'=>$param['by'] ],'show')
            );
        }
        return $return;
    }


    public function tagYear($tag)
    {
        $result = Helper::service('Config','Admin')->get('site.vod_extend_year');
        $data = explode(',',$result['val']);
        if (empty($data)){
            return [];
        }
        if (isset($tag['order']) && $tag['order'] === 'desc'){
            $data = array_reverse($data);
        }
        if (isset($tag['num']) && is_numeric($tag['num'])){
            $data = array_slice($data, 0, $tag['num']);
        }
        $obj = Context::get('obj');
        $param = Context::get('param');
        $return = [];
        foreach ($data as $_data)
        {
            $return[] = array(
                'year_name'=>$_data,
                'year_link'=>Common::ray_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$_data,'class'=>$param['class'],'by'=>$param['by'] ],'show')
            );
        }
        return $return;
    }
}