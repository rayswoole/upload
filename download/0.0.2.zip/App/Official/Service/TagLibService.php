<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-01 17:06
 ** ----------------------------------------------------------------------
 **/

namespace App\Official\Service;

/**
 * Class TagService
 * @package App\Index\Service
 */
class TagLibService extends \App\Art\Service\TagLibService
{
}