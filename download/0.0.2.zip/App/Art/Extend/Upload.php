<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Art\Extend;


use EasySwoole\Component\CoroutineSingleTon;
use EasySwoole\Http\Exception\FileException;
use EasySwoole\Http\Request;
use rayswoole\Helper;

class Upload
{

    use CoroutineSingleTon;

    protected $config = [
        'field' => 'images',
        'notExistenceMsg' => '请选择要上传的图片',
        'size' => [
            'ext' => 1024 * 1024 * 5,
            'msg' => '图片不能大于5M'
        ],
        'type' => [
            'mediaType' => ['png', 'peng', 'jpg', 'jpeg', 'gif', 'jpeg', 'pem', 'ico'],
            'msg' => '文件类型不正确！'
        ],
        'path' => '/upload/image/',
        'rule' => 'md5', // 命名规则
        'nameType' => 'md5', // sha1|md5|date|default
        'fileName' => '', // 文件名称
    ];
    protected $request = null;
    private $temp;


    public function __construct(Request $request = null)
    {
        if (!isset($this->request)) {
            $this->request = $request ?: Helper::request();
            $this->config['root_path'] = RAY_ROOT . '/Public';
        }
    }

    public function setConfig(array $config): Upload
    {
        if (is_array($config) && $config) {
            $this->config = array_merge($this->config, $config);
        }
        return $this;
    }

    public function getConfig(): array
    {
        return $this->config;
    }

    public function setSaveName(string $name): Upload
    {
        $this->config['fileName'] = $name;
        return $this;
    }

    public function upload(?array $config = null): array
    {
        if ($this->request->getMethod() === 'POST') {
            if ($config && is_array($config)) {
                $this->setConfig($config);
            }
            $request = $this->request;
            $width = $height = 0;
            $this->temp['uploadFile'] = $request->getUploadedFile($this->config['field']);
            if (!$this->temp['uploadFile']) {
                return ['code' => -1, 'msg' => '未找到文件', 'result' => [], 'statusCode' => 500];
            }
            $img_type = explode('/', $this->temp['uploadFile']->getClientMediaType());
            if ($img_type[0] === 'image') {
                [$width, $height] = getimagesize($this->temp['uploadFile']->getTempName());
            }

            if (!$this->temp['uploadFile']) {
                return ['code' => -1, 'msg' => $this->config['notExistenceMsg'], 'result' => [], 'statusCode' => 500];
            }

            if ($this->temp['uploadFile']->getSize() > $this->config['size']['ext']) {
                return ['code' => -1, 'msg' => $this->config['size']['msg'], 'result' => [], 'statusCode' => 500];
            }

            if (!in_array(strtolower($this->getExtType()), $this->config['type']['mediaType'], false)) {
                return ['code' => -1, 'msg' => $this->config['type']['msg'], 'result' => [], 'statusCode' => 500];
            }

            $fileName = $this->config['fileName'] ?: $this->buildFileHash();
            if (false === strpos($fileName, '.')) {
                $fileName .= '.' . $this->getExtType();
            }

            $this->temp['saveDirPath'] = $this->buildSaveDir($fileName);
            $targetPath = $this->buildSavePath(true);
            if (!is_dir($targetPath) && !mkdir($targetPath, 0777, true) && !is_dir($targetPath)) {
                throw new \RuntimeException(sprintf('Directory "%s" was not created', $targetPath));
            }

            $data = [
                'name' => $fileName,
                'src' => $this->buildSavePath() . $fileName,
                'width' => $width,
                'height' => $height
            ];
            try {
                if (!file_exists($targetPath . $fileName)) {
                    $this->temp['uploadFile']->moveTo($targetPath . $fileName);
                    $this->reset();
                }
                return ['code' => 0, 'msg' => '上传成功', 'result' => $data, 'statusCode' => 200];
            } catch (FileException $e) {
                return ['code' => -1, 'msg' => '上传失败', 'result' => [], 'statusCode' => 500];
            }
        }
        return [];
    }

    protected function buildFileHash(): string
    {
        $type = strtolower($this->config['nameType']);
        $ext = '.' . $this->getExtType();
        switch ($type) {
            case 'md5':
            case 'sha1':
                $res = hash_file($type, $this->temp['uploadFile']->getTempName()) . $ext;
                break;
            case 'date':
                $res = uniqid('', true) . $ext;
                break;
            default:
                $res = $this->temp['uploadFile']->getClientFileName();
                break;
        }
        return $res;
    }

    protected function buildSaveDir(string $fileName): string
    {
        $rule = $this->config['rule'];
        if (empty($rule) || strtolower($rule) === 'null') {
            return '';
        }
        if ($rule !== 'date' && in_array($rule, hash_algos(), true)) {
            return substr($fileName, 0, 2) . DIRECTORY_SEPARATOR . substr($fileName, 2, 2) . DIRECTORY_SEPARATOR;
        }
        return date('Y-m-d') . DIRECTORY_SEPARATOR;
    }

    protected function buildSavePath(bool $root = false): string
    {
        $path = ltrim($this->config['path'], '/');
        return $root ? $this->config['root_path'] . DIRECTORY_SEPARATOR . $path . $this->temp['saveDirPath'] : DIRECTORY_SEPARATOR . $path . $this->temp['saveDirPath'];
    }

    protected function getExtType(): string
    {
        return substr(strrchr($this->temp['uploadFile']->getClientFilename(),'.'),1);
    }

    protected function reset(): void
    {
        $this->temp = null;
        $this->request = null;
    }
}