<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Art\Controller\Admin;


use App\Admin\Controller\Base;
use App\Admin\Service\ConfigService;
use EasySwoole\EasySwoole\Config;
use rayswoole\Helper;

class Setting extends Base
{
    public function cache()
    {
        if ($this->isPost()) {
            $data = $this->post('config');
            $data = array_map(function ($value) {
                return $value > 0 ? (int)$value : 0;
            }, $data);
            ConfigService::getInstance()->update('art', $data);
            $this->reload();
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功,请点击右上角 “重启服务” ', 'data' => []]);
        } else {
            $data = ConfigService::getInstance()->get('art') ?? [];
            $this->assign($data);
            $this->fetch();
        }
    }

    public function extend()
    {
        if ($this->isPost()) {
            $data = $this->post('config');
            $data = array_map(function ($value) {
                return str_replace('，', '', trim($value));
            }, $data);
            ConfigService::getInstance()->update('art', $data);
            $this->reload();
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功,请点击右上角 “重启服务” ', 'data' => []]);
        } else {
            $data = ConfigService::getInstance()->get('art') ?? [];
            $this->assign($data);
            $this->fetch();
        }
    }

    public function search()
    {
        if ($this->isPost()) {
            $data = $this->post('config');
            $data = array_map(function ($value) {
                return trim(is_array($value) ? implode(',', $value) : $value);
            }, $data);
            ConfigService::getInstance()->update('art', $data);
            $this->reload();
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功,请点击右上角 “重启服务” ', 'data' => []]);
        }
        $data = ConfigService::getInstance()->get('art') ?? [];
        $this->assign($data);
        return $this->fetch();
    }

    public function rewrite()
    {
        $suffixs = Config::getInstance()->getConf('SUFFIX');
        if ($this->isGet()){
            $artConfig = ConfigService::getInstance()->get('art');
            $this->assign($artConfig);
            $this->assign('suffixs',$suffixs);
            return $this->fetch();
        } else {
            $statusArr = ['on'=>1, 'off'=>0];
            $post = $this->post();
            $status = isset($post['status']) && isset($statusArr[$post['status']]) ? $statusArr[$post['status']] : 0;
            $overlap = isset($post['overlap']) && isset($statusArr[$post['overlap']]) ? $statusArr[$post['overlap']] : 0;
            $suffix = isset($post['suffix']) && in_array($post['suffix'], $suffixs) ? $post['suffix'] : '';
            $controller = [];
            $regx = [];
            $rewrite = [];
            foreach ($post['controller'] as $key=>$_controller){
                if (!isset($post['rewrite'][$key])){
                    continue;
                }
                $controller[$key] = $_controller;
                foreach (explode("\n",$post['rewrite'][$key]) as $_regx) {
                    $_regx = trim($_regx," \t\n\r\0\x0B\/");
                    if (empty($_regx)){
                        continue;
                    }
                    $rewrite[$_regx] = array(['GET','POST'], $_controller);
                    $regx[$key][] = $_regx;
                }
            }

            if ($suffix == ''){
                $first = [''=>array(['GET','POST'], 'index/index')];
            } else {
                $first = ['index'=>array(['GET','POST'], 'index/index')];
            }
            $rewrite = array_merge($first, $rewrite);
            $data = [
                'art_rewrite_status' => $status,
                'art_rewrite_overlap' => $overlap,
                'art_rewrite_suffix' => $suffix,
                'art_rewrite_rules' => [
                    'regx' => $regx,
                    'controller' => $controller
                ]
            ];
            ConfigService::getInstance()->update('art',$data);
            $routerFile = RAY_ROOT.strtr(Helper::appNameSpace(),'\\','/').'Router.php';
            if ($status === 1){
                file_put_contents($routerFile,'<?php'."\n".'return '.var_export($rewrite, true).';');
            } else {
                file_put_contents($routerFile, '<?php'."\n".'return [];');
            }
            $this->reboot();
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功']);

        }

    }
}