<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-23 15:58
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Service;


use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Service;
use rayswoole\utils\Arrays;

class SiteConfigService extends Service
{
    /** @var \App\Admin\Service\ConfigService */
    private $systemConfigService;
    private $data = [];

    public function load($domain = '')
    {
        $this->data = [];
        if (!isset($this->systemConfigService)){
            $this->systemConfigService = Helper::service('Config','Admin');
        }
        //$this->data['raycms1'] = $this->systemConfigService->get('site');
        //$this->data['raycms2'] = $this->systemConfigService->get('system');
        $this->data['raycms']=array_merge($this->systemConfigService->get('site'),$this->systemConfigService->get('system'));
        $ray_site = Db::name('site')->where('site_url', $domain)->find();
        if (!$ray_site) {
            $ray_site = Db::name('site')->where('site_id',1)->find();
            if (empty($ray_site)) {
                throw new \RuntimeException('Domain name not found');
            }
        }
        $this->data['site'] = $ray_site;
        return $this->data;
    }

    public function get(string $key = '')
    {
        return $key === '' ? $this->data : Arrays::get($this->data, $key);
    }
}