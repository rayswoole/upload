<?php
/**版本信息**/

namespace App\Update\Controller\Admin;

use App\Admin\Controller\Base;
use App\Update\Model\VersionModel;
use rayswoole\orm\facade\Db;
use rayswoole\Helper;
use App\Vod\Extend\Upload;
use rayswoole\utils\Validators;

class Version extends Base
{
    public function index(): void
    {
        $this->fetch();
    }
//读取数据
    public function read(): ?bool
    {
        if ($this->isAjax()) {
            $param = (array)$this->get();
            $page = isset($param['page']) ? intval($param['page']) : 1;
            $limit = isset($param['limit']) ? intval($param['limit']) : 10;
            $where = [];
            $by = 'version_id';
            $versionModel = new VersionModel();
            if (isset($param['version'])){
                $versionModel = $versionModel->withSearch(['version_number'],[
                    'version_number'=>$param['version']
                ]);
            }
            $res = $versionModel->where($where)->order($by,'DESC')->limit(($page-1)*$limit,$limit)->select()->toArray();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '版本信息列表',
                'count' => count($res),
                'data' => $res
            ]);
        }
    }

    //添加版本信息
    public function create()
    {

        $this->fetch();
    }

    public function edit()
    {
        $param = $this->get('edit_id',0,'intval');

        $res=(new VersionModel())->where(['version_id'=>$param])->find();

        if (!$res) {
            return false;
        }
        $this->assign(['data' => $res]);
        return $this->fetch();
    }


//保存
    public function save(): ?bool
    {
        if ($this->isAjax()) {
            $param = $this->post();

            if (!$str = $this->post('version_number','','required')) {
                Helper::responseHtml('版本不能为空或多于20个字');
            }
            $data = [
                "version_number"      => trim($param['version_number']),
                "version_minversion"  => trim($param['version_minversion']),
                "version_description" => htmlspecialchars(trim($param['version_description'])),
                "version_downurl"     => htmlspecialchars($param['version_downurl']),
                "version_sort"        => intval($param['version_sort']),
                "version_addtime"     => time(),
            ];

            $model = new VersionModel();
            if (isset($param['edit_id'])) {
                $model = $model->where('version_id','=',(int)$param['edit_id'])->find();
                $res = $model->save($data);
            } else {
                $res = $model->save($data);
            }
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
            } else {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
            }

        }
    }

    public function delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $ids = explode(',', $param['id']);
            if (!Validators::isForeach($ids, 'number')){
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'result' => '']);
            }

            $res = Db::name('update_version')->where('version_id','IN',$ids)->delete();

            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'result' => $res]);
        }
    }


    /*
    * [upload 上传文件]
    * @method POST
    * @author C.
    * @date 2020/1/18 上午10:42
    */
    public function upload()
    {
        $param = $this->request()->getRequestParam();
        $field = 'image';
        $path = '/convert/file/';

        $config = [
            'field' => $field,
            'notExistenceMsg' => '请选择要上传的文件',
            'size' => [
                'ext' => 1024 * 1024 * 5,
                'msg' => '文件不能大于5M'
            ],
            'type' => [
                'mediaType' => ['zip'],
                'msg' => '文件类型不正确！'
            ],
            'path' => $path,
        ];
        $res = Upload::getInstance($this->request())->setConfig($config)->upload();
        return Helper::responseJson(['code' => $res['code'], 'msg' => $res['msg'], 'data' => $res['result']]);

    }


    //升级页面操作
    public function update()
    {
        //读取当前版本信息
        $oversion=fopen(RAY_ROOT.'/App/Admin/Version.php','r');
        $oversion='1.0.1';

        //获取服务器最新版本
        $newversion=Helper::service('Update','Update')->getNewVersion($oversion);

        foreach ($newversion as $k=>$v){
            $zipurl='http://new.rayswoole.com/'.$v['version_downurl'];
            $result=Helper::service('Update')->update($v['version_number'],$zipurl);
        }


        $this->fetch();

    }






}