<?php
return [
    // 默认数据连接标识
    'default'     => 'mysql',
    // 数据库连接信息
    'connections' => [
        'mysql' => [
            // 数据库类型
            'type'     => 'mysql',
            // 主机地址
            'hostname' => '127.0.0.1',
            // 用户名
            'username' => 'username',
            'password' => 'password',
            // 数据库名
            'database' => 'ray7',
            // 数据库编码默认采用utf8
            'charset'  => 'utf8',
            // 数据库表前缀
            'prefix'   => 'ray_',
            // 数据库调试模式
            'debug'    => false,
            // 断线重连
            'break_reconnect' => true,
        ],
    ],
    'pool' => [
        'max'=>20,//最大连接数
        'min'=>10,//最小连接数
        'free'=>12,//空闲连接保持数
        'intervalTime'=>15*1000,//定时清理空闲连接频率, 单位ms
        'idleTime'=>30,//设置连接最大闲置时间
        'pingTime'=>10,//心跳检测间隔时间
        'timeout'=>1.0 //获取连接超时时间
    ]
];