<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Service;


use App\User\Model\AnnalModel;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class AnnalService extends Service
{

    public function annalList($where, $order = "annal_id asc", $page = 0, $limit = 20): array
    {
        $model = new AnnalModel();
        if ($page > 0) {
            $data = $model->with(['user', 'point'])->where($where)->order($order)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->with(['user', 'point'])->where($where)->order($order)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    public function columnType(): array
    {
        return Db::table('information_schema.columns')
            ->where('table_name', 'ray_point_annal')
            ->column('column_name,data_type', 'column_name');
    }

    public function getAnnal($where): array
    {
        $model = new AnnalModel();
        if ($res = $model->with(['user', 'point'])->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    public function deleteAnnal($data): bool
    {
        return AnnalModel::destroy($data);
    }

    public function getPointAnnal($where): array
    {
        $model = new AnnalModel();
        if ($res = $model->with('point')->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }
}