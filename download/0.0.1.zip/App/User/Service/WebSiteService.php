<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Service;


use App\User\Model\WebSiteModel;
use rayswoole\Service;

class WebSiteService extends Service
{

    public function webSiteList($where, $order = "config_id asc", $page = 0, $limit = 20): array
    {
        $model = new WebSiteModel();
        if ($page > 0) {
            $data = $model->where($where)->order($order)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->where($where)->order($order)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    public function getWebSite($where): array
    {
        $model = new WebSiteModel();
        if ($res = $model->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }


}