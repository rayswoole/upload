<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Controller;


use App\User\Extend\Common;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Api extends Base
{

    public function index(): void
    {
        $this->fetch();
    }

    public function retrieve(): void
    {
        $this->fetch();
    }

    public function login(): void
    {
        $this->fetch();
    }

    public function user_register(): void
    {
        $this->fetch();
    }

    public function upoint_list(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if ($session) {
            $where['user_id'] = $session['user_id'];
            $res = Db::name('user_upoint')
                ->alias('up')
                ->field('up.*,p.point_scale,p.point_name')
                ->join('point p', 'up.point_id = p.point_id')
                ->limit(1)
                ->where($where)
                ->find();
            return Helper::responseJson(['code' => 0, 'msg' => '获取成功', 'data' => $res]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
    }

    // 会员等级提升
    public function level_up(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if ($session) {
            $where['user_id'] = $session['user_id'];
            $data['point'] = Helper::service('Point')->getUpoint($where);
            $data['level'] = Db::name('user_level')->column('level_name', 'level_id');
            return Helper::responseJson(['code' => 0, 'msg' => '获取成功', 'data' => $data]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
    }

    // 登录
    public function login_check(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $call = htmlspecialchars($this->get('callback'));
        $username = $this->get('username', '', 'required|alchina:1..50');
        $password = $this->get('password', '', 'required:6..50');
        $res = Helper::service('User')->login($username, $password, 'jsonp');
        return Helper::responseHtml($call . '(' . Helper::enJson($res) . ')');
    }

    // 注册
    public function register(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        $param = $this->post();
        $validate = Common::getInstance()->checkVar($param, [
            'user_name' => ['alchina:1..255', '账号只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符'],
            'user_passwd' => ['alnum:1..20', '账号只能为数字和字母且长度不能超出20个字符'],
            'user_nickname' => ['alchina:1..8', '昵称只能为中文\a-z\A-Z\0-9-_且长度不能超出8个字符'],
            'user_phone' => ['int:11', '电话号码为11位'],
            'user_email' => ['email', '邮箱格式不正确'],
        ]);
        if (false === $validate['status']) {
            return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
        }
        $res = Helper::service('User')->saveRegister($param);
        return Helper::responseJson($res);
    }

    // 用户详情
    public function user_info(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if ($session) {
            $where['user_id'] = $session['user_id'];
            $res = Helper::service('User')->getUser($where);
            unset($res['user_passwd']);
            return Helper::responseJson(['code' => 0, 'msg' => '获取成功', 'data' => $res]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
    }

    // 积分列表
    public function annal_list(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if ($session) {
            $res = Db::name('user_point')->select()->toArray();
            return Helper::responseJson(['code' => 0, 'msg' => '获取成功', 'data' => $res]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
    }

    // 下拉选择积分返回
    public function point_info(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        $param = (array)$this->post();
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if ($session) {
            $where = [
                'up.point_id' => $param['id'],
                'up.user_id' => $session['user_id'],
            ];
            $field='up.*,p.point_scale,p.point_name';
            $info = Helper::service('Point')->getUpoint($where,$field);
            if ($info) {
                return Helper::responseJson(['code' => 0, 'data' => $info]);
            }
            return Helper::responseJson(['code' => 1, 'data' => $info, 'msg' => "没有该积分信息"]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
    }

    // 积分记录
    public function annal_read(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        $param = (array)$this->get();
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if ($session) {
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            $order = 'annal_id';
            $where[] = ['user_id', '=', $session['user_id']];
            $res = Helper::service('Annal')->annalList($where, $order, $page, $limit);
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res['data'], 'count' => $res['count']]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
    }

    // 子会员
    public function sublist_read(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if ($session) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            $where[] = ['user_pid', '=', $session['user_id']];
            $where[] = ['user_deletetime', '=', 0];
            $order = 'user_id';
            $res = Helper::service('User')->userList($where, $order, $page, $limit);
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res['data'], 'count' => $res['count']]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
    }

    public function promote_detailt(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        $param = $this->get();
        $page = isset($param['page']) ? (int)$param['page'] : 1;
        $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if (empty($session)) {
            return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
        }
        $child_id = Helper::service('User')->subUser((int)$session['user_id']);
        $child_id['childsid'][] = $session['user_id'];
        $where = [];
        $where[] = ['user_id', 'in', $child_id['childsid']];
        $where[] = ['annal_datatype', '=', 1]; // todo: 模拟积分推广
        $order = 'annal_addtime';
        $res = Helper::service('Annal')->annalList($where, $order, $page, $limit);
        return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res['data'], 'count' => $res['count']]);
    }

    // 保存用户详情
    public function save_user_info(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        if ($this->request()->getMethod() === 'OPTIONS') {
            return Helper::responseJson(['code' => 0, 'msg' => 'ok', 'data' => []]);
        }
        $param = $this->post();
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if (empty($session)) {
            return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
        }
        $param['session'] = $session;
        $res = Helper::service('User')->saveUser($param);
        if ($res) {
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
    }

    // 积分兑换提交
    public function save_active_upoint(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        if ($this->request()->getMethod() === 'OPTIONS') {
            return Helper::responseJson(['code' => 0, 'msg' => 'ok', 'data' => []]);
        }
        $param = $this->post();
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if (empty($session)) {
            return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
        }
        $param['session'] = $session;

        //$res = UserPointModel::create()->SwapUpoint($param);
        $res = Helper::service('Point')->swapUpoint($param);

        if ($res) {
            return Helper::responseJson(['code' => 0, 'data' => $res, 'msg' => "已兑换"]);
        }

        return Helper::responseJson(['code' => 1, 'data' => $res, 'msg' => "没有该积分信息"]);
    }

    public function save_cash_rawal(): ?bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        if ($this->request()->getMethod() === 'OPTIONS') {
            return Helper::responseJson(['code' => 0, 'msg' => 'ok', 'data' => []]);
        }
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        $param = $this->post();
        $param['user_id'] = $session['user_id'];
        //字段校验
        $validate = Common::getInstance()->checkVar($param, [
            'cash_integral' => ['number:1..99999999', '积分只能为数字,且长度不能超出99999999'],
            'cash_account' => ['number:1..99999999', '账号只能只能为数字,且长度不能超出99999999'],
            'cash_cashier' => ['alchina:1..255', '账号户名只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符'],
            'cash_backname' => ['alchina:1..255', '银行名称只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符', true]
        ]);
        if (false === $validate['status']) {
            return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
        }

        //减upoint表 “三个”积分
        $upoint = Helper::service('Cash')->userCashSave($param);

        if ($upoint) {
            return Helper::responseJson($upoint);
        } else {
            return Helper::responseJson($upoint);
        }
    }

    // 充值卡提交 操作
    public function save_card_check(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        if ($this->request()->getMethod() === 'OPTIONS') {
            return Helper::responseJson(['code' => 0, 'msg' => 'ok', 'data' => []]);
        }
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        if (empty($session)) {
            return Helper::responseJson(['code' => 1, 'msg' => '获取失败，请检查是否已登录', 'data' => []]);
        }
        $param = $this->post();
        $param['user_id'] = $session['user_id'];
        $res = Helper::service('Card')->cardAction($param);
        return Helper::responseJson($res);
    }

    // 调整会员等级
    public function save_exchange_level(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        if ($this->request()->getMethod() === 'OPTIONS') {
            return Helper::responseJson(['code' => 0, 'msg' => 'ok', 'data' => []]);
        }
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        $param = $this->post();
        $param['user_id'] = $session['user_id'];
        $res = Helper::service('Level')->activeLevel($param);
        return Helper::responseJson($res);
    }

    // 找回密码
    public function findpass(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        if ($this->request()->getMethod() === 'OPTIONS') {
            return Helper::responseJson(['code' => 0, 'msg' => 'ok', 'data' => []]);
        }
        $param = $this->post();
        $data = [
            "user_name" => htmlspecialchars($param['user_name']),
            "user_issue_one" => htmlspecialchars($param['user_issue_one']),
            "user_answer_one" => htmlspecialchars($param['user_answer_one']),
        ];
        $res = Helper::service('Register')->checkAccount($data);

        if (!empty($res['user_id'])) {
            return Helper::responseJson(['code' => 0, 'msg' => '成功', 'data' => ['user_id' => $res['user_id']]]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '账号或答案错误', 'data' => []]);
    }

    // 修改密码
    public function setpassword(): bool
    {
        $this->response()->withHeader('Access-Control-Allow-Origin', '*');
        $this->response()->withHeader('Access-Control-Allow-Headers', 'token');
        if ($this->request()->getMethod() === 'OPTIONS') {
            return Helper::responseJson(['code' => 0, 'msg' => 'ok', 'data' => []]);
        }
        $param = $this->post();
        if ($param['password'] !== $param['password2']) {
            return Helper::responseJson(['code' => 1, 'msg' => '两次密码不一致', 'data' => []]);
        }
        if (empty($param["edit_id"])) {
            return Helper::responseJson(['code' => 1, 'msg' => 'id错误', 'data' => []]);
        }
        $data = [
            "user_passwd" => htmlspecialchars(password_hash($param['password'], PASSWORD_DEFAULT)),
            "user_id" => (int)$param['edit_id']
        ];
        $res = Db::name('user')->save($data);
        if ($res) {
            return Helper::responseJson(['code' => 0, 'msg' => '修改成功,请重新登陆', 'data' => []]);
        }
        return Helper::responseJson(['code' => 1, 'msg' => '保存失败，请刷新重试', 'data' => []]);
    }

}