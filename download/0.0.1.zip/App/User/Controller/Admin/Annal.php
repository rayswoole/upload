<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Controller\Admin;


use App\User\Model\AnnalModel;
use App\User\Model\UserModel;
use rayswoole\Helper;

class Annal extends Base
{

    public function index()
    {
        $userList = UserModel::with(['level'])->order('user_id asc')->select()->toArray();
        $this->assign([
            'userlist' => $userList
        ]);
        $this->fetch();
    }

    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            $order = 'annal_id';
            if (!empty($param['key'])) {
                $key = $param['key'];
                if (isset($key['time']) && $key['time'] && $t = $this->getTime($key['time'])) {
                    $where[] = ['annal_addtime', '>=', $t];
                }
                if (isset($key['user_id']) && $key['user_id']) {
                    $where[] = ['UserModel.user_id', '=', (int)$key['user_id']];
                }
                if (isset($key['annal_datatype']) && $key['annal_datatype']) {
                    $where[] = ['annal_datatype', '=', (int)$key['annal_datatype']];
                }
            }
            $res = AnnalModel::hasWhere('user', 'user_name is not null')
                ->with(['point', 'user'])->where($where)->order($order)->page($page, $limit)->select();
            $count = AnnalModel::hasWhere('user', 'user_name is not null')->where($where)->count();
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => $count]);
        }
    }

    public function delete()
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res = Helper::service('Annal')->deleteAnnal($data);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
        }
    }

    public function getTime($v)
    {
        $arr = ["-1 day", "-3 day", "-7 day", "-30 day", "-90 day",];
        return strtotime($arr[(int)$v - 1]);
    }
}