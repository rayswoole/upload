<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Controller;

use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use App\User\Extend\Common;

class Index extends Base
{

    public function index()
    {
        $session = \App\User\Extend\Common::getInstance()->checkCookie();

        if(!$session['user_id']){
            return Helper::response()->redirect('/user/login/index');
        }else{
            return Helper::response()->redirect('/user/index/userinfo');
        }

    }


    public function userinfo()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $session = \App\User\Extend\Common::getInstance()->checkCookie();
            $param['session'] = $session;
            $res = Helper::service('User')->saveUser($param);
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
        }

        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        $where['user_id'] = $session['user_id'];
        $res = Helper::service('User')->getUser($where);
        $this->assign(['data' => $res, 'active' => 'userinfo']);
        $this->fetch();
    }

    public function create()
    {
        $this->fetch();
    }

    public function pointannal()
    {
        $this->fetch();
    }

    public function read()
    {
        if ($this->isAjax()) {
            $param = (array)$this->get();
            $session = \App\User\Extend\Common::getInstance()->checkCookie();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            $order = 'annal_id';
            $where[] = ['user_id', '=', $session['user_id']];
            $res = Helper::service('Annal')->annalList($where, $order, $page, $limit);
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res['data'], 'count' => $res['count']]);
        }
    }

    //积分兑换
    public function exchangannal()
    {
        $session = \App\User\Extend\Common::getInstance()->checkCookie();

        //可兑换积分
        $where['user_id'] = $session['user_id'];
        $field='up.*,p.point_scale,p.point_name';
        $order='up.upoint_id ASC';
        $res = Helper::service('Point')->getUpoint($where,$field,$order);

        //积分列表 site_id 设置为1
        $point_list = Db::name('user_point')->select()->toArray();

        $this->assign(['data' => $res, 'point_list' => $point_list, 'active' => 'userinfo']);
        $this->fetch();
    }

    /**
     * 下拉选择积分返回
     * @return bool
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/23
     */
    public function getpointinfo(): bool
    {
        if ($this->isAjax()) {
            $param = (array)$this->post();
            $session = \App\User\Extend\Common::getInstance()->checkCookie();

            $where = [
                'up.point_id' => $param['id'],
                'up.user_id' => $session['user_id'],
                'up.site_id' => $session['site_id'],
            ];
            $field='up.*,p.point_scale,p.point_name';
            $info = Helper::service('Point')->getUpoint($where,$field);

            if ($info) {
                return Helper::responseJson(['code' => 0, 'data' => $info]);
            } else {
                return Helper::responseJson(['code' => 1, 'data' => $info, 'msg' => "没有该积分信息"]);
            }
        }
    }

    /**
     * 积分兑换提交
     * @return bool
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/23
     */
    public function active_upoint()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $session = \App\User\Extend\Common::getInstance()->checkCookie();
            $param['user_id'] = $session['user_id'];

            $res = Helper::service('Point')->swapUpoint($param);

            if ($res) {
                return Helper::responseJson(['code' => 0, 'data' => $res, 'msg' => "已兑换"]);
            } else {
                return Helper::responseJson(['code' => 1, 'data' => $res, 'msg' => "没有该积分信息"]);
            }
        }
    }


    /**
     * 充值卡兑换页面
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/24
     */
    public function exchangcard()
    {
        $session = \App\User\Extend\Common::getInstance()->checkCookie();
        //可兑换积分
        $where['user_id'] = $session['user_id'];
        $res = Helper::service('Point')->getUpoint($where);

        if(!$res){
            $res=0;
        }
        $this->assign(['data' => $res, 'active' => 'userinfo']);

        $this->fetch();
    }

    /**
     * 充值卡提交 操作
     * @return bool
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/24
     */
    public function cardcheck()
    {
        if ($this->isAjax()) {
            $session = \App\User\Extend\Common::getInstance()->checkCookie();
            $param = $this->post();
            $param['user_id'] = $session['user_id'];

            $res = Helper::service('Card')->cardAction($param);

            return Helper::responseJson($res);

        }
    }

    /**
     * 会员等级提升
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/24
     */
    public function levelup()
    {
        $session = \App\User\Extend\Common::getInstance()->checkCookie();

        //可兑换积分
        $where['user_id'] = $session['user_id'];
        $res = Helper::service('Point')->getUpoint($where);

        //会员等级列表
        $level_info = Db::name('user_level')->column('level_name','level_id');
        var_dump($level_info);
        if(!$res){
            $res=0;
        }

        $this->assign(['data' => $res, 'level_info' => $level_info,'now_level_id'=>$session['level_id']]);

        $this->fetch();
    }

    //获取会员等级信息
    public function get_level_info()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $where['level_id'] = $param['id'];
            $level_info = Db::name('user_level')->where($where)->find();
            //$level_info = Helper::service('Level')->getLevel($where);
            if ($level_info) {
                return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $level_info]);
            }
            return ['code' => 1, 'msg' => '信息错误'];
        }
    }

    //调整会员等级
    public function exchange_level()
    {
        if ($this->isAjax()) {
            $session = \App\User\Extend\Common::getInstance()->checkCookie();

            $param = $this->post();
            $param['user_id'] = $session['user_id'];

            $res = Helper::service('Level')->activeLevel($param);

            return Helper::responseJson($res);

        }
    }

    //提现
    public function usercash()
    {
        $session = \App\User\Extend\Common::getInstance()->checkCookie();

        $where=['user_id'=>$session['user_id'],'p.point_id'=>1];
        $res = Helper::service('Point')->getUpoint($where);
        if(!$res){
            $res=0;
        }
        $this->assign(['data' => $res]);
        $this->fetch();
    }
    //提现保存
    public function cashdrawal()
    {
        if ($this->isAjax()) {
            $session = \App\User\Extend\Common::getInstance()->checkCookie();
            $param = $this->post();
            $param['user_id'] = $session['user_id'];
            //字段校验
            $validate = Common::getInstance()->checkVar($param, [
                'cash_integral' => ['number:1..99999999', '积分只能为数字,且长度不能超出99999999'],
                'cash_account'  => ['number:1..99999999', '账号只能只能为数字,且长度不能超出99999999'],
                'cash_cashier'  => ['alchina:1..255', '账号户名只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符'],
                'cash_backname' => ['alchina:1..255', '银行名称只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符', true]
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }

            //减upoint表 “三个”积分
            $upoint = Helper::service('Cash')->userCashSave($param);


            if ($upoint) {
                return Helper::responseJson($upoint);
            } else {
                return Helper::responseJson($upoint);
            }


        }

    }
}