<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-08-27 18:28
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Cron;


use App\Vod\Service\CollectService;
use EasySwoole\EasySwoole\Task\TaskManager;
use rayswoole\CronTab;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Vars;

class CollectCron extends CronTab
{

    function run(int $taskId, int $workerIndex)
    {
        var_dump('定时任务执行开始');
        $data = Db::name('vod_collect')->where('collect_timing_switch','=',1)->select();
        if (!$data){
            return;
        }
        foreach ($data->toArray() as $_data) {
            $timingTime = is_numeric($_data['collect_timing_time']) ? '*/'.$_data['collect_timing_time'] : $_data['collect_timing_time'];
            $timestamp = \Cron\CronExpression::factory('0 '.$timingTime.' * * *')->getNextRunDate()->getTimestamp();
            if (time() >= $timestamp){
                TaskManager::getInstance()->async(function () use ($_data){
                    var_dump('异步采集:'.$_data['collect_url']);
                    $params = array(
                        'param'=>Helper::enJson([
                            'type'=>$_data['collect_type'],
                            'cjurl'=>$_data['collect_url'],
                            'ac'=>'videolist',
                            'h'=>24,
                            'cjflag'=>md5($_data['collect_url'])
                        ]),
                        'pg'=>0,
                    );
                    while (true) {
                        $params['pg']++;
                        var_dump('正在采集'.$params['pg'].'页');
                        $data = CollectService::getInstance()->vod($params);
                        $save_pic = Vars::get('vod.is_savepic',0);
                        CollectService::getInstance()->vod_data($data,'',$params['pg'], $save_pic);
                        if ($params['pg'] < $data['pagecount'] || $params['pg'] < 500) {
                            continue;
                        }
                        break;
                    }

                });
            }
        }
    }

    function onException(\Throwable $throwable, int $taskId, int $workerIndex)
    {
        echo $throwable->getMessage();
    }
}