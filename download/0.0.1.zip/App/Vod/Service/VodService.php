<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-23 14:54
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Service;

use rayswoole\utils\Validators;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class VodService extends Service
{
    public function get(int $id)
    {
        $result = Db::name('vod')->find($id);
        if (!$result){
            return null;
        }
        $result['vod_play_list'] = $this->urlList($result['vod_play_url'],$result['vod_play_from']);
        $result['type'] = TypeService::getInstance()->get($result['type_id']);
        return $result;
    }


    /**
     * 表单数据验证
     * @param array $param
     * @param array $data
     * @return array
     * @author zhou
     * @time 2020/11/5
     */
    public function checkVar(array &$param, array $data): array
    {
        foreach ($data as $k => $v) {
            if (empty($param[$k]) && !is_numeric($param[$k])) {
                if (!($v[2] ?? false)) {
                    return ['status' => false, 'msg' => $v[1]];
                }
                continue;
            }
            if (false === Validators::is($param[$k], $v[0])) {
                return ['status' => false, 'msg' => $v[1]];
            }
        }
        return ['status' => true, 'msg' => '验证通过'];
    }

    /**
     * 电影分类
     * @return mixed
     * @author zhou
     * @time 2020/11/5
     */
    public function getVodType()
    {
        $where = ['type_mid' => 1];
        $ordey = 'type_id';
        $by = 'DESC';
        $res2 = $this->getList($where, $ordey, $by, '*');
        $typeList = json_encode($res2);
        $list = json_decode($typeList, true);
        return $this->ray_list_to_tree($list['data'], 'type_id', 'type_pid');

    }
    //视频字段保存
    public function saveVod($param)
    {
        $data = [
            "type_id"       => $param['type_id'],
            "vod_title"     => trim($param['vod_title']),
            "vod_letter"    => $param['vod_letter'],
            "vod_class"     => trim($param['vod_class']),
            "vod_lang"      => $param['vod_lang'],
            //"vod_score" => intval($param['vod_score']),
            "vod_year"      =>$param['vod_year'],
            "vod_area"      => $param['vod_area'],
            "vod_total"     => $param['vod_total'],
            "vod_serial"    => $param['vod_serial'],
            "vod_actor"     => str_replace('创建-', '', $param['vod_actor']),
            "vod_actor_val" => $param['vod_actor_val'],  //待处理 vod和collect  传过来的值不一样
            "vod_director"  => $param['vod_director'],
            "vod_remarks"   => $param['vod_remarks'],
            "vod_status"    => isset($param['vod_status']) ? 1 : 0,
            "vod_pic"       => $param['vod_pic'],
            "vod_content"   => $param['vod_content'],
            "vod_hits"      => $param['vod_hits'],
            "vod_hits_month"=> $param['vod_hits_month'],
            "vod_hits_week" => $param['vod_hits_week'],
            "vod_hits_day"  => $param['vod_hits_day'],
            'vod_play_from' => trim($param['vod_play_from']),
            'vod_play_url'  => trim($param['vod_play_url']),
            'vod_addtime'   => trim($param['vod_addtime']) ?? time(),

            "vod_sort"      => $param['vod_sort'] ?? '', //vod
            "vod_blurb"     => $param['vod_blurb'] ?? '', //vod
            "vod_pic_thumb" => $param['vod_pic_thumb'] ?? '', //vod
            "vod_jumpurl"   => $param['vod_jumpurl']  ?? '', //vod
            "vod_jumpstatus"=> isset($param['vod_jumpstatus']) ? 1 : 0, //vod
            "vod_duration"  => $param['vod_duration']  ?? '', //vod
            "vod_score"     => $param['vod_score'] ?? rand(3,8),//vod
            "vod_star"      => $param['vod_star']  ?? '', //vod
            "vod_color"     => $param['vod_color'] ?? '', //vod
            'vod_play_server'=>$param['vod_play_server'] ?? '',
        ];
        if (isset($param['vod_id'])){
            $data['vod_id'] = $param['vod_id'];
            Db::name('vod')->update($data);
        } else {
            $res = Db::name('vod')->insert($data, true);
            if ((int)$res > 0) {
                return ['code' => 0, 'msg' => '保存成功', 'result' => ['id'=>$res]];
            } else {
                return ['code' => 1, 'msg' => '保存失败', 'result' => []];
            }
        }
        return ['code' => 0, 'msg' => '保存成功', 'result' => []];

    }

    //采集保存
    public function saveCollect(array $param)
    {
        $data = [
            "type_id"       => $param['type_id'],
            "vod_score"     => rand(3,8),
            "vod_title"     => trim($param['vod_title']),
            "vod_letter"    => $param['vod_letter'],
            "vod_class"     => trim($param['vod_class']),
            "vod_lang"      => $param['vod_lang'],
            //"vod_score" => intval($param['vod_score']),
            "vod_year"      =>$param['vod_year'],
            "vod_area"      => $param['vod_area'],
            "vod_total"     => $param['vod_total'],
            "vod_serial"    => $param['vod_serial'],
            "vod_actor"     => str_replace('创建-', '', $param['vod_actor']['actor']),
            "vod_actor_val" => $param['vod_actor']['actor_val'],
            "vod_director"  => $param['vod_director'],
            "vod_remarks"   => $param['vod_remarks'],
            "vod_status"    => isset($param['vod_status']) ? 1 : 0,
            "vod_pic"       => $param['vod_pic'],
            "vod_content"   => $param['vod_content'],
            "vod_hits"      => $param['vod_hits'],
            "vod_hits_month"=> $param['vod_hits_month'],
            "vod_hits_week" => $param['vod_hits_week'],
            "vod_hits_day"  => $param['vod_hits_day'],
            'vod_play_from' => trim($param['vod_play_from']),
            'vod_play_url'  => trim($param['vod_play_url']),
            'vod_addtime'   => trim($param['vod_addtime']),
        ];
        if (isset($param['vod_id'])){
            $data['vod_id'] = $param['vod_id'];
            Db::name('vod')->update($data);
        } else {
            $res = Db::name('vod')->insert($data, true);
            if ((int)$res <= 0) {
                return ['code' => 1, 'msg' => '保存失败', 'result' => ['id'=>$res]];
            }
        }
        return ['code' => 0, 'msg' => '保存成功', 'result' => []];
    }

    //播放url 处理
    public function playUrlList($playurl)
    {
        $url_list = array();
        $array_url = explode('#', $playurl);

        foreach ($array_url as $key => $val) {
            if (empty($val)) continue;

            list($title, $url) = explode('$', $val);
            if (empty($url)) {
                $url_list[$key + 1]['name'] = '第' . ($key + 1) . '集';
                $url_list[$key + 1]['url'] = $title;
            } else {
                $url_list[$key + 1]['name'] = $title;
                $url_list[$key + 1]['url'] = $url;

            }
            $url_list[$key + 1]['nid'] = $key + 1;
        }

        return $url_list;
    }

    //前端播放器处理
    public function urlList($play_url,$play_from)
    {
        $player_list = PlayerService::getInstance()->getPlayerList();
        $url_list = array();
        $vod_play_from_list = explode('$$$', $play_from);
        $vod_play_url_list  = explode('$$$', $play_url);

        $play=[];
        foreach ($vod_play_from_list as $k=>$v) {
            if (!isset($player_list[$v])){
                continue;
            }
            $array_url = explode('#', $vod_play_url_list[$k]);
            $k++;
            foreach ($array_url as $key => $val) {
                $key++;
                if (empty($val)) continue;
                $arr = explode('$', $val);
                if (!isset($arr[1])){
                    $url_list[$key]['name'] = '第' . $key . '集';
                    $url_list[$key]['url'] = $arr[0];
                } else {
                    $url_list[$key]['name'] = $arr[0];
                    $url_list[$key]['url'] = $arr[1];
                }
                $url_list[$key]['from'] = $arr[2] ?? '';
                $url_list[$key]['nid'] = $key;

            }
            $play[$k]['player_info']=$player_list[$v];
            $play[$k]['sid']=$k;
            $play[$k]['from']=$v;
            $play[$k]['url_count']=count($array_url);
            $play[$k]['urls']=$url_list;
        }

        return $play;

    }



}