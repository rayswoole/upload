<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-10 18:11
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Controller;


use App\Vod\Extend\Common;
use App\Vod\Service\VodService;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Detail extends Base
{
    public function index()
    {
        $param = Common::ray_param_url();
        $key = 'html_vod@detail/index/id/'.$param['id'];
        if ($this->siteConfig['vod_cache_detail'] > 10 && $html = Cache::getInstance()->get($key)){
            return Helper::responseHtml($html);
        }

        $obj = VodService::getInstance()->get($param['id']);

        Context::set('obj',$obj);
        Context::set('param',$param);
        $this->assign([
            'param' => $param,
            'obj' => $obj
        ]);

        $html = $this->fetch('vod/detail', false);
        if ($this->siteConfig['vod_cache_detail'] > 10){
            Cache::getInstance()->set($key, $html, $this->siteConfig['vod_cache_detail']);
        }
        return Helper::responseHtml($html);
    }

    protected function afterAction(?string $actionName): void
    {
        if ($actionName !== 'index') {
            return;
        }
        $obj = Context::get('obj');
        if (!is_null($obj)){
            Db::name('vod')->where('vod_id','=',$obj['vod_id'])
                ->inc('vod_hits',1)
                ->inc('vod_hits_day',1)
                ->inc('vod_hits_week',1)
                ->inc('vod_hits_month',1)->update();
        }
    }
}