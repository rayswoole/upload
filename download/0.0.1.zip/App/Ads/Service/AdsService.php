<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-08-27 15:35
 ** ----------------------------------------------------------------------
 **/

namespace App\Ads\Service;

use rayswoole\orm\facade\Db;
use rayswoole\Service;

class AdsService extends Service
{
    //广告位置
    public function getPositArr()
    {
        $positarr=Db::name('ad_posit')->order('posit_id','desc')->select()->toArray();
        foreach ($positarr as $k => $v){
            $data[]=$v['posit_ad'];
        }
        return $data;
    }

    //修改保存
    public function saveAds($param)
    {

        //site_id 默认广告site_id=1
        $data = [
            "site_id"   => 1,
            "ad_title"  => htmlspecialchars($param['ad_title']),
            "ad_posit"  => htmlspecialchars($param['ad_posit']),
            "ad_words"  => htmlspecialchars($param['ad_words']),
            "ad_words2" => htmlspecialchars($param['ad_words2']),
            "ad_words3" => htmlspecialchars($param['ad_words3']),
            "ad_pic"    => htmlspecialchars($param['ad_pic']),
            "ad_pic2"   => htmlspecialchars($param['ad_pic2']),
            "ad_pic3"   => htmlspecialchars($param['ad_pic3']),
            "ad_sort"   => intval($param['ad_sort']),
            "ad_jump_url" => htmlspecialchars($param['ad_jump_url']),
            "ad_end_time" => htmlspecialchars($param['ad_end_time']),
            "ad_status"   => isset($param['ad_status']) ? 1 : 0,
        ];
        if (isset($param['ad_id'])) {
            $data['ad_id']=$param['ad_id'];
        }

        $res = Db::name('ads')->save($data);

        return $res;

    }



    public function updateField(array $data, $id): bool
    {
        $where = [
            'ad_id' => $id
        ];
        if (is_array($id)) {
            $where = $id;
        }
        $res = Db::name('ads')->update($data, $where);
        return (bool)$res;
    }






}