<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Service;


use App\Admin\Model\UserRoleModel;
use rayswoole\Service;

class UserRoleService extends Service
{

    public function getUserRole($id)
    {
        $model = new UserRoleModel();
        return $model->where([
            'user_id' => $id
        ])->column('role_id','user_id');
    }
}