<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Extend;


use rayswoole\Service;

class Common extends Service
{

    public function tree($data, $pid, $level, &$res, $id_item = "id", $pid_item = "pid", $name_item = "name")
    {
        $items = array();
        foreach ($data as $v) {
            $items[$v[$id_item]] = $v;
        }
        foreach ($items as $k => $v) {
            if ((int)$v[$pid_item] === (int)$pid) {
                $v[$name_item] = str_repeat(" ├─  ", $level) . $v[$name_item];
                $res[] = $v;
                $this->tree($items, $v[$id_item], $level + 1, $res, $id_item, $pid_item, $name_item);
            }
        }
        return $res;
    }

    public function randStr(int $length = 32, string $char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'): string
    {
        $string = '';
        if ($length < 1) {
            return $string;
        }
        $char .= md5(uniqid(microtime(true), true));
        $char = str_shuffle($char);
        for ($i = $length; $i > 0; $i--) {
            $string .= $char[random_int(0, strlen($char) - 1)];
        }
        return $string;
    }
}