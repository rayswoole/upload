<?php /*a:2:{s:61:"/var/wwwroot/rayswoole2.1/App/Art/View/admin/index/index.html";i:1606878258;s:62:"/var/wwwroot/rayswoole2.1/App/Art/View/admin/index/header.html";i:1607167312;}*/ ?>
<!doctype html>
<html class="">
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer"  content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content{display:inline-block;width:30%;}.w-60{width:60% !important;}.xadmin-conn-height-500{min-height:500px !important;}.xform input{height:38px !important;line-height:38px !important;}.xform .layui-form-label{height:20px !important;line-height:20px !important;}.xform .layui-form-radio{margin-bottom:6px !important;}.xform .layui-form-switch{margin-top:8px !important;}.xform .layui-form-item{margin-bottom:5px !important;}.xform .layui-form-item .layui-input-inline{display:inline-block;width:260px;}.tips_text{padding-right:6px;color:darkred !important;font-weight:bold;}#search{height:31px;line-height:31px;}.clear{width:0;height:0;clear:both;}.toolTable{padding-bottom:10px;}.male-color{color:#1E9FFF;font-size:14px;}.female-color{color:#ff6bc9;font-size:14px;}.thumb_img{width:30%;height:80%;}.yes{color:#009688;font-weight:bold;}.no{color:#d6ae7b;font-weight:bold;}.pd-30-50{padding:30px 10px 50px 10px;}.layui-inline{margin-right:-10px !important;}.biaoqianyun{width:100%;margin-left:10px;}.biaoqianyun span{padding:5px 15px;background:#a8e063;border-radius:10px;color:#fff;font-size:6px;cursor:pointer;}.w-50{width:50% !important;}.w-20{width:20% !important;}.it{margin:0 10px 0 5px;color:#666;}.tagcon{width:100%;height:auto;border:1px solid #e6e6e6;display:inline-block;}.tagcon input{height:35px;border:none;}.tagcon .bq span{padding:5px 15px;margin:5px;background:#a8e063;border-radius:10px;color:#fff;font-size:6px;cursor:pointer;display:inline-block;transition:all ease-in-out .5s;position:relative;}.tagcon .bq span:hover{padding-right:25px;}.tagcon .bq span:hover:after{content:'x';padding:1px;position:absolute;top:5px;right:5px;border-radius:50%;color:#fff;}.layui-form-item div.layui-upload-list{margin:0 !important;}.layui-form-item div.layui-upload-list img{margin:10px !important;}.form-conn{margin:15px 0;}.xadmin-btn-6262{background:#de6262;}.xadmin-btn-cea2{background:#43cea2;}.xadmin-btn-5876{background:#2b5876;}.xadmin-btn-076b{background:#aa076b;}.xadmin-btn-9966{background:#ff9966;}.xadmn-btn-5f6d{background:#ff5f6d;}.xadmin-btn-cdac{background:#00cdac;}.xadmin-btn-3e50{background:#2c3e50;}.xadmin-btn-4b6d{background:#734b6d;}.xadmin-btn-b1bf{background:#48b1bf;}.re_cookie{position:relative;}.re_cookie .re{position:absolute;right:6px;top:10px;cursor:pointer;color:#009688;}.layui-table-cell{}.xa{display:none;}
    </style>
</head>
<body>
<div class="x-nav">
          <span class="layui-breadcrumb">
            <a href="">首页</a>
            <a href="">文章</a>
            <a>
              <cite>文章列表</cite></a>
          </span>
    <a class="layui-btn layui-btn-small layui-btn-sm" style="float:right; margin-top: 5px;"
       onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style=""></i></a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">

            <div class="layui-card">
                <div class="layui-card-body ">
                    <div class="layui-collapse" lay-filter="test">
                        <div class="layui-colla-item ">
                            <h2 class="layui-colla-title">条件筛选<i class="layui-icon layui-colla-icon"></i></h2>
                            <div class="layui-colla-content layui-bg-white ">
                                <form class="layui-form" action="">

                                    <div class="layui-form-item">
                                        <label class="layui-form-label">发布时间：</label>
                                        <div class="layui-input-block">
                                            <input type="radio" name="time" value="1" title="一天内">
                                            <input type="radio" name="time" value="2" title="三天内">
                                            <input type="radio" name="time" value="3" title="一周内">
                                            <input type="radio" name="time" value="4" title="一月内">
                                            <input type="radio" name="time" value="5" title="三月内">
                                        </div>
                                    </div>

                                    <div class="layui-form-item">
                                        <label class="layui-form-label">文章排序：</label>
                                        <div class="layui-input-inline">
                                            <select name="art_sort" lay-verify="" lay-search="">
                                                <option value="">直接选择或搜索选择</option>
                                                <option value="addtime">按更新时间</option>
                                                <option value="id">按编号</option>
                                                <option value="hits">按总人气</option>
                                                <option value="hits_month">按月人气</option>
                                                <option value="hits_week">按周人气</option>
                                                <option value="hits_day">按天人气</option>
                                            </select>
                                        </div>
                                    </div>

                                    <!--<div class="layui-form-item">
                                        <label class="layui-form-label">评分范围：</label>
                                        <div class="layui-input-inline">
                                            <div id="slideTest9" class="demo-slider"></div>
                                            <div id="test-slider-tips2"
                                                 style="position:relative; left: 25px; margin-top: 10px;"></div>
                                        </div>
                                    </div>-->

                                    <div class="layui-form-item">
                                        <label class="layui-form-label">文章类型：</label>
                                        <div class="layui-input-inline">
                                            <select name="art_type" lay-verify="" lay-search="">
                                                <option value="">直接选择或搜索选择</option>
                                                <option value="1">公告</option>
                                                <option value="2">头条</option>
                                                <option value="3">电影文章</option>
                                                <option value="4">行业文章</option>
                                                <option value="5">国内新闻</option>
                                                <option value="6">国外新闻</option>
                                                <option value="7">行业新闻</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="layui-form-item">
                                        <label class="layui-form-label">推荐等级：</label>
                                        <div class="layui-input-inline">
                                            <select name="art_star" lay-verify="" lay-search="">
                                                <option value="">直接选择或搜索选择</option>
                                                <option value="1">推荐等级一</option>
                                                <option value="2">推荐等级二</option>
                                                <option value="3">推荐等级三</option>
                                                <option value="5">推荐等级五</option>
                                                <option value="6">推荐等级六</option>
                                                <option value="7">推荐等级七</option>
                                                <option value="8">推荐等级八</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="layui-form-item">
                                        <label class="layui-form-label">状态：</label>
                                        <div class="layui-input-block">
                                            <input type="checkbox" checked="" name="art_status" lay-skin="switch"
                                                   lay-filter="switchTest" lay-text="启用|禁用">
                                        </div>
                                    </div>

                                    <div class="layui-form-item">
                                        <div class="layui-input-block">
                                            <button class="layui-btn" lay-submit="" lay-filter="art_index_form">立即提交
                                            </button>
                                            <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="layui-card">

                <div class="layui-card-header toolTable">
                    <div class="search-con layui-card-body" style="float: left">
                        <div class="layui-inline layui-show-xs-block" style="margin-right: 0;float: left">
                            <input type="text" name="username" placeholder="Search..." autocomplete="off"
                                   class="layui-input" id="search">
                        </div>
                        <div class="layui-inline layui-show-xs-block ctable-tool" style="margin-left: 0">
                            <button class="layui-btn layui-btn-sm" data-type="search"><i
                                    class="layui-icon">&#xe615;</i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-conn layui-card-body ctable-tool" id="" style="float:left;">
                        <!--<button class="layui-btn layui-btn-sm layui-btn-normal" data-type="show">
                            <i class="layui-icon">&#xe705;</i>查
                            所选
                        </button>-->

                        <button class="layui-btn layui-btn-sm" data-type="create">
                            <i class="layui-icon"></i>添加数据
                        </button>

                        <button class="layui-btn layui-btn-sm layui-btn-danger" data-type="delete"><i
                                class="layui-icon"></i>批量删除
                        </button>

                        <button class="layui-btn layui-btn-sm layui-bg-orange" data-type="recycle">
                            <i class="layui-icon">&#xe640;</i>垃圾箱
                        </button>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>

                <div class="layui-card-body ">
                    <table class="layui-hide" id="Ctableid" lay-filter="Ctable"></table>
                    <script type="text/html" id="art_status">
                        <input type="checkbox" name="close" value="{{d.art_id}}" lay-skin="switch"
                               lay-text="启用|禁用" lay-filter="status" {{ d.art_status== 1 ? 'checked' : '' }} >
                    </script>
                    <script type="text/html" id="thumb">
                        <img src="{{d.art_pic_thumb == '' ? d.art_pic : d.art_pic_thumb}}" alt="{{d.art_title}}"
                             class="thumb_img">
                    </script>
                    <script type="text/html" id="create_time">
                        <span>{{layui.util.toDateString(d.art_addtime*1000,'yyyy-MM-dd')}}</span>
                    </script>
                    <script type="text/html" id="barDemo">
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="edit" title="编辑">
                            <i class="layui-icon">&#xe642;</i>
                        </a>
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="delete" title="删除">
                            <i class="layui-icon">&#xe640;</i>
                        </a>
                    </script>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
<script>

    layui.use(['form', 'table', 'layer', 'slider'], function () {
        var form = layui.form,
            table = layui.table,
            layer = layui.layer,
            slider = layui.slider;

        var xtable = table.render({
            elem: '#Ctableid'
            , url: '<?php echo \rayswoole\Helper::url("admin/index/read"); ?>'
            , title: '文章列表'
            , totalRow: false
            , loading: true
            , id: "art_table"
            , even: true
            , skin: 'nob'
            , cols: [[
                {type: 'checkbox', fixed: 'left', width: 80}
                , {field: 'art_id', title: 'ID', width: 80, unresize: true, sort: true}
                , {field: 'art_title', title: '标题', edit: true, minWidth: 300}
                , {field: 'art_sub', title: '副标题', minWidth: 200}
                , {field: 'type_id', title: '所属分类', minWidth: 200}
                , {field: 'art_pic_thumb', title: '缩略图', width: 150, templet: "#thumb"}
                , {field: 'art_blurb', title: '简介', width: 150}
                , {field: 'art_sort', title: '排序', width: 150}
                , {field: 'art_star', title: '推荐等级', width: 150, sort: true}
                , {
                    field: 'art_hits',
                    title: '总人气/次',
                    width: 100,
                    sort: true,
                    style: 'color:#ffafbd;font-size: 16px;font-weight: bold'
                }
                , {
                    field: 'art_hits_month',
                    title: '月人气/次',
                    width: 100,
                    sort: true,
                    style: 'color:#2193b0;font-size: 16px;font-weight: bold'
                }
                , {
                    field: 'art_hits_week',
                    title: '周人气/次',
                    width: 100,
                    sort: true,
                    style: 'color:#cc2b5e;font-size: 16px;font-weight: bold'
                }
                , {
                    field: 'art_hits_day',
                    title: '日人气/次',
                    width: 100,
                    sort: true,
                    style: 'color:#ee9ca7;font-size: 16px;font-weight: bold'
                }
                , {field: 'art_status', title: '状态', width: 150, templet: "#art_status"}
                , {field: 'art_addtime', title: '创建时间', width: 150, sort: true, templet: "#create_time"}
                , {fixed: 'right', title: '操作', toolbar: '#barDemo', width: 200}
            ]],
            page: true,
            limit: 20,
            height: 'full-200'
        });

        table.on('tool(Ctable)', function (obj) {
            var data = obj.data,
                event = obj.event;
            if (event === 'show') {
                xadmin.open('查看文章', '', ($(window).width() * 0.7), ($(window).width() * 0.45), false, function (e) {
                    xtable.reload();
                });
            } else if (event === 'edit') {
                var url = '<?php echo \rayswoole\Helper::url("admin/index/edit",["id"=>"_id"]); ?>'.replace("_id",data.art_id);
                xadmin.open('文章编辑', url, ($(window).width() * 0.7), ($(window).width() * 0.45), false, function (e) {
                    xtable.reload();
                });
            } else if (event === 'delete') {
                layer.confirm('确定要删除数据吗?', {
                    btn: ['是的', '点错了'],
                    title: '删除提示'
                }, function (index) {
                    var l = layer.msg('正在删除中...', {
                        'xdata': data.art_id,
                        'time': new Date().getTime()
                    });
                    cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/delete"); ?>', {
                        id: data.art_id
                    }, function (before) {
                    }, function (res) {
                        layer.msg(res.msg);
                        layer.close(l);
                        xtable.reload();
                    }, function (error) {
                    });
                    layer.close(index);
                });
            }
        });
        var $ = layui.$, active = {
           create: function () {
                xadmin.open('添加文章', '<?php echo \rayswoole\Helper::url("admin/index/create"); ?>', ($(window).width() * 0.7), ($(window).width() * 0.45), false, function (e) {
                    xtable.reload();
                });
            }
            , delete: function () {
                var checkStatus = table.checkStatus('art_table')
                    , data = checkStatus.data
                    , arr = [];
                layer.confirm('确定要删除数据吗?', {
                    btn: ['是的', '点错了'],
                    title: '删除提示'
                }, function (index) {
                    $.each(data, function (i, v) {
                        arr.push(v.art_id);
                    });
                    var l = layer.msg('正在删除中...', {
                        'xdata': data.id,
                        'time': new Date().getTime()
                    });
                    cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/delete"); ?>', {
                        id: arr.join(',')
                    }, function (before) {
                    }, function (res) {
                        layer.msg(res.msg);
                        layer.close(l);
                        xtable.reload();
                    }, function (error) {
                    });
                    layer.close(index);
                });
            },
            recycle: function () {
                parent.xadmin.add_tab('文章回收站', '<?php echo \rayswoole\Helper::url("admin/index/recycle"); ?>');
            },
            search: function () {
                var search = $('#search');
                xtable.reload({
                    page: {
                        curr: 1
                    }
                    , where: {
                        key: {"searchName": search.val()}
                    }
                }, 'data');
                return false;
            }
        };

        $(".ctable-tool .layui-btn").on('click', function () {
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });
        form.on('switch(status)', function (obj) {
            var st = (obj.elem.checked) ? 1 : 0;
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/update"); ?>', {
                id: this.value,
                value: st,
                time: new Date().getTime()
            }, function (before) {
            }, function (res) {
                layer.tips(res.msg, obj.othis);
            }, function (error) {
                console.log('请求失败');
            });
        });

        table.on('edit(Ctable)', function (obj) {
            var value = obj.value
                , data = obj.data
                , field = obj.field;
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/update"); ?>', {
                id: data.art_id,
                field: field,
                value: value,
                time: new Date().getTime()
            }, function (before) {
            }, function (res) {
                layer.tips(res.msg, obj.othis);
                xtable.reload();
            }, function (error) {
                console.log('请求失败');
            });
        });
        var start_vlaue = 0, default_value = 2;
        $('#test-slider-tips2').html('开始值：' + start_vlaue + "&nbsp;&nbsp;&nbsp;&nbsp;结尾值：" + default_value);
        slider.render({
            elem: '#slideTest9'
            , value: default_value
            , range: true
            , tips: true
            , max: 10
            , step: 0.5
            , change: function (vals) {
                $('#test-slider-tips2').html('开始值：' + vals[0] + '&nbsp;&nbsp;&nbsp;&nbsp;结尾值：' + vals[1]);
            }
        });
        form.on('submit(art_index_form)', function (data) {
            var fieldx = data.field;
            xtable.reload({
                page: {
                    curr: 1
                }
                , where: {
                    key: fieldx
                }
            }, 'data');
            return false;
        });

    });
</script>
</html>