<?php /*a:1:{s:58:"/var/wwwroot/rayswoole2.1/App/Admin/View/memcache/tpl.html";i:1607498291;}*/ ?>
    'status' => <?php echo $status; ?>,
    'server' => '<?php echo $server; ?>',
    'port' => <?php echo $port; ?>,
    'pool' => [
        'max'=><?php echo $pool['max']; ?>,//最大连接数
        'min'=><?php echo $pool['min']; ?>,//最小连接数
        'free'=>5,//空闲连接保持数
        'intervalTime'=>15*1000,//定时清理空闲连接频率, 单位ms
        'idleTime'=>10,//设置连接最大闲置时间
        'pingTime'=>30,//心跳检测间隔时间
        'timeout'=>1.0 //获取连接超时时间
    ]