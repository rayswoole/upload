<?php /*a:2:{s:64:"/var/wwwroot/rayswoole2.1/App/Zhanqun/View/admin/site/index.html";i:1606878258;s:66:"/var/wwwroot/rayswoole2.1/App/Zhanqun/View/admin/index/header.html";i:1604997013;}*/ ?>
<!doctype html>
<html class="x-admin-sm">
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer"  content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content {
            display: inline-block;
            width: 30%;
        }

        .w-60 {
            width: 60% !important;
        }

        .xadmin-conn-height-500 {
            min-height: 500px !important;
        }

        .xform input {
            height: 38px !important;
            line-height: 38px !important;
        }

        .xform .layui-form-label {
            height: 20px !important;
            line-height: 20px !important;
        }

        .xform .layui-form-radio {
            margin-bottom: 6px !important;
        }

        .xform .layui-form-switch {
            margin-top: 8px !important;
        }

        .xform .layui-form-item {
            margin-bottom: 5px !important;
        }

        .xform .layui-form-item .layui-input-inline {
            display: inline-block;
            width: 260px;
        }

        .tips_text {
            padding-right: 6px;
            color: darkred !important;
            font-weight: bold;
        }

        #search {
            height: 31px;
            line-height: 31px;
        }

        .clear {
            width: 0;
            height: 0;
            clear: both;
        }

        .toolTable {
            padding-bottom: 10px;
        }

        .male-color {
            color: #1E9FFF;
            font-size: 14px;
        }

        .female-color {
            color: #ff6bc9;
            font-size: 14px;
        }

        .thumb_img {
            width: 30%;
            height: 80%;
        }

        .yes {
            color: #009688;
            font-weight: bold;
        }

        .no {
            color: #d6ae7b;
            font-weight: bold;
        }

        .pd-30-50 {
            padding: 30px 10px 50px 10px;
        }

        .layui-inline {
            margin-right: -10px !important;
        }

        .biaoqianyun {
            width: 100%;
            margin-left: 10px;
        }

        .biaoqianyun span {
            padding: 5px 15px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-20 {
            width: 20% !important;
        }

        .it {
            margin: 0 10px 0 5px;
            color: #666;
        }


        .tagcon {
            width: 100%;
            height: auto;
            border: 1px solid #e6e6e6;
            display: inline-block;
        }

        .tagcon input {
            height: 35px;
            border: none;
        }

        .tagcon .bq span {
            padding: 5px 15px;
            margin: 5px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
            display: inline-block;
            transition: all ease-in-out .5s;
            position: relative;
        }

        .tagcon .bq span:hover {
            padding-right: 25px;
        }

        .tagcon .bq span:hover:after {
            content: 'x';
            padding: 1px;
            position: absolute;
            top: 5px;
            right: 5px;
            border-radius: 50%;
            color: #fff;
        }


        .layui-form-item div.layui-upload-list {
            margin: 0 !important;
        }

        .layui-form-item div.layui-upload-list img {
            margin: 10px !important;
        }

        .form-conn {
            margin: 15px 0;
        }


        .xadmin-btn-6262 {
            background: #de6262;
        }

        .xadmin-btn-cea2 {
            background: #43cea2;
        }

        .xadmin-btn-5876 {
            background: #2b5876;
        }

        .xadmin-btn-076b {
            background: #aa076b;
        }

        .xadmin-btn-9966 {
            background: #ff9966;
        }

        .xadmn-btn-5f6d {
            background: #ff5f6d;
        }

        .xadmin-btn-cdac {
            background: #00cdac;
        }

        .xadmin-btn-3e50 {
            background: #2c3e50;
        }

        .xadmin-btn-4b6d {
            background: #734b6d;
        }

        .xadmin-btn-b1bf {
            background: #48b1bf;
        }

        .re_cookie {
            position: relative;
        }

        .re_cookie .re {
            position: absolute;
            right: 6px;
            top: 10px;
            cursor: pointer;
            color: #009688;
        }

        .layui-table-cell {
            /*height: auto !important;*/
        }
        .xa {
            display: none;
        }
    </style>
</head>
<body>
<div class="x-nav">
          <span class="layui-breadcrumb">
            <a href="">首页</a>
            <a href="">演示</a>
            <a>
              <cite>导航元素</cite></a>
          </span>
    <a class="layui-btn layui-btn-small layui-btn-sm" style="float:right; margin-top: 5px;"
       onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style=""></i></a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">

            <!-- 条件筛选 -->

            <!-- 表格内容 -->
            <div class="layui-card">
                <!-- 顶部工具条 -->
                <div class="layui-card-header toolTable">
                    <div class="search-con layui-card-body" style="float: left">
                        <div class="layui-inline layui-show-xs-block" style="margin-right: 0;float: left">
                            <input type="text" name="site_name" placeholder="Search..." autocomplete="off"
                                   class="layui-input" id="search">
                        </div>
                        <div class="layui-inline layui-show-xs-block ctable-tool" style="margin-left: 0">
                            <button class="layui-btn layui-btn-sm" data-type="search"><i
                                    class="layui-icon">&#xe615;</i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-conn layui-card-body ctable-tool" id="" style="float:left;">
                        <button class="layui-btn layui-btn-sm" data-type="create">
                            <i class="layui-icon"></i>添加数据
                        </button>

                        <button class="layui-btn layui-btn-sm layui-btn-danger" data-type="delete"><i
                                class="layui-icon"></i>批量删除
                        </button>

                    </div>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
                <!-- 表格内容定义 -->
                <div class="layui-card-body ">
                    <table class="layui-hide" id="Ctableid" lay-filter="Ctable"></table>
                    <script type="text/html" id="checkboxTpl">
                        <input type="checkbox" name="lock" value="{{d.id}}" title="锁定" lay-filter="clock" {{ d.id== 10006 ? 'checked' : '' }}>
                    </script>
                    <script type="text/html" id="status">
                        <input type="checkbox" name="close" value="{{d.site_id}}" lay-skin="switch" lay-filter="status" lay-text="ON|OFF" {{ d.site_status== 1 ? 'checked' : '' }}>
                    </script>
                    <!--<script type="text/html" id="sex">-->
                    <!--<i class="layui-icon {{ d.sex == 1?'layui-icon-male male-color':'layui-icon-female female-color'}}">{{d.sex==1?'男':'女'}}</i>-->
                    <!--</script>-->
                    <!-- 行内工具条 -->
                    <script type="text/html" id="barDemo">
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="edit" title="编辑">
                            <i class="layui-icon">&#xe642;</i>
                        </a>
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="delete" title="删除">
                            <i class="layui-icon">&#xe640;</i>
                        </a>
                    </script>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
<script>

    layui.use([ 'form', 'table', 'layer'], function() {
        var form = layui.form,
            table = layui.table,
            layer = layui.layer;

        // 数据表格
        var xtable = table.render({
            elem: '#Ctableid'
            , url: '<?php echo \rayswoole\Helper::url("admin/site/read"); ?>'
            , title: '列表'
            , totalRow: false
            , loading: true
            , id: "Ctable_x_1" // 此处必须为唯一值
            , even: true
            , skin: 'nob'
            , size: 'lg'
            , cols: [[
                {type: 'checkbox', fixed: 'left', width: 80}
                , {field: 'site_id', title: 'ID', width: 80, fixed: 'left', unresize: true, sort: true}
                , {field: 'site_name', title: '网站名称', edit: true}
                , {field: 'site_url', title: '域名'}
                , {field: 'site_sort', title: '排序', width: 150, sort: true, templet: '#sort', edit: true}
                , {field: 'site_status', title: '状态', width: 150, templet: "#status"}
                , {field: 'site_addtime', title: '时间', width: 120,
                    templet: "<div>{{layui.util.toDateString(d.site_addtime*1000, 'yyyy-MM-dd')}}</div>"
                }
                , {fixed: 'right', title: '操作', toolbar: '#barDemo', width: 250}
            ]],
            page: true,
            height: 'full-200'
        });

        // 行内工具栏
        table.on('tool(Ctable)', function (obj) {
            var data = obj.data,
                event = obj.event;
            if (event === 'edit') {
                xadmin.open('修改', '<?php echo \rayswoole\Helper::url("admin/site/edit"); ?>?id='+data.site_id, ($(window).width() * 0.6), ($(window).width() * 0.45), false, function (e) {
                    // 销毁后回调
                    xtable.reload();
                });
            } else if (event === 'delete') {
                /* 删除前询问 */
                layer.confirm('确定要删除数据吗?', {
                    btn: ['是的', '点错了'],
                    title: '删除提示'
                }, function (index) {
                    var l = layer.msg('正在删除中...', {
                        'xdata': data.site_id,
                        'time': new Date().getTime()
                    });
                    // 删除请求数据
                    cre.xpost('/admin/webset/delete', {
                        // 请求数据 json {a:a,b:b,c:c}
                        id: data.site_id
                    }, function (before) {
                        // 请求前执行的
                    }, function (res) {
                        // 请求成功返回
                        layer.msg(res.msg);
                        layer.close(l);
                        xtable.reload();
                    }, function (error) {
                        // 请求失败返回
                    });
                    // 关闭当前提示框
                    layer.close(index);
                });

            }

        });

        // 头部工具栏
        var $ = layui.$, active = {

            create: function () {
                xadmin.open('添加', '<?php echo \rayswoole\Helper::url("admin/site/create"); ?>', ($(window).width() * 0.6), ($(window).width() * 0.45), false, function (e) {
                    // 销毁回调
                    xtable.reload();
                });
            }
            , delete: function () {
                var checkStatus = table.checkStatus('Ctable_x_1')
                    , data = checkStatus.data
                    , arr = [];
                /* 删除前询问 */
                layer.confirm('确定要删除数据吗?', {
                    btn: ['是的', '点错了'],
                    title: '删除提示'
                }, function (index) {
                    $.each(data, function (i, v) {
                        arr.push(v.site_id);
                    });
                    var l = layer.msg('正在删除中...', {
                        'xdata': data.site_id,
                        'time': new Date().getTime()
                    });
                    // 删除请求数据
                    cre.xpost('<?php echo \rayswoole\Helper::url("admin/site/delete"); ?>', {
                        // 请求数据 json {a:a,b:b,c:c}
                        id: arr.join(',')
                    }, function (before) {
                        // 请求前执行的
                    }, function (res) {
                        // 请求成功返回
                        layer.msg(res.msg);
                        layer.close(l);
                        xtable.reload();
                    }, function (error) {
                        // 请求失败返回
                    });
                    // 关闭当前提示框
                    layer.close(index);
                });
            },
            search: function () {
                var search = $('#search');
                //执行搜索重载 // 需后台配合  getAdmin()
                xtable.reload({
                    page: {
                        curr: 1 //重新从第 1 页开始
                    }
                    , where: {
                        site_name: search.val()
                    }
                }, 'data');
            }
        };

        $(".ctable-tool .layui-btn").on('click', function () {
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });

        //监听锁定操作
        form.on('checkbox(clock)', function (obj) {
            var st = (obj.elem.checked) ? 1 : 2;
            cre.xpost('地址', {
                id: this.value,
                st: st,
                time: new Date().getTime()
            }, function (before) {
                // 请求前执行的
            }, function (res) {
                // 请求成功返回
                layer.tips(res.msg, obj.othis);
            }, function (error) {
                // 请求失败返回
                console.log('请求失败');
            });
        });
        // 监听编辑变化
        table.on('edit(Ctable)', function (obj) {
            var value = obj.value // 得到修改后的新值
                , data = obj.data // 得到所在行所有键值
                , field = obj.field; // 得到字段
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/site/updateFile"); ?>', {
                id: data.site_id,
                field: field,
                value: value,
                time: new Date().getTime()
            }, function (before) {
            }, function (res) {
                layer.tips(res.msg, obj.othis);
                xtable.reload();
            }, function (error) {
                // 请求失败返回
                console.log('请求失败');
            });
        });

        // 监听状态变化
        form.on('switch(status)', function (obj) {
            var st = (obj.elem.checked) ? 1 : 2;
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/site/updateFile"); ?>', {
                id: this.value,
                value: st,
                time: new Date().getTime()
            }, function (before) {
                // 请求前执行的
                console.log('switch');
            }, function (res) {
                // 请求成功返回
                layer.tips(res.msg, obj.othis);
            }, function (error) {
                // 请求失败返回
                console.log('请求失败');
            });
        });

    });
</script>
</html>