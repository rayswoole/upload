<?php /*a:1:{s:57:"/var/wwwroot/rayswoole2.1/App/Admin/View/login/index.html";i:1607506071;}*/ ?>
<!doctype html>
<html class="x-admin-sm">
<head>
    <meta charset="UTF-8">
    <title>Ray7-后台登录</title>
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link href="/static/js/xadmin/css/font.css" rel="stylesheet">
    <link href="/static/js/xadmin/css/login.css" rel="stylesheet">
    <link href="/static/js/xadmin/css/xadmin.css" rel="stylesheet">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <script src="/static/js/layui/layui/layui.all.js" charset="utf-8"></script>
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <style>
        .ify_con {
            position: relative;
        }

        .ify_inp {
            width: 50% !important;
            float: left;
        }

        .clear {
            clear: both;
        }

        .ify_img {
            height: 50px;
            float: right;
            border-radius: 3px;
            cursor: pointer;
        }
    </style>
</head>
<body class="login-bg">

<div class="login layui-anim layui-anim-up">
    <div class="message">Ray7系统登录</div>
    <div id="darkbannerwrap"></div>
    <form class="layui-form" action="">
        <input name="username" placeholder="用户名" type="text" lay-verify="username" class="layui-input">
        <hr class="hr15">
        <input name="password" lay-verify="password" placeholder="密码" type="password" class="layui-input">
        <hr class="hr15">
        <!--<div class="ify_con">
            <input type="text" lay-verify="verify" name="verify" placeholder="验证码" class="layui-input ify_inp">
            <img src="/admin/login/verify" class="ify_img" alt="验证码"
                 onclick="this.src = this.src+'?time='+ Math.random()">
        </div>-->
        <div class="clear"></div>
        <hr class="hr15">
        <input value="登录" lay-submit lay-filter="login" style="width:100%;" type="submit">
        <hr class="hr20">
    </form>
</div>

</body>

<script>
    var form = layui.form,
        layer = layui.layer;
    form.verify({
        username: function (value) {
            if (value.length < 3) {
                return '用户名至少得3个字符啊';
            }
        }
        , password: [
            /^[\S]{6,}$/
            , '密码至少需要6位，且不能出现空格'
        ],
        verify: function (value) {

        }
    });
    form.on('submit(login)', function (data) {
        cre.xpost('<?php echo \rayswoole\Helper::url("login/check"); ?>', data.field, function (before) {
            console.log(before)
        }, function (res) {
            if (res.code !== 0) {
                layer.msg(res.msg);
            } else {
                layer.msg(res.msg);
                parent.location.href = res.data.url;
            }
        }, function (error) {
            layer.msg(error.statusText);
        });
        return false;
    });
</script>
</html>