<?php /*a:2:{s:62:"/var/wwwroot/rayswoole2.1/App/Art/View/admin/column/index.html";i:1607582270;s:63:"/var/wwwroot/rayswoole2.1/App/Art/View/admin/column/header.html";i:1606878258;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer"  content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content {
            display: inline-block;
            width: 30%;
        }

        .w-60 {
            width: 60% !important;
        }

        .xadmin-conn-height-500 {
            min-height: 500px !important;
        }

        .xform input {
            height: 38px !important;
            line-height: 38px !important;
        }

        .xform .layui-form-label {
            height: 20px !important;
            line-height: 20px !important;
        }

        .xform .layui-form-radio {
            margin-bottom: 6px !important;
        }

        .xform .layui-form-switch {
            margin-top: 8px !important;
        }

        .xform .layui-form-item {
            margin-bottom: 5px !important;
        }

        .xform .layui-form-item .layui-input-inline {
            display: inline-block;
            width: 260px;
        }

        .tips_text {
            padding-right: 6px;
            color: darkred !important;
            font-weight: bold;
        }

        #search {
            height: 31px;
            line-height: 31px;
        }

        .clear {
            width: 0;
            height: 0;
            clear: both;
        }

        .toolTable {
            padding-bottom: 10px;
        }

        .male-color {
            color: #1E9FFF;
            font-size: 14px;
        }

        .female-color {
            color: #ff6bc9;
            font-size: 14px;
        }

        .thumb_img {
            width: 30%;
            height: 80%;
        }

        .yes {
            color: #009688;
            font-weight: bold;
        }

        .no {
            color: #d6ae7b;
            font-weight: bold;
        }

        .pd-30-50 {
            padding: 30px 10px 50px 10px;
        }

        .layui-inline {
            margin-right: -10px !important;
        }

        .biaoqianyun {
            width: 100%;
            margin-left: 10px;
        }

        .biaoqianyun span {
            padding: 5px 15px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-20 {
            width: 20% !important;
        }

        .it {
            margin: 0 10px 0 5px;
            color: #666;
        }


        .tagcon {
            width: 100%;
            height: auto;
            border: 1px solid #e6e6e6;
            display: inline-block;
        }

        .tagcon input {
            height: 35px;
            border: none;
        }

        .tagcon .bq span {
            padding: 5px 15px;
            margin: 5px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
            display: inline-block;
            transition: all ease-in-out .5s;
            position: relative;
        }

        .tagcon .bq span:hover {
            padding-right: 25px;
        }

        .tagcon .bq span:hover:after {
            content: 'x';
            padding: 1px;
            position: absolute;
            top: 5px;
            right: 5px;
            border-radius: 50%;
            color: #fff;
        }


        .layui-form-item div.layui-upload-list {
            margin: 0 !important;
        }

        .layui-form-item div.layui-upload-list img {
            margin: 10px !important;
        }

        .form-conn {
            margin: 15px 0;
        }


        .xadmin-btn-6262 {
            background: #de6262;
        }

        .xadmin-btn-cea2 {
            background: #43cea2;
        }

        .xadmin-btn-5876 {
            background: #2b5876;
        }

        .xadmin-btn-076b {
            background: #aa076b;
        }

        .xadmin-btn-9966 {
            background: #ff9966;
        }

        .xadmn-btn-5f6d {
            background: #ff5f6d;
        }

        .xadmin-btn-cdac {
            background: #00cdac;
        }

        .xadmin-btn-3e50 {
            background: #2c3e50;
        }

        .xadmin-btn-4b6d {
            background: #734b6d;
        }

        .xadmin-btn-b1bf {
            background: #48b1bf;
        }

        .re_cookie {
            position: relative;
        }

        .re_cookie .re {
            position: absolute;
            right: 6px;
            top: 10px;
            cursor: pointer;
            color: #009688;
        }

        .layui-table-cell {
            /*height: auto !important;*/
        }
        .xa {
            display: none;
        }
    </style>
</head>
<body>
<div class="x-nav">
          <span class="layui-breadcrumb">
            <a href="">首页</a>
            <a href="">文章</a>
            <a>
              <cite>文章列表</cite></a>
          </span>
    <a class="layui-btn layui-btn-small layui-btn-sm" style="float:right; margin-top: 5px;"
       onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style=""></i></a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">

            <div class="layui-card">

                <div class="layui-card-header toolTable">
                    <div class="search-con layui-card-body" style="float: left;display: none;">
                        <div class="layui-inline layui-show-xs-block" style="margin-right: 0;float: left">
                            <input type="text" name="username" placeholder="Search..." autocomplete="off"
                                   class="layui-input" id="search">
                        </div>
                        <div class="layui-inline layui-show-xs-block ctable-tool" style="margin-left: 0">
                            <button class="layui-btn layui-btn-sm" data-type="search"><i
                                    class="layui-icon">&#xe615;</i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-conn layui-card-body ctable-tool" id="" style="float:left;">
                        <button class="layui-btn layui-btn-sm" data-type="create">
                            <i class="layui-icon"></i>添加栏目
                        </button>
                        <button class="layui-btn layui-btn-sm layui-btn-danger" data-type="delete"><i
                                class="layui-icon"></i>批量删除
                        </button>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>

                <div class="layui-card-body ">
                    <table class="layui-table layui-form" id="tree-table" lay-size="sm"></table>
                    <script type="text/html" id="status">
                        <input type="checkbox" name="type_status" value="{{d.type_id}}" lay-skin="switch"
                               lay-text="启用|禁用" lay-filter="status" {{ d.type_status== 1 ? 'checked' : '' }} >
                    </script>
                    <script type="text/html" id="verify">
                        <input type="checkbox" name="type_verify" value="{{d.type_id}}" lay-skin="switch"
                               lay-text="校验|不校验" lay-filter="status" {{ d.type_verify== 1 ? 'checked' : '' }} >
                    </script>
                    <script type="text/html" id="position">
                        <span>{{d.type_position == 1 ?'左侧': (d.type_position == 3 ? '不显示' :  '顶部')}}</span>
                    </script>
                    <script type="text/html" id="create_time">
                        <span>{{layui.util.toDateString(d.art_addtime*1000,'yyyy-MM-dd')}}</span>
                    </script>
                    <script type="text/html" id="barDemo">
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="edit" title="编辑">
                            <i class="layui-icon">&#xe642;</i>
                        </a>
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="delete" title="删除">
                            <i class="layui-icon">&#xe640;</i>
                        </a>
                    </script>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
<script>
    layui.config({
        base: '/static/js/layui/layui_exts/',
    }).use(['form', 'table', 'layer', 'treeTable'], function () {
        var form = layui.form,
            table = layui.table,
            layer = layui.layer,
            treeTable = layui.treeTable,
            treeC = {
                elem: '#tree-table',
                url: '<?php echo \rayswoole\Helper::url("admin/column/read"); ?>',
                icon_key: 'type_name',
                is_checkbox: true,
                primary_key: 'type_id',
                parent_key: 'type_pid',
                checked: {
                    key: 'id',
                    data: [],
                },
                end: function (e) {
                },
                cols: [
                    {
                        key: 'type_id',
                        title: 'ID',
                        width: '100px',
                        align: 'center',
                    },
                    {
                        key: 'type_name',
                        title: '名称',
                        width: '200px',
                        template: function (item) {
                            if (item.level === 0) {
                                return '<span style="color:red;">' + item.type_name + '</span>';
                            } else if (item.level === 1) {
                                return '<span style="color:green;">' + item.type_name + '</span>';
                            } else {
                                return '<span style="color:#aaa;">' + item.type_name + '</span>';
                            }
                        }
                    },
                    {
                        key: 'type_logo',
                        title: 'LOGO',
                        width: '200px',
                        align: 'center',
                    },
                    {
                        key: 'type_status',
                        title: '状态',
                        width: '100px',
                        align: 'center',
                        template: function (item) {
                            return item.type_status == 1 ? '<span lay-filter=\"status\" style=\'cursor: pointer; color: #00b269\'>启用</span>' : '<span lay-filter=\"status\" style=\'cursor: pointer; color: tan\'>禁用</span>';
                        }
                    },
                    {
                        key: 'type_pid',
                        title: '所属上级',
                        width: '100px',
                        align: 'center',
                    },
                    {
                        key: 'type_sort',
                        title: '排序码',
                        width: '100px',
                        align: 'center',
                    },
                    {
                        title: '操作',
                        align: 'center',
                        template: function (item) {
                            return '<div class=""><a class="layui-btn layui-btn-xs layui-btn-primary" lay-filter="edit" title="编辑">\n' +
                                '<i class="layui-icon">&#xe642;</i>\n' +
                                '</a>\n' +
                                '<a class="layui-btn layui-btn-xs layui-btn-primary" lay-filter="delete" title="删除">\n' +
                                '<i class="layui-icon">&#xe640;</i>\n' +
                                '</a></div>';
                        }
                    }
                ]
            };

        var xtable = treeTable.render(treeC);

        xtable.reload = function () {
            treeTable.render(xtable);
        };

        treeTable.on('tree(edit)', function (data) {
            var url = '<?php echo \rayswoole\Helper::url("admin/column/edit",["id"=>"_id"]); ?>'.replace("_id", data.item.type_id);
            xadmin.open('栏目编辑', url, ($(window).width() * 0.7), ($(window).width() * 0.45), false, function (e) {
                xtable.reload();
            });
        });

        treeTable.on('tree(delete)', function (data) {
            layer.confirm('确定要删除数据吗?', {
                btn: ['是的', '点错了'],
                title: '删除提示'
            }, function (index) {
                var l = layer.msg('正在删除中...', {
                    'data': data.item.type_id,
                    'time': new Date().getTime()
                });
                cre.xpost('<?php echo \rayswoole\Helper::url("admin/column/delete"); ?>', {
                    id: data.item.type_id
                }, function (before) {
                }, function (res) {
                    layer.msg(res.msg);
                    layer.close(l);
                    xtable.reload();
                }, function (error) {
                });
                layer.close(index);
            });
        });

        treeTable.on('tree(status)', function (data) {
            var st = (!parseInt(data.item.type_status)) ? 1 : 0,
                id = data.item.type_id;
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/column/update"); ?>', {
                id: id,
                value: st,
                field: this.name,
                time: new Date().getTime()
            }, function (before) {
            }, function (res) {
                layer.msg(res.msg);
                xtable.reload();
            }, function (error) {
                console.log('请求失败');
            });
        });

        var $ = layui.$, active = {
            create: function () {
                xadmin.open('添加栏目', '<?php echo \rayswoole\Helper::url("admin/column/create"); ?>', ($(window).width() * 0.7), ($(window).width() * 0.45), false, function (e) {
                    xtable.reload();
                });
            }
            , delete: function () {
                var data = treeTable.checked(xtable), l = '';
                layer.confirm('确定要删除数据吗?', {
                    btn: ['是的', '点错了'],
                    title: '删除提示'
                }, function (index) {
                    l = layer.msg('正在删除中...', {
                        'time': new Date().getTime()
                    });
                    cre.xpost('<?php echo \rayswoole\Helper::url("admin/column/delete"); ?>', {
                        id: data.join(',')
                    }, function (before) {
                    }, function (res) {
                        layer.msg(res.msg);
                        layer.close(l);
                        xtable.reload();
                    }, function (error) {
                    });
                    layer.close(index);
                });
            },
            search: function () {
            },
            treeres: [],
            tree: function (data, pid, level) {
                var items = {};
                $.each(data, function (i, v) {
                    items[v['type_id']] = v;
                });
                $.each(items, function (i, v) {
                    if (v['type_pid'] === pid) {
                        v['type_name'] = " &nbsp;&nbsp;|-- ".repeat(level) + v['type_name'];
                        active.treeres.push(v);
                        active.tree(data, v['type_id'], level + 1);
                    }
                });
                return this;
            },
            parse: function (code, msg, count, data) {
                data = data || active.treeres;
                var res = {
                    "code": code,
                    "msg": msg,
                    "count": count,
                    "data": data
                };
                active.treeres = [];
                return res;
            }
        };

        $(".ctable-tool .layui-btn").on('click', function () {
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });

        form.on('switch(status)', function (obj) {
            var st = (obj.elem.checked) ? 1 : 0;
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/column/update"); ?>', {
                id: this.value,
                value: st,
                field: this.name,
                time: new Date().getTime()
            }, function (before) {
            }, function (res) {
                layer.tips(res.msg, obj.othis);
            }, function (error) {
                console.log('请求失败');
            });
        });


    });
</script>
</html>