<?php /*a:2:{s:62:"/var/wwwroot/rayswoole2.1/App/Art/View/admin/index/create.html";i:1606878258;s:62:"/var/wwwroot/rayswoole2.1/App/Art/View/admin/index/header.html";i:1607167312;}*/ ?>
<!doctype html>
<html class="">
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer"  content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content{display:inline-block;width:30%;}.w-60{width:60% !important;}.xadmin-conn-height-500{min-height:500px !important;}.xform input{height:38px !important;line-height:38px !important;}.xform .layui-form-label{height:20px !important;line-height:20px !important;}.xform .layui-form-radio{margin-bottom:6px !important;}.xform .layui-form-switch{margin-top:8px !important;}.xform .layui-form-item{margin-bottom:5px !important;}.xform .layui-form-item .layui-input-inline{display:inline-block;width:260px;}.tips_text{padding-right:6px;color:darkred !important;font-weight:bold;}#search{height:31px;line-height:31px;}.clear{width:0;height:0;clear:both;}.toolTable{padding-bottom:10px;}.male-color{color:#1E9FFF;font-size:14px;}.female-color{color:#ff6bc9;font-size:14px;}.thumb_img{width:30%;height:80%;}.yes{color:#009688;font-weight:bold;}.no{color:#d6ae7b;font-weight:bold;}.pd-30-50{padding:30px 10px 50px 10px;}.layui-inline{margin-right:-10px !important;}.biaoqianyun{width:100%;margin-left:10px;}.biaoqianyun span{padding:5px 15px;background:#a8e063;border-radius:10px;color:#fff;font-size:6px;cursor:pointer;}.w-50{width:50% !important;}.w-20{width:20% !important;}.it{margin:0 10px 0 5px;color:#666;}.tagcon{width:100%;height:auto;border:1px solid #e6e6e6;display:inline-block;}.tagcon input{height:35px;border:none;}.tagcon .bq span{padding:5px 15px;margin:5px;background:#a8e063;border-radius:10px;color:#fff;font-size:6px;cursor:pointer;display:inline-block;transition:all ease-in-out .5s;position:relative;}.tagcon .bq span:hover{padding-right:25px;}.tagcon .bq span:hover:after{content:'x';padding:1px;position:absolute;top:5px;right:5px;border-radius:50%;color:#fff;}.layui-form-item div.layui-upload-list{margin:0 !important;}.layui-form-item div.layui-upload-list img{margin:10px !important;}.form-conn{margin:15px 0;}.xadmin-btn-6262{background:#de6262;}.xadmin-btn-cea2{background:#43cea2;}.xadmin-btn-5876{background:#2b5876;}.xadmin-btn-076b{background:#aa076b;}.xadmin-btn-9966{background:#ff9966;}.xadmn-btn-5f6d{background:#ff5f6d;}.xadmin-btn-cdac{background:#00cdac;}.xadmin-btn-3e50{background:#2c3e50;}.xadmin-btn-4b6d{background:#734b6d;}.xadmin-btn-b1bf{background:#48b1bf;}.re_cookie{position:relative;}.re_cookie .re{position:absolute;right:6px;top:10px;cursor:pointer;color:#009688;}.layui-table-cell{}.xa{display:none;}
    </style>
</head>
<body>
<div class="x-nav">
          <span class="layui-breadcrumb">
            <a href="">首页</a>
            <a href="">文章</a>
            <a>
              <cite>添加文章</cite></a>
          </span>
    <a class="layui-btn layui-btn-small layui-btn-sm" style="float:right; margin-top: 5px;"
       onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style=""></i></a>
</div>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-row pd-30-50">
            <div class="layui-col-md12">
                <form class="layui-form xform" action="" lay-filter="artform">

                    <div class="layui-tab" lay-filter="test">
                        <ul class="layui-tab-title">
                            <li class="layui-this" lay-id="xx01">基本参数</li>
                            <li lay-id="xx02">附加参数</li>
                        </ul>
                        <div class="layui-tab-content">
                            <div class="layui-tab-item layui-show">

                                <div class="layui-form-item">
                                    <div class="layui-inline">
                                        <label class="layui-form-label">分类栏目</label>
                                        <div class="layui-input-inline">
                                            <select lay-verify="required" lay-search="" name="type_id">
                                                <option value="">请选择分类栏目</option>
                                                <?php if(is_array($columnList) || $columnList instanceof \think\Collection || $columnList instanceof \think\Paginator): $i = 0; $__LIST__ = $columnList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                                <option value="<?php echo $vo['type_id']; ?>"><?php echo $vo['type_name']; ?></option>
                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="layui-inline">
                                        <label class="layui-form-label">推荐</label>
                                        <div class="layui-input-inline">
                                            <select lay-verify="" lay-search="" name="art_star">
                                                <option value="">请选择推荐位置</option>
                                                <option value="1">首页</option>
                                                <option value="2">电影首页</option>
                                                <option value="3">文章首页</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="layui-form-item">
                                    <div class="layui-inline">
                                        <label class="layui-form-label">文章标题</label>
                                        <div class="layui-input-inline">
                                            <input type="text" name="art_title" lay-verify="art_title"
                                                   placeholder="请输入标题"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <div class="layui-inline">
                                        <label class="layui-form-label">副标题</label>
                                        <div class="layui-input-inline">
                                            <input type="text" name="art_sub" lay-verify="art_sub"
                                                   placeholder="请输入标题"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                </div>

                                <div class="layui-form-item">
                                    <div class="layui-inline">
                                        <label class="layui-form-label">标题颜色</label>
                                        <div class="layui-input-inline" style="width: 225px !important;">
                                            <input type="text" name="art_color" value="" placeholder="请选择标题颜色"
                                                   class="layui-input"
                                                   id="test-form-input" style="height: 38px !important;"
                                                   lay-verify="art_color">
                                        </div>
                                        <div class="layui-inline" style="left: -11px;">
                                            <div id="test-form"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="layui-form-item">
                                    <div class="layui-inline">
                                        <label class="layui-form-label">文章来源</label>
                                        <div class="layui-input-inline">
                                            <input type="text" name="art_from" lay-verify="art_from"
                                                   placeholder="如：网络|文章地址"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <div class="layui-inline">
                                        <label class="layui-form-label">文章作者</label>
                                        <div class="layui-input-block">
                                            <input type="text" name="art_author" lay-verify="art_author"
                                                   placeholder="如：admin"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <div class="layui-inline">
                                        <label class="layui-form-label">排序</label>
                                        <div class="layui-input-block">
                                            <input type="number" name="art_sort" lay-verify="art_sort"
                                                   placeholder="请输入排序"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                </div>

                                <div class="layui-form-item">
                                    <div class="layui-form-item">
                                        <div class="layui-inline">
                                            <label class="layui-form-label">开启跳转</label>
                                            <div class="layui-input-block">
                                                <input type="hidden" name="art_jumpstatus" id="art_jumpstatus"
                                                       value="0">
                                                <input type="checkbox" lay-filter="art_jumpstatus"
                                                       lay-skin="switch" lay-text="开启|禁止">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="layui-inline">
                                        <label class="layui-form-label">跳转地址</label>
                                        <div class="layui-input-inline">
                                            <input type="text" name="art_jumpurl" lay-verify="art_jumpurl"
                                                   placeholder="请输入跳转地址"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                </div>

                                <div class="layui-form-item layui-form-text">
                                    <label class="layui-form-label">简介</label>
                                    <div class="layui-input-block">
                                            <textarea placeholder="请输入简介" class="layui-textarea"
                                                      name="art_blurb"></textarea>
                                    </div>
                                </div>

                                <div class="layui-form-item">
                                    <div class="layui-inline">
                                        <label class="layui-form-label">审核状态</label>
                                        <input type="hidden" name="art_status" id="art_status" value="1">
                                        <div class="layui-input-block">
                                            <input type="checkbox" lay-filter="status"
                                                   lay-skin="switch" lay-text="通过|待审" checked>
                                        </div>
                                    </div>
                                </div>


                                <div class="layui-form-item">
                                    <div class="layui-inline">
                                        <label class="layui-form-label">图片上传</label>
                                        <div class="layui-input-inline">
                                            <div class="layui-upload">
                                                <input type="text" name="art_pic" placeholder="" autocomplete="off"
                                                       class="layui-input">
                                                <div class="layui-upload-list">
                                                    <img class="layui-upload-img img-content" id="img-conn-i">
                                                    <p id="text-conn-i"></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-input-inline w150">
                                            <button type="button" class="layui-btn" id="image"><i
                                                    class="layui-icon"></i>上传图片
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="layui-form-item">
                                    <div class="layui-inline">
                                        <label class="layui-form-label">缩略图上传</label>
                                        <div class="layui-input-inline">
                                            <div class="layui-upload">
                                                <input type="text" name="art_pic_thumb" placeholder=""
                                                       autocomplete="off"
                                                       class="layui-input">
                                                <div class="layui-upload-list">
                                                    <img class="layui-upload-img img-content" id="img-conn-ii">
                                                    <p id="text-conn-ii"></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-input-inline w150">
                                            <button type="button" class="layui-btn" id="thumb"><i
                                                    class="layui-icon"></i>上传图片
                                            </button>
                                        </div>
                                    </div>
                                    <input type="hidden" name="pic_temp">
                                    <input type="hidden" name="thumb_temp">
                                </div>

                                <div class="layui-form-item layui-form-text">
                                    <label class="layui-form-label">内容</label>
                                    <div class="layui-input-block">
                                        <textarea id="details" style="display: none;"
                                                  lay-verify="art_content"></textarea>
                                        <input type="hidden" name="art_content">
                                    </div>
                                </div>

                            </div>
                            <div class="layui-tab-item">

                                <fieldset class="layui-elem-field layui-field-title ">
                                    <legend>
                                        <div class="btn" style="display: inline-block">
                                            <button class="layui-btn" type="button" data-type="yjsc">一键生成</button>
                                        </div>
                                    </legend>
                                </fieldset>

                                <div class="layui-form-item">
                                    <div class="layui-inline">
                                        <label class="layui-form-label">总人气</label>
                                        <div class="layui-input-block">
                                            <input type="number" name="art_hits" lay-verify="art_hits"
                                                   placeholder="请输入总人气"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <div class="layui-inline">
                                        <label class="layui-form-label">月人气</label>
                                        <div class="layui-input-block">
                                            <input type="number" name="art_hits_month"
                                                   lay-verify="art_hits_month"
                                                   placeholder="请输入月人气"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <div class="layui-inline">
                                        <label class="layui-form-label">周人气</label>
                                        <div class="layui-input-block">
                                            <input type="number" name="art_hits_week" lay-verify="art_hits_week"
                                                   placeholder="请输入周人气"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                </div>

                                <div class="layui-form-item">
                                    <div class="layui-inline">
                                        <label class="layui-form-label">日人气</label>
                                        <div class="layui-input-block">
                                            <input type="number" name="art_hits_day" lay-verify="art_hits_day"
                                                   placeholder="请输入日人气"
                                                   autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="layui-form-item form-conn">
                        <div class="layui-input-block">
                            <button class="layui-btn" lay-filter="art_form" lay-submit id="btn-form">立即提交</button>
                            <button type="reset" class="layui-btn layui-btn-primary reset">重置</button>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>
</div>
</body>
<script src="/static/js/ace/ace.js"></script>
<script>
    layui.use(['layer', 'form', 'upload', 'laydate', 'colorpicker', 'layedit'], function () {
        var $ = layui.$,
            form = layui.form,
            layer = layui.layer,
            upload = layui.upload,
            laydate = layui.laydate,
            colorpicker = layui.colorpicker,
            layedit = layui.layedit;

        const ieditor = layedit.build('details',{
            uploadImage: {
                url: '<?php echo \rayswoole\Helper::url("admin/index/upload"); ?>',
                accept: 'image',
                acceptMime: 'image/*',
                exts: 'jpg|png|gif|bmp|jpeg',
                size: '10240',
                field: 'image'
            }
            , devmode: true
            , codeConfig: {
                hide: true,
                default: 'javascript'
            }
            , tool: [
                'code', 'strong', 'italic', 'underline', 'del', 'addhr', '|', 'fontFomatt', 'colorpicker', 'face'
                , '|', 'left', 'center', 'right', '|', 'link', 'unlink', 'image', 'anchors'
                , '|'
            ]
            , height: 366
        });

        // 验证规则
        form.verify({
            art_title: function (v) {
                if (v.length === 0) {
                    return '文章标题不能为空';
                } else if (v.length > 250) {
                    return '文章标题不能为超出250個字符';
                }
            },
            art_sub: function (v) {
                if (v.length > 0 && v.length > 250) {
                    return '文章副标题不能为超出250個字符';
                }
            },
            art_from: function (v) {
                if (v.length > 0 && v.length > 50) {
                    return '文章來源不能超出50個字符';
                }
            },
            art_author: function (v) {
                if (v.length > 0 && v.length > 50) {
                    return '文章作者不能超出50個字符';
                }
            },
            art_sort: function (v) {
                if (v.length > 0 && v.length > 9999999) {
                    return '文章排序值长度超出限制';
                }
            },
            art_blurb: function (v) {
                if (v.length > 0 && v.length > 250) {
                    return '文章簡介长不能超出250個字符';
                }
            },
            art_hits: function (v) {
                if (v.length > 0 && v.length > 9999999) {
                    return '总人气值长度超出限制';
                }
            },
            art_hits_month: function (v) {
                if (v.length > 0 && v.length > 9999999) {
                    return '月人气值长度超出限制';
                }
            },
            art_hits_week: function (v) {
                if (v.length > 0 && v.length > 9999999) {
                    return '周人气值长度超出限制';
                }
            },
            art_hits_day: function (v) {
                if (v.length > 0 && v.length > 9999999) {
                    return '日人气值长度超出限制';
                }
            },
            art_content: function (v) {
                layedit.sync(ieditor);
            }
        });


        // 监听提交
        form.on('submit(art_form)', function (data) {
            var fieldx = data.field;
            fieldx.art_content = layedit.getContent(ieditor);
            cre.load();
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/save"); ?>', fieldx, function (before) {
                }, function (res) {
                    console.log(res);
                    if (!res.code) {
                        layer.msg(res.msg);
                        $('button[type=\'reset\']').click();
                        cre.loadclose();
                        window.location.reload();
                        if (parent.layer.getFrameIndex(window.name)) {
                            cre.fclose();
                        }
                    } else {
                        layer.msg(res.msg);
                        cre.loadclose();
                    }

                }, function (error) {
                    layer.msg('请求失败');
                }
            );
            return false;
        });

        laydate.render({
            elem: '#time_start'
            , type: 'datetime'
        });
        laydate.render({
            elem: '#time_end'
            , type: 'datetime'
        });

        colorpicker.render({
            elem: '#test-form'
            , color: '#1c97f5'
            , done: function (color) {
                $('#test-form-input').val(color);
            }
        });

        $(document).keydown(function (event) {
            if (event.keyCode === 13) {
                return false;
            }
        });

        form.on('switch(status)', function (data) {
            $('#art_status').val(this.checked ? 1 : 0);
        });
        form.on('switch(art_jumpstatus)', function (data) {
            $('#art_jumpstatus').val(this.checked ? 1 : 0);
        });

        var arr = []
            , arr2 = [];
        $('.biaoqianyun span').on('click', function () {
            var tagtext = $(this).data('tagtext');
            if ($.inArray(tagtext, arr) === -1) {
                var text = $(this).text();
                arr.push(tagtext);
                $('.bq').append('<span data-tagtext="' + tagtext + '" class="tagi">' + text + '</span>');
            }
            $('#bqyid').val(JSON.stringify(arr));
        });

        $(document).on('click', '.tagi', function () {
            arr.pop($(this).data('tagtext'));
            $('#bqyid').val(JSON.stringify(arr));
            $(this).animate({opacity: '0.1'}, 'hide').remove();
        });

        $(document).on('keydown', '#bqy', function (event) {
            if (event.keyCode === 13) {
                var t = $('#bqy').val();
                if ($.trim(t) == '') return false;
                arr.push(t);
                $('.bq').append('<span data-tagtext="' + t + '" class="tagi">' + t + '</span>');
                $('#bqyid').val(JSON.stringify(arr));
                $('#bqy').val('');
            }
        });


        var uploadInst_x = upload.render({
            elem: '#image'
            , field: "image"
            , data: {
                'type': 'image',
                'time': new Date().getTime()
            }
            , url: '<?php echo \rayswoole\Helper::url("admin/index/upload"); ?>'
            , before: function (obj) {
                obj.preview(function (index, file, result) {
                    $('#img-conn-i').attr('src', result);
                });
                if ($('input[name=\'pic_temp\']').val()) {
                }
            }
            , done: function (res) {
                var tipstext = $('#text-conn-i');
                if (!res.code) {
                    tipstext.html('<span class="yes">' + res.msg + '</span>');
                    $('input[name=\'art_pic\']').val(res.data.src);
                    $('input[name=\'pic_temp\']').val(res.data.src);
                } else {
                    tipstext.html('<span class="no">' + res.msg + '</span>');
                }

            }
            , error: function () {
                var demoText = $('#text-conn-i');
                demoText.html('<span style="color: #FF5722; line-height: 35px; display: inline-block">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst_x.upload();
                });
            }
        });

        var uploadInst_i = upload.render({
            elem: '#thumb'
            , field: 'thumb'
            , url: '<?php echo \rayswoole\Helper::url("admin/index/upload"); ?>'
            , data: {
                'type': 'thumb',
                'time': new Date().getTime()
            }
            , before: function (obj) {
                obj.preview(function (index, file, result) {
                    $('#img-conn-ii').attr('src', result);
                });
                if ($('input[name=\'thumb_temp\']').val()) {

                }
            }
            , done: function (res) {
                var tipstext = $('#text-conn-ii');
                if (!res.code) {
                    tipstext.html('<span class="yes">' + res.msg + '</span>');
                    $('input[name=\'art_pic_thumb\']').val(res.data.src);
                    $('input[name=\'thumb_temp\']').val(res.data.src);
                } else {
                    tipstext.html('<span class="no">' + res.msg + '</span>');
                }
            }
            , error: function () {
                var demoText = $('#text-conn-ii');
                demoText.html('<span style="color: #FF5722; line-height: 35px; display: inline-block">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst_i.upload();
                });
            }
        });


        var active = {
            yjsc: function () {
                var randi = Math.floor(Math.random() * (500 - 150 + 1)) + 500;
                var fen = Math.floor(Math.random() * (100 - 20 + 1)) + 20;
                var c = Math.floor(Math.random() * (10 - 2 + 1)) + 2;
                var config = {
                    'art_hits': randi * 6,
                    'art_hits_month': randi * 3,
                    'art_hits_week': randi * 2,
                    'art_hits_day': randi,
                    'total_score': fen * c,
                    'total_second': fen,
                    'access_integral': 0
                };
                $.each(config, function (k, v) {
                    $('input[name="' + k + '"]').val(v);
                })
            }
        };

        $(".btn .layui-btn").on('click', function () {
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });


    });

</script>
</html>