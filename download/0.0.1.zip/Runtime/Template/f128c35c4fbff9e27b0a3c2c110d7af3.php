<?php /*a:2:{s:62:"/var/wwwroot/rayswoole2.1/App/Vod/View/admin/index/create.html";i:1607582151;s:62:"/var/wwwroot/rayswoole2.1/App/Vod/View/admin/index/header.html";i:1604997013;}*/ ?>
<script src="/static/js/layui/layui_exts/xm-select.js"></script>
<!doctype html>
<html class="x-admin-sm">
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer"  content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content {
            display: inline-block;
            width: 30%;
        }

        .w-60 {
            width: 60% !important;
        }

        .xadmin-conn-height-500 {
            min-height: 500px !important;
        }

        .xform input {
            height: 38px !important;
            line-height: 38px !important;
        }

        .xform .layui-form-label {
            height: 20px !important;
            line-height: 20px !important;
        }

        .xform .layui-form-radio {
            margin-bottom: 6px !important;
        }

        .xform .layui-form-switch {
            margin-top: 8px !important;
        }

        .xform .layui-form-item {
            margin-bottom: 5px !important;
        }

        .xform .layui-form-item .layui-input-inline {
            display: inline-block;
            width: 260px;
        }

        .tips_text {
            padding-right: 6px;
            color: darkred !important;
            font-weight: bold;
        }

        #search {
            height: 31px;
            line-height: 31px;
        }

        .clear {
            width: 0;
            height: 0;
            clear: both;
        }

        .toolTable {
            padding-bottom: 10px;
        }

        .male-color {
            color: #1E9FFF;
            font-size: 14px;
        }

        .female-color {
            color: #ff6bc9;
            font-size: 14px;
        }

        .thumb_img {
            width: 30%;
            height: 80%;
        }

        .yes {
            color: #009688;
            font-weight: bold;
        }

        .no {
            color: #d6ae7b;
            font-weight: bold;
        }

        .pd-30-50 {
            padding: 30px 10px 50px 10px;
        }

        .layui-inline {
            margin-right: -10px !important;
        }

        .biaoqianyun {
            width: 100%;
            margin-left: 10px;
        }

        .biaoqianyun span {
            padding: 5px 15px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-20 {
            width: 20% !important;
        }

        .it {
            margin: 0 10px 0 5px;
            color: #666;
        }


        .tagcon {
            width: 100%;
            height: auto;
            border: 1px solid #e6e6e6;
            display: inline-block;
        }

        .tagcon input {
            height: 35px;
            border: none;
        }

        .tagcon .bq span {
            padding: 5px 15px;
            margin: 5px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
            display: inline-block;
            transition: all ease-in-out .5s;
            position: relative;
        }

        .tagcon .bq span:hover {
            padding-right: 25px;
        }

        .tagcon .bq span:hover:after {
            content: 'x';
            padding: 1px;
            position: absolute;
            top: 5px;
            right: 5px;
            border-radius: 50%;
            color: #fff;
        }


        .layui-form-item div.layui-upload-list {
            margin: 0 !important;
        }

        .layui-form-item div.layui-upload-list img {
            margin: 10px !important;
        }

        .form-conn {
            margin: 15px 0;
        }


        .xadmin-btn-6262 {
            background: #de6262;
        }

        .xadmin-btn-cea2 {
            background: #43cea2;
        }

        .xadmin-btn-5876 {
            background: #2b5876;
        }

        .xadmin-btn-076b {
            background: #aa076b;
        }

        .xadmin-btn-9966 {
            background: #ff9966;
        }

        .xadmn-btn-5f6d {
            background: #ff5f6d;
        }

        .xadmin-btn-cdac {
            background: #00cdac;
        }

        .xadmin-btn-3e50 {
            background: #2c3e50;
        }

        .xadmin-btn-4b6d {
            background: #734b6d;
        }

        .xadmin-btn-b1bf {
            background: #48b1bf;
        }

        .re_cookie {
            position: relative;
        }

        .re_cookie .re {
            position: absolute;
            right: 6px;
            top: 10px;
            cursor: pointer;
            color: #009688;
        }

        .layui-table-cell {
            /*height: auto !important;*/
        }
        .xa {
            display: none;
        }
    </style>
</head>
<script src="/static/admin/js/Convert_Pinyin.js"></script>
<body>
<div class="layui-fluid" >
    <div class="layui-card">
    <div class="layui-row pd-30-50">
        <div class="layui-col-md12">
            <form class="layui-form xform" action="">
                <div class="layui-tab">
                    <ul class="layui-tab-title ">
                        <li class="layui-this">基本信息</a></li>
                        <li>其他信息</li>
                        <!--<li>剧情信息</li>-->
                    </ul>
                    <div class="layui-tab-content">
                        <div class="layui-tab-item layui-show">
                    <!-- 表单内容 -->
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">电影分类</label>
                                    <div class="layui-input-inline">
                                        <select name="type_id" lay-search="" required lay-verify="vodcid" >
                                            <?php if(is_array($type_tree) || $type_tree instanceof \think\Collection || $type_tree instanceof \think\Paginator): $i = 0; $__LIST__ = $type_tree;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                                <option value="<?php echo $vo['type_id']; ?>" ><?php echo $vo['type_name']; ?></option>
                                                <?php if(isset($vo['child'])): if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ch): $mod = ($i % 2 );++$i;?>
                                                <option value="<?php echo $ch['type_id']; ?>">├ <?php echo $ch['type_name']; ?></option>
                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="layui-inline">
                                    <label class="layui-form-label">推荐等级</label>
                                    <div class="layui-input-inline">
                                        <select name="vod_star"  lay-search="" lay-verify="vodstar">
                                            <option value="">可直接输入搜索</option>
                                            <option value="0">等级-1</option>
                                            <option value="1">等级-2</option>
                                            <option value="2">等级-3</option>
                                            <option value="3">等级-4</option>
                                            <option value="4">等级-5</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">视频标题</label>
                                    <div class="layui-input-inline">
                                        <input type="text" name="vod_title" required lay-verify="vod_title" placeholder="请输入视频标题"
                                               autocomplete="off" class="layui-input" id="vod_title">
                                    </div>
                                </div>
                                <div class="layui-inline">
                                    <label class="layui-form-label">标题颜色</label>
                                    <div class="layui-input-inline" style="width: 225px">
                                        <input type="text" name="vod_color" value="" placeholder="请选择标题颜色"
                                               class="layui-input"
                                               id="test-form-input"
                                               lay-verify="vod_color">
                                    </div>
                                    <div id="test-form" style="left: -11px;margin-bottom:0"></div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">语言</label>
                                    <div class="layui-input-inline">
                                        <select name="vod_lang" lay-search="">
                                            <option value="">请选择语言</option>
                                            <?php if(is_array($arr_type['lang']) || $arr_type['lang'] instanceof \think\Collection || $arr_type['lang'] instanceof \think\Paginator): $i = 0; $__LIST__ = $arr_type['lang'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                            <option value="<?php echo $vo; ?>"><?php echo $vo; ?></option>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="layui-inline">
                                    <label class="layui-form-label">首字母</label>
                                    <div class="layui-input-inline">
                                        <input type="text" name="vod_letter" placeholder="请输入首字母"
                                               autocomplete="off" class="layui-input" lay-verify="vod_letter"
                                               id="vod_letter">
                                    </div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">上映年代</label>
                                    <div class="layui-input-inline">
                                        <select name="vod_year" lay-search="">
                                            <option value="">请选择上映年代</option>
                                            <?php if(is_array($arr_type['year']) || $arr_type['year'] instanceof \think\Collection || $arr_type['year'] instanceof \think\Paginator): $i = 0; $__LIST__ = $arr_type['year'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                            <option value="<?php echo $vo; ?>"><?php echo $vo; ?></option>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="layui-inline">
                                    <label class="layui-form-label">发行地区</label>
                                    <div class="layui-input-inline">
                                        <select name="vod_area" lay-search="">
                                            <option value="">请选择地区</option>
                                            <?php if(is_array($arr_type['area']) || $arr_type['area'] instanceof \think\Collection || $arr_type['area'] instanceof \think\Paginator): $i = 0; $__LIST__ = $arr_type['area'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                            <option value="<?php echo $vo; ?>"><?php echo $vo; ?></option>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">总集数</label>
                                    <div class="layui-input-inline">
                                        <input type="text" name="vod_total" lay-verify="vod_total" placeholder="请输入总集数"
                                               autocomplete="off" class="layui-input">
                                    </div>
                                </div>
                                <div class="layui-inline">
                                    <label class="layui-form-label">连载数</label>
                                    <div class="layui-input-inline">
                                        <input type="text" name="vod_serial" lay-verify="vod_serial"
                                               placeholder="请输入连载数"
                                               autocomplete="off" class="layui-input">
                                    </div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">主演</label>
                                <div class="layui-input-inline">
                                    <div id="vod_actor" class="demo-transfer" style="width: 623px !important;"></div>
                                    <input type="hidden" class="layui-input" value="" placeholder="" name="vod_actor"
                                           id="vod_rel_actor">
                                    <input type="hidden" class="layui-input" value="" placeholder=""
                                           name="vod_actor_val" id="actor_id">
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">评分</label>
                                    <div class="layui-input-inline">
                                        <input type="text" name="vod_score" lay-verify="vod_score" placeholder="请输入评分"
                                               autocomplete="off" class="layui-input">
                                    </div>
                                </div>
                                <div class="layui-inline">
                                    <label class="layui-form-label">视频时长</label>
                                    <div class="layui-input-inline">
                                        <input type="text" name="vod_duration" lay-verify="vod_duration"
                                               placeholder="请输入视频时长"
                                               autocomplete="off" class="layui-input">
                                    </div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">导演</label>
                                <div class="layui-input-inline">
                                    <input type="text" name="vod_director" lay-verify="vod_director"
                                           placeholder="导演"
                                           autocomplete="off" class="layui-input">
                                </div>
                            </div>
                            <div class="layui-form-item" style="display:none">
                                <label class="layui-form-label">启用跳转</label>
                                <div class="layui-input-block">
                                    <input type="checkbox" name="vod_jumpstatus" lay-filter="vod_jumpstatus"
                                           lay-skin="switch" lay-text="开启|禁止">
                                </div>
                            </div>
                            <div class="layui-form-item" style="display:none">
                                <label class="layui-form-label">跳转地址</label>
                                <div class="layui-input-inline">
                                    <input type="text" name="vod_jumpurl" lay-verify="vod_jumpurl"
                                           placeholder="http(s)://www.rayswoole.com"
                                           autocomplete="off" class="layui-input">
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">状态</label>
                                <div class="layui-input-block">
                                    <input type="checkbox" name="vod_status" lay-skin="switch" lay-text="通过|待审" checked>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">图片上传</label>
                                    <div class="layui-input-inline">
                                        <input type="text" name="vod_pic" placeholder="图片"  autocomplete="off" class="layui-input">
                                        <input type="hidden" id="isthumb" value="0">
                                        <div class="layui-upload-list">
                                            <img class="layui-upload-img img-content" id="img-conn-i">
                                            <p id="text-conn-i"></p>
                                        </div>
                                    </div>
                                    <div class="layui-input-inline w150">
                                        <div class="layui-upload">
                                            <button type="button" class="layui-btn" id="image" style="height: 35px;"><i class="layui-icon"></i>上传图片</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">缩略图上传</label>
                                    <div class="layui-input-inline">
                                        <input type="text" name="vod_p_thumb" id="vod_p_thumb" placeholder="缩略图" autocomplete="off" class="layui-input" value="">
                                        <input type="hidden" name="vod_pic_thumb" id="vod_pic_thumb" value="">
                                        <div class="layui-upload">
                                            <div class="layui-upload-list">
                                                <img class="layui-upload-img img-content" id="img-conn-ii">
                                                <p id="text-conn-ii"></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="layui-input-inline">
                                        <div class="layui-upload">
                                            <button type="button" class="layui-btn" id="thumb" style="height: 35px;"><i class="layui-icon"></i>上传图片</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="layui-form-item" style="display: none">
                                <div class="layui-inline">
                                    <label class="layui-form-label">海报</label>
                                    <div class="layui-input-inline" style="width: 350px !important;" >
                                        <input type="text" name="vod_pic_slide" placeholder="请输入海报"
                                               autocomplete="off" class="layui-input">
                                    </div>
                                </div>
                                <div class="layui-inline">
                                    <div class="btn">
                                        <button type="button" class="layui-btn layui-upload" lay-data="{data:{thumb:0,thumb_class:'upload-thumb'}}" id="upload3">上传图片</button>
                                    </div>
                                </div>
                            </div>
                            <div id="player_list" class="contents">
                                <div data-i="1">
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">播放器</label>
                                        <div class="layui-input-inline">
                                            <select name="vod_play_from[]" required lay-verify="vod_play_from">
                                                <option value="0">请选择播放器.</option>
                                                <?php if(is_array($player_list) || $player_list instanceof \think\Collection || $player_list instanceof \think\Paginator): $i = 0; $__LIST__ = $player_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                                    <option value="<?php echo $vo['player_from']; ?>"><?php echo $vo['player_name']; ?></option>
                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                            </select>
                                        </div>
                                        <div class="layui-input-inline"><select name="vod_play_server[]"><option value="0">请选择服务器.</option><option value="1">服务器1</option></select></div>
                                        <a href="javascript:void(0)" class="j-editor-remove layui-btn layui-btn-danger">删除</a>

                                    </div>
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">播放列表</label>
                                        <div class="layui-input-block">
                                            <textarea name="vod_play_url[]" placeholder="" class="layui-textarea"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class=""><button class="layui-btn radius j-player-add" type="button">添加一组播放</button></label>
                                <div class="layui-input-block">
                                </div>
                            </div>
                            <div class="layui-form-item layui-form-text">
                                <label class="layui-form-label">剧情简介</label>
                                <div class="layui-input-block">
                                    <textarea name="vod_blurb" lay-verify="vod_blurb" placeholder="请输入简介" class="layui-textarea"></textarea>
                                </div>
                            </div>
                            <div class="layui-form-item layui-form-text">
                                <label class="layui-form-label">剧情内容</label>
                                <div class="layui-input-block">
                                    <textarea id="details" style="display: none;"></textarea>
                                    <input type="hidden" name="vod_content">
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">排序</label>
                                <div class="layui-input-inline">
                                    <input type="number" name="vod_sort" lay-verify="vod_sort" placeholder="值越大越靠前"
                                           autocomplete="off" min="0" value="0" class="layui-input" >
                                </div>
                            </div>
                        </div>
                        <div class="layui-tab-item">
                                <div class="layui-form-item">
                                    <label class="layui-form-label"></label>
                                    <div class="layui-input-inline ">
                                        <button class="layui-btn" type="button" id="btn_rnd">随机生成</button>
                                    </div>
                                </div>
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">总人气：</label>
                                    <div class="layui-input-inline ">
                                        <input type="text" class="layui-input" value="" placeholder="" id="vod_hits"
                                               name="vod_hits">
                                    </div>
                                </div>
                                <div class="layui-inline">
                                    <label class="layui-form-label">月人气：</label>
                                    <div class="layui-input-inline ">
                                        <input type="text" class="layui-input" value="" placeholder=""
                                               id="vod_hits_month" name="vod_hits_month">
                                    </div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <label class="layui-form-label">周人气：</label>
                                    <div class="layui-input-inline ">
                                        <input type="text" class="layui-input" value="" placeholder=""
                                               id="vod_hits_week" name="vod_hits_week">
                                    </div>
                                </div>
                                <div class="layui-inline">
                                    <label class="layui-form-label">日人气：</label>
                                    <div class="layui-input-inline ">
                                        <input type="text" class="layui-input " value="" placeholder=""
                                               id="vod_hits_day" name="vod_hits_day">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--<div class="layui-tab-item">内容3</div>-->
                        <div class="layui-form-item">
                            <div class="layui-input-block">
                                <button class="layui-btn" lay-filter="vod_form" lay-submit id="btn-form">立即提交</button>
                                <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
</body>
<script src="/static/admin/js/Convert_Pinyin.js"></script>
<script>
    layui.config({
        base: '/static/js/layui/layui_exts/',
    }).extend({
        xmSelect: 'xm-select'
    }).use(['layer', 'form', 'upload', 'laydate','xmSelect','colorpicker','layedit'], function () {
        var form = layui.form,
            layer = layui.layer,
            upload = layui.upload,
            laydate = layui.laydate,
            colorpicker = layui.colorpicker,
            layedit = layui.layedit,
            xmSelect = layui.xmSelect;

        // 验证规则
        form.verify({
            vodcid: function (value) {
                if (value== "") {
                    return '请选择电影分类';
                }
            },
            vod_title: function (value) {
                if (value.length > 250 ) {
                    return '视频标题过长';
                }else if(value.length ==0){
                    return '视频标题不能为空';
                }
            },
            vod_color: function (value) {
                var reg = /#([\da-f]{3}){1,2}/gi;
                if (value.length > 0 && !reg.test(value)) {
                    return '标题颜色格式不正确';
                }
            },
            vod_letter: function (value) {
                var reg = /^[0-9a-zA-Z]$/;
                if (value.length>0 && !reg.test(value)) {
                    return '请填写正确首字母';
                }
            },
            vod_total: function (value) {
                var reg = /^\d+$/; // 非负整数
                if(value.length > 0 && !reg.test(value)){
                    return '总集数只能为数字';
                }
            },
            vod_serial: function (value) {
                var reg = /^\d+$/; // 非负整数
                if(value.length > 0 && !reg.test(value)){
                    return '连载数只能为数字';
                }
            },
            vod_score: function (value) {
                var reg = /^\d+(\.\d+)?$/; // 非负整数带浮点
                if(value.length > 0 && !reg.test(value)){
                    return '评分为数字';
                }
            },
            vod_duration: function (value) {
                var reg = /^\d+([\:\.\d]+)?$/; // 非负整数
                if(value.length > 0 && !reg.test(value)){
                    return '视频时长为数字';
                }
            },
            vod_jumpurl: function (value) {
                var reg = /^(ht|f)tp(s?)\:\/\/[0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*(:(0-9)*)*(\/?)([a-zA-Z0-9\-\.\?\,\'\/\\\+&amp;%$#_]*)?$/;
                if(value.length > 0 && !reg.test(value)){
                    return '跳转地址格式不正确';
                }
            },
            vod_sort: function (value) {
                var reg = /^\d+$/;
                if(value.length > 0 && !reg.test(value)){
                    return '排序为整数';
                }
            }

        });
        const ieditor = layedit.build('details',{
            uploadImage: {
                url: '<?php echo \rayswoole\Helper::url("admin/index/upload"); ?>',
                accept: 'image',
                acceptMime: 'image/*',
                exts: 'jpg|png|gif|bmp|jpeg',
                size: '10240',
                field: 'image'
            }
            , devmode: true
            , codeConfig: {
                hide: true,
                default: 'javascript'
            }
            , tool: [
                'code', 'strong', 'italic', 'underline', 'del', 'addhr', '|', 'fontFomatt', 'colorpicker', 'face'
                , '|', 'left', 'center', 'right', '|', 'link', 'unlink', 'image', 'anchors'
                , '|'
            ]
            , height: 366
        });


        // 监听提交
        form.on('submit(vod_form)', function (data) {
            var fieldx = data.field;
            fieldx.vod_content = layedit.getContent(ieditor);
            //layer.msg(JSON.stringify(data.field));
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/save"); ?>', fieldx, function (before) {
                // 请求前执行的
            }, function (res) {
                if (!res.code) {
                    layer.msg(res.msg);
                    $('.reset').click();
                    if (parent.layer.getFrameIndex(window.name)) {
                        layer.msg(res.msg);
                        cre.fclose();
                    }
                } else {
                    layer.msg(res.msg);
                    cre.close();
                }
                // 请求成功返回
            }, function (error) {
                // 请求失败返回
                layer.msg('请求失败');
            });
            return false;
        });
        // 颜色选择
        colorpicker.render({
            elem: '#test-form'
            , color: '#1c97f5'
            , done: function (color) {
                $('#test-form-input').val(color);
            }
        });
        // 时间选择
        laydate.render({
            elem: '#time_start'
            //, type: 'datetime'
        });
        laydate.render({
            elem: '#time_end'
           // , type: 'datetime'
        });
        //主角演员
        var index=-1;
        var demo3 = xmSelect.render({
            el: '#vod_actor',
            paging: true,
            pageSize: 10,
            autoRow: true,
            toolbar: { show: true },
            filterable: true,
            remoteSearch: true
            ,remoteMethod: function(val, cb, show){
                $.ajax({
                    url: '<?php echo \rayswoole\Helper::url("admin/index/actorapi"); ?>',
                    type: 'post', //或者post　　 请求类型
                    dataType: 'json',
                    data: { // 要发送的请求参数
                        'actorname' : val
                    },
                    success : function (aa) {
                        console.log(aa);
                        var res = aa.result;
                        //console.log(res);
                        var data = [];
                        if (res.length>0) {
                            var actors=JSON.parse(JSON.stringify(res)),
                                ac="{actors.actor_id}";
                            var actor_id=ac.split(",");
                            $.each(actors,function(i,val)
                            {
                                if($.inArray(val.actor_id.toString(),actor_id)>-1){
                                    data.push({
                                        name: val.actor_name,
                                        value: val.actor_id,
                                        selected:true
                                    })
                                }else{
                                    data.push({
                                        name: val.actor_name,
                                        value: val.actor_id,
                                        selected:false
                                    })
                                }
                            })
                        } else {
                            data.push({
                                name: val,
                                value:index--,
                                selected:false
                            })
                        }
                        cb(data)
                    }
                })
            }
            ,data:[]
            ,on: function(data){
                //arr:  当前多选已选中的数据
                var arr = data.arr;
                var insert='';
                var name='';
                $.each(arr,function(i,val){
                    insert+=val.value+',';
                    name+=val.name+',';
                })
                var reg=/,$/gi;
                insert=insert.replace(reg,"");
                name=name.replace(reg,"");
                //console.log(insert);
                $("#vod_rel_actor").val(name);
                $("#actor_id").val(insert);
            },
        })


        //随机生成分数
        $("#btn_rnd").click(function(){
            var _mtday = rndNum(1,200);
            var _mtweek = rndNum(3,7);
            var _mtmonth = rndNum(2,4);
            var _mtall = rndNum(2,5);

            $("#vod_hits").val( _mtday*_mtweek*_mtmonth*_mtall );
            $("#vod_hits_week").val( _mtday*_mtweek );
            $("#vod_hits_month").val( _mtday*_mtweek*_mtmonth );
            $("#vod_hits_day").val( _mtday );

        });
        function rndNum(under, over){
            switch(arguments.length){
                case 1: return parseInt(Math.random()*under+1);
                case 2: return parseInt(Math.random()*(over-under+1) + under);
                default: return 0;
            }
        }
    //上传图片
        var uploadInst_x = upload.render({
            elem: '#image'
            , field: "image"
            , data: {
                'type': 'image',
                'time': new Date().getTime()
            }
            , url: '<?php echo \rayswoole\Helper::url("admin/index/upload"); ?>'
            , before: function (obj) {
                console.log(obj);
                //预读本地文件示例，不支持ie8
                obj.preview(function (index, file, result) {
                    $('#img-conn-i').attr('src', result); //图片链接（base64）
                    if(!$('#vod_pic_thumb').val()){
                        $('#img-conn-ii').attr('src', result); //图片链接（base64）
                    }

                });
            }
            , done: function (res) {
                console.log(res);
                var tipstext = $('#text-conn-i');
                if (!res.code) {
                    tipstext.html('<span class="yes">'+res.msg+'</span>');
                    $('input[name=\'vod_pic\']').val(res.data.src);
                    if($("#isthumb").val()==0){
                        $('input[name=\'vod_p_thumb\']').val(res.data.thumbsrc);
                        $('input[name=\'vod_pic_thumb\']').val(res.data.thumbsrc);
                    }
                } else {
                    tipstext.html('<span class="no">${res.msg}</span>');
                }
            }
            , error: function () {
                //演示失败状态，并实现重传
                var demoText = $('#text-conn-i');
                demoText.html('<span style="color: #FF5722; line-height: 35px; display: inline-block">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst_x.upload();
                });
            }
        });

        var uploadInst_i = upload.render({
            elem: '#thumb'
            , field: 'thumb'
            , url: '<?php echo \rayswoole\Helper::url("admin/index/upload"); ?>'
            , data: {
                'type': 'thumb',
               // 'oldthumb':$('input[name=\'vod_pic_thumb\']').val(),
                'time': new Date().getTime()
            }
            , before: function (obj) {
                //预读本地文件示例，不支持ie8
                obj.preview(function (index, file, result) {
                    $('#img-conn-ii').attr('src', result); //图片链接（base64）
                });
            }
            , done: function (res) {
                var tipstext = $('#text-conn-ii');
                if (!res.code) {
                    tipstext.html('<span class="yes">'+res.msg+'</span>');
                    $('input[name=\'vod_p_thumb\']').val(res.data.src);
                    $('input[name=\'vod_pic_thumb\']').val(res.data.src);
                    $("#isthumb").val("1");
                } else {
                    tipstext.html('<span class="no">'+res.msg+'</span>');
                }
            }
            , error: function () {
                var demoText = $('#text-conn-ii');
                demoText.html('<span style="color: #FF5722; line-height: 35px; display: inline-block">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst_i.upload();
                });
            }
        });
        //输出电影名称获取首字母
        $("#vod_title").blur(function(){
            var chinaName = $('#vod_title').val();
            //获取全写拼音（调用js中方法）
            //var fullName = pinyin.getFullChars(chinaName);
            //获取简写拼音（调用js中方法）
            var easyName = pinyin.getCamelChars(chinaName.substr(0, 1));
            //给两个文本框赋值
            $('#vod_letter').val(easyName);
            //$('#easyName').val(easyName);
        })

        var players_arr_len = 1;
        var player_select='<?php if(is_array($player_list) || $player_list instanceof \think\Collection || $player_list instanceof \think\Paginator): $i = 0; $__LIST__ = $player_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo $vo['player_from']; ?>"><?php echo $vo['player_name']; ?></option><?php endforeach; endif; else: echo "" ;endif; ?>';
        $('.j-player-add').on('click',function(){
            players_arr_len++;
            var tpl='<div data-i="'+players_arr_len+'"><div class="layui-form-item"><label class="layui-form-label">播放器'+(players_arr_len)+'：</label><div class="layui-input-inline"><select name="vod_play_from[]" required lay-verify="vod_play_from"><option value="0">请选择播放器.</option>'+player_select+'</select></div><div class="layui-input-inline"><select name="vod_play_server[]"><option value="0">请选择服务器.</option><option value="1">服务器1</option></select></div><a href="javascript:void(0)" class="j-editor-remove layui-btn layui-btn-danger">删除</a></div><div class="layui-form-item"><label class="layui-form-label">播放列表</label><div class="layui-input-block"><textarea name="vod_play_url[]" placeholder="" class="layui-textarea"></textarea></div></div></div>'
            $("#player_list").append(tpl);

            form.render('select');
        });

        if(players_arr_len==0 && downers_arr_len==0) {
            $('.j-player-add').click();
        }
        $('.contents').on('click','.j-editor-remove',function(){
            var datai = $(this).parent().parent().attr('data-i');
            if(datai!=1){
                $(this).parent().parent().remove();
            }
        });


    });
</script>
</html>