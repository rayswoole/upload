<?php /*a:1:{s:60:"/var/wwwroot/rayswoole2.1/App/Document/View/index/index.html";i:1607506071;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ray7文档 <?php echo !empty($md['doc_title']) ? $md['doc_title'] : ''; ?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="keywords" content="Ray7文档 <?php echo !empty($md['doc_keys']) ? $md['doc_keys'] : ''; ?>">
    <meta name="description" content="Ray7文档 <?php echo !empty($md['doc_desc']) ? $md['doc_desc'] : ''; ?>">
    <link rel="stylesheet" href="/static/js/editor/eca7087.css">
</head>
<body class="ready sticky">
<nav class="app-nav no-badge">
    <ul>
        <li>
            <span class="iconfont icon-tianxie"></span> Language
            <ul>
                <li>
                    <a href='<?php echo \rayswoole\Helper::url("/document/index/index",["lang"=>"zh"]); ?>' target="" rel="noopener" title=" 简体中文">
                        <span class="iconfont icon-csdn"></span> 简体中文
                    </a>
                </li>
                <li>
                    <a href='<?php echo \rayswoole\Helper::url("/document/index/index",["lang"=>"en"]); ?>' target="" rel="noopener" title=" English">
                        <span class="iconfont icon-github"></span> English
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<main>
    <button class="sidebar-toggle">
        <div class="sidebar-toggle-button">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </button>
    <aside class="sidebar">
        <div class="search">
            <div class="input-wrap">
                <input type="search" value="" id="search_input" aria-label="Search text" placeholder="搜索">
                <div class="clear-button">
                    <svg width="26" height="24">
                        <circle cx="12" cy="12" r="11" fill="#ccc"></circle>
                        <path stroke="white" stroke-width="2" d="M8.25,8.25,15.75,15.75"></path>
                        <path stroke="white" stroke-width="2" d="M8.25,15.75,15.75,8.25"></path>
                    </svg>
                </div>
            </div>
            <div class="results-panel"></div>
        </div>

        <h1 class="app-name">
            <a class="app-name-link" data-nosearch="" href="">
                RayCms
            </a>
        </h1>

        <div class="sidebar-nav">
            <div id="carbonads">
            </div>
            <ul class="sidebar-nav-ul">
                <?php if(!empty($nav)): if(is_array($nav) || $nav instanceof \think\Collection || $nav instanceof \think\Paginator): $i = 0; $__LIST__ = $nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$l): $mod = ($i % 2 );++$i;?>
                <li class="<?php echo $l['type_id']==$id ? 'active'  : ''; ?>">
                    <?php if(!empty($l['child'])): ?>
                    <p><?php echo $l['type_name']; ?></p>
                    <ul>
                        <?php if(is_array($l['child']) || $l['child'] instanceof \think\Collection || $l['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $l['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$lc): $mod = ($i % 2 );++$i;?>
                        <li class="<?php echo $lc['type_id']==$id ? 'active'  : ''; ?>">
                            <?php if(!empty($lc['child'])): ?>
                            <p><?php echo $lc['type_name']; ?></p>
                            <ul>
                                <?php if(is_array($lc['child']) || $lc['child'] instanceof \think\Collection || $lc['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $lc['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ld): $mod = ($i % 2 );++$i;?>
                                <li class="<?php echo $ld['type_id']==$id ? 'active'  : ''; ?>">
                                    <a href='<?php echo \rayswoole\Helper::url("/document/index/index",["lang"=>$lang,"id"=>$ld['type_id']]); ?>'
                                       title="<?php echo $ld['type_name']; ?>"><?php echo $ld['type_name']; ?></a>
                                </li>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </ul>
                            <?php else: ?>
                            <a href='<?php echo \rayswoole\Helper::url("/document/index/index",["lang"=>$lang,"id"=>$lc['type_id']]); ?>'
                               title="<?php echo $lc['type_name']; ?>"><?php echo $lc['type_name']; ?></a>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                    <?php else: ?>
                    <a href='<?php echo \rayswoole\Helper::url("/document/index/index",["lang"=>$lang,"id"=>$l['type_id']]); ?>'
                       title="<?php echo $l['type_name']; ?>"><?php echo $l['type_name']; ?></a>
                    <?php endif; ?>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; else: ?>
                <li>
                    <p>暂无数据</p>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </aside>
    <div class="content">
        <article class="markdown-section" id="main">
            <input type="hidden" name="md" id="md" value="<?php echo isset($md['doc_content']) ? $md['doc_content'] : ''; ?>">
            <div id="main_section"></div>
        </article>
    </div>
</main>
<div class="flex_container">
    <div class="topc">
        <div class="title"><span>本章目录</span></div>
        <div id="topc_item"></div>
    </div>
</div>
</body>
<script src="/static/js/editor/lib/jquery.min.js"></script>
<script src="/static/js/editor/lib/marked.min.js"></script>
<script src="/static/js/editor/lib/prettify.min.js"></script>
<script src="/static/js/editor/lib/raphael.min.js"></script>
<script src="/static/js/editor/lib/underscore.min.js"></script>
<script src="/static/js/editor/lib/sequence-diagram.min.js"></script>
<script src="/static/js/editor/lib/flowchart.min.js"></script>
<script src="/static/js/editor/lib/jquery.flowchart.min.js"></script>
<script src="/static/js/editor/editormd.min.js"></script>
<script src="/static/js/editor/lib/edcy.js"></script>
<script type="text/javascript">
    var doclist = <?php echo $doc; ?>, editor_view = {
        _render_sidebar_nav: function () {
            $.ajax({
                url: "/document/index/sidebar_nav", data: {}, type: "get", dataType: "json", success: function (e) {
                    var n;
                    0 === e.code ? (n = "", $.each(e.data, function (e, t) {
                        n += "<li>\n<p>" + t.type_name + "</p>\n", t.child && (n += "<ul>", $.each(t.child, function (e, t) {
                            n += '<li class=""><a href="/document/index/index?lang=zh&name=' + t.type_name + "&id=" + t.type_id + '" title="' + t.type_name + '">' + t.type_name + "</a></li>"
                        }), n += "</ul>"), n += "</li>"
                    }), console.log(n), $(".sidebar-nav-ul").html("").html(n)) : console.log(e.msg)
                }
            })
        }, _sidebar_nav_event: function () {
            var t = this;
            $(document).on("click", ".sidebar-nav-ul li a", function () {
                $(".sidebar-nav-ul").find("li").removeClass("active"), $(this).parent("li").addClass("active");
                var e = $(this).attr("href");
                $(this).html();
                return window.history.pushState(null, null, e), $.ajax({
                    url: e,
                    data: {},
                    type: "post",
                    dataType: "json",
                    success: function (e) {
                        e ? (document.title = "Ray7文档 " + (e.md.doc_title || ""), $('meta[name="keywords"]').attr("content", "Ray7文档 " + (e.md.doc_keys || "")), $('meta[name="description"]').attr("content", "Ray7文档 " + e.md.doc_desc || ""), t._render_markdown("main_section", e.md.doc_content), copyRender.init()) : $("#main").html("").html("暂未有数据.")
                    }
                }), !1
            })
        }, _header_nav_event: function () {
            $(document).on("click", ".app-nav ul li a", function () {
                var e = $(this).attr("href");
                $(this).html();
                return window.location.href = e, !1
            })
        }, _sidebar_hidden: function () {
            var e = !0;
            return $(".sidebar-toggle").on("click", function () {
                e ? (e = !1, $(".sidebar").css("transform", "-300px" == $(".sidebar").css("left") ? "translateX(300px)" : "translateX(-300px)"), $(".content").css("left", 0), $(".app-nav").css("width", "-300px" == $(".sidebar").css("left") ? "calc(100% - 325px)" : "calc(100%)")) : (e = !0, $(".sidebar").css("transform", ""), $(".content").css("left", ""), $(".app-nav").css("width", "calc(100% - 325px)"))
            }), !1
        }, _render_markdown: function (e, t) {
            e = e || "main_section", t = t || "## 暂未有数据,管理员正在积极书写中", $("#" + e).html(""), editormd.markdownToHTML(e, {
                markdown: this._unescapeHTML(t),
                htmlDecode: "style,script,iframe",
                tocm: !0,
                tocContainer: "#topc_item",
                emoji: !0,
                taskList: !0,
                tex: !0,
                flowChart: !0,
                sequenceDiagram: !0
            })
        }, _chang_search_input: function () {
            var n = this;
            $("#search_input").bind("input propertychange", function (e) {
                var t = $("#search_input").val();
                t ? n._search_key(t) : ($(".search").css("border-bottom", "1px solid #eee"), $(".results-panel").css("display", "none").children().remove())
            })
        }, _goup_header: function () {
            setTimeout(function () {
                $.goup({trigger: 600, bottomOffset: 52, locationOffset: 15, title: "", titleAsText: !0})
            }, 2e3)
        }, _HTMLDecode: function (e) {
            (n = document.createElement("div")).innerHTML = e;
            var t = n.innerText || n.textContent, n = null;
            return t
        }, _unescapeHTML: function (e) {
            return (e = "" + e).replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&apos;/g, "'")
        }, _queryVar: function (e, t, n) {
            for (var a = (n = n || window.location.search.substring(1)).split("&"), i = [], r = 0; r < a.length; r++) {
                var c = a[r].split("=");
                if (c[0] === e) return unescape(c[1]);
                i.push(c)
            }
            return e && t !== undefined ? t : 0 < i.length && "" !== i[0][0] ? JSON.stringify(i) : ""
        }, _search_key: function (v) {
            var f = [];
            $.each(doclist, function (e, t) {
                var n = 0, a = t.name, i = t.content, r = t.href, c = new RegExp(v, "g"), s = a.match(c),
                    o = i.match(c),
                    d = s ? s.length : 0, l = o ? o.length : 0;
                n += s && 0 < d ? 6 * d : o && 0 < l ? 2 * l : 0;
                var _, h, u, p, m = "";
                o ? (h = (_ = i.indexOf(v)) - 20, u = _ + 60, p = _ + v.length, m += i.slice(h, _), m += "<span  class=\"weig\" style='font-weight: bold; color: #42b983'>" + v + "</span>", m += i.slice(p, u)) : m += i.slice(0, 120), 0 < n && f.push({
                    weight: n,
                    name: a,
                    href: r,
                    content: (m || a) + "..."
                })
            });
            var n = "";
            0 < f.length ? (f.sort(function (e, t) {
                return t.weight - e.weight
            }), $.each(f, function (e, t) {
                n += '<div class="matching-post"><a href="' + t.href + '" style=""><h2>' + t.name + "</h2><p>" + t.content + "</p></a></div>"
            })) : n += '<div class="matching-post"><span href="#" style="text-align: center;color: #505d6b"><h2 style="font-size: 12px; ">－－ 暂未找到数据 －－</h2></span></div>', $(".search").css("border-bottom", "none"), $(".results-panel").css("display", "block").html("").html(n)
        }, _target: function () {
            $(document).on('click', 'a[href*=#],area[href*=#]', function () {
                if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') && location.hostname === this.hostname) {
                    const g = this.hash, n = $('[name="' + decodeURIComponent(g.slice(1)) + '"]');
                    if (n.length) {
                        const t = n.offset().top - 60;
                        $('html,body').stop(true).animate({
                                scrollTop: t
                            },
                            500);
                        return false;
                    }
                }
            });
        }
    };
    $(document).ready(function () {
        editor_view._goup_header(), editor_view._sidebar_nav_event(), editor_view._header_nav_event(), editor_view._sidebar_hidden(), editor_view._chang_search_input(), editor_view._render_markdown("main_section", $("#md").val()), copyRender.init(), editor_view._target()
    });


</script>
</html>