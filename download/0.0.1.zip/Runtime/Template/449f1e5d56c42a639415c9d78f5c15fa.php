<?php /*a:2:{s:66:"/var/wwwroot/rayswoole2.1/App/Update/View/admin/version/index.html";i:1607427444;s:65:"/var/wwwroot/rayswoole2.1/App/Update/View/admin/index/header.html";i:1606707105;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer"  content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content {
            display: inline-block;
            width: 30%;
        }

        .w-60 {
            width: 60% !important;
        }

        .xadmin-conn-height-500 {
            min-height: 500px !important;
        }

        .xform input {
            height: 38px !important;
            line-height: 38px !important;
        }

        .xform .layui-form-label {
            height: 20px !important;
            line-height: 20px !important;
        }

        .xform .layui-form-radio {
            margin-bottom: 6px !important;
        }

        .xform .layui-form-switch {
            margin-top: 8px !important;
        }

        .xform .layui-form-item {
            margin-bottom: 5px !important;
        }

        .xform .layui-form-item .layui-input-inline {
            display: inline-block;
            width: 260px;
        }

        .tips_text {
            padding-right: 6px;
            color: darkred !important;
            font-weight: bold;
        }

        #search {
            height: 31px;
            line-height: 31px;
        }

        .clear {
            width: 0;
            height: 0;
            clear: both;
        }

        .toolTable {
            padding-bottom: 10px;
        }

        .male-color {
            color: #1E9FFF;
            font-size: 14px;
        }

        .female-color {
            color: #ff6bc9;
            font-size: 14px;
        }

        .thumb_img {
            width: 30%;
            height: 80%;
        }

        .yes {
            color: #009688;
            font-weight: bold;
        }

        .no {
            color: #d6ae7b;
            font-weight: bold;
        }

        .pd-30-50 {
            padding: 30px 10px 50px 10px;
        }

        .layui-inline {
            margin-right: -10px !important;
        }

        .biaoqianyun {
            width: 100%;
            margin-left: 10px;
        }

        .biaoqianyun span {
            padding: 5px 15px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-20 {
            width: 20% !important;
        }

        .it {
            margin: 0 10px 0 5px;
            color: #666;
        }


        .tagcon {
            width: 100%;
            height: auto;
            border: 1px solid #e6e6e6;
            display: inline-block;
        }

        .tagcon input {
            height: 35px;
            border: none;
        }

        .tagcon .bq span {
            padding: 5px 15px;
            margin: 5px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
            display: inline-block;
            transition: all ease-in-out .5s;
            position: relative;
        }

        .tagcon .bq span:hover {
            padding-right: 25px;
        }

        .tagcon .bq span:hover:after {
            content: 'x';
            padding: 1px;
            position: absolute;
            top: 5px;
            right: 5px;
            border-radius: 50%;
            color: #fff;
        }


        .layui-form-item div.layui-upload-list {
            margin: 0 !important;
        }

        .layui-form-item div.layui-upload-list img {
            margin: 10px !important;
        }

        .form-conn {
            margin: 15px 0;
        }


        .xadmin-btn-6262 {
            background: #de6262;
        }

        .xadmin-btn-cea2 {
            background: #43cea2;
        }

        .xadmin-btn-5876 {
            background: #2b5876;
        }

        .xadmin-btn-076b {
            background: #aa076b;
        }

        .xadmin-btn-9966 {
            background: #ff9966;
        }

        .xadmn-btn-5f6d {
            background: #ff5f6d;
        }

        .xadmin-btn-cdac {
            background: #00cdac;
        }

        .xadmin-btn-3e50 {
            background: #2c3e50;
        }

        .xadmin-btn-4b6d {
            background: #734b6d;
        }

        .xadmin-btn-b1bf {
            background: #48b1bf;
        }

        .re_cookie {
            position: relative;
        }

        .re_cookie .re {
            position: absolute;
            right: 6px;
            top: 10px;
            cursor: pointer;
            color: #009688;
        }

        .layui-table-cell {
            /*height: auto !important;*/
        }
        .xa {
            display: none;
        }
    </style>
</head>
<body>
<div class="x-nav">
          <span class="layui-breadcrumb">
            <a href="">首页</a>
            <a href="">版本信息</a>
            <a>
              <cite>版本列表</cite></a>
          </span>
    <a class="layui-btn layui-btn-small layui-btn-sm" style="float:right; margin-top: 5px;"
       onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style=""></i></a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">

                <div class="layui-card-header toolTable">
                    <div class="search-con layui-card-body" style="float: left">
                        <div class="ctable-tool">
                            <input type="text" name="username" placeholder="Search..." autocomplete="off"
                                   class="layui-input" id="search"
                                   style="display: inline-block;width: auto;height: 30px;line-height: 30px;margin-top: 1px;">
                            <button class="layui-btn layui-btn-sm" data-type="search"
                                    style="margin-left: -5px;border-radius: 0 2px 2px 0;margin-top: -2px;">
                                <i class="layui-icon">&#xe615;</i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-conn layui-card-body ctable-tool" id="" style="float:left;">
                        <button class="layui-btn layui-btn-sm" data-type="create">
                            <i class="layui-icon"></i>添加数据
                        </button>
                        <button class="layui-btn layui-btn-sm layui-btn-danger" data-type="delete"><i
                                class="layui-icon"></i>批量删除
                        </button>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>

                <div class="layui-card-body ">
                    <table class="layui-hide" id="Ctableid" lay-filter="Ctable"></table>
                    <script type="text/html" id="card_status">
                        <input type="checkbox" name="close" value="{{d.card_id}}" lay-skin="switch"
                               lay-text="未用|已用" lay-filter="status" {{ d.card_status== 0 ? 'checked' : '' }} >
                    </script>
                    <script type="text/html" id="thumb">
                        <img src="{{d.art_pic_thumb == '' ? d.art_pic : d.art_pic_thumb}}" alt="{{d.art_title}}"
                             class="thumb_img">
                    </script>
                    <script type="text/html" id="card_usertime">
                        {{#if (d.card_usertime!=0){ }}
                            <span>{{ layui.util.toDateString(d.card_usertime*1000,'yyyy-MM-dd') }}</span>
                        {{# }else{ }}
                            <span>未使用</span>
                        {{# } }}
                    </script>
                    <script type="text/html" id="barDemo">
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="edit" title="编辑">
                            <i class="layui-icon">&#xe642;</i>
                        </a>
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="delete" title="删除">
                            <i class="layui-icon">&#xe640;</i>
                        </a>
                    </script>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
<script>

    layui.use(['form', 'table', 'layer'], function() {
        const $ = layui.$,
            form = layui.form,
            table = layui.table,
            layer = layui.layer;

        // 数据表格
        const xtable = table.render({
            elem: '#Ctableid'
            , url: '<?php echo \rayswoole\Helper::url("admin/version/read"); ?>'
            , title: '会员列表'
            , totalRow: false
            , loading: true
            , id: "CTableToMaster"
            , even: true
            , skin: 'nob'
            , cols: [[
                {type: 'checkbox', width: 80}
                , {field: 'version_id', title: 'ID', width: 80, unresize: true, sort: true}
                , {field: 'version_sort', title: '排序', width: 100, sort: true,}
                , {field: 'version_number', title: '版本', width: 150}
                , {field: 'version_minversion', title: '最低更新版本', width: 150}
                , {field: 'version_description', title: '描述'}
                , {field: 'version_downurl', title: '下载地址'}
                , {field: 'version_addtime ', title: '添加时间', width: 120,
                    templet: "<div>{{layui.util.toDateString(d.version_addtime*1000, 'yyyy-MM-dd')}}</div>"
                }
                , {title: '操作', toolbar: '#barDemo', width: 200}
            ]],
            page: true,
            limit: 20,
            height: 'full-200'
        });

        // 行内工具栏
        table.on('tool(Ctable)', function (obj) {
            var data = obj.data,
                event = obj.event;

            if (event === 'edit') {
                /* 弹出宽 */
                xadmin.open('修改', '<?php echo \rayswoole\Helper::url("admin/version/edit"); ?>?edit_id=' + data.version_id, ($(window).width() * 0.6), ($(window).width() * 0.45), false, function (e) {
                    // 销毁后回调
                    xtable.reload();
                });
            }else if (event === 'delete') {
                /* 删除前询问 */
                layer.confirm('确定要删除数据吗?', {
                    btn: ['是的', '点错了'],
                    title: '删除提示'
                }, function (index) {
                    const l = layer.msg('正在删除中...', {
                        'xdata': data.link_id,
                        'time': new Date().getTime()
                    });
                    // 删除请求数据
                    cre.xpost('<?php echo \rayswoole\Helper::url("admin/version/delete"); ?>', {
                        id: data.link_id
                    }, function (before) {
                        // 请求前执行的
                    }, function (res) {
                        layer.msg(res.msg);
                        layer.close(l);
                        xtable.reload();
                    }, function (error) {
                        // 请求失败返回
                    });
                    // 关闭当前提示框
                    layer.close(index);
                });

            }

        });

        // 头部工具栏
        const active = {
            create: function () {
                xadmin.open("添加会员", '<?php echo \rayswoole\Helper::url("admin/version/create"); ?>', ($(window).width() * 0.6), ($(window).width() * 0.45), false, function (e) {
                    // 销毁回调
                    xtable.reload();
                });
            },
            delete: function () {
                const checkStatus = table.checkStatus("CTableToMaster")
                    , data = checkStatus.data
                    , arr = [];
                /* 删除前询问 */
                if(data==''){
                    layer.msg("请选择要删除的数据！");
                    return false;
                }
                layer.confirm('确定要删除数据吗?', {
                    btn: ['是的', '点错了'],
                    title: '删除提示'
                }, function (index) {
                    $.each(data, function (i, v) {
                        arr.push(v.version_id);
                    });
                    var l = layer.msg('正在删除中...', {
                        'xdata': data.version_id,
                        'time': new Date().getTime()
                    });
                    // 删除请求数据
                    cre.xpost('<?php echo \rayswoole\Helper::url("admin/version/delete"); ?>', {
                        id: arr.join(',')
                    }, function (before) {
                        // 请求前执行的
                    }, function (res) {
                        layer.msg(res.msg);
                        layer.close(l);
                        xtable.reload();
                    }, function (error) {
                        // 请求失败返回
                    });
                    // 关闭当前提示框
                    layer.close(index);
                });
            },
            search: function () {
                const search = $('#search');
                xtable.reload({
                    page: {
                        curr: 1 //重新从第 1 页开始
                    }
                    , where: {
                        version: search.val()
                    }
                }, 'data');
            }
        };

        $(".ctable-tool .layui-btn").on('click', function () {
            const type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });


    });
</script>
</html>