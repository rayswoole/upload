<?php /*a:1:{s:55:"/var/wwwroot/rayswoole2.1/App/Admin/View/redis/tpl.html";i:1607501948;}*/ ?>
    'status' => <?php echo $status; ?>,
    'server' => [<?php echo $server; ?>],//多IP时为cluster模式, 第1个默认为主
    'dbIndex' => 0,//数据库序号
    'username'=>'',//适用于账号密码认证
    'password'=>'<?php echo $password; ?>',//适用于账号密码/密码认证
    'writeOnly' => false,//主服务器是否只写
    'options' => [],
    'pool' => [
        'max'=><?php echo $pool['max']; ?>,//最大连接数
        'min'=><?php echo $pool['min']; ?>,//最小连接数
        'free'=>5,//空闲连接保持数
        'intervalTime'=>15*1000,//定时清理空闲连接频率, 单位ms
        'idleTime'=>10,//设置连接最大闲置时间
        'pingTime'=>30,//心跳检测间隔时间
        'timeout'=>1.0 //获取连接超时时间
    ]