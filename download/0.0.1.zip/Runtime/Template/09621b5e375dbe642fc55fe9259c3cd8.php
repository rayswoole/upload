<?php /*a:1:{s:65:"/var/wwwroot/rayswoole2.1/App/Document/View/admin/index/edit.html";i:1606878258;}*/ ?>
<!doctype html>
<html class="x-admin-sm">
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport"
          content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi"/>
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content {
            display: inline-block;
            width: 30%;
        }

        .w-60 {
            width: 60% !important;
        }

        .xadmin-conn-height-500 {
            min-height: 500px !important;
        }

        .xform input {
            height: 38px !important;
            line-height: 38px !important;
        }

        .xform .layui-form-label {
            height: 20px !important;
            line-height: 20px !important;
        }

        .xform .layui-form-radio {
            margin-bottom: 6px !important;
        }

        .xform .layui-form-switch {
            margin-top: 8px !important;
        }

        .xform .layui-form-item {
            margin-bottom: 5px !important;
        }

        .xform .layui-form-item .layui-input-inline {
            display: inline-block;
            width: 260px;
        }

        .tips_text {
            padding-right: 6px;
            color: darkred !important;
            font-weight: bold;
        }

        #search {
            height: 31px;
            line-height: 31px;
        }

        .clear {
            width: 0;
            height: 0;
            clear: both;
        }

        .toolTable {
            padding-bottom: 10px;
        }

        .male-color {
            color: #1E9FFF;
            font-size: 14px;
        }

        .female-color {
            color: #ff6bc9;
            font-size: 14px;
        }

        .thumb_img {
            width: 30%;
            height: 80%;
        }

        .yes {
            color: #009688;
            font-weight: bold;
        }

        .no {
            color: #d6ae7b;
            font-weight: bold;
        }

        .pd-30-50 {
            padding: 30px 10px 50px 10px;
        }

        .layui-inline {
            margin-right: -10px !important;
        }

        .biaoqianyun {
            width: 100%;
            margin-left: 10px;
        }

        .biaoqianyun span {
            padding: 5px 15px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-20 {
            width: 20% !important;
        }

        .it {
            margin: 0 10px 0 5px;
            color: #666;
        }


        .tagcon {
            width: 100%;
            height: auto;
            border: 1px solid #e6e6e6;
            display: inline-block;
        }

        .tagcon input {
            height: 35px;
            border: none;
        }

        .tagcon .bq span {
            padding: 5px 15px;
            margin: 5px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
            display: inline-block;
            transition: all ease-in-out .5s;
            position: relative;
        }

        .tagcon .bq span:hover {
            padding-right: 25px;
        }

        .tagcon .bq span:hover:after {
            content: 'x';
            padding: 1px;
            position: absolute;
            top: 5px;
            right: 5px;
            border-radius: 50%;
            color: #fff;
        }


        .layui-form-item div.layui-upload-list {
            margin: 0 !important;
        }

        .layui-form-item div.layui-upload-list img {
            margin: 10px !important;
        }

        .form-conn {
            margin: 15px 0;
        }


        .xadmin-btn-6262 {
            background: #de6262;
        }

        .xadmin-btn-cea2 {
            background: #43cea2;
        }

        .xadmin-btn-5876 {
            background: #2b5876;
        }

        .xadmin-btn-076b {
            background: #aa076b;
        }

        .xadmin-btn-9966 {
            background: #ff9966;
        }

        .xadmn-btn-5f6d {
            background: #ff5f6d;
        }

        .xadmin-btn-cdac {
            background: #00cdac;
        }

        .xadmin-btn-3e50 {
            background: #2c3e50;
        }

        .xadmin-btn-4b6d {
            background: #734b6d;
        }

        .xadmin-btn-b1bf {
            background: #48b1bf;
        }

        .re_cookie {
            position: relative;
        }

        .re_cookie .re {
            position: absolute;
            right: 6px;
            top: 10px;
            cursor: pointer;
            color: #009688;
        }

        .layui-table-cell {
            /*height: auto !important;*/
        }

        .xa {
            display: none;
        }
        .abc {
            color: #585555;
        }

        .dayx {
            display: inline-block;
            border: 0;
            margin: 0 0 0 15px;
            padding: 0;
        }

        .dayx .layui-form-radio {
            margin: 0 !important;
            padding-right: 0 !important;
        }

        .dayx input::-webkit-outer-spin-button,
        .dayx input::-webkit-inner-spin-button {
            -webkit-appearance: none;
        }

        .editormd-fullscreen {
            z-index: 9999999999999 !important;
        }

    </style>
</head>
<body>
<div class="x-nav">
          <span class="layui-breadcrumb">
            <a href="">首页</a>
            <a href="">文档中心</a>
            <a>
              <cite>编辑文档</cite></a>
          </span>
    <a class="layui-btn layui-btn-small layui-btn-sm" style="float:right; margin-top: 5px;"
       onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style=""></i></a>
</div>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-row pd-30-50">
            <div class="layui-col-md12">
                <form class="layui-form xform" action="">

                    <div class="layui-form-item">
                        <label class="layui-form-label">所属语言</label>
                        <div class="layui-input-inline">
                            <select name="doc_lang" lay-filter="lang" id="lang">
                                <option value="1" <?php if($edit['type_lang'] == '1'): ?>selected<?php endif; ?>>中文</option>
                                <option value="2" <?php if($edit['type_lang'] == '2'): ?>selected<?php endif; ?>>英文</option>
                            </select>
                        </div>
                    </div>

                    <div class="layui-form-item">
                        <label class="layui-form-label">所属上级</label>
                        <div class="layui-input-inline" id="type_list">
                        </div>
                    </div>

                    <div class="layui-form-item">
                        <div class="layui-inline">
                            <label class="layui-form-label">文档标题</label>
                            <input type="hidden" name="doc_id" value="<?php echo $edit['doc_id']; ?>">
                            <div class="layui-input-inline">
                                <input type="text" name="doc_title" lay-verify="doc_title"
                                       placeholder="请输入文档标题"
                                       autocomplete="off" class="layui-input" value="<?php echo $edit['doc_title']; ?>">
                            </div>
                        </div>
                    </div>

                    <div class="layui-form-item">
                        <label class="layui-form-label">文档关键字</label>
                        <div class="layui-input-inline">
                            <input type="text" name="doc_keys" lay-verify="doc_keys"
                                   placeholder="请输入文档关键字"
                                   autocomplete="off" class="layui-input" value="<?php echo $edit['doc_keys']; ?>">
                        </div>
                    </div>

                    <div class="layui-form-item layui-form-text">
                        <label class="layui-form-label">文档描述</label>
                        <div class="layui-input-block">
                            <textarea placeholder="请输入文档描述" name="doc_desc"
                                      class="layui-textarea"><?php echo $edit['doc_desc']; ?></textarea>
                        </div>
                    </div>


                    <div class="layui-form-item">
                        <label class="layui-form-label">文档状态</label>
                        <div class="layui-input-block">
                            <input type="hidden" name="doc_status" id="doc_status" value="<?php echo $edit['doc_status']; ?>">
                            <input type="checkbox" lay-skin="switch"
                                   lay-text="启用|禁用"
                                   lay-filter="status" data-id="doc_status" <?php if($edit['doc_status'] == '1'): ?>checked<?php endif; ?>>
                        </div>
                    </div>


                    <div class="layui-form-item" style="height: 100%;width: 100%">
                        <input type="hidden" id="content" value="<?php echo $edit['doc_content']; ?>">
                        <label class="layui-form-label" style="display: inline;font-weight: bold;">文档内容</label>
                        <div id="doc_content"></div>
                    </div>


                    <div class="layui-form-item form-conn">
                        <div class="layui-input-block">
                            <button class="layui-btn" lay-filter="art_form" lay-submit id="btn-form">立即提交</button>
                            <button type="reset" class="layui-btn layui-btn-primary reset">重置</button>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>
</div>
</body>
<script src="/static/js/editor.js"></script>
<script>
    layui.use(['layer', 'form'], function () {
        const $ = layui.$,
            form = layui.form,
            layer = layui.layer;
        form.verify({});

        form.on('submit(art_form)', function (data) {
            var fieldx = data.field;
            cre.load();
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/save"); ?>', fieldx, function (before) {
                }, function (res) {
                    if (!res.code) {
                        layer.msg(res.msg);
                        $("button[type='reset']").click();
                        cre.loadclose();
                        if (parent.layer.getFrameIndex(window.name)) {
                            cre.fclose();
                        }
                    } else {
                        layer.msg(res.msg);
                        cre.loadclose();
                    }
                }, function (error) {
                    layer.msg('请求失败');
                }
            );
            return false;
        });

        const active = {};

        $(".btn .layui-btn").on('click', function () {
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });

        let arr = [];
        let ta = [];
        form.on('select(level)', function (obj) {
            l(obj.value);
            s($('input[name="level_time"]:checked').val());
        });
        form.on('radio(level_time)', function (obj) {
            s(obj.value);
        });
        let s = function (sid) {
            let num = parseInt($("input[name='level_time_day_number']").val());
            let dj = parseInt(arr[sid - 1]);
            let res = sid === '1' ? (num * dj) : dj;
            $('.price_num').html((res).toString().length < 2 ? '0' + (res) : res);
            t(sid, num);
        };
        $(function () {
            $("input[name='level_time_day_number']").on('input', function (e) {
                if ($('input[name="level_time"]:checked').val() === '1') {
                    let res = parseInt(arr[0]) * e.delegateTarget.value;
                    $('.price_num').html((res).toString().length < 2 ? '0' + (res) : res);
                    t('1', e.delegateTarget.value);
                }
            });
        });
        let l = function (lid) {
            const levelp = $('#levelp_' + lid);
            const day = levelp.attr('day_m');
            const week = levelp.attr('week_m');
            const month = levelp.attr('month_m');
            const period = levelp.attr('period_m');
            const year = levelp.attr('year_m');
            arr = [day, week, month, period, year];
        };
        let t = function (sid, val) {
            if (arr.length > 0) {
                ta = [1, 7, 30, 90, 365];
                let dt = new Date();
                let dj = sid === '1' ? val : parseInt(ta[sid - 1]);
                let tt = dj * 24 * 60 * 60 * 1000;
                dt.setTime(dt.getTime() + tt);
                var res = '至' + dt.getFullYear().toString() + '-' + ((dt.getMonth() + 1 < 10) ? '0' + (dt.getMonth() + 1) : (dt.getMonth() + 1)).toString() + ' -' + (((dt.getDate() + 1) < 10) ? '0' + (dt.getDate() + 1) : (dt.getDate() + 1)).toString();
                $('.changeExprietime').html(res);
            }
        };

        form.on('switch(status)', function (data) {
            $('#' + $(data.elem).attr('data-id')).val(this.checked ? 1 : 0);
        });


        editor.render({
            width: '95%',
            height: 750,
            elem: 'doc_content',
            markdown: $('#content').val()
        }, function (res, obj) {
        });

        form.on('select(lang)', function (data) {
            var value = data.value;
            gettype(value);
        });

        function gettype(value) {
            var tid = <?php echo $edit['type_id']; ?>;
            cre.xget('<?php echo \rayswoole\Helper::url("admin/type/get_type"); ?>', {
                    id: value
                }, function (before) {
                }, function (res) {
                    var html = " <select lay-verify=\"\" lay-search=\"\" name=\"type_id\">\n" +
                        "<option value=\"\">请选择所属上级</option>\n";
                    if (res.data.list) {
                        $.each(res.data.list, function (i, v) {
                            html += "<option value='" + v.type_id + "' " + ($.inArray(v.type_id, res.data.dis) > -1 ? 'disabled' : '') + " " + (tid == v.type_id ? 'selected' : '') + ">" + v.type_name + "</option>"
                        })
                    }
                    html += "</select>";
                    $('#type_list').html('').html(html);
                    layui.form.render();
                }, function (error) {
                    layer.msg('请求失败');
                }
            );
        }

        $(function () {
            gettype($('#lang').val());
        });

    });
</script>
</html>