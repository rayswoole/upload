<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;


use App\Admin\Extend\Common;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\session\Session;

class Node extends Base
{

    public function index(): void
    {
        $this->fetch();
    }


    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $where = [];
            $session = Session::all();
            $order = "node_position asc node_sort asc node_id asc";
            if ((int)$session['role_id'] !== 1) {
                $id = !empty($param['id']) ? $param['id'] : $session['id'];
                $arr = Db::name('role_menu')->where([
                    'role_id' => (int)$id
                ])->column('node_id');
                if ($arr) {
                    $where[] = ['node_id', 'in', $arr];
                }
            }
            if (!empty($param['key'])) {
                $key = $param['key'];
                if (isset($key['searchName']) && $key['searchName']) {
                    $where[] = ['node_name', 'like', "%{$key['searchName']}%"];
                }
            }
            $res = Db::name('node')->where($where)->order($order)->select()->toArray();
            $count = Db::name('node')->where($where)->count('*');
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => $count]);
        }
    }

    public function topnode(): bool
    {
        if ($this->isAjax()) {
            $where['node_position'] = 2;
            $res = Db::name('node')->where($where)->order('node_id desc')->select()->toArray();
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => 0]);
        }
        return false;
    }

    public function create(): void
    {
        $arr = Db::name('node')->select()->toArray();
        $data = Common::getInstance()->tree($arr, 0, 0, $result, 'node_id', 'node_pid', 'node_name');
        $this->assign(['data' => $data]);
        $this->fetch();
    }

    public function save(): ?bool
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $data = [
                'node_name' => trim($param['node_name'], "/\\ \t\n\r\0\x0B"),
                'node_path' => trim($param['node_path'], "/\\ \t\n\r\0\x0B"),
                'node_class' => trim($param['node_class'], "/\\ \t\n\r\0\x0B"),
                'node_pid' => (int)$param['node_pid'],
                'node_description' => trim($param['node_description'], "/\\ \t\n\r\0\x0B"),
                'node_status' => (int)$param['node_status'],
                'node_mark' => trim($param['node_mark'], "/\\ \t\n\r\0\x0B"),
                'node_sort' => (int)$param['node_sort'],
                'node_position' => trim($param['node_position'], "/\\ \t\n\r\0\x0B"),
                'create_time' => time(),
            ];
            if (!empty($param['id'])) {
                $data['node_id'] = (int)$param['id'];
            }
            if (empty($data['node_mark']) && (int)$param['node_position'] === 2) {
                $data['node_mark'] = Common::getInstance()->randStr(12);
            }
            $res = Helper::service('Node')->saveNode($data);
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
        }
    }

    public function edit(): bool
    {
        $id = (int)$this->get('id');
        $res = Db::name('node')->where(['node_id' => $id])->find();
        if (!$res) {
            return Helper::responseJson(['error' => '未找到数据']);
        }
        $arr = Db::name('node')->select()->toArray();
        $data = Common::getInstance()->tree($arr, 0, 0, $result, 'node_id', 'node_pid', 'node_name');
        $this->assign(['edit' => $res, 'data' => $data]);
        $this->fetch();
        return false;
    }

    public function update(): ?bool
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $field = $param['field'] ?? 'node_status';
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $res = Helper::service('Node')->saveNode([
                $field => $value,
                'node_id' => $id
            ]);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
        }
        return false;
    }

    public function delete(): ?bool
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $id_arr = explode(',', $id);
            $x = [];
            $msg = "";
            foreach ($id_arr as $k => $v) {
                $res = Db::name('node')->where(['node_pid' => $id])->find();
                if (!$res) {
                    $x[] = $v;
                } else {
                    $msg = " id为《{$v}》存在子级删除失败";
                }
            }
            $res = Helper::service('Node')->deleteNode($x);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败' . $msg, 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
        }
        return false;
    }


}