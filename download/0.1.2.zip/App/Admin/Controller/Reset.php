<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;


use EasySwoole\EasySwoole\Task\TaskManager;
use rayswoole\Helper;
use rayswoole\utils\File;

class Reset extends Base
{


    public function clear(): bool
    {
        if ($this->isPost()) {
            TaskManager::getInstance()->async(function (){
                File::cleanDirectory(RAY_ROOT.'/Runtime/Cache/cookie');
                File::cleanDirectory(RAY_ROOT.'/Runtime/Cache/tmp');
                File::cleanDirectory(RAY_ROOT.'/Runtime/Template');
            });
            sleep(3);
            return Helper::responseJson(['code' => 0, 'msg' => '清除', 'url' => Helper::url('index/index')]);
        }
        return false;
    }

    public function restart(): bool
    {
        if ($this->isPost()) {
            $this->reboot(5);
            sleep(3);
            return Helper::responseJson(['code' => 0, 'msg' => '重启成功', 'url' => Helper::url('admin@index/index')]);
        }
        return false;
    }


}