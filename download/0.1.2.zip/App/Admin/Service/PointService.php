<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Service;

use rayswoole\Service;
use rayswoole\orm\facade\Db;

class PointService extends Service
{

    //获取数据
    public function getData(array $param): array
    {

        $page = isset($param['page']) ? (int)$param['page'] : 1;
        $limit = isset($param['limit']) ? (int)$param['limit'] : 10;
        $where = [];

        $order = 'point_id';
        if (isset($param['key'])) {
            $key = $param['key'];
            if (isset($key['searchName']) && $key['searchName']) {
                $v = $key['searchName'];
                $where[] = ['point_name', 'like',"%{$v}%"];
            }
        }
        //$res = $this->getList($where, $order, 'ASC', '*', $page, $limit);
        $res = Db::name('user_point')
            ->where($where)
            ->order($order,'ASC')
            ->limit($limit * ($page - 1),$limit)
            ->select()->toArray();
        return [
            'code' => 0,
            'msg' => '积分列表',
            'count' => count($res),
            'data' => $res
        ];
    }


    /*
     * [save 保存数据]
     * @param array $data
     * @return bool
     * @author C.
     * @date 2020/1/17 下午5:24
     */
    public function savePoint(array $param):array
    {
        $data = [
            "point_name" => htmlspecialchars($param['point_name']),
            "point_scale" => htmlspecialchars($param['point_scale']),
            "point_status" => isset($param['point_status']) ? 1 : 0,
        ];
        if(!empty($param['edit_id'])){
            $data['point_id']=$param['edit_id'];
        }
        $res = Db::name('user_point')->save($data);

        return [
            'code' => 0,
            'msg' => '添加成功',
            'result' => $res,
        ];
    }




}