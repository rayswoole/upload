<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Art\Controller\Admin;

use App\Admin\Controller\Base;
use App\Art\Extend\Common;
use App\Art\Extend\Upload;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Column extends Base
{

    public function index(): void
    {
        $this->fetch();
    }


    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $where = [];
            if (!empty($param['key']) && !empty($key['searchName'])) {
                $where[] = ['vod_title', 'like', "%{$key['searchName']}%"];
            }
            $where[] = ['type_mid', '=', 2];
            $res = Db::name('type')->where($where)->order('type_sort,type_id','asc')->select();
            $count = Db::name('type')->where($where)->count('*');
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res ? $res->toArray() : [], 'count' => $count]);
        }
    }

    public function create(): void
    {
        $column = Common::getInstance()->tree(Db::name('type')->where('type_mid','=',2)->select()->toArray(), 0, 0, $result);
        $this->assign(['columnList' => $column]);
        $this->fetch();
    }

    public function edit(): bool
    {
        $id = (int)$this->get('id');
        $res = Db::name('type')->where(['type_id' => $id])->find();
        if (!$res) {
            return Helper::responseJson(['msg' => '未找到数据']);
        }
        $column = Common::getInstance()->tree(Db::name('type')->select()->toArray(), 0, 0, $result);
        $this->assign(['edit' => $res, 'columnList' => $column]);
        $this->fetch();
        return false;
    }

    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $validate = Common::getInstance()->checkVar($param, [
                'type_name' => ['alchina:1..255', '标题只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符'],
                'type_sort' => ['number:1..999999999', '排序只能为数字', true],
                'type_status' => ['number:1..4', '状态值只能为数字', true],
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }

            $res = Helper::service('Column','Vod')->columnType();
            array_walk($param, static function (&$v, $k) use (&$res) {
                if (!empty($res[$k])) {
                    $v = in_array($res[$k]['data_type'], ['int', 'tinyint']) ? (int)$v : addslashes(trim($v, "/\\ \t\n\r\0\x0B"));
                }
            });
            $res = Helper::service('Column','Vod')->saveColumn($param);
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
        }
    }


    public function delete()
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            foreach ($data as $v) {
                $res = Db::name('art')->where(['type_id' => $v])->find();
                $child = Db::name('type')->where(['type_pid' => $v])->find();
                if (!empty($res) || !empty($child)) {
                    return Helper::responseJson(['code' => 1, 'msg' => "当前分类{$v}正在使用,或存在子级", 'data' => []]);
                }
            }
            $res = Helper::service('Column','Vod')->deleteColumn($data);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
        }
    }

    public function update()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $field = $param['field'] ?? 'type_status';
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $res = Helper::service('Column','Vod')->saveColumn([
                $field => $value,
                'type_id' => $id
            ]);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
        }
    }


    public function upload(): bool
    {
        $config = [
            'field' => 'column_logo',
            'path' => '/static/upload/column_logo/'
        ];
        $res = Upload::getInstance($this->request())->setConfig($config)->upload();
        return Helper::responseJson(['code' => $res['code'], 'msg' => $res['msg'], 'data' => $res['result']]);
    }
}