<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-13 18:15
 ** ----------------------------------------------------------------------
 **/

namespace App\Art\Controller;


use App\Art\Extend\Common;
use App\Art\Service\TypeService;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;

class Type extends Base
{
    public function index()
    {
        $param = Common::ray_param_url();
        $key = 'html_art@type/index/type_id/'.$param['id'].'/page/'.$param['page'];
        if ($this->siteConfig['art_cache_type'] > 10 && $html = Cache::getInstance()->get($key)){
            return Helper::responseHtml($html);
        }
        if ($param['id'] <= 0 || !$obj = Helper::service('Type','Vod')->get($param['id'])){
            return Helper::responseHtml('分类没有找到');
        }
        $param['type_id'] = $obj['type_id'];
        $this->siteConfig['type_id'] = $obj['type_id'];
        $this->siteConfig['type_pid'] = $obj['type_pid'];
        Context::set('obj',$obj);
        Context::set('param',$param);
        $this->assign([
            'obj' => $obj,
            'param' => $param
        ]);
        $html = $this->fetch('art/type', false);
        if ($this->siteConfig['art_cache_type'] > 10){
            Cache::getInstance()->set($key, $html, $this->siteConfig['art_cache_type']);
        }
        return Helper::responseHtml($html);
    }
}