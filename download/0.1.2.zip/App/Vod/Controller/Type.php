<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-10 16:40
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Controller;


use App\Vod\Extend\Common;
use App\Vod\Service\TypeService;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;

class Type extends Base
{
    public function index()
    {
        $param = Common::ray_param_url();
        $key = 'html_vod@type/index/type_id/'.$param['id'].'/page/'.$param['page'];
        if ($this->siteConfig['vod_cache_type'] > 10 && $html = Cache::getInstance()->get($key)){
            return Helper::responseHtml($html);
        }
        if ($param['id'] <= 0 || !$obj = TypeService::getInstance()->get($param['id'])){
            return Helper::responseHtml('分类没有找到');
        }
        $param['type_id'] = $obj['type_id'];
        $this->siteConfig['type_id'] = $obj['type_id'];
        $this->siteConfig['type_pid'] = $obj['type_pid'];
        Context::set('obj',$obj);
        Context::set('param',$param);
        $this->assign([
            'obj' => $obj,
            'param' => $param
        ]);
        $html = $this->fetch('vod/type', false);
        if ($this->siteConfig['vod_cache_type'] > 10){
            Cache::getInstance()->set($key, $html, $this->siteConfig['vod_cache_type']);
        }
        return Helper::responseHtml($html);
    }
}