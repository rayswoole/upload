<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Vod\Service;

use EasySwoole\EasySwoole\ServerManager;
use EasySwoole\EasySwoole\Task\TaskManager;
use rayswoole\orm\facade\Db;
use rayswoole\Service;
use rayswoole\Helper;
use GuzzleHttp\Client;
use rayswoole\utils\File;

class CollectService extends Service
{

    //分类树
    function ray_list_to_tree($list, $pk = 'id', $pid = 'pid', $child = 'child', $root = 0)
    {
        $tree = array();
        if (is_array($list)) {
            $refer = array();
            foreach ($list as $key => $data) {
                $refer[$data[$pk]] =& $list[$key];
            }

            foreach ($list as $key => $data) {
                $parentId = $data[$pid];

                if ($root == $parentId) {
                    $tree[] =& $list[$key];
                } else {
                    if (isset($refer[$parentId])) {
                        $parent =& $refer[$parentId];
                        $parent[$child][] =& $list[$key];
                    }
                }
            }
        }
        return $tree;
    }


    public function vod($params)
    {
        $param=json_decode($params['param'],true);
        if($param['type'] == '1'){
            return $this->vod_json($params);
        }
        elseif($param['type'] == '2'){
            return $this->vod_xml($params);
        }
        else{
            $data = $this->vod_json($params);

            if($data['code'] == 1){
                return $data;
            }
            else{
                return $this->vod_xml($params);
            }
        }
    }


    public function vod_xml($params,$html='')
    {
        $param=json_decode($params['param'],true);

        //url_param[] 组装处理需要的数据
        $url_param = [];
        $url_param['ac'] = $param['ac'];
        $url_param['pg'] = $params['page'] ?? 0;
        if ($url_param['pg'] <= 0) {
            $url_param['pg'] = $param['pg'] ?? 1;
        }

        $url_param['h']   = $param['h'];
        $url_param['ids'] = $param['ids'] ?? '';
        $url_param['wd']  = isset($param['wd']) ? trim($param['wd']) : '';
        $url_param['t']   = $param['t'] ?? ''; //分类筛选
        if(empty($param['h']) && !empty($param['rday'])){
            $url_param['h'] = $param['rday'];
        }

        if($param['ac']!='list'){
            $url_param['ac'] = 'videolist';
        }

        $url = $param['cjurl'];
        if(strpos($url,'?')===false){
            $url .='?';
        }
        else{
            $url .='&';
        }
        //返回一个 URL 编码后的字符串
        $url .= http_build_query($url_param);

        $response = Helper::simpleGet($url);
        if ($response['code'] !== 200){
            return ['code'=>1001, 'msg'=>$response['body']];
        }
        $data = $response['body']; unset($response);

        //XML 字符串转为 SimpleXMLElement 对象。
        try {
            $xml = simplexml_load_string($data, 'SimpleXMLElement', LIBXML_NOERROR | LIBXML_NOCDATA);
        } catch (\Throwable $throwable) {
            $xml = false;
        }

        if(empty($xml)) {
            return ['code' => 1002, 'msg' => 'XML格式不正确，不支持采集'];
        }

        //翻页属性
        $array_page = [];
        $array_page['url']       = $url;
        $array_page['page']      = (string)$xml->list->attributes()->page;
        $array_page['pagecount'] = (string)$xml->list->attributes()->pagecount;
        $array_page['pagesize']  = (string)$xml->list->attributes()->pagesize;

        //视频数据
        $key = 0;
        $array_data = [];
        //查询出该接口下已绑定的分类数据
        $where[]=['type_key','like',"%{$param['cjflag']}%"];
        $bind_list=Db::name('vod_collect_type')->where($where)->column('type_value','type_key');

        foreach ($xml->list->video as $video)
        {
            $bind_key = $param['cjflag'] .'_'.(string)$video->tid;//视频分类

            //绑定分类
            if(isset($bind_list[$bind_key])){
                $array_data[$key]['type_id'] = $bind_list[$bind_key];
            }else{
                $array_data[$key]['type_id'] = 0;
            }
            $array_data[$key]['vod_id']      = (string)$video->id;
            $array_data[$key]['vod_name']    = (string)$video->name;
            $array_data[$key]['vod_remarks'] = (string)$video->note;
            $array_data[$key]['type_name']   = (string)$video->type;
            $array_data[$key]['vod_class']   = (string)$video->type;
            $array_data[$key]['vod_pic']     = (string)$video->pic;
            $array_data[$key]['vod_lang']    = (string)$video->lang;
            $array_data[$key]['vod_area']    = (string)$video->area;
            $array_data[$key]['vod_year']    = (string)$video->year;
            $array_data[$key]['vod_serial']  = (string)$video->state;
            $array_data[$key]['vod_actor']   = (string)$video->actor;
            $array_data[$key]['vod_director']= (string)$video->director;
            $array_data[$key]['vod_content'] = (string)$video->des;

            $array_data[$key]['vod_status'] = 1;
            $array_data[$key]['vod_time']   = (string)$video->last;
            $array_data[$key]['vod_total']  = 0;
            //$array_data[$key]['vod_isend'] = 1;
            if($array_data[$key]['vod_serial']){
                $array_data[$key]['vod_isend'] = 0;
            }
            //videolist|list播放列表不同
            $count=0;
            if($video->dl->dd){
                $count=count($video->dl->dd);
                if ($count < 1) {
                    continue;
                }
            }
            $array_from = [];
            $array_server = [];
            $array_url = [];
            if($count>0){
                for($i=0; $i<$count; $i++){
                    $array_from[$i]   = (string)$video->dl->dd[$i]['flag'];
                    $array_url[$i]    = $this->vod_xml_replace((string)$video->dl->dd[$i]);
                    $array_server[$i] = 'no';
                    $array_note[$i]   = '';
                }
                $array_data[$key]['vod_play_from']   = implode('$$$', $array_from);
                $array_data[$key]['vod_play_server'] = implode('$$$', $array_server);
                $array_data[$key]['vod_play_url']    = implode('$$$', $array_url);
            }else{
                $array_data[$key]['vod_play_from']   = (string)$video->dt;
            }

            $key++;
        }
        $array_type = [];
        $key=0;

        //分类列表
        if($xml->class->ty){
            foreach($xml->class->ty as $ty){
                $array_type[$key]['type_id']    = (string)$ty->attributes()->id;
                $array_type[$key]['type_name']  = (string)$ty;
                $key++;
            }
        }

        return ['code'=>1, 'msg'=>'xml', 'count'=>$array_page['pagecount'],'type'=>$array_type,'pagecount'=>$array_page['pagecount'],  'list'=>$array_data ];

    }

    /**
     * @param $url
     * @return string
     */
    public function vod_xml_replace($url)
    {
        $array_url = array();
        $arr_ji = explode('#',str_replace('||','//',$url));
        foreach($arr_ji as $key=>$value){
            $urlji = explode('$',$value);
            if( count($urlji) > 1 ){
                $array_url[$key] = $urlji[0].'$'.trim($urlji[1]);
            }else{
                $array_url[$key] = trim($urlji[0]);
            }
        }
        return implode('#',$array_url);
    }

    /**
     * @param $params
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     * @author zhou
     * @time 2020/10/10
     */
    public function vod_json($params){
        $param = json_decode($params['param'],true);

        $url_param = [];
        $url_param['pg']  = $params['pg'] ?? 1;
        $url_param['ac']  = $param['ac'] ?? 'videolist';
        $url_param['h']   = $param['h'] ?? '';
        $url_param['t']   = $param['t'] ?? '';
        $url_param['ids'] = $param['ids'] ?? '';
        $url_param['wd']  = $param['wd'] ?? '';

        $url = $param['cjurl'];
        if(strpos($url,'?')===false){
            $url .='?';
        }
        else{
            $url .='&';
        }

        $url .= http_build_query($url_param);

        $response = Helper::simpleGet($url);
        if ($response['code'] !== 200){
            return ['code'=>1001, 'msg'=>$response['body']];
        }
        $json = json_decode($response['body'],true); unset($response);
        if(!$json){
            return ['code'=>1002, 'msg'=>'JSON格式不正确，不支持采集'];
        }

        $array_page              = [];
        $array_page['page']      = $json['page'];
        $array_page['pagecount'] = $json['pagecount'];
        $array_page['pagesize']  = $json['limit'];
        $array_page['recordcount'] = $json['total'];
        $array_page['url']       = $url;

        //绑定分类数据
        $where[]=['type_key', 'like',"%{$param['cjflag']}%"];
        $bind_list=Db::name("vod_collect_type")->where($where)->column('type_value','type_key');
        $key = 0;
        $array_data = [];
        foreach($json['list'] as $key=>$v){
            $array_data[$key] = $v;
            $bind_key = $param['cjflag'] .'_'.$v['type_id'];

            if(isset($bind_list[$bind_key])){
                $array_data[$key]['type_id'] = $bind_list[$bind_key];
            }
            else{
                $array_data[$key]['type_id'] = 0;
            }

            if(!empty($v['dl'])) {
                //格式化地址与播放器
                $array_from = [];
                $array_url = [];
                $array_server = [];
                //videolist|list播放列表不同
                foreach ($v['dl'] as $k2 => $v2) {
                    $array_from[] = $k2;
                    $array_url[] = $v2;
                    $array_server[] = 'no';
                }

                //格式化地址与播放器
                if(!empty($array_from)) {
                    $array_data[$key]['vod_play_from']   = implode('$$$', $array_from);
                    $array_data[$key]['vod_play_server'] = implode('$$$', $array_server);
                    $array_data[$key]['vod_play_url']    = implode('$$$', $array_url);
                }
                else{
                    $array_data[$key]['vod_play_from']   = '';
                    $array_data[$key]['vod_play_server'] = '';
                    $array_data[$key]['vod_play_url']    = '';
                }
            }
        }

        $array_type = [];
        $key=0;
        //分类列表
        if($param['ac'] == 'list'){
            foreach($json['class'] as $k=>$v){
                $array_type[$key]['type_id'] = $v['type_id'];
                $array_type[$key]['type_name'] = $v['type_name'];
                $key++;
            }
        }
        $res = ['code'=>1, 'msg'=>'json', 'count'=>$array_page['recordcount'],'pagecount'=>$array_page['pagecount'], 'type'=>$array_type, 'list'=>$array_data ];
        return $res;

    }

    /**
     * @param $data
     * @param $cjflag
     * @param $pg
     * @param int $save_pic
     * @return array
     * @throws \EasySwoole\ORM\Exception\Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/8/1
     */
    public function vod_data($data,$cjflag,$pg,$save_pic)
    {
        //下载图片保留目录
        $path = '/static/upload/vod/image/';
        $date = date("Y-m-d", time());
        $dir = RAY_ROOT . '/Public' . $path . $date . '/';
        //$pic_dir = $path.$date;

        $pagecount=$data['count'] ?? $data['pagecount'];
        foreach($data['list'] as $k=>$v){
            if($v['type_id']==0){
                $des = '<font color="red">分类未绑定，跳过err</font>';
            }
            elseif(empty($v['vod_name'])) {
                $des = '<font color="red">数据不完整，跳过err</font>';
            }
            else{
                unset($v['vod_id']);
                //处理演员名 和值
                $actor = $this->actorReplace($v['vod_actor']);

                $d['type_id']     = trim($v['type_id']);
                $d['vod_title']   = trim($v['vod_name']);
                $d['vod_letter']  = $this->getFirstChar(mb_substr($v['vod_name'],0,1,'utf-8'));
                $d['vod_addtime'] = time();
                $d['vod_lang']    = $v['vod_lang'];
                $d['vod_total']   = $v['vod_total'];
                $d['vod_area']    = $v['vod_area'];
                $d['vod_year']    = $v['vod_year'];
                $d['vod_class']   = $v['type_name'];
                $d['vod_remarks'] = $v['vod_remarks'];
                $d['vod_serial']  = trim(isset($v['vod_serial']) ? $v['vod_serial'] :"" );
                $d['vod_actor']   = $actor['actor'];
                $d['vod_actor_val']= $actor['actor_val'];
                $d['vod_director'] = trim($v['vod_director']);
                $d['vod_content']  = $v['vod_content'];
                $d['vod_addtime']  = time();
                $d['vod_status']   = trim(isset($v['vod_status']) ? $v['vod_status'] :1 );
                $d['vod_play_from']= trim($v['vod_play_from']);
                $d['vod_play_url'] = trim($v['vod_play_url']);
                /*$d['vod_hits']     = rand(100,500);
                $d['vod_hits_day'] = rand(0,50);
                $d['vod_hits_week']=  rand(50,100);
                $d['vod_hits_month'] = rand(150,300);*/
                $d['vod_hits']     = 0;
                $d['vod_hits_day'] = 0;
                $d['vod_hits_week']=  0;
                $d['vod_hits_month'] = 0;
                $d['vod_pic'] = trim($v['vod_pic']);

                $where = [];
                $where['vod_title'] = $d['vod_title'];

                //查询是否采集过 没有直接入库   数据库存在比对url是否一样  不一样则更新
                $info=Db::name("vod")->where($where)->find();
                if(!$info){
                    $result=VodService::getInstance()->saveVod($d);
                    $des = '<font color="green">新加入库，成功ok</font>';
                    if($result['code']==0 && $save_pic==1){
                        $result['pic']=$d['vod_pic'];
                        $result['dir']=$dir;
                        $result['path']=$path;
                        //异步保存图片
                         $this->imageAsync($result);
                    }

                }else{
                    $db_vod_play_from = explode('$$$', $info['vod_play_from']);
                    $db_vod_play_url = explode('$$$', $info['vod_play_url']);
                    $remote_vod_play_from = explode('$$$', $d['vod_play_from']);
                    $remote_vod_play_url = explode('$$$', $d['vod_play_url']);
                    $changeTime = false;
                    foreach ($remote_vod_play_from as $key=>$remote_from){
                        $index = array_search($remote_from, $db_vod_play_from);
                        if ($index === false){
                            $db_vod_play_from[] = $remote_vod_play_from[$key];
                            $db_vod_play_url[] = $remote_vod_play_url[$key];
                            $changeTime = true;
                        } else {
                            if (count(explode('#',$db_vod_play_url[$index])) !== count(explode('#',$remote_vod_play_url[$key]))) {
                                $changeTime = true;
                            }
                            $db_vod_play_from[$index] = $remote_vod_play_from[$key];
                            $db_vod_play_url[$index] = $remote_vod_play_url[$key];
                        }
                    }
                    $info['vod_serial'] = $this->getUrlMax($db_vod_play_url);
                    $info['vod_remarks'] = $d['vod_remarks'];
                    $info['vod_play_from'] = implode('$$$',$db_vod_play_from);
                    $info['vod_play_url'] = implode('$$$',$db_vod_play_url);
                    if ($changeTime){
                        $info['vod_addtime'] = time();
                    }
                    VodService::getInstance()->saveVod($info);
                    $des = '<font color="green">更新入库，成功ok</font>';
                }
            }

            $msg[$k]= ($k + 1) .'、'. $v['vod_name'] . "<font>" .$des .'</font>'.'' ;
        }

        if($pg>$pagecount){
            $des = '<font color="blue">数据采集完成</font>';
            array_push($msg,$des);
        }
        return ['msg'=>$msg];

    }

    //异步处理采集图片
    function imageAsync(array $arr)
    {
        TaskManager::getInstance()->async(function () use ($arr){
            usleep(3000);
            $res=$this->getImage($arr);
            if($res['error']!=1){
                Db::name('vod')->where(['vod_id'=>$arr['result']['id']])->update(['vod_pic'=>$res['save_path']]);
            }

        });
    }


    /**
     * @param $arr
     * @return array
     * @author zhou
     * @time 2020/12/18
     */
    function getImage($arr){
        $url     =$arr['pic'];
        $save_dir=$arr['dir'];
        $save_path=$arr['path'].date('Y-m-d',time())."/";
        if(trim($url)==''){
            return array('file_name'=>'','save_path'=>'','error'=>1);
        }

        if(!File::createDirectory($save_dir)){
            return array('file_name'=>'','save_path'=>'','error'=>5);
        }
        $ext=strrchr($url,'.');
        $filename = uniqid().$ext;

        $response = Helper::simpleGet($url, 10, $save_dir.$filename);
        if ($response['code'] == 200){
            return array('file_name'=>$filename,'save_path'=>$save_path.$filename,'error'=>0);
        } else {
            return array('error'=>1);
        }
    }

    /**
     * 处理演员名字
     * @param $string
     * @return mixed
     * @author zhou
     * @time 2020/8/1
     */
    public function actorReplace($string)
    {
        $string=htmlspecialchars($string);
        //替换成用，分割的字符串
        if (strpos($string,'/')) {
            $string=str_replace('/',',',$string);
        } else if (strpos($string,'|')){
            $string=str_replace('|',',',$string);
        }else if (strpos($string,'-')){
            $string=str_replace('-',',',$string);
        }else if (strpos($string,' ')){
            $string=str_replace(' ',',',$string);
        }else{
            $string;
        }
        //做成数组 组合成vod_actor_val
        $actor=explode(',',$string);
        $num=-1;
        for($i=0;$i<count($actor);$i++){
            $actor_val_arr[]=$num--;
        }
        $actor_val=implode(',',$actor_val_arr);

        return $data=[
            'actor'=>$string,
            'actor_val'=>$actor_val
        ];

    }

    /**
     * 获取汉字首字母
     * @param $str
     * @return string
     * @author zhou
     * @time 2020/8/1
     */
    function getFirstChar($str) {

        if (empty($str)) {
            return '';
        }

        $fir = $fchar = ord($str[0]);
        if ($fchar >= ord('A') && $fchar <= ord('z')) {
            return strtoupper($str[0]);
        }

        $s = mb_convert_encoding($str,"gb2312",'UTF-8');

        if (!isset($s[0]) || !isset($s[1])) {
            return '';
        }
        $asc = ord($s[0]) * 256 + ord($s[1]) - 65536;

        if (is_numeric($str)) {
            return $str;
        }

        if (($asc >= -20319 && $asc <= -20284) || $fir == 'A') {
            return 'A';
        }
        if (($asc >= -20283 && $asc <= -19776) || $fir == 'B') {
            return 'B';
        }
        if (($asc >= -19775 && $asc <= -19219) || $fir == 'C') {
            return 'C';
        }
        if (($asc >= -19218 && $asc <= -18711) || $fir == 'D') {
            return 'D';
        }
        if (($asc >= -18710 && $asc <= -18527) || $fir == 'E') {
            return 'E';
        }
        if (($asc >= -18526 && $asc <= -18240) || $fir == 'F') {
            return 'F';
        }
        if (($asc >= -18239 && $asc <= -17923) || $fir == 'G') {
            return 'G';
        }
        if (($asc >= -17922 && $asc <= -17418) || $fir == 'H') {
            return 'H';
        }
        if (($asc >= -17417 && $asc <= -16475) || $fir == 'J') {
            return 'J';
        }
        if (($asc >= -16474 && $asc <= -16213) || $fir == 'K') {
            return 'K';
        }
        if (($asc >= -16212 && $asc <= -15641) || $fir == 'L') {
            return 'L';
        }
        if (($asc >= -15640 && $asc <= -15166) || $fir == 'M') {
            return 'M';
        }
        if (($asc >= -15165 && $asc <= -14923) || $fir == 'N') {
            return 'N';
        }
        if (($asc >= -14922 && $asc <= -14915) || $fir == 'O') {
            return 'O';
        }
        if (($asc >= -14914 && $asc <= -14631) || $fir == 'P') {
            return 'P';
        }
        if (($asc >= -14630 && $asc <= -14150) || $fir == 'Q') {
            return 'Q';
        }
        if (($asc >= -14149 && $asc <= -14091) || $fir == 'R') {
            return 'R';
        }
        if (($asc >= -14090 && $asc <= -13319) || $fir == 'S') {
            return 'S';
        }
        if (($asc >= -13318 && $asc <= -12839) || $fir == 'T') {
            return 'T';
        }
        if (($asc >= -12838 && $asc <= -12557) || $fir == 'W') {
            return 'W';
        }
        if (($asc >= -12556 && $asc <= -11848) || $fir == 'X') {
            return 'X';
        }
        if (($asc >= -11847 && $asc <= -11056) || $fir == 'Y') {
            return 'Y';
        }
        if (($asc >= -11055 && $asc <= -10247) || $fir == 'Z') {
            return 'Z';
        }

        return '';
    }

    /**
     * 获取数量最大的子集
     * @param $array
     * @return int|mixed
     */
    function getUrlMax($array)
    {
        $max = 0;
        for ($i = 0; $i<count($array); $i++) {
            if (is_array($array[$i])){
                $max = max($max, count(explode('#',$array[$i])));
            }
        }
        return $max;
    }

}