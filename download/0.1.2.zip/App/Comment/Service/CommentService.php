<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Comment\Service;


use App\Comment\Model\CommentModel;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class CommentService extends Service
{

    public function commentList($where, $order = "comment_id asc", $page = 0, $limit = 20): array
    {
        $model = new CommentModel();
        if ($page > 0) {
            $data = $model->with('user')->where($where)->order($order)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->with('user')->where($where)->order($order)->select()->toArray();
        }

        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    public function columnType(): array
    {
        return Db::table('information_schema.columns')
            ->where('table_name', 'ray_comment')
            ->column('column_name,data_type', 'column_name');
    }

    public function getComment($where): array
    {
        $model = new CommentModel();
        if ($res = $model->with('user')->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    public function saveComment(array $data): bool
    {
        $model = new CommentModel();
        if (!empty($data['comment_id'])) {
            $model = $model->find($data['comment_id']);
        }
        return $model->save($data);
    }

    public function deleteComment($data): bool
    {
        return CommentModel::destroy($data);
    }

    public function viewComment($data): array
    {
        $msg_limit = isset($data['msg_limit']) ? (int)$data['msg_limit'] : 3;
        $msg_page = isset($data['msg_page']) ? (int)$data['msg_page'] : 1;
        $reply_limit = isset($data['reply_limit']) ? (int)$data['reply_limit'] : 3;
        $reply_page = isset($data['reply_page']) ? (int)$data['reply_page'] : 1;
        $where = [
            'c.comment_status' => 1,
            'c.comment_pid' => 0,
            'c.comment_mid' => (int)$data['comment_mid'],
            'c.comment_rid' => (int)$data['comment_rid'],
            //'c.site_id' => (int)$data['comment_sid'],
        ];

        if (!empty($data['comment_id'])) {
            $where['c.comment_id'] = (int)$data['comment_id'];
        }
        $order = 'comment_addtime';
        $resModel = Db::getInstance()->table('ray_comment')->alias('c')->field('c.*,u.user_name')
            ->join('ray_user u', 'c.user_id = u.user_id', 'left')
            ->where($where)
            ->order($order, 'desc');

        if (!empty($msg_page) || !empty($msg_limit)) {
            $resModel->page($msg_page, $msg_limit);
        }
        $res = $resModel->select()->toArray();
        foreach ($res as $k => $v) {
            $w = [
                'comment_pid' => $v['comment_id'],
                'comment_status' => 1,
                'comment_level' => 2,
                'comment_mid' => (int)$data['comment_mid'],
                'comment_rid' => (int)$data['comment_rid'],
            ];
            $replyModel = Db::getInstance()->table('ray_comment')->alias('c')->field('c.*,u.user_name')
                ->join('ray_user u', 'c.user_id = u.user_id', 'left')
                ->order($order, 'asc');
            if (!empty($data['comment_id'])) {
                $w['comment_pid'] = (int)$data['comment_id'];
                $replyModel->page($reply_page, $reply_limit);
            } else {
                $replyModel->limit($reply_limit);
            }
            $reply_res = $replyModel->where($w)->select()->toArray();
            $reply_count = Db::getInstance()->table('ray_comment')->where($w)->count();
            foreach ($reply_res as $reply_k => $reply_v) {
                $reply_res[$reply_k]['reply_name'] = empty($reply = $this->getReplyName($reply_v['comment_reply_cid'])) ? '无' : ($reply['user_name'] ?: '系统');;
            }
            $res[$k]['reply'] = $reply_res;
            $res[$k]['reply_count'] = $reply_count;
        }
        return [
            'code' => 0,
            'msg' => '评论数据',
            'count' => 0,
            'data' => $res
        ];
    }

    public function getReplyName($cid)
    {
        $res = Db::name('comment')->alias('c')->field('c.*,u.user_name')
            ->join('ray_user u', 'c.user_id = u.user_id', 'left')
            ->column('*','comment_id');
        return $res[$cid] ?? '';
    }

    public function replyComment($data): array
    {
        $model = new CommentModel();
        if (!empty($data['reply'])) {
            $data['comment_pid'] = (int)$data['comment_id'];
            $data['comment_level'] = 2;
            $data['comment_reply_cid'] = (int)$data['comment_pid'];
            unset($data['comment_id']);
        }
        $res =  $model->save($data);
        if ($res) {
            $data['comment_id'] = $model->comment_id;
            $data['username'] = Helper::service('User','User')->getUser(['user_id'=>$data['user_id']])['user_name'] ?: '';
            return ['code' => 0, 'msg' => '保存成功', 'data' => $data];
        }
        return ['code' => 1, 'msg' => '保存失败', 'data' => []];

    }
}