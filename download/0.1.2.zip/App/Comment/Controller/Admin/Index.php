<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Comment\Controller\Admin;

use App\Admin\Controller\Base;
use App\Comment\Model\CommentModel;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Index extends Base
{

    public function index(): void
    {
        $this->fetch();
    }

    public function read(): bool
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            $order = 'comment_id';
            if (!empty($param['key'])) {
                $key = $param['key'];
                if (!empty($key['comment_mid'])) {
                    $where[] = ['comment_mid', '=', (int)$key['comment_mid']];
                }
                if (!empty($key['comment_level'])) {
                    $where[] = ['comment_level', '=', (int)$key['comment_level']];
                }
                $where[] = ['comment_status', '=', isset($key['comment_status']) ? 1 : 0];
            }
            $res = CommentModel::with(['user'])->where($where)->order($order)->page($page, $limit)->select()->toArray();
            $count = CommentModel::hasWhere('user', 'user_name is not null')->where($where)->count('*');
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => $count]);
        }
        return false;
    }

    public function show(): void
    {
        $id = (int)$this->get('id');
        $info = CommentModel::with('user')->where([
            'comment_id' => $id
        ])->find();
        if ($info && $info['comment_level'] !== 1) {
            $info['parent'] =  CommentModel::with('user')->where([
                'comment_id' => $info['comment_reply_cid']
            ])->find();
        }
        $this->assign(['comment' => $info]);
        $this->fetch();
    }

    public function reply(): bool
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $comment = json_decode($param['comment'], true);
            $data = [
                'user_id' => 0,
                'comment_pid' => (int)$comment['comment_pid'] === 0 ? (int)$comment['comment_id'] : (int)$comment['comment_pid'],
                'comment_mid' => (int)$comment['comment_mid'],
                'comment_rid' => (int)$comment['comment_rid'],
                'site_id' => (int)$comment['site_id'], // todo site_id
                'comment_content' => trim(htmlspecialchars($param['comment_content'])),
                'comment_status' => (int)$comment['comment_status'],
                'comment_level' => 2,
                'comment_reply_cid' => (int)$comment['user_id'] === 0 ? (int)$param['p_cid'] : (int)$comment['comment_id'],
                'comment_addtime' => time(),
            ];
            $res = Helper::service('Comment')->saveComment($data);
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
        }
        return false;
    }

    public function delete(): bool
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res = Helper::service('Comment')->deleteComment($data);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
        }
        return false;
    }

}