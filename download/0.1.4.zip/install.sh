root_path=$(pwd)
domain=$1
config_file=/www/server/panel/vhost/nginx/${domain}.conf
php_version=$(cat $config_file|grep 'enable-php'|grep -Eo "[0-9]+"|head -n 1)
PHP_EXT_DIR=`/www/server/php/${php_version}/bin/php -i | grep "^extension_dir" | awk '{ print $3"/" }'`;

#切换PHP命令行版本
php_bin='/usr/bin/php'
php_bin_src="/www/server/php/${php_version}/bin/php"
php_ize='/usr/bin/phpize'
php_ize_src="/www/server/php/${php_version}/bin/phpize"
php_fpm='/usr/bin/php-fpm'
php_fpm_src="/www/server/php/${php_version}/sbin/php-fpm"
php_pecl='/usr/bin/pecl'
php_pecl_src="/www/server/php/${php_version}/bin/pecl"
php_pear='/usr/bin/pear'
php_pear_src="/www/server/php/${php_version}/bin/pear"
isChattr=$(lsattr /usr|grep /usr/bin  | head -n 1)
# shellcheck disable=SC2046
if [[ $isChattr =~ '-i-' ]]; then
    chattr -i /usr/bin
fi
rm -f $php_bin $php_ize $php_fpm $php_pecl $php_pear
ln -sf "$php_bin_src" "$php_bin"
ln -sf "$php_ize_src" "$php_ize"
ln -sf "$php_fpm_src" "$php_fpm"
ln -sf "$php_pecl_src" "$php_pecl"
ln -sf "$php_pear_src" "$php_pear"
if [[ $isChattr =~ '-i-' ]]; then
    chattr +i /usr/bin
fi

#安装PHP扩展
if [ ! -f "${PHP_EXT_DIR}opcache.so" ]; then
  cd /www/server/panel/install
  bash install_soft.sh 3 install opcache 72
fi
if [ ! -f "${PHP_EXT_DIR}swoole.so" ]; then
  cd /www/server/panel/install
  bash install_soft.sh 3 install swoole4 72
fi
cd $root_path

#接触shell_exec函数禁用
sed -i 's/,shell_exec//g' /www/server/php/${php_version}/etc/php.ini
/etc/init.d/php-fpm-${php_version} reload

#安装并配置守护程序
if [ ! -d /www/server/panel/plugin/supervisor ]; then
  mkdir "/www/server/panel/plugin/supervisor"
  wget https://ray7.cc/sh/bt.supervisor.install.sh -O /www/server/panel/plugin/supervisor/install.sh --no-check-certificate
  sh /www/server/panel/plugin/supervisor/install.sh install
fi

if [ -e '/www/server/panel/pyenv/' ]; then
  supervisorctl='/www/server/panel/pyenv/bin/supervisorctl'
else
  supervisorctl='supervisorctl'
fi

proname=$(head /dev/urandom |cksum |md5sum |cut -c 1-4)
cat >/www/server/panel/plugin/supervisor/profile/ray_${proname}.ini<<EOF
[program:ray_${proname}]
command=/www/server/php/${php_version}/bin/php rayswoole start
directory=${root_path}
autorestart=true
startsecs=3
startretries=3
stdout_logfile=/www/server/panel/plugin/supervisor/log/ray_${proname}.out.log
stderr_logfile=/www/server/panel/plugin/supervisor/log/ray_${proname}.err.log
stdout_logfile_maxbytes=2MB
stderr_logfile_maxbytes=2MB
user=www
priority=999
numprocs=1
EOF

$supervisorctl update
$supervisorctl start ray_$proname

