<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Controller\Admin;

use App\Admin\Controller\Base;
use App\Vod\Service\VodService;
use rayswoole\orm\facade\Db;
use App\Admin\Service\ConfigService;
use rayswoole\Helper;
use rayswoole\Service;

class UrlSend extends Base
{

    public function index()
    {
        if ($this->isPost()) {
            $data = $this->post('config');
            $data = array_map(function ($value) {
                return trim($value);
            }, $data);
            ConfigService::getInstance()->update('site', $data);
            $this->reload();
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功,请点击右上角 “重启服务” ', 'data' => []]);
        } else {
            $data = ConfigService::getInstance()->get('site') ?? [];
            $this->assign($data);
            $this->fetch();
        }

    }


//百度推送
    public function baidu_push()
    {
        $param=$this->get();
        $db=DB::name('vod')->field('vod_id,vod_title');
        //查出视频id
        $today = strtotime(date('Y-m-d 00:00:00',time()));
        if($param['ac']=='today'){
            $db->where('vod_addtime','>',$today);
        }
        $limit = 30;
        $page=isset($param['page']) ? $param['page'] : 1;
        $count=$db->count('vod_id');
        $data=$db->limit($page,($page*$limit))->select()->toArray();

        $page_count=ceil($count/$limit);

        //获取域名
        $server=$this->request()->getUri();
        $http_type=$server->getScheme();
        $host=$server->getHost();
        $domain=$http_type.'://'.$host;

        //查出推广token
        $config= ConfigService::getInstance()->get('site') ?? [];
        $token=$config['baidu_push_token']['val'];

        foreach ($data as $key=>$val){
            $urls[]=$domain.Helper::url('vod@detail/index',['id'=>$val['vod_id']]);
            $msg[$key] = ($key+1).",<font color='blue'>".$val["vod_title"]."</font>  ".$domain.Helper::url('vod@detail/index',['id'=>$val['vod_id']]);
        }

        //推送接口
        $api = 'http://data.zz.baidu.com/urls?site='.$domain.'&token='.$token;
        $response = Helper::simpleHttp($api, ['body'=>implode("\n", $urls)], 'POST');
        $body = Helper::deJson($response['body']);
        if ($body['error']) {
            unset($response);
            return Helper::responseHtml('<br><span style="color: red">ERROR:'.$body["message"].'</span>');
        } else {
            unset($response);
        }

        $this->assign(['msg'=>$msg,'page_count'=>$page_count,'page'=>$page,'count'=>$count,'result'=>true,'ac'=>$param['ac']]);
        $this->fetch();
    }

//创建map地图
    public function baidu_map()
    {
        //查询出数据
        $data=DB::name('vod')->field('vod_id,vod_addtime')->order('vod_addtime','desc')->limit(40000)->select()->toArray();

        //获取域名
        $server=$this->request()->getUri();
        $http_type=$server->getScheme();
        $host=$server->getHost();
        $domain=$http_type.'://'.$host;

        $XML = '<?xml version="1.0" encoding="utf-8"?><urlset>';
        foreach ($data as $key=>$val) {
            $url=$domain.Helper::url('vod@detail/index',['id'=>$val['vod_id']]);
            $lastmod=date('Y-m-d H:s:i',$val["vod_addtime"]);
            $XML.='<url>';
                $XML.='<loc>'.$url.'</loc>';
                $XML.='<lastmod>'.$lastmod.'</lastmod>';
                $XML.='<changefreq>daily</changefreq>';
                $XML.='<priority>0.8</priority>';
            $XML.='</url>';
        }
        $XML.='</urlset>';
        $dir=dirname(RAY_ROOT.'/Public/rss/map.xml');
        if(!is_dir($dir)){
            mkdir($dir,0777,true);
        }
        file_put_contents(RAY_ROOT.'/Public/rss/map.xml',$XML);

        $this->assign(['sitemap'=>RAY_ROOT.'/Public/rss/map.xml']);
        $this->fetch();


    }


}