<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-08-07 09:49
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Model;

use rayswoole\orm\Model;
use rayswoole\orm\facade\Db;

class TypeModel extends Model
{
    protected $name = 'type';
    protected $pk = 'type_id';


    public function getDataAll(array $where, string $ordey, string $field = '*'): array
    {
        $res = $this->field($field)
                ->order($ordey, 'DESC')
                ->where($where)
                ->select()
                ->toArray();
        return (array)$res;
    }


    public function typeArray(): ?array
    {
        $list = $this->getDataAll(['type_status' => 1], 'type_id', 'type_id,type_name');
        foreach ($list as $k => $v) {
            $arr[$v['type_id']] = $v['type_name'];
        }
        return $arr;
    }

    /**
     * 影视分类键值对
     * @return array
     */
    public function getKeyVal():?array
    {
        $res = $this->field('type_id,type_name')
            ->where(['type_mid' => 1])
            ->select()
            ->toArray();
        $type_id = array_column($res, 'type_id');
        $type_name = array_column($res, 'type_name');
        $data = array_combine($type_id, $type_name);
        return (array)$data;
    }


    /**
     * 返回子分类 加自身大类
     * @param string $pid
     * @return string
     * @throws \EasySwoole\ORM\Exception\Exception
     * @throws \Throwable
     */
    public function getChildsType($pid = '')
    {
        $where['type_pid'] = $pid;
        $res = $this->field('type_id')
                    ->where($where)
                    ->order('type_id', 'ASC')
                    ->select()->toArray();
        $childs = [];
        if ($res) {
            foreach ($res as $k => $v) {
                $childs[] = $v['type_id'];
            }
        }

        $child = implode(',', $childs);
        return (string)$child;
    }


}