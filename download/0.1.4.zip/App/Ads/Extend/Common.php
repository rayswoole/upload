<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-16 14:43
 ** ----------------------------------------------------------------------
 **/

namespace App\Ads\Extend;

use rayswoole\utils\Validators;

class Common
{

    public static function checkVar(array &$param, array $data): array
    {
        foreach ($data as $k => $v) {
            if (empty($param[$k]) && !is_numeric($param[$k])) {
                if (!($v[2] ?? false)) {
                    return ['status' => false, 'msg' => $v[1]];
                }
                continue;
            }
            if (false === Validators::is($param[$k], $v[0])) {
                return ['status' => false, 'msg' => $v[1]];
            }
        }
        return ['status' => true, 'msg' => '验证通过'];
    }

    /**
     * 网站模板目录
     * @return array
     */
    public static function getDirarr(): array
    {
        $path = EASYSWOOLE_ROOT . '/Public/skin/';
        $temarry = array_diff(scanDir($path), array('..', '.'));
        foreach ($temarry as $k => $v) {
            if (strpos($v, '.') || $v == 'admin') {
                unset($temarry[$k]);
            }
        }
        return (array)$temarry;
    }







}