<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Service;


use App\Admin\Model\ConfigModel;
use rayswoole\Service;

class SystemService extends Service
{

    public function getColumn(): array
    {
        $configModel = new ConfigModel();
        return $configModel->column('*', 'name');
    }


    public function saveSystem(array $data): bool
    {
        $res = (new ConfigModel())->saveAll($data);
        return $res ? true : false;
    }

}