<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Service;


use App\Admin\Model\NodeModel;
use rayswoole\Service;

class NodeService extends Service
{

    public function nodeList($where, $order = "node_id desc", $page = 0, $limit = 20): array
    {
        $model = new NodeModel();
        if ($page > 0) {
            $data = $model->where($where)->order($order)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->where($where)->order($order)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    public function getNode($where): array
    {
        $model = new NodeModel();
        if ($res = $model->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    public function getNodeTree(): ?array
    {
        $model = new NodeModel();
        $this->tree($model->select()->toArray(), 0, 0, $res);
        return $res;
    }

    public function tree($data, $pid, $level, &$res)
    {
        $items = array();
        foreach ($data as $v) {
            $items[$v['node_id']] = $v;
        }
        foreach ($items as $k => $v) {
            if ($v['node_pid'] === $pid) {
                $v['node_name'] = str_repeat(" ├─  ", $level) . $v['node_name'];
                $res[] = $v;
                $this->tree($items, $v['node_id'], $level + 1, $res);
            }
        }
        return $res;
    }

    public function saveNode(array $data): bool
    {
        $model = new NodeModel();
        if (!empty($data['node_id'])) {
            $model = $model->find($data['node_id']);
        }
        return $model->save($data);
    }


    public function deleteNode($data): bool
    {
        return NodeModel::destroy($data);
    }

}