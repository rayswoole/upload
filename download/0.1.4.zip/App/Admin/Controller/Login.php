<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;

use rayswoole\Helper;
use rayswoole\session\Session;

class Login extends Base
{

    public function index(): void
    {
        $this->fetch();
    }


    public function verify(): void
    {
    }

    public function check(): bool
    {
        if ($this->isAjax()) {
            $username = $this->post('username', '', 'required|alchina:1..50');
            $password = $this->post('password', '', 'required:6..50');
            $res = Helper::service('Admin')->login($username, $password);
            return Helper::responseJson($res);
        }
        return false;
    }

    public function loginout(): bool
    {
        Session::clear();
        return Helper::response()->redirect('login/index');
    }


    public function setpassword(): bool
    {
        if ($this->isAjax()) {
            $password = $this->post('password', '', 'required:6..50');
            $password2 = $this->post('password2', '', 'required:6..50');
            $res = Helper::service('Admin')->checkPwd($password, $password2);
            return Helper::responseJson($res);
        }
        $this->fetch();
        return false;
    }

}