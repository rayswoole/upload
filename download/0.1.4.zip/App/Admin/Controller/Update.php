<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;

use EasySwoole\EasySwoole\Config;
use EasySwoole\Utility\File;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use rayswoole\utils\Str;
use rayswoole\Vars;


class Update extends Base
{

    public function index()
    {
        //当前版本号
        $version=Config::getInstance()->getConf('App_Admin.version');
        //todo center_api
        $centerApi = Vars::get('CENTER_API');
        $response = Helper::simpleGet($centerApi.'index/version/v/'.$version);
        $versions = [];
        if ($response['code'] == 200){
            $versions = Helper::deJson($response['body']);
            $current = [];
            foreach ($versions as $_k=>$_version){
                if ($_version['min'] == $version){
                    $current = $_version;
                    unset($versions[$_k]);
                }
            }
            if (!empty($current)){
                array_unshift($versions, $current);
            }
        }
        $this->assign([
            'version'=>$version,
            'versions'=>$versions
        ]);
        $this->fetch();
    }

    public function upgradeStep1()
    {
        $lockFile = RAY_ROOT.'/Runtime/Tmp/upgrade.lock';
        if (file_exists($lockFile)){
            return Helper::responseJson(['code'=>0, 'body'=>'有尚未完成的升级任务，请先删除/Runtime/Tmp/upgrade.lock文件']);
        }
        $lockContent = uniqid();
        file_put_contents($lockFile, $lockContent);

        $downUrl = $this->get('downurl');
        $tmpFile = RAY_ROOT.'/Runtime/Tmp/upgrade.zip';
        if (file_exists($tmpFile)){
            unlink($tmpFile);
        }
        $data = Helper::simpleGet($downUrl, 30, $tmpFile);
        $data['lock'] = $lockContent;
        return Helper::responseJson($data);
    }

    public function upgradeStep2()
    {
        //判断升级锁是否由当前升级流程持有
        $lockFile = RAY_ROOT.'/Runtime/Tmp/upgrade.lock';
        if (!file_exists($lockFile)){
            return Helper::responseJson(['code'=>0,'body'=>'升级锁不存在，中止执行']);
        }
        $lockContent = file_get_contents($lockFile);
        $lock = $this->get('lock');
        if ($lock !== $lockContent) {
            return Helper::responseJson(['code'=>0,'body'=>'升级锁秘钥与传输的秘钥不一致，中止执行']);
        }

        //检测升级包是否存在
        $tmpFile = RAY_ROOT.'/Runtime/Tmp/upgrade.zip';
        if (!file_exists($tmpFile)){
            return Helper::responseJson(['code'=>0,'body'=>'升级包不存在']);
        }
        //检测ZipArchive类是否存在
        if (!class_exists('ZipArchive')){
            return Helper::responseJson(['code'=>0,'body'=>'PHP需要加载zip组件才能继续运行']);
        }
        $version=Config::getInstance()->getConf('App_Admin.version');
        $back_path = RAY_ROOT.'/Backup/update/'.$version;
        //如果是重复升级，先移除原有的备份目录
        if (is_dir($back_path) && !rename($back_path, $back_path.'_'.date('Ymd').'_'.uniqid())){
            return Helper::responseJson(['code'=>0,'body'=>'文件备份目录'.'/Backup/update/'.$version.'/已存在但是移动失败,可能是没有权限']);
        }
        //创建备份目录
        if (!is_dir($back_path) && !File::createDirectory($back_path)){
            return Helper::responseJson(['code'=>0,'body'=>'文件备份目录'.'/Backup/update/'.$version.'/创建失败,可能是没有权限']);
        }
        //打开压缩包
        $zip = new \ZipArchive();
        if ($zip->open($tmpFile) !== true) {
            return Helper::responseJson(['code'=>0,'body'=>'升级包解压失败, 可能是文件不完整']);
        }
        //备份即将覆盖的文件
        for($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            if(is_file(RAY_ROOT.'/'.$filename)){
                File::copyFile(RAY_ROOT.'/'.$filename,$back_path.'/'.$filename);
            }
            //判断是否有 sql
            if(Str::endsWith($filename,'.sql')){
                $installSql = $filename;
            }
        }
        //覆盖解压
        $zip->extractTo(RAY_ROOT);
        //关闭压缩包
        $zip->close();
        //如果有sql 执行sql
        if (isset($installSql) && file_exists($installSql)){
            $fp = fopen($installSql, 'r');
            $sql = '';
            while (!feof($fp)){
                $line = trim(fgets($fp));
                if ($line == '' || strpos($line,'--') === 0){
                    continue;
                }
                if (substr($line, -1) == ';') {
                    try {
                        Db::execute($sql."\n".$line);
                    } catch (\Throwable | \PDOException $exception){
                        $msg = '数据库升级执行失败';
                        break;
                    }
                    $sql = '';
                } else {
                    $sql .= "\n".$line;
                }
            }
            fclose($fp);
        }
        //删除升级锁
        unlink($lockFile);
        return Helper::responseJson(['code'=>200,'body'=>$msg ?? '升级成功，旧文件备份在:'.$back_path]);
    }

    public function upgradestep3()
    {
        $this->reboot();
        return Helper::responseJson(['code'=>0,'body'=>'已经通知服务重启']);
    }

}