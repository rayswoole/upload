<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;

use rayswoole\orm\facade\Db;
use rayswoole\Helper;

class Point extends Base
{

    public function index()
    {
        return $this->fetch();
    }

    /**
     * 读取数据
     * @return bool|null
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/23
     */
    public function read(): ?bool
    {
        if ($this->isAjax()) {
            $param = (array)$this->get();

            $page  = isset($param['page'])  ? (int)$param['page']  : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 10;
            $where = [];

            $order = 'point_id';
            if (isset($param['key'])) {
                $key = $param['key'];
                if (isset($key['searchName']) && $key['searchName']) {
                    $v = $key['searchName'];
                    $where[] = ['point_name', 'like',"%{$v}%"];
                }
            }
            $res = Db::name('user_point')
                ->where($where)
                ->order($order,'ASC')
                ->limit($limit * ($page - 1),$limit)
                ->select()->toArray();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '积分列表',
                'count' => count($res),
                'data' => $res
            ]);
        }
    }

    /**
     * 新增 修改
     * @author zhou
     * @time 2020/7/25
     */
    public function create()
    {
        $param = $this->get();

        $edit_id = isset($param['edit_id']) ? $param['edit_id'] : "";
        if ($edit_id) {
            $where = [
                'point_id' => intval($param['edit_id'])
            ];
            $res = Db::name('user_point')->where($where)->find();
            $this->assign(['data' => $res]);
        } else {
            $this->assign(['data' => '']);
        }
        return $this->fetch();
    }

    /**
     * 删除
     * @return bool
     * @throws \rayswoole\orm\db\exception\DbException
     * @author zhou
     * @time 2020/10/23
     */

    public function delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id = explode(',', $id);
            $res = Db::name('user_point')->delete($id);

            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'result' => $res]);
            } else {
                return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'result' => $res]);
            }
        }
    }

    public function edit(): void
    {

    }

    /**
     * 新增 修改保存
     * @return mixed
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/10/23
     */
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();

            $res = Helper::service('Point')->savePoint($param);

            return Helper::responseJson($res);
        }
    }


    /*
     * [updateField 字段值更新]
     * @method POST
     * @author C.
     * @time 2020/2/3 上午2:18
     */
    public function update_field()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'point_status';

            $where = [
                'point_id' => $id
            ];
            if (is_array($id)) {
                $where = $id;
            }
            $res = Db::name('user_point')->where($where)->update([$field => $value]);

            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '更新失败', 'result' => $res]);
            } else {
                return Helper::responseJson(['code' => 0, 'msg' => '更新成功', 'result' => $res]);
            }
        }

    }
}