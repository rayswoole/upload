<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Art\Controller\Admin;

use App\Admin\Controller\Base;
use App\Art\Extend\Common;
use App\Art\Extend\Upload;
use App\Art\Model\ArticleModel;
use App\Art\Model\ArticleRecycleModel;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Index extends Base
{


    public function index(): void
    {
        $this->fetch('admin/index/index');
    }


    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            $order = 'art_id';
            if (!empty($param['key'])) {
                $key = $param['key'];
                if (!empty($key['art_sort'])) {
                    $order = "art_{$key['art_sort']} desc";
                }
                if (!empty($key['time']) && $t = $this->getTime($key['time'])) {
                    $where[] = ['art_addtime', '>=', $t];
                }
                if (isset($key['art_type']) && $key['art_type']) {
                    $where[] = ['type_id', '=', (int)$key['art_type']];
                }
                if (isset($key['art_star']) && $key['art_star']) {
                    $where[] = ['art_star', '=', (int)$key['art_star']];
                }
                $where[] = ['art_status', '=', isset($key['art_status']) ? 1 : 0];
                if (isset($key['searchName'])) {
                    $where = [];
                    if (!empty($key['searchName'])) {
                        $where[] = ['art_title', 'like', "%{$key['searchName']}%"];
                    }
                }
            }
            //$res = Db::name('art')->where($where)->order($order)->page($page, $limit)->select()->toArray();
            $res=Db::name('art')->alias('a')
                ->leftJoin('type t','a.type_id=t.type_id')
                ->field('a.*,t.type_name')
                ->where($where)
                ->order($order)
                ->page($page, $limit)
                ->select()->toArray();

            $count = Db::name('art')->where($where)->count('*');
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => $count]);
        }
    }

    public function create(): void
    {
        $column = Common::tree(Db::name('art_type')->select()->toArray(), 0, 0, $result);
        $this->assign(['columnList' => $column]);
        $this->fetch('admin/index/create');
    }

    public function edit()
    {
        $id = (int)$this->get('id');
        $res = Db::name('art')->where(['art_id' => $id])->find();
        if (!$res) {
            return Helper::responseJson(['msg' => '未找到数据']);
        }
        $column = Common::tree(Db::name('art_type')->select()->toArray(), 0, 0, $result);
        $this->assign(['edit' => $res, 'columnList' => $column]);
        $this->fetch('admin/index/edit');
    }

    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $validate = Common::checkVar($param, [
                'art_star' => ['number', '推荐参数ID错误', true],
                'art_sub' => ['alchina:1..255', '副标题只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符', true],
                'art_from' => ['alchina:1..255', '来源只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符', true],
                'art_author' => ['alchina:1..255', '作者只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字', true],
                'art_sort' => ['number:1..999999999', '排序只能为数字,且长度不能超出999999999', true],
                'art_jumpurl' => ['url', '条件链接只能为合法URL', true],
                'art_hits' => ['number:1..99999999,且长度不能超出99999999', '总人气只能为数字', true],
                'art_hits_month' => ['number:1..99999999', '月人气只能为数字,且长度不能超出99999999', true],
                'art_hits_week' => ['number:1..99999999', '周人气只能为数字,且长度不能超出99999999', true],
                'art_hits_day' => ['number:1..99999999', '天人气只能为数字,且长度不能超出99999999', true],
                'art_status' => ['number:1..4', '状态值只能为数字', true]
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }
            $res = Helper::service('Article')->columnType();
            array_walk($param, static function (&$v, $k) use (&$res) {
                if (!empty($res[$k])) {
                    $v = in_array($res[$k]['data_type'], ['int', 'tinyint']) ? (int)$v : addslashes(trim($v, "\\ \t\n\r\0\x0B"));
                }
            });
            $param['art_addtime'] = time();
            $res = Helper::service('Article')->saveArt($param);
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
        }
    }

    public function update()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $field = $param['field'] ?? 'art_status';
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $res = Helper::service('Article')->saveArt([
                $field => $value,
                'art_id' => $id
            ]);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
        }
    }

    public function upload(): bool
    {
        $param = $this->request()->getRequestParam();
        $field = 'image';
        $path = '/static/upload/art/image/';
        if (!empty($param['type']) && $param['type'] === 'thumb') {
            $field = 'thumb';
            $path = '/static/upload/art/thumb/';
        }
        $config = [
            'field' => $field,
            'path' => $path
        ];
        $res = Upload::getInstance($this->request())->setConfig($config)->upload();
        return Helper::responseJson(['code' => $res['code'], 'msg' => $res['msg'], 'data' => $res['result']]);
    }

    public function delete(): bool
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res = Helper::service('Article')->deleteArt($data);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
        }
        return false;
    }

    private function getTime($v)
    {
        $arr = ["-1 day", "-3 day", "-7 day", "-30 day", "-90 day",];
        return strtotime($arr[(int)$v - 1]);
    }

    public function recycle(): bool
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            $order = 'art_id';
            if (!empty($param['key'])) {
                $key = $param['key'];
                if (isset($key['searchName']) && $key['searchName']) {
                    $where[] = ['art_title', 'like', "%{$key['searchName']}%"];
                }
            }
            $res = Db::name('art_recycle')->where($where)->order($order)->page($page, $limit)->select()->toArray();
            $count = Db::name('art_recycle')->where($where)->count('*');
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => $count]);
        }
        $this->fetch('admin/index/recycle');
        return false;
    }

    public function recovery(): bool
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res = false;
            $data = (new ArticleRecycleModel())->select($data)->toArray();
            $ins = (new ArticleModel())->insertAll($data);
            if (0 !== $ins) {
                $art_id = array_column($data, 'art_id');
                $res = ArticleRecycleModel::destroy($art_id);
            }
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '恢复失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '恢复成功', 'data' => []]);
        }
        return false;
    }

    public function recycle_delete(): bool
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res = Helper::service('ArticleRecycle')->deleteArt($data);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
        }
        return false;
    }
}