<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Art\Service;


use App\Art\Model\ArticleModel;
use App\Art\Model\ArticleRecycleModel;
use rayswoole\Service;

class ArticleRecycleService extends Service
{

    public function artList($where, $order = "art_id asc", $page = 0, $limit = 20): array
    {
        $model = new ArticleRecycleModel();
        if ($page > 0) {
            $data = $model->where($where)->order($order)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->where($where)->order($order)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    public function recovery($data): bool
    {
        $data = (new ArticleRecycleModel())->select($data)->toArray();
        $res = (new ArticleModel())->insertAll($data);
        if (0 !== $res) {
            $art_id = array_column($data, 'art_id');
            return ArticleRecycleModel::destroy($art_id);
        }
        return false;
    }

    public function deleteArt($data): bool
    {
        return ArticleRecycleModel::destroy($data);
    }
}