<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Model;


use rayswoole\orm\Model;

class WebSiteModel extends Model
{

    protected $name = 'site_config';
    protected $pk = 'config_id';


}