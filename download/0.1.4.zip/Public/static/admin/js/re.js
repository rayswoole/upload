'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
    return typeof obj;
} : function (obj) {
    return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};

!function (win) {

    var _this = '';
    var re = function re() {
    };
    re.prototype.init = function () {
        this.time = '201912310860';
        _this = this;
    };

    re.prototype.xpost = function (u, x, b, c, e) {
        $.ajax({
            url: u, data: x, async: true, type: 'post', dataType: "json",
            beforeSend: function beforeSend(be) {
                b(be);
            },
            success: function success(se) {
                c(se);
            },
            error: function error(er) {
                e(er);
            }
        });
    };

    re.prototype.xget = function (u, x, b, c, e) {
        $.ajax({
            url: u, data: x, async: true, type: 'get', dataType: "json",
            beforeSend: function beforeSend(be) {
                b(be);
            },
            success: function success(se) {
                c(se);
            },
            error: function error(er) {
                e(er);
            }
        });
    };

    re.prototype.xtimeFormat = function (tt) {
        if (tt === 0) return tt;
        var n = new Date(tt * 1000);
        var y = n.getFullYear();
        var mon = n.getMonth() + 1;
        var d = n.getDate().toString().length === 1 ? '0' + n.getDate().toString() : n.getDate();
        var h = n.getHours().toString().length === 1 ? '0' + n.getHours().toString() : n.getHours();
        var m = n.getMinutes().toString().length === 1 ? '0' + n.getMinutes().toString() : n.getMinutes();
        var s = n.getSeconds().toString().length === 1 ? '0' + n.getSeconds().toString() : n.getSeconds();
        return y + "-" + mon + "-" + d + "   " + h + ":" + m + ":" + s;
    };

    re.prototype.xtimeToDay = function (s, e, format) {
        if (e < s) return '结束时间不能小于开始时间';
        var m = '',
            f = '';
        s = new Date(s).getTime();
        e = new Date(e).getTime();
        format = format || 'd-h-m-s';
        var mss = e - s;
        if (isNaN(mss)) return '时间格式不合法';
        var xx = {
            d: function d() {
                return parseInt(mss / (1000 * 60 * 60 * 24)) + " 天 ";
            },
            h: function h() {
                return parseInt(mss % (1000 * 60 * 60 * 24) / (1000 * 60 * 60)) + " 小时 ";
            },
            m: function m() {
                return parseInt(mss % (1000 * 60 * 60) / (1000 * 60)) + " 分钟 ";
            },
            s: function s() {
                return mss % (1000 * 60) / 1000 + " 秒 ";
            }
        };
        f = format.split('-');
        try {
            $.each(f, function (i, a) {
                if (a != '') {
                    m += xx[a].call(this);
                }
            });
            return m;
        } catch (e) {
            console.log(e.message);
        }
    };

    re.prototype.load = function (msg) {
        msg = msg || '正在提交程序中...';
        this.index_msg = layer.msg("<i class='layui-icon'>&#xe63d;</i><p>" + msg + "</p>", {
            time: this.time,
            shade: .6,
            type: 1,
            scrollbar: false
        });
    };

    re.prototype.loadclose = function () {
        layer.close(this.index_msg);
    };

    re.prototype.fclose = function () {
        var index = parent.layer.getFrameIndex(window.name);
        parent.layer.close(index);
    };

    re.prototype.url = {
        'path': function () {
            return win.location.pathname;
        },
        'domain': function () {
            return win.location.origin;
        }
    };

    re.prototype.layuiDataName = function () {
        return 'topazx' + cre.url.path().replace(/(^\/)|(\/$)/g, "").split('/')[0];
    };

    re.prototype.set_top_nav_data = function (data) {
        if (data != null) {
            layui.data(this.layuiDataName(), data);
        }
    };

    re.prototype.get_top_nav_data = function () {
        return layui.data(this.layuiDataName());
    };

    re.prototype.del_top_nav_data = function (id) {
        id = id | 'topnav';
        if (typeof id != "undefined") {
            layui.data(this.layuiDataName(), {
                key: id,
                remove: true
            });
        } else {
            layui.data(this.layuiDataName(), null);
        }
    };

    re.prototype.cookie = {
        'init': function () {
            if (_typeof($.cookie) === undefined || $.cookie === undefined) {
                cre.getScript.load('/static/js/jquery.cookie.js');
            }
        },
        'set': function set(n, v, t) {
            this.init();
            if (!n) {
                return $.cookie(n, v, {expires: t});
            }
        },
        'get': function get(n) {
            this.init();
            return $.cookie(n);
        },
        'del': function del(n) {
            this.init();
            return $.removeCookie(n);
        }
    };

    re.prototype.usertoken = function () {
        if (this.cookie.get('ULTOKEN') !== undefined && this.cookie.get('ULTOKEN') !== null) {
            return !!JSON.parse(this.cookie.get('ULTOKEN')).token ? JSON.parse(this.cookie.get('ULTOKEN')).token : undefined;
        }
    };

    re.prototype.username = function () {
        if (this.cookie.get('ULTOKEN') !== null && this.cookie.get('ULTOKEN') !== undefined) {
            return !!JSON.parse(this.cookie.get('ULTOKEN')).user_name ? JSON.parse(this.cookie.get('ULTOKEN')).user_name : undefined;
        }
    };

    re.prototype.loginbtn = function (name) {
        if (!name) return false;
        if ($.cookie !== undefined && this.usertoken()) {
            $(name).html('<a href="javascript:;" class="username">' + this.username() + '</a>\n                <dl class="layui-nav-child">\n                    <dd>\n                        <a href="/user/index/userinfo">个人信息</a></dd>\n                    <dd>\n                        <a href="/user/login/loginout">切换帐号</a></dd>\n                    <dd>\n                        <a href="/user/login/loginout">退出</a></dd>\n                </dl>\n            </li>');
        }
        return true;
    };

    re.prototype.getScript = {
        'isInclude': function isInclude(name) {
            var js = /js$/i.test(name);
            var es = document.getElementsByTagName(js ? 'script' : 'link');
            for (var i = 0; i < es.length; i++) {
                if (es[i][js ? 'src' : 'href'].indexOf(name) !== -1) return true;
            }
            return false;
        },
        'load': function load(n, c) {
            if (!this.isInclude(n)) {
                c = c || new Function();
                $.ajax({
                    url: n, async: false, dataType: "script", cache: true,
                    success: function success(se) {
                        return c(se);
                    }
                });
            }
        }
    };

    re.prototype.QRcode = {
        'get': function get(cn, text, w, h, cd, cl, le) {
            try {
                cre.getScript.load('/static/js/qrcode.min.js');
                this.qrcode_test = text;
                return this.qrcode = new QRCode(cn, {
                    text: text,
                    width: w || 128,
                    height: h || 128,
                    colorDark: cd || "#000000",
                    colorLight: cl || "#ffffff",
                    correctLevel: le || QRCode.CorrectLevel.H
                });
            } catch (e) {
                layui.layer.msg(e.message);
            }
        },
        'reload': function reload() {
            null != this.qrcode && this.qrcode.makeCode(this.qrcode_test + (-1 !== this.qrcode_test.indexOf("?") ? "&" : "?&") + "_t=" + (new Date).getTime());
        }
    };

    re.prototype.end = function () {
        var top_list = this.get_top_nav_data();
        $.each(top_list, function (i, v) {
            if (_typeof(top_list[i]) !== undefined) {
                layui.jquery('.xxx .top_nav .x').eq(top_list[i]).click();
            }
        });
    };

    win.cre = new re();
}(window);

layui.use(['layer', 'element', 'jquery'], function () {
    var element = layui.element,
        layer = layui.layer;
    cre.init();
    // var $ = cre.$;
    $('.xxx .top_nav').on('click', '.x', function (e) {
        var xg = xadmin.get_cate_data();
        var d = $(this).data('open');

        $('.left-nav').animate({width: '220px'}, 100);
        $('.page-content').animate({left: $(window).width() < 768 ? '0px' : '220px'}, 100);
        $('.left-nav i').css('font-size', '14px');
        $('.left-nav cite,.left-nav .nav_right').show();
        if ($(window).width() < 768) {
            $('.page-content-bg').show();
        }

        if (d !== '') {
            $('.left-nav #nav').children('div').slideUp();
            if (!$('.left-nav #nav').find('div[data-en=' + d + ']').stop(true, true).slideDown().children('li').hasClass('open')) {
                $('.left-nav #nav').find('div[data-en=' + d + ']').eq(0).slideDown();
                $('.left-nav #nav').find('div[data-en=' + d + ']').eq(0).children('li').children('.sub-menu').slideDown();
            }
            cre.set_top_nav_data({
                key: 'topnav',
                value: $('.xxx .top_nav .x').index($(this))
            });
        }
        e.stopPropagation();
    });

    if ($.isEmptyObject(cre.get_top_nav_data())) {
        $('.xxx .top_nav .x:first-child').click();
        cre.set_top_nav_data({
            key: 'topnav',
            value: 0
        });
    }
    (function () {
        var layid = location.hash.replace(/^#urlhash=/, '');
        var layidx = parent.location.hash.replace(/^#urlhashx=/, '');
        element.tabChange('test', layid.split('_')[0]);
        element.on('tab(test)', function (elem) {
            location.hash = 'urlhash=' + $(this).attr('lay-id') + '_' + new Date().getTime();
        });
        element.tabChange('test', layidx.split('_')[0]);
        element.on('tab(test)', function (elem) {
            parent.location.hash = 'urlhashx=' + $(this).attr('lay-id') + '_' + new Date().getTime();
        });
    })();
    cre.end();
});

