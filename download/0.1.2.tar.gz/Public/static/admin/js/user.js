"use strict";
var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (e) {
    return typeof e
} : function (e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
};
!function (e) {
    e.login = {
        temp: {},
        loadFiles: {js: [], css: []},
        config: {
            url: {
                login: "/user/api/login",
                registered: "/user/api/register",
                retrievePass: "/user/api/retrieve",
                setPassword: "",
                userInfo: "/user/index/userinfo"
            },
            req_url: {
                login: "/user/api/login_check",
                registered: "/user/api/save_register",
                findPass: "/user/api/findpass",
                setPass: "/user/api/setpassword"
            },
            script: {layui: "/static/js/layui/layui/layui.all.js"}
        },
        init: function () {
            var t = Array.apply(null, document.querySelectorAll("[cc-event]"));
            "undefined" == typeof $ && (window.$ = layui.$),
                t.forEach(function (e) {
                    if (null !== e.getAttribute("cc-event")) try {
                        e.addEventListener("click", new Function("window.login." + e.getAttribute("cc-event")))
                    } catch (t) {
                        console.log(t)
                    }
                })
        },
        showBtn: function (e, t) {
            var n = e || this.getCookie('temp'), a = $.extend({login: "alert", registered: "alert", info: "black"}, t, {}),
                i = [
                    ['<a href="javascript:;" cc-event="login(\'\',\'' + a.login + '\')">登录</a>\n<a href="javascript:;" cc-event="registered(\'\',\'' + a.registered + "')\">注册</a>\n"].join(""),
                    ['<a href="javascript:;" cc-event="userInfo(\'\',\'' + a.info + "')\">" + this.userData("user_name") + '</a>\n<a href="javascript:;" cc-event=\'logout()\'>退出</a></div>'].join("")
                ];
            return a.html = a.html || (this.isLogin() ? i[1] : i[0]), this.setCookie('temp', n),
                (this.temp.showBtn = n) && 0 < $(n).length ?
                    ($(n).html("").html(a.html), this.init(), !0) :
                    (console.log("未找到类 “" + n + "” ，无法执行登录按钮初始化"), !1);
        },
        login: function login(e, t, n, a, d) {
            var e = e || this.config.url.login,
                n = n || 500,
                a = a || 300,
                d = d || function () {};
            if ("black" === (t = t || "alert")){
                window.open(e, "_blank");
            } else {
                if ("self" === t) {
                    window.location.href = e;
                } else if (window.name && parent.layer.getFrameIndex(window.name)) {
                    console.log(e);
                    parent.layer.close(parent.layer.getFrameIndex(window.name));
                    parent.login.pO("用户登录", e, 2, n, a, d);
                } else {
                    console.log('e:'+e);
                    this.alert("用户登录", e, 2, n, a, d);
                }
            }
            return this;
        },
        logout: function (e) {
            var t = this;
            this.loadJC(this.config.script.layui, function () {
                e = e || function () {
                    layui.layer.msg("退出成功"),
                        window.location.reload(),
                        parent.login.showBtn(t.temp.showBtn)
                }, t.removeCookie("ULTOKEN"), e()
            })
        },
        registered: function (e, t, n, a) {
            return e = e || this.config.url.registered, n = n || 500, a = a || 800,
                "black" === (t = t || "alert") ?
                    window.open(e, "_blank") :
                    window.name && parent.layer.getFrameIndex(window.name) ?
                        (parent.layer.close(parent.layer.getFrameIndex(window.name)),
                            parent.login.pO("用户注册-1", e, 2, n, a)) : this.alert("用户注册-2", e, 2, n, a), this
        },
        retrievePass: function (e, t, n, a) {
            return e = e || this.config.url.retrievePass, n = n || 500, a = a || 800, "black" === (t = t || "alert") ? window.open(e, "_blank") : window.name && parent.layer.getFrameIndex(window.name) ? (parent.layer.close(parent.layer.getFrameIndex(window.name)), parent.login.pO("找回密码", e, 2, n, a)) : this.alert("找回密码", e, 2, n, a), this
        },
        setPassword: function (e, t, n, a) {
            return this
        },
        userInfo: function (e, t, n, a) {
            var i = this;
            return this.loadJC(this.config.script.layui, function () {
                return i.isLogin() ? (e = e || i.config.url.userInfo, t = t || "alert", n = n || .9 * $(window).width(), a = a || $(window).height() - 50,
                        void ("black" === t ? window.open(e, "_blank") : window.name && parent.layer.getFrameIndex(window.name) ? (parent.layer.close(parent.layer.getFrameIndex(window.name)),
                            parent.login.pO("用户中心", e, 2, n, a)) : i.alert("用户中心", e, 2, n, a)))
                    :
                    (layui.layer.msg("请先登录"), setTimeout(function () {
                        window.name && parent.layer.getFrameIndex(window.name) ? i.login() : i.login("", "black")
                    }, 120), !1)
            }), this
        },
        req_login: function (t, n) {
            var a = this;
            t = t || this.config.req_url.login, n = n || !1, this.loadJC(this.config.script.layui, function () {
                layui.form.verify({
                    username: function (e) {
                        if (e.length < 3) return "用户名至少得3个字符!"
                    }, password: [/^[\S]{6,}$/, "密码至少需要6位，且不能出现空格!"]
                }),
                    layui.form.on("submit(login)", function (e) {
                        return a.ajax(t, e.field, {}, function (e) {
                            e.code ? layer.msg(e.msg) :
                                (layer.msg(e.msg), a.setCookie("ULTOKEN", JSON.stringify(e.data.info)),
                                    window.name && parent.layer.getFrameIndex(window.name) ? setTimeout(function () {
                                        parent.layer.close(parent.layer.getFrameIndex(window.name)),
                                            parent.login.showBtn(a.getCookie('temp')),
                                            parent.$('.ray_comment_iframe').attr('src',parent.$('.ray_comment_iframe').attr('src'))
                                    }, 500) : window.location.href = n ? document.referrer : a.config.url.userInfo)
                        }, function (e) {
                            layer.msg(e.statusText)
                        }, "get", "jsonp"), !1
                    })
            })
        },
        req_register: function (t, n) {
            var a = this;
            this.loadJC(this.config.script.layui, function () {
                layui.jquery;
                t = t || a.config.req_url.registered, n = n || function (e) {
                    e.code ? layer.msg(e.msg) : (layer.msg(e.msg), setTimeout(function () {
                        window.name && parent.layer.getFrameIndex(window.name) ? a.login() : a.login("", "self")
                    }, 500))
                },
                    layui.form.verify({
                        user_name: function (e) {
                            if (e.length < 3) return "账号3位字符以上！"
                        }, user_passwd: function (e) {
                            if (e.length < 6) return "密码长度6位以上！"
                        }
                    }),
                    layui.form.on("submit(site_form)", function (e) {
                        return a.ajax(t, e.field, {}, function (e) {
                            n(e)
                        }, function (e) {
                            layer.msg(e.statusText)
                        }, "post"), !1
                    })
            })
        },
        req_retrieve: function (i, s) {
            var c = this;
            i = i || this.config.req_url.findPass, s = s || this.config.req_url.setPass, this.loadJC(this.config.script.layui, function () {
                layui.config({base: "/static/js/layui/layui_exts/"}).use(["layer", "form", "step"], function () {
                    var e = layui.form, t = layui.layer, n = layui.jquery;
                    e.verify({
                        user_name: function (e) {
                            if (e.length < 3) return "账号3位字符以上！"
                        }, user_passwd: function (e) {
                            if (e.length < 6) return "密码长度6位以上！"
                        }
                    }), layui.step.render({
                        elem: "#stepForm",
                        filter: "stepForm",
                        width: "100%",
                        stepWidth: "510px",
                        height: "500px",
                        stepItems: [{title: "填写问题"}, {title: "修改密码"}, {title: "完成"}]
                    }), n(document).on("click", ".pre", function () {
                        layui.step.pre("#stepForm")
                    }), n(document).on("click", ".next", function () {
                        layui.step.next("#stepForm")
                    });
                    var a = 0;
                    layui.form.on("submit(go_next)", function (e) {
                        return c.ajax(i, e.field, {}, function (e) {
                            e.code ? t.msg(e.msg) : (a = e.data.user_id, layui.step.next("#stepForm"))
                        }, function (e) {
                            t.msg(e.statusText)
                        }, "post"), !1
                    }),
                        layui.form.on("submit(set_pass)", function (e) {
                            return e.field.edit_id = a, c.ajax(s, e.field, {}, function (e) {
                                e.code ? t.msg(e.msg) : (t.msg(e.msg), layui.step.next("#stepForm"))
                            }, function (e) {
                                t.msg(e.statusText)
                            }, "post"), !1
                        })
                })
            })
        },
        alert: function (title, content, type, width, height, endBack, isFull) {
            var title = title || !1, type = type || 2, content = content || "404.html",
                width = width || .9 * $(window).width(), height = height || $(window).height() - 50,
                endBack = endBack || function () {};
            return this.loadJC(this.config.script.layui, function () {
                var index = layer.open({
                    type: type,
                    area: [width + "px", height === 'auto' ? 'auto' : height + "px"],
                    fixed: false,
                    maxmin: false,
                    shadeClose: !1,
                    shade: .4,
                    title: title,
                    content: content,
                    scrollbar: false,
                    end: function (e) {
                        endBack(e)
                    }
                });
                isFull && layer.full(index)
            }), !0
        },
        pO: function (title, content, type, width, height, endBack, isFull) {
            var title = title || !1, type = type || 2, content = content || "404.html",
                width = width || .9 * $(window).width(), height = height || $(window).height() - 50,
                endBack = endBack || function () {};
            var index = parent.layer.open({
                type: type,
                area: [width + "px", height === 'auto' ? 'auto' : height + "px"],
                fixed: false,
                maxmin: false,
                shadeClose: !1,
                shade: .4,
                title: title,
                content: content,
                end: function (e) {
                    endBack(e)
                }
            });
            parent.layer.iframeAuto(index);
            isFull && layer.full(e)
        },
        getCookie: function (e) {
            var t = new RegExp("(^| )" + e + "=([^;]*)(;|$)");
            return document.cookie.match(t) ? unescape(document.cookie.match(t)[2]) : null
        },
        setCookie: function (e, t, n, a) {
            var i = new Date;
            n = n || "/", a = a || 1, i.setTime(i.getTime() + 60 * a * 60 * 1e3), document.cookie = e + "=" + escape(t) + ";path=" + n + (null === a ? "" : "; expires=" + i.toUTCString())
        },
        removeCookie: function (e) {
            this.setCookie(e, "", "/", 0)
        },
        userData: function (e) {
            var t;
            return e = e || "", (t = this.getCookie("ULTOKEN")) ? "token" === e ? JSON.parse(t).token : "user_name" === e ? JSON.parse(t).user_name : "user_id" === e ? JSON.parse(t).user_id : JSON.parse(t) : ""
        },
        ajax: function (e, t, n, a, i, s, c) {
            return a = a || function (e) {
            }, i = i || function (e) {
            }, s = s || "get", c = c || "json", t = t || {}, n = n || {token: this.getCookie("ULTOKEN")}, $.ajax({
                url: e,
                dataType: c,
                type: s,
                data: t,
                headers: n,
                success: function (e) {
                    a(e)
                },
                error: function (e) {
                    i(e)
                }
            }), !0
        },
        isLogin: function () {
            return !!this.userData("")
        },
        loadJC: function (e, n) {
            var i = [], s = function s(e, t) {
                if (null != e && 0 < e.length) for (var n = e.length, a = 0; a < n; a++) if (e[a] === t) return !0;
                return !1
            }, c = function c(e) {
                return null != e && 0 < e.length ? e.substr(e.lastIndexOf(".")).toLowerCase() : ""
            }, o = function o(e, t) {
                var n, a;
                s(i, e) ? t() : (".js" === (n = c(e).toString()) ? (a = document.createElement("script")).src = e : ".css" === n ? ((a = document.createElement("link")).href = e, a.type = "text/css", a.rel = "stylesheet") : ".less" === n && ((a = document.createElement("link")).href = e, a.type = "text/css", a.rel = "stylesheet/less"), t = t || function () {
                }, a.onload = a.onreadystatechange = function () {
                    this.readyState && "loaded" !== this.readyState && "complete" !== this.readyState || (t(), i.push(e))
                }, document.getElementsByTagName("head")[0].appendChild(a))
            }, a = [];
            "object" === (void 0 === e ? "undefined" : _typeof(e)) ? a = e : "string" == typeof e && (a = e.split(",")), null != a && 0 < a.length && function () {
                for (var e = 0, t = 0; t < a.length; t++) o(a[t], function () {
                    ++e == a.length && n()
                })
            }()
        }
    },
    e.comment = {
        facePath: [
            {faceName: "微笑", facePath: "/static/admin/face/0.gif"}, {
                faceName: "撇嘴",
                facePath: "/static/admin/face/1.gif"
            }, {faceName: "色", facePath: "/static/admin/face/2.gif"}, {
                faceName: "发呆",
                facePath: "/static/admin/face/3.gif"
            }, {faceName: "得意", facePath: "/static/admin/face/4.gif"}, {
                faceName: "流泪",
                facePath: "/static/admin/face/5.gif"
            }, {faceName: "害羞", facePath: "/static/admin/face/6.gif"}, {
                faceName: "闭嘴",
                facePath: "/static/admin/face/7.gif"
            }, {faceName: "大哭", facePath: "/static/admin/face/9.gif"}, {
                faceName: "尴尬",
                facePath: "/static/admin/face/10.gif"
            }, {faceName: "发怒", facePath: "/static/admin/face/11.gif"}, {
                faceName: "调皮",
                facePath: "/static/admin/face/12.gif"
            }, {faceName: "龇牙", facePath: "/static/admin/face/13.gif"}, {
                faceName: "惊讶",
                facePath: "/static/admin/face/14.gif"
            }, {faceName: "难过", facePath: "/static/admin/face/15.gif"}, {
                faceName: "酷",
                facePath: "/static/admin/face/16.gif"
            }, {faceName: "冷汗", facePath: "/static/admin/face/17.gif"}, {
                faceName: "抓狂",
                facePath: "/static/admin/face/18.gif"
            }, {faceName: "吐", facePath: "/static/admin/face/19.gif"}, {
                faceName: "偷笑",
                facePath: "/static/admin/face/20.gif"
            }, {faceName: "可爱", facePath: "/static/admin/face/21.gif"}, {
                faceName: "白眼",
                facePath: "/static/admin/face/22.gif"
            }, {faceName: "傲慢", facePath: "/static/admin/face/23.gif"}, {
                faceName: "饥饿",
                facePath: "/static/admin/face/24.gif"
            }, {faceName: "困", facePath: "/static/admin/face/25.gif"}, {
                faceName: "惊恐",
                facePath: "/static/admin/face/26.gif"
            }, {faceName: "流汗", facePath: "/static/admin/face/27.gif"}, {
                faceName: "憨笑",
                facePath: "/static/admin/face/28.gif"
            }, {faceName: "大兵", facePath: "/static/admin/face/29.gif"}, {
                faceName: "奋斗",
                facePath: "/static/admin/face/30.gif"
            }, {faceName: "咒骂", facePath: "/static/admin/face/31.gif"}, {
                faceName: "疑问",
                facePath: "/static/admin/face/32.gif"
            }, {faceName: "嘘", facePath: "/static/admin/face/33.gif"}, {
                faceName: "晕",
                facePath: "/static/admin/face/34.gif"
            }, {faceName: "折磨", facePath: "/static/admin/face/35.gif"}, {
                faceName: "衰",
                facePath: "/static/admin/face/36.gif"
            }, {faceName: "骷髅", facePath: "/static/admin/face/37.gif"}, {
                faceName: "敲打",
                facePath: "/static/admin/face/38.gif"
            }, {faceName: "再见", facePath: "/static/admin/face/39.gif"}, {
                faceName: "擦汗",
                facePath: "/static/admin/face/40.gif"
            }],
        config: {
            url: {
                "delete": "/comment/index/delete",
                reply: "/comment/index/save",
                message: "/comment/index/save",
                reply_more: "/comment/index/read",
                message_more: "/comment/index/read"
            },
            user: {
                id: 0, name: 0, token: "", avatar: "/static/images/face.png", unloginClickBtn: function () {
                    const s = '';
                    return layer.msg("清先登录"), "undefined" !== window.login && top.window.login.login(s, s, s, s, function () {
                        window.comment.reload();
                        parent.login.showBtn();
                    }), !0
                }
            },
            message_init_num: 1,
            reply_init_num: 2,
            message_load_num: 1,
            reply_load_num: 2,
            comment_mid: 1,
            comment_rid: 666,
            comment_sid: 0,
            parseData: function (e) {
                return {code: e.code, msg: e.msg, result: e.data}
            }
        },
        init: function (e) {
            this.dataMerge(e);
            var t = $(".skin").data("rid"), n = $(".skin").data("mid");
            $(".skin").removeClass().addClass("skin_write"),
                this.config.user.id = this.userData("user_id"),
                this.config.user.name = this.userData("user_name"),
                this.config.user.token = this.userData("token"),
                this.config.comment_mid = n || this.config.comment_mid,
                this.config.comment_rid = t || this.config.comment_rid;
            var a = $(".comment_date_or_hf_c").children(".c_hf"),
                o = (this.config.user.id, this.config.user.name);
            $.each(a, function (e, t) {
                var n = $(t), a = (n.data("uid"), n.data("cid")),
                    i = n.data("mname"), s = n.data("pid"), c = "",
                    c = i.toString() === o.toString() ? [' <a class="del" data-cid="' + a + '" data-mname="' + i + '" data-pid="' + s + '" style="display: none">删除</a>'].join(" ") : [' <a class="com c_show" data-cid="' + a + '" data-mname="' + i + '" data-pid="' + s + '" style="display: inline-block">回复</a>'].join(" ");
                n.html("").append(c)
            });
            var i = $(".hf_more");
            $.each(i, function (e, t) {
                var n = $(t),
                    a = (n.data("cid"),
                        parseInt(n.data("len")));
                n.prev().children(".hf").length < a ? n.addClass("c_show") : n.addClass("c_hide")
            });
            !this.isLogin() ? $('.ly_btn').html('登录并留言') : $('.ly_btn').html('发表');
            this.expression(),
                this.speak(),
                this.reply(),
                this["delete"](),
                this.speak_more(),
                this.reply_more()
        },
        show: function () {
            var e = $(".ray_comment").data("mid"),
                t = $(".ray_comment").data("rid");
            if (this.isEmpty(e) || this.isEmpty(t)) return layer.msg("模块id[mid]或关联id[rid]不能为空"), !1;
            var n = ["<iframe id='ray_comment_iframe_"+t+"' src='/comment/index?mid=" + e + "&rid=" + t + '&sid=0\' width="100%" height=\'100%\' frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="yes" allowtransparency="yes" class="ray_comment_iframe"></iframe>'].join(" ");
            $(".ray_comment").html("").html(n)
        },
        expression: function () {
            var n = !1, a = this;
            $(document).on("click", ".imgBtn", function () {
                var e = $(this).parent().siblings(".faceDiv");
                if (!1 === n) {
                    if (n = !0, $(this).parent().prev().animate({marginTop: "-125px"}, 300), 0 === parseInt(e.children().length)) {
                        for (var t = 0; t < a.facePath.length; t++) e.append('<img title="' + a.facePath[t].faceName + '" src=' + a.facePath[t].facePath + " />");
                        $(this).parent().siblings(".faceDiv").children("img").click(function () {
                            n = !1, $(this).parent().animate({marginTop: "0px"}, 300), a.insertAtCursor($(this).parent().siblings(".Input_text")[0], "[" + $(this).attr("title") + "]")
                        })
                    }
                } else n = !1, $(this).parent().prev().animate({marginTop: "0px"}, 300)
            })
        },
        read: function (e, t) {
            var a = $(".comment_list"), i = (this.config.user.id, this.config.user.name), s = this;
            return s.ajax(s.config.url.message_more, {
                msg_limit: s.config.message_load_num,
                msg_page: e,
                reply_limit: s.config.message_load_num,
                reply_page: t,
                comment_mid: s.config.comment_mid,
                comment_rid: s.config.comment_rid,
                comment_sid: s.config.comment_sid,
                time: (new Date).getTime()
            }, s.config.headers || {}, function (e) {
                var n, t = e;
                if ("function" == typeof s.config.parseData && (e = s.config.parseData(e), t.code !== e.code)) return layui.layer.msg("状态码有误"), !1;
                0 === e.code ? (n = "", s.isEmpty(e.result) ? $(".ly_more").removeClass("ly_more").addClass("reload_html").html("无更多数据...点击刷新") : $.each(e.result, function (e, t) {
                    n += '<div class="comment_list_i c_hf_' + t.comment_id + '">\n<div class="comment_face_img comment_list_i_left">\n<img src="' + (t.avatar || "/static/images/face.png") + '" alt="用户头像信息">\n</div>\n<div class="comment_list_i_right">\n<div class="ly_main">\n<div class="ly c_btn">\n<div class="comment_text">\n<span class="name">@' + (0 === t.user_id ? "系统" : t.user_name) + '：</span>\n<span class="text">' + s.decodeEntities(t.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + s.timeFormat(t.comment_addtime) + '</span>\n<span class="c_hf" >\n<a class="del ' + (i !== t.user_name ? "c_hide" : "c_show") + '" data-cid="' + t.comment_id + '" data-mname="' + t.user_name + '" data-pid="' + t.comment_id + '">删除</a>\n<a class="com ' + (i !== t.user_name ? "c_show" : "c_hide") + '" data-cid="' + t.comment_id + '" data-mname="' + t.user_name + '" data-pid="' + t.comment_id + '">回复</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>\n</div>\n<div class="hf_main">\n<div class="hf_text">\n', s.isEmpty(t.reply) || $.each(t.reply, function (e, t) {
                        n += '<div class="hf c_btn c_hf_' + t.comment_id + '">\n<div class="comment_text">\n<span class="name">@' + (0 === t.user_id ? "系统" : t.user_name) + '<span style="color: #333333;margin: 0 1px;">回复</span>@' + t.reply_name + '：</span>\n<span class="text">' + s.decodeEntities(t.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + s.timeFormat(t.comment_addtime) + '</span>\n<span class="c_hf">\n<a class="del ' + (i !== t.user_name ? "c_hide" : "c_show") + '" data-cid="' + t.comment_id + '" data-mname="' + t.user_name + '" data-pid="' + t.comment_pid + '">删除</a>\n<a class="com ' + (i !== t.user_name ? "c_show" : "c_hide") + '" data-cid="' + t.comment_id + '" data-mname="' + t.user_name + '" data-pid="' + t.comment_pid + '">回复</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>'
                    }), n += '</div>\n<div class="hf_more more ' + (1 <= t.reply_count - s.config.reply_init_num ? "c_show" : "c_hide") + " more_" + t.comment_id + '" data-cid="' + t.comment_id + '" data-reply_len="' + t.reply_count + '">\n<span>查看更多</span>\n</div></div>\n</div>\n<div class="_clear"></div>\n</div>'
                }), a.append(n)) : layui.layer.msg(e.msg)
            }, function (e, t) {
                layer.msg("接口请求异常: " + t)
            }, "post"), !0
        },
        speak: function () {
            var o = this;
            $(".ly_btn").on("click", function () {
                if (!o.isLogin()) return o.config.user.unloginClickBtn(), $('ly_btn').html('登录并发表'), !0;
                var n = $(this).parent(".Input_Foot").siblings(".Input_text"), e = o.emoticonConversion(n.val()),
                    t = o.config.user.id, a = (o.config.user.name, o.config.user.avatar), i = o.config.comment_mid,
                    s = o.config.comment_rid, c = $(this).parents(".ly_box").siblings(".comment_list");
                return "" !== e && o.ajax(o.config.url.message, {
                    user_id: t,
                    content: e,
                    comment_mid: i,
                    comment_rid: s,
                    time: (new Date).getTime()
                }, o.config.headers || {}, function (e) {
                    var t = e;
                    if ("function" == typeof o.config.parseData && (e = o.config.parseData(e), t.code !== e.code)) return layui.layer.msg("状态码有误"), !1;
                    0 === e.code ? (c.prepend('<div class="comment_list_i c_hf_' + e.result.comment_id + '">\n<div class="comment_face_img comment_list_i_left">\n<img src="' + a + '" alt="用户头像信息">\n</div>\n<div class="comment_list_i_right">\n<div class="ly_main">\n<div class="ly c_btn">\n<div class="comment_text">\n<span class="name">@' + e.result.username + '：</span>\n<span class="text">' + o.decodeEntities(e.result.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + o.timeFormat(e.result.comment_addtime) + '</span>\n<span class="c_hf">\n<a class="del" data-cid="' + e.result.comment_id + '" data-mname="' + e.result.username + '">删除</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>\n</div>\n<div class="hf_main">\n<div class="hf_text">\n</div>\n</div>\n</div>\n<div class="_clear"></div>\n</div>'), n.val("")) : layer.msg(e.msg)
                    var iframe = parent.document.getElementById('ray_comment_iframe_'+s);
                    console.log((iframe.contentWindow.document.body.scrollHeight + 50) + 'px');
                    iframe.height = Math.min(iframe.contentWindow.document.body.scrollHeight + 50, 1000) + 'px';
                }, function (e, t) {
                    layer.msg("接口请求异常: " + t)
                }, "post"), !0
            })
        },
        speak_more: function () {
            var t = this;
            $(".ly_more").on("click", function () {
                $(this).siblings(".comment_list");
                var e = parseInt($(".comment_list_i").length / t.config.message_load_num) + 1;
                return t.read(e, 0), !0
            })
        },
        reply_init: function () {
            var a = !0, i = this;
            $(document).on("click", ".com", function () {
                return i.isLogin() ? (!1 !== a ? (e = $(this).data("cid"), t = $(this).data("mname"), n = $(this).data("pid"), $(".hf_box").remove(), 0 < $(this).parents(".comment_date_or_hf_c").siblings(".Input_Box").length ? $(this).parents(".comment_date_or_hf_c").siblings(".Input_Box").remove() : $(this).parents(".comment_date_or_hf").append('<div class="Input_Box hf_box">\n<textarea class="Input_text"></textarea>\n<div class="faceDiv"></div>\n<div class="Input_Foot">\n<a class="imgBtn" href="javascript:void(0);"></a>\n<a class="postBtn hf_btn" data-cid="' + e + '" data-mname="' + t + '" data-pid="' + n + '">发表</a>\n</div>\n</div>'), a = !1) : (a = !0, $(this).parents(".comment_date_or_hf_c").siblings(".Input_Box").remove()), !0) : i.config.user.unloginClickBtn();
                var e, t, n
            })
        },
        reply: function () {
            this.reply_init();
            var c = this;
            $(document).on("click", ".hf_btn", function () {
                if (c.isLogin) {
                    var e = c.emoticonConversion($(this).parent(".Input_Foot").siblings(".Input_text").val()),
                        t = $(this).data("cid"), n = $(this).data("mname"), a = c.config.user.id,
                        i = (c.config.user.name, $(this).data("pid")),
                        s = $(this).parents().siblings(".hf_main").children(".hf_text");
                    return s.length <= 0 && (s = $(this).parents().siblings(".hf").parent(".hf_text")), "" !== e && c.ajax(c.config.url.reply, {
                        comment_id: t,
                        comment_pid: i,
                        reply: !0,
                        user_id: a,
                        content: e,
                        comment_mid: c.config.comment_mid,
                        comment_rid: c.config.comment_rid,
                        time: (new Date).getTime()
                    }, c.config.headers || {}, function (e) {
                        var t = e;
                        if ("function" == typeof c.config.parseData && (e = c.config.parseData(e), t.code !== e.code)) return layui.layer.msg("状态码有误"), !1;
                        0 === e.code ? s.append(' <div class="hf c_btn c_hf_' + e.result.comment_id + '">\n<div class="comment_text">\n<span class="name">@' + e.result.username + '<span style="color: #333333;margin: 0 1px;">回复</span>@' + n + '：</span>\n<span class="text">' + c.decodeEntities(e.result.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + c.timeFormat(e.result.comment_addtime) + '</span>\n<span class="c_hf">\n<a class="del" data-cid="' + e.result.comment_id + '" data-mname="' + e.result.username + '">删除</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>') : layui.layer.msg(e.msg);
                        var iframe = parent.document.getElementById('ray_comment_iframe_'+c.config.comment_mid);
                        console.log((iframe.contentWindow.document.body.scrollHeight + 50) + 'px');
                        iframe.style.height = (iframe.contentWindow.document.body.scrollHeight + 50) + 'px';
                    }, function (e, t) {
                        layer.msg("接口请求异常: " + t)
                    }, "post"), $(this).parent(".Input_Foot").siblings(".Input_text").val(""), $(document).find(".hf_box").remove(), !0
                }
                return c.config.user.unloginClickBtn();
            })
        },
        reply_more: function () {
            var o = 0, r = this, m = 0;
            $(document).on("click", ".hf_more", function () {
                var i = $(this), s = $(this).siblings(".hf_text"), c = (r.config.user.id, r.config.user.name),
                    e = $(this).data("cid"), t = $(this).data("len"), n = $(this).prev(".hf_text"),
                    a = $(n).children(".c_btn").length;
                return o !== e && (m = Math.ceil(a / r.config.reply_load_num)), r.config.reply_load_num = t - a < r.config.reply_load_num ? t - a : r.config.reply_load_num, o = e, m += 1, r.ajax(r.config.url.message_more, {
                    comment_id: e,
                    reply_limit: r.config.reply_load_num,
                    reply_page: m,
                    comment_mid: r.config.comment_mid,
                    comment_rid: r.config.comment_rid,
                    comment_sid: r.config.comment_sid,
                    time: (new Date).getTime()
                }, r.config.headers || {}, function (e) {
                    var t = e;
                    if ("function" == typeof r.config.parseData && (e = r.config.parseData(e), t.code !== e.code)) return layui.layer.msg("状态码有误"), !1;
                    var n, a = "";
                    0 === e.code ? (r.isEmpty(e.result[0].reply) ? --m : ($.each(e.result[0].reply, function (e, t) {
                        a += '<div class="hf c_btn c_hf_' + t.comment_id + '">\n<div class="comment_text">\n<span class="name">@' + (0 === t.user_id ? "系统" : t.user_name) + '<span style="color: #333333;margin: 0 1px;">回复</span>@' + t.reply_name + '：</span>\n<span class="text">' + r.decodeEntities(t.comment_content) + '</span>\n</div>\n<div class="comment_date_or_hf">\n<div class="comment_date_or_hf_c">\n<span class="c_date">' + r.timeFormat(t.comment_addtime) + '</span>\n<span class="c_hf">\n<a class="del ' + (c !== t.user_name ? "c_hide" : "c_show") + '" data-cid="' + t.comment_id + '" data-mname="' + t.user_name + '" data-pid="' + t.comment_pid + '">删除</a>\n<a class="com ' + (c !== t.user_name ? "c_show" : "c_hide") + '" data-cid="' + t.comment_id + '" data-mname="' + t.user_name + '" data-pid="' + t.comment_pid + '">回复</a>\n</span>\n</div>\n</div>\n<div class="_clear"></div>\n</div>'
                    }), s.append(a)), n = s.children(".c_btn").length, e.result[0].reply_count - n < 1 && (e.result[0].comment_id, i.html("无更多数据"))) : layer.msg(e.msg)
                }, function (e, t) {
                    layer.msg("接口请求异常: " + t)
                }, "post"), !0
            })
        },
        delete_init: function () {
            var t = this;
            $(document).on("mouseenter mouseleave", ".comment_date_or_hf_c", function (e) {
                "mouseenter" === e.type ? !$(this).children(".c_hf").children(".del").hasClass("c_hide") && t.isLogin() && $(this).find(".del").show() : "mouseleave" === e.type && $(this).find(".del").hide()
            })
        },
        "delete": function () {
            this.delete_init();
            var a = this;
            $(document).on("click", ".del", function () {
                var e = $(this).data("cid"), n = $(this);
                a.ajax(a.config.url["delete"], {
                    c_id: e,
                    time: (new Date).getTime()
                }, a.config.headers || {}, function (e) {
                    var t = e;
                    if ("function" == typeof a.config.parseData && (e = a.config.parseData(e), t.code !== e.code)) return layer.msg("状态码有误"), !1;
                    0 === e.code && (0 < n.parents(".hf").length ? n.parents(".hf").remove() : n.parents(".comment_list_i").remove()), layer.msg(e.msg)
                }, function (e, t) {
                    layer.msg("接口请求异常: " + t)
                }, "post")
            })
        },
        emoticonConversion: function (o) {
            var r = this;
            return void 0 !== o && function () {
                var a, i, s, c = o.match(/\[(.*?)\]/g);
                if (null != c && "" !== c) for (var e = function e(n) {
                    s = c[n].replace(/(^\[)|(\]$)/g, ""), $.each(r.facePath, function (e, t) {
                        t.faceName === s && (a = window.location.origin + "/" + t.facePath, i = '<img src="' + a + '" height="22" width="22" />', o = o.replace(c[n], i))
                    })
                }, t = 0; t < c.length; t++) e(t)
            }(), o
        },
        insertAtCursor: function (e, t) {
            var n, a, i, s;
            document.selection ? (e.focus(), (n = document.selection.createRange()).text = t, n.select()) : e.selectionStart || "0" == e.selectionStart ? (a = e.selectionStart, i = e.selectionEnd, s = e.scrollTop, e.value = e.value.substring(0, a) + t + e.value.substring(i, e.value.length), 0 < s && (e.scrollTop = s), e.focus(), e.selectionStart = a + t.length, e.selectionEnd = a + t.length) : (e.value += t, e.focus())
        },
        decodeEntities: function (e) {
            var t = document.createElement("textarea");
            return t.innerHTML = e, t.value
        },
        isEmpty: function (e) {
            return !(e !== undefined && null != e && "" !== e && e && $.trim(e) && 0 !== e.length)
        },
        dataMerge: function (n) {
            var a = this;
            return $.each(n, function (e, t) {
                a.config[e] instanceof Object ? $.extend(a.config[e], n[e]) : a.config[e] = n[e]
            }), a.config
        },
        reload: function () {
            window.location.reload(true)
        },
        timeFormat: function (e) {
            if (0 === e) return e;
            var t = new Date(1e3 * e);
            return t.getFullYear() + "-" + (t.getMonth() + 1) + "-" + (1 === t.getDate().toString().length ? "0" + t.getDate().toString() : t.getDate()) + "   " + (1 === t.getHours().toString().length ? "0" + t.getHours().toString() : t.getHours()) + ":" + (1 === t.getMinutes().toString().length ? "0" + t.getMinutes().toString() : t.getMinutes()) + ":" + (1 === t.getSeconds().toString().length ? "0" + t.getSeconds().toString() : t.getSeconds())
        },
        getCookie: function (e) {
            return login.getCookie(e)
        },
        setCookie: function (e, t, n, a) {
            login.setCookie(e, t, n, a)
        },
        removeCookie: function (e) {
            this.setCookie(e, "", "/", 0)
        },
        userData: function (e) {
            return login.userData(e)
        },
        isLogin: function () {
            return !!this.userData("")
        },
        ajax: function (e, t, n, a, i, s, c) {
            return login.ajax(e, t, n, a, i, s, c);
        }
    }
}(window);