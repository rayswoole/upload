!function() {
    "use strict";
    var t, e;
    t = window, e = function e() {
        this.options = {
            elem: "test-editor",
            width: "90%",
            height: 740,
            path: "/static/js/editor/lib/",
            theme: "default",
            previewTheme: "default",
            editorTheme: "default",
            codeFold: !0,
            saveHTMLToTextarea: !0,
            searchReplace: !0,
            htmlDecode: "style,script,iframe|on*",
            emoji: !0,
            taskList: !0,
            tocm: !0,
            tex: !0,
            flowChart: !0,
            sequenceDiagram: !0,
            imageUpload: !0,
            imageFormats: [ "jpg", "jpeg", "gif", "png", "bmp", "webp" ],
            imageUploadURL: "/document/index/upload",
            onload: function() {}
        };
    }, e.prototype.init = function() {
        var o = this, n = this;
        this.config = $.extend({
            config_url: "",
            script_url: {
                editor_js: "/static/js/editor/editormd.min.js",
                editor_css: "/static/js/editor/css/editormd.css",
                layui_js: "https://www.layuicdn.com/layui/layui.all.js"
            }
        }, t.$editor_config, {}), this.promist = new Promise(function(t, e) {
            var i = function i() {
                "undefined" == typeof editormd && n._script.load(n.config.script_url.editor_js, function() {
                    layui.link(n.config.script_url.editor_css), t("成功");
                });
            };
            "undefined" == typeof layui || "undefined" == typeof layer ? o._script.load(o.config.script_url.layui_js, function() {
                i();
            }) : i();
        }), console.log("初始化载入完毕");
    }, e.prototype.render = function(t, i) {
        var o = this;
        this.init(), t = t || this._options(), this.options = $.extend(this.options, t, {}),
            this.promist.then(function(t) {
                var e = editormd(o.options.elem, o.options);
                i = i || function(){};
                i(e, o), layui.link("/static/js/editor/doc.css"), console.log(t);
            })["catch"](function(t) {
                console.log("初始化失败");
                console.log(t);
            });
    }, e.prototype._options = function() {
        return this._ajax(this.config.config_url, {}, function(t) {
            return t.data;
        });
    }, e.prototype._ajax = function(t, e, i, o, n, s) {
        i = i || function(t) {
            layer.msg(t.msg);
        }, o = o || function(t) {
            layer.msg(t.statusText);
        }, n = n || "get", s = s || "json", e = e || {}, $.ajax({
            url: t,
            dataType: s,
            type: n,
            data: e,
            headers: {},
            success: function(t) {
                i(t);
            },
            error: function(t) {
                o(t);
            }
        });
    }, e.prototype._script = {
        isInclude: function(t) {
            for (var e = /js$/i.test(t), i = document.getElementsByTagName(e ? "script" : "link"), o = 0; o < i.length; o++) if (-1 !== i[o][e ? "src" : "href"].indexOf(t)) return !0;
            return !1;
        },
        isLoad: function(t) {
            return void 0 !== t;
        },
        load: function(t, i) {
            this.isInclude(t) || (i = i || new Function(), $.getScript(t, function(t, e) {
                i(t, e);
            }));
        },
        css: function(t) {
            var e = document.createElement("link");
            e.type = "text/css", e.rel = "stylesheet", e.href = t, document.getElementsByTagName("head")[0].appendChild(e);
        }
    }, t.editor = new e();
}("undefined" == typeof editor && (editor = {}));