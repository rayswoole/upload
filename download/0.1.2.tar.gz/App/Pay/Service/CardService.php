<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-08-27 15:35
 ** ----------------------------------------------------------------------
 **/

namespace App\Pay\Service;

use rayswoole\orm\facade\Db;
use rayswoole\Service;
use rayswoole\utils\Validators;

class CardService extends Service
{

    /**
     * 字段验证
     * @param array $param
     * @param array $data
     * @return array
     * @author zhou
     * @time 2020/11/18
     */
    public static function checkVar(array &$param, array $data): array
    {
        foreach ($data as $k => $v) {
            if (empty($param[$k]) && !is_numeric($param[$k])) {
                if (!($v[2] ?? false)) {
                    return ['status' => false, 'msg' => $v[1]];
                }
                continue;
            }
            if (false === Validators::is($param[$k], $v[0])) {
                return ['status' => false, 'msg' => $v[1]];
            }
        }
        return ['status' => true, 'msg' => '验证通过'];
    }

    public function getData($param)
    {
        $page = isset($param['page']) ? (int)$param['page'] : 1;
        $limit = isset($param['limit']) ? (int)$param['limit'] : 10;
        $where = [];

        if (isset($param['key'])) {
            $key = $param['key'];
            if (isset($key['searchName']) && $key['searchName']) {
                $v = $key['searchName'];
                $where[] = ['card_no|card_money', 'like',"%{$v}%"];
            }
        }

        $res = Db::name('pay_card')->where($where)->order('card_id','ASC')->page(($page-1)*$limit,$limit)->select()->toArray();
        return [
            'code' => 0,
            'msg' => '充值卡列表',
            'count' => count($res),
            'data' => $res
        ];

    }

    public function saveCard($param)
    {
        $data = [
            "card_num"   => intval($param['card_num']),
            "card_money" => intval($param['card_money']),
            "card_points"=> intval($param['card_points']),
            "role_no"    => htmlspecialchars($param['role_no']),
            "role_pas"   => htmlspecialchars($param['role_pas']),
        ];

        for($i=1;$i<=$data['card_num'];$i++){
            $card_no  = $this->getRndstr(16,$data['role_no']);
            $card_pwd = $this->getRndstr(8,$data['role_pas']);
            $data2[$card_no] = [
                'card_no'   =>$card_no,
                'card_pwd'  =>$card_pwd,
                'card_money'=>$data['card_money'],
                'card_points'=>$data['card_points'],
                'card_addtime'=>time(),
            ];
        }
        $data3 = array_values($data2);
        $res = Db::name('pay_card')->insertAll($data3);

        if (!(bool)$res) {
            return ['code' => 1, 'msg' => '保存失败', 'result' => []];
        }
        return ['code' => 0, 'msg' => '保存成功', 'result' => []];
    }








    /**
     * 卡号生成原则
     * @param int $length
     * @param string $f
     * @return string
     */
    public function getRndstr($length=32,$f='')
    {
        $pattern = "234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        if($f=='num'){
            $pattern = '1234567890';
        }
        elseif($f=='letter'){
            $pattern = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        }
        $len = strlen($pattern) -1;
        $res='';
        for($i=0; $i<$length; $i++){
            $res .= $pattern{mt_rand(0,$len)};
        }
        return $res;
    }

}