<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-23 14:54
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Service;

use App\Vod\Extend\Common;
use rayswoole\Helper;
use rayswoole\utils\Validators;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class VodService extends Service
{
    public function get(int $id)
    {
        $result = Db::name('vod')->find($id);
        if (!$result){
            return null;
        }
        $result['vod_play_list'] = $this->urlList($result['vod_play_url'],$result['vod_play_from']);
        $result['type'] = TypeService::getInstance()->get($result['type_id']);
        return $result;
    }


    /**
     * 表单数据验证
     * @param array $param
     * @param array $data
     * @return array
     * @author zhou
     * @time 2020/11/5
     */
    public function checkVar(array &$param, array $data): array
    {
        foreach ($data as $k => $v) {
            if (empty($param[$k]) && !is_numeric($param[$k])) {
                if (!($v[2] ?? false)) {
                    return ['status' => false, 'msg' => $v[1]];
                }
                continue;
            }
            if (false === Validators::is($param[$k], $v[0])) {
                return ['status' => false, 'msg' => $v[1]];
            }
        }
        return ['status' => true, 'msg' => '验证通过'];
    }

    /**
     * 电影分类
     * @return mixed
     * @author zhou
     * @time 2020/11/5
     */
    public function getVodType()
    {
        $where = ['type_mid' => 1];
        $ordey = 'type_id';
        $by = 'DESC';
        $res2 = $this->getList($where, $ordey, $by, '*');
        $typeList = json_encode($res2);
        $list = json_decode($typeList, true);
        return $this->ray_list_to_tree($list['data'], 'type_id', 'type_pid');

    }
    //视频字段保存
    public function saveVod($param)
    {
        $data = [
            "type_id"       => $param['type_id'],
            "vod_title"     => trim($param['vod_title']),
            "lang_tail_id"  => isset($param['lang_tail_id']) ? $param['lang_tail_id'] : 0,
            "vod_letter"    => $param['vod_letter'],
            "vod_class"     => trim($param['vod_class']),
            "vod_lang"      => $param['vod_lang'],
            //"vod_score" => intval($param['vod_score']),
            "vod_year"      =>$param['vod_year'],
            "vod_area"      => $param['vod_area'],
            "vod_total"     => $param['vod_total'],
            "vod_serial"    => $param['vod_serial'],
            "vod_actor"     => str_replace('创建-', '', $param['vod_actor']),
            "vod_actor_val" => $param['vod_actor_val'],  //待处理 vod和collect  传过来的值不一样
            "vod_director"  => $param['vod_director'],
            "vod_remarks"   => $param['vod_remarks'],
            "vod_status"    => isset($param['vod_status']) ? 1 : 0,
            "vod_pic"       => $param['vod_pic'],
            "vod_content"   => $param['vod_content'],
            "vod_hits"      => $param['vod_hits'],
            "vod_hits_month"=> $param['vod_hits_month'],
            "vod_hits_week" => $param['vod_hits_week'],
            "vod_hits_day"  => $param['vod_hits_day'],
            'vod_play_from' => trim($param['vod_play_from']),
            'vod_play_url'  => trim($param['vod_play_url']),
            'vod_addtime'   => trim($param['vod_addtime']) ?? time(),

            "vod_sort"      => $param['vod_sort'] ?? '', //vod
            "vod_blurb"     => Common::ray_substring(strip_tags($param['vod_content']),100,0),
            "vod_pic_thumb" => $param['vod_pic_thumb'] ?? '', //vod
            "vod_jumpurl"   => $param['vod_jumpurl']  ?? '', //vod
            "vod_jumpstatus"=> isset($param['vod_jumpstatus']) ? 1 : 0, //vod
            "vod_duration"  => $param['vod_duration']  ?? '', //vod
            "vod_score"     => $param['vod_score'] ?? rand(3,8),//vod
            "vod_star"      => $param['vod_star']  ?? '', //vod
            "vod_color"     => $param['vod_color'] ?? '', //vod
            'vod_play_server'=>$param['vod_play_server'] ?? '',
        ];
        if (isset($param['vod_id'])){
            $data['vod_id'] = $param['vod_id'];
            Db::name('vod')->update($data);
        } else {
            $res = Db::name('vod')->insert($data, true);
            if ((int)$res > 0) {
                return ['code' => 0, 'msg' => '保存成功', 'result' => ['id'=>$res]];
            } else {
                return ['code' => 1, 'msg' => '保存失败', 'result' => []];
            }
        }
        return ['code' => 0, 'msg' => '保存成功', 'result' => []];

    }

    //采集保存
    public function saveCollect(array $param)
    {
        $data = [
            "type_id"       => $param['type_id'],
            "vod_score"     => rand(3,8),
            "vod_title"     => trim($param['vod_title']),
            "vod_letter"    => $param['vod_letter'],
            "vod_class"     => trim($param['vod_class']),
            "vod_lang"      => $param['vod_lang'],
            //"vod_score" => intval($param['vod_score']),
            "vod_year"      =>$param['vod_year'],
            "vod_area"      => $param['vod_area'],
            "vod_total"     => $param['vod_total'],
            "vod_serial"    => $param['vod_serial'],
            "vod_actor"     => str_replace('创建-', '', $param['vod_actor']['actor']),
            "vod_actor_val" => $param['vod_actor']['actor_val'],
            "vod_director"  => $param['vod_director'],
            "vod_remarks"   => $param['vod_remarks'],
            "vod_status"    => isset($param['vod_status']) ? 1 : 0,
            "vod_pic"       => $param['vod_pic'],
            "vod_content"   => $param['vod_content'],
            "vod_hits"      => $param['vod_hits'],
            "vod_hits_month"=> $param['vod_hits_month'],
            "vod_hits_week" => $param['vod_hits_week'],
            "vod_hits_day"  => $param['vod_hits_day'],
            'vod_play_from' => trim($param['vod_play_from']),
            'vod_play_url'  => trim($param['vod_play_url']),
            'vod_addtime'   => trim($param['vod_addtime']),
        ];
        if (isset($param['vod_id'])){
            $data['vod_id'] = $param['vod_id'];
            Db::name('vod')->update($data);
        } else {
            $res = Db::name('vod')->insert($data, true);
            if ((int)$res <= 0) {
                return ['code' => 1, 'msg' => '保存失败', 'result' => ['id'=>$res]];
            }
        }
        return ['code' => 0, 'msg' => '保存成功', 'result' => []];
    }

    //播放url 处理
    public function playUrlList($playurl)
    {
        $url_list = array();
        $array_url = explode('#', $playurl);

        foreach ($array_url as $key => $val) {
            if (empty($val)) continue;

            list($title, $url) = explode('$', $val);
            if (empty($url)) {
                $url_list[$key + 1]['name'] = '第' . ($key + 1) . '集';
                $url_list[$key + 1]['url'] = $title;
            } else {
                $url_list[$key + 1]['name'] = $title;
                $url_list[$key + 1]['url'] = $url;

            }
            $url_list[$key + 1]['nid'] = $key + 1;
        }

        return $url_list;
    }

    //前端播放器处理
    public function urlList($play_url,$play_from)
    {
        $player_list = PlayerService::getInstance()->getPlayerList();
        $url_list = array();
        $vod_play_from_list = explode('$$$', $play_from);
        $vod_play_url_list  = explode('$$$', $play_url);

        $play=[];
        foreach ($vod_play_from_list as $k=>$v) {
            if (!isset($player_list[$v])){
                continue;
            }
            $array_url = explode('#', $vod_play_url_list[$k]);
            $k++;
            foreach ($array_url as $key => $val) {
                $key++;
                if (empty($val)) continue;
                $arr = explode('$', $val);
                if (!isset($arr[1])){
                    $url_list[$key]['name'] = '第' . $key . '集';
                    $url_list[$key]['url'] = $arr[0];
                } else {
                    $url_list[$key]['name'] = $arr[0];
                    $url_list[$key]['url'] = $arr[1];
                }
                $url_list[$key]['from'] = $arr[2] ?? '';
                $url_list[$key]['nid'] = $key;

            }
            $play[$k]['player_info']=$player_list[$v];
            $play[$k]['sid']=$k;
            $play[$k]['from']=$v;
            $play[$k]['url_count']=count($array_url);
            $play[$k]['urls']=$url_list;
        }

        return $play;

    }




//长尾关健词
    public function getKeywords2($k=''){

        if($arr = $this->getKeywords($k)){
            foreach ($arr as $k => $v) {
                $data[$k]['lang_keyword'] = $v;
                $data[$k]['lang_parent_id'] = 1;
                if ($_data = $this->getKeywords($v)){
                    $arr = array_merge($arr, $_data);
                }
            }
            $arr  = array_unique($arr);

            if (!empty($arr)){
                return $arr;
            }
        }
    }


    //关健字查询百度长尾词
    public function getKeywords($kw='')
    {
        $key_word = urlencode($kw);//需要对关键词进行url解析,否者部分带字符的标题会返回空
        $url = 'https://www.baidu.com/s?ie=UTF-8&wd='.$key_word;
        //curl获取数据
        $res = $this->curl_request($url);

        //正则处理获取数据
        $match=[];

        if(strpos($res, '相关搜索</div>')){
            $reach_word = substr($res,strpos($res, '相关搜索</div>'),strpos($res, '<div class="page-inner">')-strpos($res, '相关搜索</div>') );//截取需要的内容
            preg_match_all('/<a.*?>(.*?)<\/a>/', $reach_word,$match);//正则匹配第一个搜索词
        }

        return $match[1] ?? null;
    }


//curl获取百度内容
    function curl_request($url, $data=null, $method='get', $https=true){
        $ch = curl_init();//初始化
        curl_setopt($ch, CURLOPT_URL, $url);//访问的URL
        curl_setopt($ch, CURLOPT_HEADER, false);//设置不需要头信息
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);//只获取页面内容，但不输出
        if($https){
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);//https请求 不验证证书
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);//https请求 不验证HOST
        }
        curl_setopt($ch,CURLOPT_ENCODING,'gzip');//百度返回的内容进行了gzip压缩,需要用这个设置解析
        //curl模拟头部信息
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: */*',
            'Accept-Encoding: gzip, deflate, br',
            'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
            'Connection: keep-alive',
            'Host: www.baidu.com',
            'is_referer: https://www.baidu.com/',
            'is_xhr: 1',
            'Referer: https://www.baidu.com/',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36',
            'X-Requested-With: XMLHttpRequest',
        ));
        if($method == 'post'){
            curl_setopt($ch, CURLOPT_POST, true);//请求方式为post请求
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);//请求数据
        }
        $result = curl_exec($ch);//执行请求
        curl_close($ch);//关闭curl，释放资源
        $result = mb_convert_encoding($result, 'utf-8', 'GBK,UTF-8,ASCII,gb2312');//百度默认编码是gb2312 这个设置转化为utf8编码
        return $result;
    }


























}