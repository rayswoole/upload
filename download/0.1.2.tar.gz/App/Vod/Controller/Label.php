<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-10 16:40
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Controller;

use rayswoole\Helper;
use App\Vod\Extend\Common;
use rayswoole\Context;

class Label extends Base
{
    public function index()
    {
         $this->fetch('label/top', false);

    }

    public function top()
    {

        $param = Common::ray_param_url();
        Context::set('param',$param);
        $html =$this->fetch('label/top', false);
        return Helper::responseHtml($html);
    }

    public function new()
    {
        $param = Common::ray_param_url();
        Context::set('param',$param);
        $html =$this->fetch('label/new', false);
        return Helper::responseHtml($html);
    }

    public function tv()
    {
        $param = Common::ray_param_url();
        Context::set('param',$param);
        $html =$this->fetch('label/tv', false);
        return Helper::responseHtml($html);
    }

    public function dy()
    {
        $param = Common::ray_param_url();
        Context::set('param',$param);
        $html =$this->fetch('label/dy', false);
        return Helper::responseHtml($html);
    }

    public function zy()
    {
        $param = Common::ray_param_url();
        Context::set('param',$param);
        $html =$this->fetch('label/zy', false);
        return Helper::responseHtml($html);
    }

    public function dm()
    {
        $param = Common::ray_param_url();
        Context::set('param',$param);
        $html =$this->fetch('label/dm', false);
        return Helper::responseHtml($html);
    }

}