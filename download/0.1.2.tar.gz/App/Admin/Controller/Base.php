<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01 10:00
 ** ----------------------------------------------------------------------
 **/

namespace App\Admin\Controller;


use rayswoole\auth\config\Config;
use rayswoole\auth\facade\Auth;
use rayswoole\Helper;
use rayswoole\HttpController;
use rayswoole\orm\facade\Db;
use rayswoole\session\Session;


class Base extends HttpController
{
    protected function onRequest(?string $action): ?bool
    {
        Session::getInstance()->start();
        // 權限校驗
        Auth::getInstanceCoroutine()->init(Config::getInstance()->init([
            'user' => Db::name('admin')->select()->toArray(),
            'user_role' => Db::name('user_role')->select()->toArray(),
            'role_node' => Db::name('role_menu')->select()->toArray(),
            'role' => Db::name('role')->select()->toArray(),
            'node' => Db::name('node')->select()->toArray(),
            'no_check_path' => [
                'admin/login/index',
                'admin/login/check',
                'admin/login/verify',
            ]
        ]));
        // 检测
        $classRealPath = explode('\\', static::class);
        unset($classRealPath[0], $classRealPath[2]);
        $classRealPath[] = $action;
        $path = strtolower(implode('/', $classRealPath));
        if (!in_array($path, Auth::getInstanceCoroutine()->getNotCheckPath(), true)) {
            if (!Session::check('nickname')) {
                if (Helper::appName() !== 'Admin') {
                    if ($this->isAjax()){
                        Helper::responseJson(['code'=>0, 'msg'=>'请重新登录']);
                    } else {
                        Helper::responseHtml('请重新登录');
                    }
                } else {
                    Helper::responseRedirect('admin@login/index');
                }
                return false;
            }
            $uid = Session::get('id');
            if (!Auth::getInstanceCoroutine()->check($uid, $path)) {
                Helper::responseJson(['msg' => '没有权限']);
                return false;
            }
            $this->assign([
                'left_node' => Auth::getInstanceCoroutine()->getPerInfo($uid, \rayswoole\auth\Auth::POSITION_LEFT, true),
                'top_node' => Auth::getInstanceCoroutine()->getPerInfo($uid, \rayswoole\auth\Auth::POSITION_TOP)
            ]);
        }
        $this->userinfo();
        return true;
    }


    protected function userinfo(): void
    {
        $this->assign(['userinfo' => Session::all()]);
    }

}