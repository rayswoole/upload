<?php /*a:4:{s:68:"/var/wwwroot/rayswoole2.1/Public/skin/shuang11/html/index/index.html";i:1607485835;s:71:"/var/wwwroot/rayswoole2.1/Public/skin/shuang11/html/public/include.html";i:1607427427;s:68:"/var/wwwroot/rayswoole2.1/Public/skin/shuang11/html/public/head.html";i:1607427427;s:68:"/var/wwwroot/rayswoole2.1/Public/skin/shuang11/html/public/foot.html";i:1607427427;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $raycms['site_name']; ?></title>
    <meta name="keywords" content="<?php echo $raycms['site_keywords']; ?>" />
    <meta name="description" content="<?php echo $raycms['site_description']; ?>" />
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $raycms['path_tpl']; ?>static/favicon.png">
<link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/swiper/swiper.css">
<link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/css/common.css">
<script>var raycms={"path":"","mid":"<?php echo $raycms['mid']; ?>","url":"<?php echo $raycms['site_pc_url']; ?>","wapurl":"<?php echo $raycms['site_wap_url']; ?>","mob_status":"<?php echo $raycms['mob_status']; ?>","css":"<?php echo $raycms['path_tpl']; ?>static/"};</script>
<script src="<?php echo $raycms['path_tpl']; ?>static/js/jquery.min.js"></script>
<script src="<?php echo $raycms['path_tpl']; ?>static/js/home.js"></script>
<script src="<?php echo $raycms['path_tpl']; ?>static/js/bottom.js"></script>
<script type="text/javascript" src="/static/js/jquery.base.js?t=003"></script>
<script type="text/javascript" src="<?php echo $raycms['path_tpl']; ?>static/swiper/swiper.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/css/index.css">
</head>
<body>
<body class="index">
<script src="/static/js/jquery.base.js?t=01"></script>
<link rel="stylesheet" href="/static/css/home.css">
<header class="header" id="header">
    <div class="container">
        <h1 class="logo"><a href="<?php echo $raycms['path']; ?>" title="<?php echo $raycms['site_name']; ?>"></a></h1>
        <nav class="main-nav swiper-container">
            <ul class="nav-list swiper-wrapper">
                  <li class="nav-item swiper-slide<?php if($raycms['aid'] == 1): ?> active<?php endif; ?>"><a href="<?php echo $raycms['path']; ?>"><i class="fa fa-home"></i>首页</a></li>
				  <?php $__TAG__ = '{"ids":"parent","order":"asc","by":"sort","key":"key"}';$tagType=\App\Vod\Service\TagLibService::getInstance()->hook("tagType",$__TAG__);if(is_array($tagType) || is_object($tagType) || $tagType instanceof \think\Collection ): $key = 0; $__LIST__ = $tagType;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;if($key==1): ?>
                  <li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-film"></i><?php echo $vo['type_name']; ?></a></li>
				   <?php elseif($key==2): ?>
                   <li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-tv"></i><?php echo $vo['type_name']; ?></a></li>
					<?php elseif($key==3): ?>
                    <li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-video-camera"></i><?php echo $vo['type_name']; ?></a></li>
					<?php elseif($key==4): ?>
                    <li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-github-alt"></i><?php echo $vo['type_name']; ?></a></li>
					<?php elseif($key > 4): ?>
					<li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-tv"></i><?php echo $vo['type_name']; ?></a></li>
					<?php endif; ?>
					<?php endforeach; endif; else: echo "" ;endif; ?>
                    <li class="nav-item swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url('label/top'); ?>"><i class="fa fa-list-alt"></i>排行榜</a></li>
                    <li class="nav-item swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url('label/new'); ?>"><i class="fa fa-window-maximize"></i>最近更新</a></li>
            </ul>
        </nav>
        <div class="search-container">
        <ul class="right-wrap">
            <li class="user-wrap hidden-xs"><a href="<?php echo \rayswoole\Helper::url('user@index/index'); ?>"><i class="fa fa-user-o login-btn" title="登录账户"></i><em>登录账户</em></a></li>
        </ul>
            <div class="search-wrapper">
			    <form id="search" name="search" method="get" action="<?php if($raycms['mid']==8): ?><?php echo \App\Vod\Extend\Common::ray_url('vod@actor/index'); elseif($raycms['mid']==2): ?><?php echo \App\Vod\Extend\Common::ray_url('art@search/index'); else: ?><?php echo \App\Vod\Extend\Common::ray_url('vod@search/index'); ?><?php endif; ?>" onSubmit="return qrsearch();">
                <input type="text" name="wd" id="wd" class="search-input keywords ray_wd" value="<?php echo (isset($param['wd']) && ($param['wd'] !== '')?$param['wd']:''); ?>" placeholder="<?php if(($raycms['aid'] == 13)): ?><?php echo (isset($param['wd']) && ($param['wd'] !== '')?$param['wd']:''); ?><?php echo (isset($param['actor']) && ($param['actor'] !== '')?$param['actor']:''); ?><?php echo (isset($param['director']) && ($param['director'] !== '')?$param['director']:''); ?><?php echo (isset($param['area']) && ($param['area'] !== '')?$param['area']:''); ?><?php echo (isset($param['lang']) && ($param['lang'] !== '')?$param['lang']:''); ?><?php echo (isset($param['year']) && ($param['year'] !== '')?$param['year']:''); ?><?php echo (isset($param['class']) && ($param['class'] !== '')?$param['class']:''); else: ?>搜索电影/演员/导演<?php endif; ?>" />
				<button type="submit" id="searchbutton" class="sbt ray_search"><i class="fa fa-search"></i></button>
            </form>
            </div>
			</div>

    </div>
</header>
<main class="main main_index">
    <!--幻灯模块-->

    <section class="lunbotu">
        <div class="container">
            <div class="layout-box clearfix">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <div class="swiper-container box-slide">
                        <div class="swiper-wrapper">
                            <?php $__TAG__ = '{"num":"5","order":"desc","by":"time"}';$tagVod=\App\Vod\Service\TagLibService::getInstance()->hook("tagVod",$__TAG__);if(is_array($tagVod) || is_object($tagVod) || $tagVod instanceof \think\Collection ): $key = 0; $__LIST__ = $tagVod;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;?>
                            <div class="swiper-slide">
                                <div class="box-video-slide">
                                    <a class="slide-pic swiper-lazy" href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_title']; ?>" data-background="<?php echo \App\Vod\Extend\Common::ray_url_img($vo['vod_pic']); ?>" style="padding-top:60%;background-position:50% 50%;background-size:cover;">
                                        <span class="slide-title"><?php echo $vo['vod_title']; ?></span><div class="swiper-lazy-preloader"></div></a>
                                </div>
                            </div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                        <div class="swiper-button-next hidden-xs"><span class="glyphicon glyphicon-chevron-right"></span></div>
                        <div class="swiper-button-prev hidden-xs"><span class="glyphicon glyphicon-chevron-left"></span></div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>


                <div class="col-lg-5 col-md-6 col-sm-12 p-0 hidden visible-md-block visible-lg-block">
                    <div class="index-menu clearfix">
                        <div class="item">
                            <ul class="clearfix">
                                <li class="hidden-sm hidden-xs"><a href="" title="全部影片"><i class="icon iconfont text-color">&#xe641;</i><span>全部影片</span></a></li>
                                <li><a href="<?php echo \App\Vod\Extend\Common::ray_url('label/top'); ?>" title="影片排行"><i class="icon iconfont text-color">&#xe613;</i><span>影片排行</span></a></li>
                                <li><a href="<?php echo \App\Vod\Extend\Common::ray_url('label/new'); ?>" title="最近更新"><i class="icon iconfont text-color">&#xe626;</i><span>最近更新</span></a></li>
                                <li><a href="<?php echo \App\Vod\Extend\Common::ray_url_topic_index(); ?>" title="专题合集"><i class="icon iconfont text-color">&#xe66d;</i><span>专题合集</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix hidden-xs">
                        <div class="box-title">
                            <h3 class="m-0"><i class="icon iconfont text-color">&#xe60e;</i>新闻头条</h3>
                        </div>
                        <div class="box-video-text-list clearfix">
                            <ul>
                                <?php $__TAG__ = '{"num":"12","order":"desc","by":"time"}';$tagArt=\App\Vod\Service\TagLibService::getInstance()->hook("tagArt",$__TAG__);if(is_array($tagArt) || is_object($tagArt) || $tagArt instanceof \think\Collection ): $key = 0; $__LIST__ = $tagArt;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;?>
                                <li class="list2 text-overflow<?php if(($key > 10)): ?> layout-xx<?php endif; ?>">
                                    <em class="key"><?php echo $key; ?>.</em><a href="<?php echo \App\Vod\Extend\Common::ray_url_art_detail($vo); ?>" title="<?php echo $vo['art_title']; ?>"><?php echo $vo['art_title']; ?></a>
                                </li>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
    </section>

    <!-- 广告展示 -->
    <section class="ys-recommend clearfix">
        <div class="container">
            <div class="new-up card-wrap">
                <div class="title clearfix">
                    <h2 class="theme">广告展示</h2>
                </div>
                <div class="content clearfix">
                    <?php $__TAG__ = '{"num":"5"}';$tagAds=\App\Vod\Service\TagLibService::getInstance()->hook("tagAds",$__TAG__);if(is_array($tagAds) || is_object($tagAds) || $tagAds instanceof \think\Collection ): $key = 0; $__LIST__ = $tagAds;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;?>
                    <a style="margin-right: 20px;"><img src="<?php echo $vo['ad_pic']; ?>" width="100" height="60" title="<?php echo $vo['ad_title']; ?>"></a>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
    </section>




    <!-- 影视推荐 -->
    <section class="ys-recommend clearfix">
        <div class="container">
            <div class="new-up card-wrap">
                <div class="title clearfix">
                    <h2 class="theme"><i class="fa fa-flag"></i>影视推荐</h2>
                    <div class="rolling-tips swiper-container">
                        <ul class="swiper-wrapper">
                            <?php $__TAG__ = '{"ids":"1","order":"asc","by":"sort","id":"vo1","key":"key1"}';$tagType=\App\Vod\Service\TagLibService::getInstance()->hook("tagType",$__TAG__);if(is_array($tagType) || is_object($tagType) || $tagType instanceof \think\Collection ): $key1 = 0; $__LIST__ = $tagType;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo1): $mod = ($key1 % 2 );++$key1;?>
                            <li class="swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo1); ?>" class="today-up fr" target="_blank">现已收录影视资源 <?php echo \App\Vod\Extend\Common::ray_data_count(1,'all'); ?> 个</a></li>
                            <li class="swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo1); ?>" class="today-up fr" target="_blank">今日更新影视资源 <?php echo \App\Vod\Extend\Common::ray_data_count(1,'today'); ?> 个</a></li>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="content clearfix">
                    <ul class="new-up-list lazy-load-list ys-list">
                        <?php $__TAG__ = '{"num":"8","cache":"60","order":"desc","by":"time"}';$tagVod=\App\Vod\Service\TagLibService::getInstance()->hook("tagVod",$__TAG__);if(is_array($tagVod) || is_object($tagVod) || $tagVod instanceof \think\Collection ): $key = 0; $__LIST__ = $tagVod;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;?>
                        <li class="item<?php if($key==7): ?> hidex-3<?php elseif($key==8): ?> showx-2 hide-0<?php endif; ?>">
                            <div class="item-con">
                                <span class="state"><em><?php if(empty($vo['vod_remarks']) || (($vo['vod_remarks'] instanceof \think\Collection || $vo['vod_remarks'] instanceof \think\Paginator ) && $vo['vod_remarks']->isEmpty())): ?><?php echo $vo['vod_serial']; else: ?><?php echo $vo['vod_remarks']; ?><?php endif; ?></em></span>
                                <a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" class="thumb" title="<?php echo $vo['vod_title']; ?> <?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?>" target="_blank"><img class="lazyload" data-original="<?php echo \App\Vod\Extend\Common::ray_url_img($vo['vod_pic']); ?>" alt="<?php echo $vo['vod_title']; ?>"><span class="hot"><b><?php echo \App\Vod\Extend\Common::ray_substring($vo['vod_hits_day'],2); ?></b><i>°C</i></span></a>
                                <h5 class="subject" title="<?php echo $vo['vod_title']; ?> <?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" target="_blank"><b><?php echo $vo['vod_title']; ?></b></a><span class="update"><?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?></span></h5>
                                <a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" class="info-layer">
                                    <p class="tags" title="<?php echo $vo['vod_class']; ?>"><label>类型：</label><?php echo $vo['vod_class']; ?></p>
                                    <p class="year" title="<?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)"><label>上映：</label><?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)</p>
                                    <p class="area" title="<?php echo $vo['vod_area']; ?>"><label>地区：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_area'],'未知'); ?></p>
                                    <p class="director" title="<?php echo $vo['vod_director']; ?>"><label>导演：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_director'],'未知'); ?></p>
                                    <p class="performer" title="<?php echo $vo['vod_actor']; ?>"><label>主演：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_actor'],'未知'); ?></p>
                                </a>
                            </div>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </div>
            </div>
    </section>
    <?php $__TAG__ = '{"ids":"1,2","order":"desc","by":"sort","id":"vo1","key":"key1"}';$tagType=\App\Vod\Service\TagLibService::getInstance()->hook("tagType",$__TAG__);if(is_array($tagType) || is_object($tagType) || $tagType instanceof \think\Collection ): $key1 = 0; $__LIST__ = $tagType;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo1): $mod = ($key1 % 2 );++$key1;?>
    <!-- <?php echo $vo1['type_name']; ?> -->
    <section class="new-hot-up clearfix">
        <div class="container">
            <aside class="left-content">
                <div class="new-up card-wrap">
                    <div class="title clearfix">
                        <h2 class="theme"><i class="fa <?php if(($key == 1)): ?>fa-video-camera<?php else: ?>fa-github-alt<?php endif; ?>"></i><?php echo $vo1['type_name']; ?></h2>
                        <div class="rolling-tips swiper-container">
                            <ul class="swiper-wrapper">
                                <li class="swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo1); ?>" class="today-up fr" target="_blank">今日更新<?php echo $vo1['type_name']; ?> <?php echo \App\Vod\Extend\Common::ray_data_count($vo1['type_id'],'all'); ?> 部</a></li>
                                <li class="swiper-slide"><em class="today-up fr">本站网址：<?php echo $raycms['site_pc_url']; ?></em></li>
                                <li class="swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo1); ?>" class="today-up fr" target="_blank">豆瓣优片库，万部<?php echo $vo1['type_name']; ?>在线选 <i class="fa fa-arrow-right"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="content clearfix">
                        <ul class="new-up-list lazy-load-list dianshiju-list">
                            <?php $__TAG__ = '{"num":"12","type":"'.$vo1['type_id'].'","order":"desc","by":"time"}';$tagVod=\App\Vod\Service\TagLibService::getInstance()->hook("tagVod",$__TAG__);if(is_array($tagVod) || is_object($tagVod) || $tagVod instanceof \think\Collection ): $key = 0; $__LIST__ = $tagVod;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;?>
                            <li class="item<?php if($key > 10): ?> showx-2 hide-0<?php endif; ?>">
                                <div class="item-con">
                                    <span class="state"><em><?php if(empty($vo['vod_remarks']) || (($vo['vod_remarks'] instanceof \think\Collection || $vo['vod_remarks'] instanceof \think\Paginator ) && $vo['vod_remarks']->isEmpty())): ?><?php echo $vo['vod_serial']; else: ?><?php echo $vo['vod_remarks']; ?><?php endif; ?></em></span>
                                    <a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" class="thumb" title="<?php echo $vo['vod_title']; ?> <?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?>" target="_blank"><img class="lazyload" data-original="<?php echo \App\Vod\Extend\Common::ray_url_img($vo['vod_pic']); ?>" alt="<?php echo $vo['vod_title']; ?>"><span class="hot"><b><?php echo \App\Vod\Extend\Common::ray_substring($vo['vod_hits_day'],2); ?></b><i>°C</i></span></a>
                                    <h5 class="subject" title="<?php echo $vo['vod_title']; ?> <?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" target="_blank"><b><?php echo $vo['vod_title']; ?></b></a><span class="update"><?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?></span></h5>
                                    <a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" class="info-layer">
                                        <p class="tags" title="<?php echo $vo['vod_class']; ?>"><label>类型：</label><?php echo $vo['vod_class']; ?></p>
                                        <p class="year" title="<?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)"><label>上映：</label><?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)</p>
                                        <p class="area" title="<?php echo $vo['vod_area']; ?>"><label>地区：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_area'],'未知'); ?></p>
                                        <p class="director" title="<?php echo $vo['vod_director']; ?>"><label>导演：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_director'],'未知'); ?></p>
                                        <p class="performer" title="<?php echo $vo['vod_actor']; ?>"><label>主演：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_actor'],'未知'); ?></p>
                                    </a>
                                </div>
                            </li>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>

                    </div>
                </div>
            </aside>
            <aside class="right-side">
                <div class="hot-up card-wrap">
                    <div class="title clearfix">
                        <h3 class="theme"><em class="after-dot"><?php echo $vo1['type_name']; ?></em>新播榜</h3>
                        <a href="<?php if(($key1 == 1)): ?><?php echo \App\Vod\Extend\Common::ray_url('label/tv'); else: ?><?php echo \App\Vod\Extend\Common::ray_url('label/dy'); ?><?php endif; ?>" title="新热<?php echo $vo1['type_name']; ?>榜TOP100" class="more more-arrow" target="_blank">TOP100</a>
                    </div>
                    <div class="content">
                        <ul class="list">
                            <?php $__TAG__ = '{"num":"10","type":"'.$vo1['type_id'].'","order":"desc","by":"hits_day"}';$tagVod=\App\Vod\Service\TagLibService::getInstance()->hook("tagVod",$__TAG__);if(is_array($tagVod) || is_object($tagVod) || $tagVod instanceof \think\Collection ): $key = 0; $__LIST__ = $tagVod;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;if(($key == 1)): ?><li class="item"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_title']; ?>" target="_blank"><i class="num">1</i><span class="subject"><em class="ellipsis-one"><?php echo $vo['vod_title']; ?></em> <i class="douban_score"><?php if(empty($vo['vod_remarks']) || (($vo['vod_remarks'] instanceof \think\Collection || $vo['vod_remarks'] instanceof \think\Paginator ) && $vo['vod_remarks']->isEmpty())): ?><?php echo $vo['vod_serial']; else: ?><?php echo $vo['vod_remarks']; ?><?php endif; ?></i></span><em class="hot"><?php echo \App\Vod\Extend\Common::ray_substring($vo['vod_hits_day'],2); ?>°C</em>
                            <div class="more-details">
                                <img data-original="<?php echo \App\Vod\Extend\Common::ray_url_img($vo['vod_pic']); ?>" class="movie_thumb lazyload" title="<?php echo $vo['vod_title']; ?>" alt="<?php echo $vo['vod_title']; ?>">
                                <div class="info clearfix">
                                    <p>类型：<?php echo $vo['vod_class']; ?></p>
                                    <p>地区：<?php echo $vo['vod_area']; ?></p>
                                    <p>上映：<?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)</p>
                                    <p>豆瓣：<?php echo $vo['vod_score']; ?>分</p>
                                </div>
                            </div>
                        </a></li>
                            <?php else: ?>
                            <li class="item"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_title']; ?>" target="_blank"><i class="num"><?php echo $key; ?></i><span class="subject"><em class="ellipsis-one"><?php echo $vo['vod_title']; ?></em> <i class="douban_score"><?php if(empty($vo['vod_remarks']) || (($vo['vod_remarks'] instanceof \think\Collection || $vo['vod_remarks'] instanceof \think\Paginator ) && $vo['vod_remarks']->isEmpty())): ?><?php echo $vo['vod_serial']; else: ?><?php echo $vo['vod_remarks']; ?><?php endif; ?></i></span><em class="hot"><?php echo \App\Vod\Extend\Common::ray_substring($vo['vod_hits_day'],2); ?>°C</em>
                            </a></li>
                            <?php endif; ?>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </div>
                </div>
            </aside>
        </div>
    </section>
    <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"ids":"3,4","order":"asc","by":"sort","id":"vo1","key":"key1"}';$tagType=\App\Vod\Service\TagLibService::getInstance()->hook("tagType",$__TAG__);if(is_array($tagType) || is_object($tagType) || $tagType instanceof \think\Collection ): $key1 = 0; $__LIST__ = $tagType;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo1): $mod = ($key1 % 2 );++$key1;?>
    <section class="new-hot-up clearfix">
        <div class="container">
            <aside class="left-content">
                <div class="new-up card-wrap">
                    <div class="title clearfix">
                        <h2 class="theme"><i class="fa <?php if(($key == 1)): ?>fa-video-camera<?php else: ?>fa-github-alt<?php endif; ?>"></i><?php echo $vo1['type_name']; ?></h2>
                        <div class="rolling-tips swiper-container">
                            <ul class="swiper-wrapper">
                                <li class="swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo1); ?>" class="today-up fr" target="_blank">今日更新<?php echo $vo1['type_name']; ?> <?php echo \App\Vod\Extend\Common::ray_data_count($vo1['type_id'],'all'); ?> 部</a></li>
                                <li class="swiper-slide"><em class="today-up fr">本站网址：<?php echo $raycms['site_pc_url']; ?></em></li>
                                <li class="swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo1); ?>" class="today-up fr" target="_blank">豆瓣优片库，万部<?php echo $vo1['type_name']; ?>在线选 <i class="fa fa-arrow-right"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="content clearfix">
                        <ul class="new-up-list lazy-load-list dianshiju-list">
                            <?php $__TAG__ = '{"num":"12","type":"'.$vo1['type_id'].'","order":"desc","by":"time"}';$tagVod=\App\Vod\Service\TagLibService::getInstance()->hook("tagVod",$__TAG__);if(is_array($tagVod) || is_object($tagVod) || $tagVod instanceof \think\Collection ): $key = 0; $__LIST__ = $tagVod;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;?>
                            <li class="item<?php if($key > 10): ?> showx-2 hide-0<?php endif; ?>">
                                <div class="item-con">
                                    <span class="state"><em><?php if(empty($vo['vod_remarks']) || (($vo['vod_remarks'] instanceof \think\Collection || $vo['vod_remarks'] instanceof \think\Paginator ) && $vo['vod_remarks']->isEmpty())): ?><?php echo $vo['vod_serial']; else: ?><?php echo $vo['vod_remarks']; ?><?php endif; ?></em></span>
                                    <a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" class="thumb" title="<?php echo $vo['vod_title']; ?> <?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?>" target="_blank"><img class="lazyload" data-original="<?php echo \App\Vod\Extend\Common::ray_url_img($vo['vod_pic']); ?>" alt="<?php echo $vo['vod_title']; ?>"><span class="hot"><b><?php echo \App\Vod\Extend\Common::ray_substring($vo['vod_hits_day'],2); ?></b><i>°C</i></span></a>
                                    <h5 class="subject" title="<?php echo $vo['vod_title']; ?> <?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" target="_blank"><b><?php echo $vo['vod_title']; ?></b></a><span class="update"><?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?></span></h5>
                                    <a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" class="info-layer">
                                        <p class="tags" title="<?php echo $vo['vod_class']; ?>"><label>类型：</label><?php echo $vo['vod_class']; ?></p>
                                        <p class="year" title="<?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)"><label>上映：</label><?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)</p>
                                        <p class="area" title="<?php echo $vo['vod_area']; ?>"><label>地区：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_area'],'未知'); ?></p>
                                        <p class="director" title="<?php echo $vo['vod_director']; ?>"><label>导演：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_director'],'未知'); ?></p>
                                        <p class="performer" title="<?php echo $vo['vod_actor']; ?>"><label>主演：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_actor'],'未知'); ?></p>
                                    </a>
                                </div>
                            </li>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>

                    </div>
                </div>
            </aside>
            <aside class="right-side">
                <div class="hot-up card-wrap">
                    <div class="title clearfix">
                        <h3 class="theme"><em class="after-dot"><?php echo $vo1['type_name']; ?></em>新播榜</h3>
                        <a href="<?php if(($key1 == 1)): ?><?php echo \App\Vod\Extend\Common::ray_url('label/zy'); else: ?><?php echo \App\Vod\Extend\Common::ray_url('label/dm'); ?><?php endif; ?>" title="新热<?php echo $vo1['type_name']; ?>榜TOP100" class="more more-arrow" target="_blank">TOP100</a>
                    </div>
                    <div class="content">
                        <ul class="list">
                            <?php $__TAG__ = '{"num":"10","type":"'.$vo1['type_id'].'","order":"desc","by":"hits_day"}';$tagVod=\App\Vod\Service\TagLibService::getInstance()->hook("tagVod",$__TAG__);if(is_array($tagVod) || is_object($tagVod) || $tagVod instanceof \think\Collection ): $key = 0; $__LIST__ = $tagVod;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;if(($key == 1)): ?>
                            <li class="item"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_title']; ?>" target="_blank"><i class="num">1</i><span class="subject"><em class="ellipsis-one"><?php echo $vo['vod_title']; ?></em> <i class="douban_score"><?php if(empty($vo['vod_remarks']) || (($vo['vod_remarks'] instanceof \think\Collection || $vo['vod_remarks'] instanceof \think\Paginator ) && $vo['vod_remarks']->isEmpty())): ?><?php echo $vo['vod_serial']; else: ?><?php echo $vo['vod_remarks']; ?><?php endif; ?></i></span><em class="hot"><?php echo \App\Vod\Extend\Common::ray_substring($vo['vod_hits_day'],2); ?>°C</em>
                                <div class="more-details">
                                    <img data-original="<?php echo \App\Vod\Extend\Common::ray_url_img($vo['vod_pic']); ?>" class="movie_thumb lazyload" title="<?php echo $vo['vod_title']; ?>" alt="<?php echo $vo['vod_title']; ?>">
                                    <div class="info clearfix">
                                        <p>类型：<?php echo $vo['vod_class']; ?></p>
                                        <p>地区：<?php echo $vo['vod_area']; ?></p>
                                        <p>上映：<?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)</p>
                                        <p>豆瓣：<?php echo $vo['vod_score']; ?>分</p>
                                    </div>
                                </div>
                            </a>
                            </li>
                            <?php else: ?>
                            <li class="item"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_title']; ?>" target="_blank"><i class="num"><?php echo $key; ?></i><span class="subject"><em class="ellipsis-one"><?php echo $vo['vod_title']; ?></em> <i class="douban_score"><?php if(empty($vo['vod_remarks']) || (($vo['vod_remarks'] instanceof \think\Collection || $vo['vod_remarks'] instanceof \think\Paginator ) && $vo['vod_remarks']->isEmpty())): ?><?php echo $vo['vod_serial']; else: ?><?php echo $vo['vod_remarks']; ?><?php endif; ?></i></span><em class="hot"><?php echo \App\Vod\Extend\Common::ray_substring($vo['vod_hits_day'],2); ?>°C</em>
                            </a></li>
                            <?php endif; ?>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </div>
                </div>
            </aside>
        </div>
    </section>
    <?php endforeach; endif; else: echo "" ;endif; ?>
    <!-- 最新专题 -->
    <section class="new-special">
        <div class="container">
            <div class=" card-wrap">
                <div class="title clearfix">
                    <h3 class="theme">影视专题</h3>
                    <a href="/zhuanti" target="_blank" class="more more-arrow fr">更多</a>
                </div>
                <div class="content clearfix">
                    <div class="swiper-container list-wrap">
                        <ul class="list swiper-wrapper">
                            <?php $__TAG__ = '{"num":"5","type":"4","order":"desc","by":"time"}';$tagVod=\App\Vod\Service\TagLibService::getInstance()->hook("tagVod",$__TAG__);if(is_array($tagVod) || is_object($tagVod) || $tagVod instanceof \think\Collection ): $key = 0; $__LIST__ = $tagVod;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;?>
                            <li class="item swiper-slide">
                                <a class="img" href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" target="_blank" title="<?php echo $vo['vod_title']; ?>"><img class="lazyload" data-original="<?php echo \App\Vod\Extend\Common::ray_url_img($vo['vod_pic']); ?>" alt="<?php echo $vo['vod_title']; ?>">
                                    <div class="details text-bg-c"><span class="name"><?php echo $vo['vod_title']; ?></span></div>
                                </a>
                            </li>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="link-special">
        <div class="container">
            <div class=" card-wrap">
                <div class="title clearfix">
                    <h3 class="theme">友情链接</h3>
                </div>
                <section class="friend-link">
                    <ul>
                        <?php $__TAG__ = '{"num":"10","type":"all","order":"desc","by":"id"}';$tagLink=\App\Vod\Service\TagLibService::getInstance()->hook("tagLink",$__TAG__);if(is_array($tagLink) || is_object($tagLink) || $tagLink instanceof \think\Collection ): $key = 0; $__LIST__ = $tagLink;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;?>
                        <li class="item"><a href="<?php echo $vo['link_url']; ?>" title="<?php echo $vo['link_name']; ?>" target="_blank"><?php echo $vo['link_name']; ?></a></li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </section>


</main>
<footer class="footer">
    <div class="container">
        <div class="top layout-xs">
            郑重声明：<?php echo $raycms['site_name']; ?>所有播放资源均由机器人收集于互联网，本站不参与任何影视资源制作与存储，如若侵犯了您的权益请书面告知，我们会及时处理。站务邮箱<?php echo $raycms['site_email']; ?>
        </div>
        <div class="middle layout-xs">如果喜欢<?php echo $raycms['site_name']; ?>请分享给身边的朋友，站内广告是本站能持续为大家服务的立命之本还望顺手支持一下^_^</div>
        <div class="bottom">
            <p>Copyright © 2018~2019 · <a href="<?php echo $raycms['site_pc_url']; ?>" class="js-index-href" title="<?php echo $raycms['site_name']; ?>"><?php echo $raycms['site_name']; ?> <?php echo $raycms['site_pc_url']; ?></a></p>
            <div class="float-box">
                <i class="fa fa-angle-up" id="goTop" title="返回顶部"></i>
            </div>
        </div>
    </div>
</footer>
</body>
</html>
