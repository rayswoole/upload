<?php /*a:2:{s:58:"/var/wwwroot/rayswoole2.1/App/Admin/View/update/index.html";i:1607081896;s:59:"/var/wwwroot/rayswoole2.1/App/Admin/View/public/header.html";i:1606550842;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer"  content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content {
            display: inline-block;
            width: 30%;
        }

        .w-60 {
            width: 60% !important;
        }

        .xadmin-conn-height-500 {
            min-height: 500px !important;
        }

        .xform input {
            height: 38px !important;
            line-height: 38px !important;
        }

        .xform .layui-form-label {
            height: 20px !important;
            line-height: 20px !important;
        }

        .xform .layui-form-radio {
            margin-bottom: 6px !important;
        }

        .xform .layui-form-switch {
            margin-top: 8px !important;
        }

        .xform .layui-form-item {
            margin-bottom: 5px !important;
        }

        .xform .layui-form-item .layui-input-inline {
            display: inline-block;
            width: 260px;
        }

        .tips_text {
            padding-right: 6px;
            color: darkred !important;
            font-weight: bold;
        }

        #search {
            height: 31px;
            line-height: 31px;
        }

        .clear {
            width: 0;
            height: 0;
            clear: both;
        }

        .toolTable {
            padding-bottom: 10px;
        }

        .male-color {
            color: #1E9FFF;
            font-size: 14px;
        }

        .female-color {
            color: #ff6bc9;
            font-size: 14px;
        }

        .thumb_img {
            width: 30%;
            height: 80%;
        }

        .yes {
            color: #009688;
            font-weight: bold;
        }

        .no {
            color: #d6ae7b;
            font-weight: bold;
        }

        .pd-30-50 {
            padding: 30px 10px 50px 10px;
        }

        .layui-inline {
            margin-right: -10px !important;
        }

        .biaoqianyun {
            width: 100%;
            margin-left: 10px;
        }

        .biaoqianyun span {
            padding: 5px 15px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-20 {
            width: 20% !important;
        }

        .it {
            margin: 0 10px 0 5px;
            color: #666;
        }


        .tagcon {
            width: 100%;
            height: auto;
            border: 1px solid #e6e6e6;
            display: inline-block;
        }

        .tagcon input {
            height: 35px;
            border: none;
        }

        .tagcon .bq span {
            padding: 5px 15px;
            margin: 5px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
            display: inline-block;
            transition: all ease-in-out .5s;
            position: relative;
        }

        .tagcon .bq span:hover {
            padding-right: 25px;
        }

        .tagcon .bq span:hover:after {
            content: 'x';
            padding: 1px;
            position: absolute;
            top: 5px;
            right: 5px;
            border-radius: 50%;
            color: #fff;
        }


        .layui-form-item div.layui-upload-list {
            margin: 0 !important;
        }

        .layui-form-item div.layui-upload-list img {
            margin: 10px !important;
        }

        .form-conn {
            margin: 15px 0;
        }


        .xadmin-btn-6262 {
            background: #de6262;
        }

        .xadmin-btn-cea2 {
            background: #43cea2;
        }

        .xadmin-btn-5876 {
            background: #2b5876;
        }

        .xadmin-btn-076b {
            background: #aa076b;
        }

        .xadmin-btn-9966 {
            background: #ff9966;
        }

        .xadmn-btn-5f6d {
            background: #ff5f6d;
        }

        .xadmin-btn-cdac {
            background: #00cdac;
        }

        .xadmin-btn-3e50 {
            background: #2c3e50;
        }

        .xadmin-btn-4b6d {
            background: #734b6d;
        }

        .xadmin-btn-b1bf {
            background: #48b1bf;
        }

        .re_cookie {
            position: relative;
        }

        .re_cookie .re {
            position: absolute;
            right: 6px;
            top: 10px;
            cursor: pointer;
            color: #009688;
        }

        .layui-table-cell {
            /*height: auto !important;*/
        }
        .xa {
            display: none;
        }
    </style>
</head>
<style type="text/css">
    .li-height{line-height: 40px;}
</style>
<body>

<div class="x-nav">
          <span class="layui-breadcrumb">
            <a href="">首页</a>
            <a href="">版本信息</a>
          </span>
    <a class="layui-btn layui-btn-small layui-btn-sm" style="float:right; margin-top: 5px;"
       onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style=""></i></a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md6">
            <div class="layui-card">
                <div class="layui-card-header">
                    更新日志
                </div>
                <div class="layui-card-body">
                    <ul class="layui-timeline">
                        <?php if(is_array($versions) || $versions instanceof \think\Collection || $versions instanceof \think\Paginator): $i = 0; $__LIST__ = $versions;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <li class="layui-timeline-item">
                            <i class="layui-icon layui-timeline-axis"><?php if(version_compare($version, $vo['min'], '=')): ?>&#xe643;<?php else: ?>&#xe63f;<?php endif; ?></i>
                            <div class="layui-timeline-content layui-text">
                                <h3 class="layui-timeline-title">V<?php echo $vo['number']; ?></h3>
                                <?php if(version_compare($version, $vo['number'], '<=')): if(version_compare($version, $vo['min'], '=')): ?>
                                <p><button type="button" class="layui-btn layui-btn-sm upgrade" data-link='<?php echo urlencode($vo['down']); ?>'>升级到此版本</button></p><p>&nbsp;</p><?php else: ?>
                                <p><button type="button" class="layui-btn layui-btn-disabled layui-btn-sm">需要先升级到<?php echo $vo['min']; ?></button></p><p>&nbsp;</p>
                                <?php endif; ?><?php endif; ?>
                                <p>
                                    <?php echo $vo['desc']; ?>
                                </p>
                            </div>
                        </li><?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="layui-col-md6">
            <div class="layui-card">
                <div class="layui-card-header">
                    升级实时信息
                </div>
                <div class="layui-card-body">
                    <textarea class="layui-textarea" style="width: 100%; height: 200px;" id="notice">当前版本：<?php echo $version; ?></textarea>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script>
    layui.use(['layer','jquery'], function () {
        var layer = layui.layer,
            $=layui.jquery;

        $('.upgrade').on('click', function (){
            $(this).attr("disabled","disabled").addClass('layui-btn-disabled').text('正在升级中, 请勿离开当前页面');
            let link = $(this).data('link');
            let noticeObj = document.getElementById('notice');
            $(noticeObj).append("\n"+'开始下载升级包:'+unescape(link)+"\n");
            $.getJSON('<?php echo \rayswoole\Helper::url("update/upgradeStep1"); ?>?downurl='+link, function (data) {
                if (data.code === 200) {
                    $(noticeObj).append('升级包下载成功'+"\n");
                    $(noticeObj).append('开始从升级包提取文件并覆盖...'+"\n");
                    $.getJSON('<?php echo \rayswoole\Helper::url("update/upgradeStep2"); ?>?lock='+data.lock, function (data2) {
                        $(noticeObj).append(data2.body+"\n");
                        if (data2.code === 200) {
                            $(noticeObj).append("升级完成，系统开始重启\n");
                            $.getJSON('<?php echo \rayswoole\Helper::url("update/upgradeStep3"); ?>', function (data3) {
                                $(noticeObj).append(data3.body + "\n");
                                setTimeout(function () {
                                    window.location.href = window.location.href;
                                },5000);
                            });
                        } else {
                            $(this).attr("disabled","").removeClass('layui-btn-disabled').text('升级到此版本');
                        }
                    })
                } else {
                    $(this).attr("disabled","").removeClass('layui-btn-disabled').text('升级到此版本');
                    $(noticeObj).append('升级包下载失败'+"\n");
                    $(noticeObj).append('状态码：'+ data.code + "\n");
                    $(noticeObj).append('错误信息：'+data.body + "\n");
                }
            });
        });
    });
</script>
</html>