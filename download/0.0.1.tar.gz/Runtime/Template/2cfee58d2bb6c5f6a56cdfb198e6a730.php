<?php /*a:5:{s:57:"/var/wwwroot/rayswoole2.1/App/Admin/View/index/index.html";i:1604997013;s:59:"/var/wwwroot/rayswoole2.1/App/Admin/View/public/header.html";i:1606550842;s:56:"/var/wwwroot/rayswoole2.1/App/Admin/View/public/top.html";i:1607506071;s:57:"/var/wwwroot/rayswoole2.1/App/Admin/View/public/left.html";i:1607076304;s:58:"/var/wwwroot/rayswoole2.1/App/Admin/View/public/right.html";i:1607079150;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer"  content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content {
            display: inline-block;
            width: 30%;
        }

        .w-60 {
            width: 60% !important;
        }

        .xadmin-conn-height-500 {
            min-height: 500px !important;
        }

        .xform input {
            height: 38px !important;
            line-height: 38px !important;
        }

        .xform .layui-form-label {
            height: 20px !important;
            line-height: 20px !important;
        }

        .xform .layui-form-radio {
            margin-bottom: 6px !important;
        }

        .xform .layui-form-switch {
            margin-top: 8px !important;
        }

        .xform .layui-form-item {
            margin-bottom: 5px !important;
        }

        .xform .layui-form-item .layui-input-inline {
            display: inline-block;
            width: 260px;
        }

        .tips_text {
            padding-right: 6px;
            color: darkred !important;
            font-weight: bold;
        }

        #search {
            height: 31px;
            line-height: 31px;
        }

        .clear {
            width: 0;
            height: 0;
            clear: both;
        }

        .toolTable {
            padding-bottom: 10px;
        }

        .male-color {
            color: #1E9FFF;
            font-size: 14px;
        }

        .female-color {
            color: #ff6bc9;
            font-size: 14px;
        }

        .thumb_img {
            width: 30%;
            height: 80%;
        }

        .yes {
            color: #009688;
            font-weight: bold;
        }

        .no {
            color: #d6ae7b;
            font-weight: bold;
        }

        .pd-30-50 {
            padding: 30px 10px 50px 10px;
        }

        .layui-inline {
            margin-right: -10px !important;
        }

        .biaoqianyun {
            width: 100%;
            margin-left: 10px;
        }

        .biaoqianyun span {
            padding: 5px 15px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-20 {
            width: 20% !important;
        }

        .it {
            margin: 0 10px 0 5px;
            color: #666;
        }


        .tagcon {
            width: 100%;
            height: auto;
            border: 1px solid #e6e6e6;
            display: inline-block;
        }

        .tagcon input {
            height: 35px;
            border: none;
        }

        .tagcon .bq span {
            padding: 5px 15px;
            margin: 5px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
            display: inline-block;
            transition: all ease-in-out .5s;
            position: relative;
        }

        .tagcon .bq span:hover {
            padding-right: 25px;
        }

        .tagcon .bq span:hover:after {
            content: 'x';
            padding: 1px;
            position: absolute;
            top: 5px;
            right: 5px;
            border-radius: 50%;
            color: #fff;
        }


        .layui-form-item div.layui-upload-list {
            margin: 0 !important;
        }

        .layui-form-item div.layui-upload-list img {
            margin: 10px !important;
        }

        .form-conn {
            margin: 15px 0;
        }


        .xadmin-btn-6262 {
            background: #de6262;
        }

        .xadmin-btn-cea2 {
            background: #43cea2;
        }

        .xadmin-btn-5876 {
            background: #2b5876;
        }

        .xadmin-btn-076b {
            background: #aa076b;
        }

        .xadmin-btn-9966 {
            background: #ff9966;
        }

        .xadmn-btn-5f6d {
            background: #ff5f6d;
        }

        .xadmin-btn-cdac {
            background: #00cdac;
        }

        .xadmin-btn-3e50 {
            background: #2c3e50;
        }

        .xadmin-btn-4b6d {
            background: #734b6d;
        }

        .xadmin-btn-b1bf {
            background: #48b1bf;
        }

        .re_cookie {
            position: relative;
        }

        .re_cookie .re {
            position: absolute;
            right: 6px;
            top: 10px;
            cursor: pointer;
            color: #009688;
        }

        .layui-table-cell {
            /*height: auto !important;*/
        }
        .xa {
            display: none;
        }
    </style>
</head>
<body class="index">
<div class="container">
    <div class="logo xxx">
        <div class="top_nav">
            <a href="javascript:window.location.reload();">Ray7-后台管理系统</a>
        </div>
    </div>
    <div class="left_open">
        <i title="展开左侧栏" class="iconfont">&#xe699;</i>
    </div>
    <div class="layui-hide-xs layui-hide-sm layui-show-lg-inline-block layui-show-md-inline-block">
        <ul class="layui-nav left fast-add xxx" lay-filter="">
            <div class="top_nav">
                <?php if(!empty($top_node)): if(is_array($top_node) || $top_node instanceof \think\Collection || $top_node instanceof \think\Paginator): $i = 0; $__LIST__ = $top_node;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$t): $mod = ($i % 2 );++$i;?>
                <li class="layui-nav-item <?php if(empty($t['node_path'])): ?>x<?php endif; ?>" <?php if(!empty($t['node_path'])): ?>
                    onclick="xadmin.add_tab('<?php echo $t['node_name']; ?>','<?php echo \rayswoole\Helper::url($t['node_path']); ?>')" <?php else: ?> data-open="<?php echo $t['node_mark']; ?>"<?php endif; ?>>
                <a href="javascript:;"><?php echo $t['node_name']; ?></a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <?php endif; ?>
            </div>
        </ul>
    </div>
    <div class="layui-hide-lg layui-hide-md layui-show-xs-inline-block layui-show-sm-inline-block">
        <ul class="layui-nav left xxx" lay-filter="" style="z-index: 20200717;">
            <li>
                <dd class="layui-nav-item top_nav">
                    <a href="javascript:;">模块选择</a>
                    <dl class="layui-nav-child">
                        <?php if(!empty($top_node)): if(is_array($top_node) || $top_node instanceof \think\Collection || $top_node instanceof \think\Paginator): $i = 0; $__LIST__ = $top_node;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$t): $mod = ($i % 2 );++$i;?>
                        <dd class="<?php if(empty($t['node_path'])): ?>x<?php endif; ?>" <?php if(!empty($t['node_path'])): ?>
                            onclick="xadmin.add_tab('<?php echo $t['node_name']; ?>','<?php echo \rayswoole\Helper::url($t['node_path']); ?>')" <?php else: ?> data-open="<?php echo $t['node_mark']; ?>"<?php endif; ?>>
                        <a href="javascript:;"><?php echo $t['node_name']; ?></a>
                        </dd>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        <?php endif; ?>
                    </dl>
                </dd>
            </li>
        </ul>
    </div>
    <ul class="layui-nav right" lay-filter="">
        <div class="layui-show-lg-inline-block layui-show-md-inline-block layui-show-xs-inline-block layui-show-sm-inline-block">
            <li class="layui-nav-item">
                <a href="javascript:;"><?php echo isset($userinfo['nickname']) ? $userinfo['nickname'] : '未登录'; ?></a>
                <dl class="layui-nav-child">
                    <dd>
                        <a onclick="xadmin.open('找回密码','<?php echo \rayswoole\Helper::url('login/setpassword'); ?>',($(window).width() * 0.5), ($(window).width() * 0.3))">找回密码</a>
                    </dd>
                    <dd>
                        <a href='<?php echo \rayswoole\Helper::url("login/index"); ?>'>切换帐号</a></dd>
                    <dd>
                        <a href="<?php echo \rayswoole\Helper::url('Login/loginout'); ?>">退出</a></dd>
                </dl>
            </li>
            <li class="layui-nav-item">
                <a href="/" target="_blank">网站首页</a>
            </li>
            <li class="layui-nav-item">
                <a id="clear">清除缓存</a>
            </li>
            <li class="layui-nav-item">
                <a id="restart">重启服务</a>
            </li>

        </div>

    </ul>
</div>
<script>
    $(document).on('click', '#clear', function () {
        cre.load();
        cre.xpost('<?php echo \rayswoole\Helper::url("reset/clear"); ?>', {}, function (before) {
            }, function (res) {
                if (!res.code) {
                    layer.msg(res.msg);
                    cre.loadclose();
                    parent.location.href = res.url;
                } else {
                    layer.msg(res.msg);
                    cre.loadclose();
                }
            }, function (error) {
                layer.msg('请求失败');
            }
        );
    });
    $(document).on('click', '#restart', function () {
        cre.load();
        cre.xpost('<?php echo \rayswoole\Helper::url("reset/restart"); ?>', {}, function (before) {
            }, function (res) {
                if (!res.code) {
                    layer.msg(res.msg);
                    cre.loadclose();
                    parent.location.href = res.url;
                } else {
                    layer.msg(res.msg);
                    cre.loadclose();
                }
            }, function (error) {
                layer.msg('请求失败');
            }
        );
    })
</script>
<div class="left-nav">
    <div id="side-nav">
        <ul id="nav">

            <?php if(!empty($left_node)): if(is_array($left_node) || $left_node instanceof \think\Collection || $left_node instanceof \think\Paginator): $i = 0; $__LIST__ = $left_node;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$l): $mod = ($i % 2 );++$i;?>
            <div class="xc xa" data-en="<?php echo $l['node_mark']; ?>">
                <li>
                    <a  <?php if(!empty($l['node_path'])): ?> onclick="xadmin.add_tab('<?php echo $l['node_name']; ?>','<?php echo \rayswoole\Helper::url($l['node_path']); ?>')" <?php else: ?> href="javascript:;" <?php endif; ?>>
                        <i class="iconfont left-nav-li" lay-tips="<?php echo $l['node_name']; ?>" >&#xe74e;</i>
                        <cite><?php echo $l['node_name']; ?></cite>
                        <i class="iconfont nav_right"><?php if(empty($l['node_path'])): ?>&#xe697;<?php endif; ?></i></a>
                    <?php if(!empty($l['child'])): ?>
                        <ul class="sub-menu">
                            <?php if(is_array($l['child']) || $l['child'] instanceof \think\Collection || $l['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $l['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$lc): $mod = ($i % 2 );++$i;if(!empty($lc['child'])): ?>
                                    <li>
                                        <a href="javascript:;">
                                            <i class="iconfont left-nav-li" lay-tips="<?php echo $lc['node_name']; ?>">&#xe74e;</i>
                                            <cite><?php echo $lc['node_name']; ?></cite>
                                            <i class="iconfont nav_right">&#xe697;</i></a>
                                        <ul class="sub-menu">
                                            <?php if(is_array($lc['child']) || $lc['child'] instanceof \think\Collection || $lc['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $lc['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ld): $mod = ($i % 2 );++$i;?>
                                                <li class="sxa">
                                                    <a onclick="xadmin.add_tab('<?php echo $ld['node_name']; ?>','<?php echo \rayswoole\Helper::url($ld['node_path']); ?>')">
                                                        <i class="iconfont">&#xe6a7;</i>
                                                        <cite><?php echo $ld['node_name']; ?></cite></a>
                                                </li>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                        </ul>
                                    </li>
                                <?php else: ?>
                                    <li class="sxa">
                                        <a onclick="xadmin.add_tab('<?php echo $lc['node_name']; ?>','<?php echo \rayswoole\Helper::url($lc['node_path']); ?>')">
                                            <i class="iconfont">&#xe6a7;</i>
                                            <cite><?php echo $lc['node_name']; ?></cite></a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    <?php endif; ?>
                </li>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <?php endif; ?>

        </ul>
    </div>
</div>

<!-- <div class="x-slide_left"></div> -->
<div class="page-content">
    <div class="layui-tab tab" lay-filter="xbs_tab" lay-allowclose="false">
        <ul class="layui-tab-title">
            <li class="home">
                <i class="layui-icon">&#xe68e;</i>我的桌面</li></ul>
        <div class="layui-unselect layui-form-select layui-form-selected" id="tab_right">
            <dl>
                <dd data-type="this">关闭当前</dd>
                <dd data-type="other">关闭其它</dd>
                <dd data-type="all">关闭全部</dd></dl>
        </div>
        <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
                <iframe src='<?php echo \rayswoole\Helper::url("index/welcome"); ?>' frameborder="0" scrolling="yes" class="x-iframe"></iframe>
            </div>
        </div>
        <div id="tab_show"></div>
    </div>
</div>
<div class="page-content-bg"></div>
</body>
</html>