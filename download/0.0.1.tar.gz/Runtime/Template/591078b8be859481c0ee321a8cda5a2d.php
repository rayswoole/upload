<?php /*a:4:{s:67:"/var/wwwroot/rayswoole2.1/Public/skin/shuang11/html/vod/detail.html";i:1607572478;s:71:"/var/wwwroot/rayswoole2.1/Public/skin/shuang11/html/public/include.html";i:1607427427;s:68:"/var/wwwroot/rayswoole2.1/Public/skin/shuang11/html/public/head.html";i:1607427427;s:68:"/var/wwwroot/rayswoole2.1/Public/skin/shuang11/html/public/foot.html";i:1607427427;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $obj['vod_title']; ?>详情介绍-<?php echo $obj['vod_title']; ?>在线观看-<?php echo $obj['vod_title']; ?>迅雷下载 - <?php echo $raycms['site_name']; ?></title>
    <meta name="keywords" content="<?php echo $obj['vod_title']; ?>在线收看,<?php echo $obj['vod_title']; ?>迅雷下载"/>
    <meta name="description" content="<?php echo $obj['vod_title']; ?>剧情:<?php echo $obj['vod_blurb']; ?>"/>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $raycms['path_tpl']; ?>static/favicon.png">
<link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/swiper/swiper.css">
<link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/css/common.css">
<script>var raycms={"path":"","mid":"<?php echo $raycms['mid']; ?>","url":"<?php echo $raycms['site_pc_url']; ?>","wapurl":"<?php echo $raycms['site_wap_url']; ?>","mob_status":"<?php echo $raycms['mob_status']; ?>","css":"<?php echo $raycms['path_tpl']; ?>static/"};</script>
<script src="<?php echo $raycms['path_tpl']; ?>static/js/jquery.min.js"></script>
<script src="<?php echo $raycms['path_tpl']; ?>static/js/home.js"></script>
<script src="<?php echo $raycms['path_tpl']; ?>static/js/bottom.js"></script>
<script type="text/javascript" src="/static/js/jquery.base.js?t=003"></script>
<script type="text/javascript" src="<?php echo $raycms['path_tpl']; ?>static/swiper/swiper.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo $raycms['path_tpl']; ?>static/css/movie_details.css">
    <link rel="stylesheet" href="/static/css/comment.css">
</head>
<body>
<script src="/static/js/jquery.base.js?t=01"></script>
<link rel="stylesheet" href="/static/css/home.css">
<header class="header" id="header">
    <div class="container">
        <h1 class="logo"><a href="<?php echo $raycms['path']; ?>" title="<?php echo $raycms['site_name']; ?>"></a></h1>
        <nav class="main-nav swiper-container">
            <ul class="nav-list swiper-wrapper">
                  <li class="nav-item swiper-slide<?php if($raycms['aid'] == 1): ?> active<?php endif; ?>"><a href="<?php echo $raycms['path']; ?>"><i class="fa fa-home"></i>首页</a></li>
				  <?php $__TAG__ = '{"ids":"parent","order":"asc","by":"sort","key":"key"}';$tagType=\App\Vod\Service\TagLibService::getInstance()->hook("tagType",$__TAG__);if(is_array($tagType) || is_object($tagType) || $tagType instanceof \think\Collection ): $key = 0; $__LIST__ = $tagType;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;if($key==1): ?>
                  <li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-film"></i><?php echo $vo['type_name']; ?></a></li>
				   <?php elseif($key==2): ?>
                   <li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-tv"></i><?php echo $vo['type_name']; ?></a></li>
					<?php elseif($key==3): ?>
                    <li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-video-camera"></i><?php echo $vo['type_name']; ?></a></li>
					<?php elseif($key==4): ?>
                    <li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-github-alt"></i><?php echo $vo['type_name']; ?></a></li>
					<?php elseif($key > 4): ?>
					<li class="nav-item swiper-slide<?php if(($vo['type_id'] == $raycms['type_id'] && $raycms['aid'] != 1)): ?> active<?php endif; ?>"><a href="<?php echo \App\Vod\Extend\Common::ray_url_type($vo); ?>"><i class="fa fa-tv"></i><?php echo $vo['type_name']; ?></a></li>
					<?php endif; ?>
					<?php endforeach; endif; else: echo "" ;endif; ?>
                    <li class="nav-item swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url('label/top'); ?>"><i class="fa fa-list-alt"></i>排行榜</a></li>
                    <li class="nav-item swiper-slide"><a href="<?php echo \App\Vod\Extend\Common::ray_url('label/new'); ?>"><i class="fa fa-window-maximize"></i>最近更新</a></li>
            </ul>
        </nav>
        <div class="search-container">
        <ul class="right-wrap">
            <li class="user-wrap hidden-xs"><a href="<?php echo \rayswoole\Helper::url('user@index/index'); ?>"><i class="fa fa-user-o login-btn" title="登录账户"></i><em>登录账户</em></a></li>
        </ul>
            <div class="search-wrapper">
			    <form id="search" name="search" method="get" action="<?php if($raycms['mid']==8): ?><?php echo \App\Vod\Extend\Common::ray_url('vod@actor/index'); elseif($raycms['mid']==2): ?><?php echo \App\Vod\Extend\Common::ray_url('art@search/index'); else: ?><?php echo \App\Vod\Extend\Common::ray_url('vod@search/index'); ?><?php endif; ?>" onSubmit="return qrsearch();">
                <input type="text" name="wd" id="wd" class="search-input keywords ray_wd" value="<?php echo (isset($param['wd']) && ($param['wd'] !== '')?$param['wd']:''); ?>" placeholder="<?php if(($raycms['aid'] == 13)): ?><?php echo (isset($param['wd']) && ($param['wd'] !== '')?$param['wd']:''); ?><?php echo (isset($param['actor']) && ($param['actor'] !== '')?$param['actor']:''); ?><?php echo (isset($param['director']) && ($param['director'] !== '')?$param['director']:''); ?><?php echo (isset($param['area']) && ($param['area'] !== '')?$param['area']:''); ?><?php echo (isset($param['lang']) && ($param['lang'] !== '')?$param['lang']:''); ?><?php echo (isset($param['year']) && ($param['year'] !== '')?$param['year']:''); ?><?php echo (isset($param['class']) && ($param['class'] !== '')?$param['class']:''); else: ?>搜索电影/演员/导演<?php endif; ?>" />
				<button type="submit" id="searchbutton" class="sbt ray_search"><i class="fa fa-search"></i></button>
            </form>
            </div>
			</div>

    </div>
</header>
<!--当前位置-->
<main class="main main_movie_details db">
    <div class="main-content">
        <section class="introduce sbg">
            <div class="container">
                <div class="card-wrap clearfix">
                    <div class="crumbs-nav mb15"><a href="<?php echo $raycms['path']; ?>"><i class="fa fa-home"></i>首页</a>
                        <?php if(!(empty($obj['type']) || (($obj['type'] instanceof \think\Collection || $obj['type'] instanceof \think\Paginator ) && $obj['type']->isEmpty()))): ?><i class="fa fa-angle-double-right"></i>
                        <?php echo $obj['type']['type_name']; ?><?php endif; ?> <i class="fa fa-angle-double-right"></i>&nbsp;<?php echo $obj['vod_title']; ?>
                    </div>
                    <div class="play-container"></div>
                    <div class="intro-con clearfix">
                        <div class="subject-row-m">
                            <h1 class="article-subject-m"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($obj); ?>" target="_blank"><?php echo $obj['vod_title']; ?></a>
                            </h1>
                            <h5 class="order-name-m"></h5>
                        </div>
                        <div class="thumb-wrap">
                            <img src="<?php echo \App\Vod\Extend\Common::ray_url_img($obj['vod_pic']); ?>" alt="<?php echo $obj['vod_title']; ?>" id="movie_thumb">

                            <label class="state"><?php if(empty($obj['vod_remarks']) || (($obj['vod_remarks'] instanceof \think\Collection || $obj['vod_remarks'] instanceof \think\Paginator ) && $obj['vod_remarks']->isEmpty())): ?><?php echo $obj['vod_serial']; else: ?><?php echo $obj['vod_remarks']; ?><?php endif; ?></label>
                        </div>
                        <div class="info-wrap low">
                            <div class="subject-row pc">
                                <h1 class="article-subject"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($obj); ?>" target="_blank"><?php echo $obj['vod_title']; ?></a>
                                </h1>
                                <h5 class="order-name"></h5>
                            </div>
                            <p class="director">
                                <label>导演：</label><span><?php echo \App\Vod\Extend\Common::ray_url_create($obj['vod_director'],'director'); ?></span></p>
                            <p class="performer"><label>主演：</label><span><?php echo \App\Vod\Extend\Common::ray_url_create($obj['vod_actor'],'actor'); ?></span>
                            </p>
                            <p class="tags"><label>类型：</label><span><?php echo \App\Vod\Extend\Common::ray_url_create($obj['vod_class'],'class'); ?></span></p>
                            <p class="country"><label>地区：</label><span><?php echo \App\Vod\Extend\Common::ray_url_create($obj['vod_area'],'area'); ?></span></p>
                            <p class="language"><label>语言：</label><span><?php echo \App\Vod\Extend\Common::ray_url_create($obj['vod_lang'],'lang'); ?></span></p>
                            <p class="year">
                                <label>上映：</label><span><?php echo date('Y-m-d',$obj['vod_addtime']); ?>(<?php echo $obj['vod_area']; ?>)</span></p>
                            <p class="duration"><label>片长：</label><span>45分钟</span></p>
                            <p class="episodes"><label>集数：</label><span><?php if(empty($obj['vod_remarks']) || (($obj['vod_remarks'] instanceof \think\Collection || $obj['vod_remarks'] instanceof \think\Paginator ) && $obj['vod_remarks']->isEmpty())): ?><?php echo $obj['vod_serial']; else: ?><?php echo $obj['vod_remarks']; ?><?php endif; ?></span>
                            </p>
                            <p class="douban_score"><label>评分：</label><span><?php echo $obj['vod_score']; ?>分</a></span></p>
                            <div class="like mt15"><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_play($obj); ?>" title="在线观看"
                                                      class="fabulous db-fabulous db-fabulous-8696 btn"><i
                                    class="fa fa-play"></i>在线观看</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="play-resource">
            <div class="container">
                <div class="card-wrap">
                    <div class="resource-box">
                        <div class="hd clearfix">
                            <div class="resource-box-nav swiper-container">
                                <ul class="nav nav-tabs swiper-wrapper">
                                    <?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key2=>$vo): ?>
                                    <li class='swiper-slide<?php if(($key2== 1)): ?> active<?php endif; ?>'><a href="javascript:;" class="tab-nav" title="605-605yun"><?php echo $vo['from']; ?><?php echo $key2; ?></a></li>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </ul>
                            </div>
                        </div>


                        <div class="bd clearfix">
                            <?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key2=>$vo): ?>
                                <div class="rb-item"<?php if(($key2 == 1)): ?> style="display:block;"<?php endif; ?>>
                                    <ul class="episodes-list clearfix">
                                        <?php if(is_array($vo['urls']) || $vo['urls'] instanceof \think\Collection || $vo['urls'] instanceof \think\Paginator): if( count($vo['urls'])==0 ) : echo "" ;else: foreach($vo['urls'] as $key2=>$vo2): ?>
                                        <li><a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>" rel="nofollow"><?php echo $vo2['name']; ?></a></li>
                                        <?php endforeach; endif; else: echo "" ;endif; ?>
                                    </ul>
                                </div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    </div>
                </div>
                <p class="play-tips"><i class="fa fa-heart"></i> 看片小贴士：画面质量从高到低依次为 BD &gt; HD &gt; DVD &gt; HC &gt; TC&gt; TS(偶尔难免片源方所标明资源与实际有误请甄别选择/如电脑端不能播放可切换手机试试/如手机端播放卡可搜索相同资源切换线路试试)</p>
            </div>
        </section>
        <section class="movie-summary sbg">
            <div class="container">
                <div class="card-wrap clearfix">
                    <div class="title mb10"><h3 class="theme">剧情简介</h3></div>
                    <div class="summary-con">
                        <p><?php echo $raycms['site_name']; ?>大全<?php echo $raycms['site_pc_url']; ?>第一时间收录《<?php echo $obj['vod_title']; ?>》并提供免费在线观看。<?php echo $obj['vod_title']; ?>上映于
                            <?php echo date('Y-m-d',$obj['vod_addtime']); ?>(<?php echo $obj['vod_area']; ?>)，是一部<?php echo $obj['vod_area']; ?>制片作品，由<?php echo $obj['vod_actor']; ?>等领衔主演。影片(剧)类型为<?php if(!(empty($typekv[$obj['type_id']]) || (($typekv[$obj['type_id']] instanceof \think\Collection || $typekv[$obj['type_id']] instanceof \think\Paginator ) && $typekv[$obj['type_id']]->isEmpty()))): ?><?php echo $typekv[$obj['type_id']]; else: ?><?php echo $obj['type']['type_name']; ?><?php endif; ?>，对白语言为<?php echo $obj['vod_lang']; ?>。全片(剧)时长45分钟，喜欢<?php echo $raycms['site_name']; ?>欢迎分享给身边的朋友，顺祝您观影愉快！</p>
                        <p>以下为<?php echo $obj['vod_title']; ?>剧情简介：<?php echo $obj['vod_blurb']; ?></p>
                        <p><?php echo $raycms['site_name']; ?>大全不参与<?php echo $obj['vod_title']; ?>的录制上传，当前播放线路分别由<?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?><?php echo $vo['from']; ?><?php endforeach; endif; else: echo "" ;endif; ?>采集。有关<?php echo $obj['vod_title']; ?>的后续高清完整版本资源会陆续放出，敬请关注。</p>

                    </div>
                    <div class="mark-wrap">
                        <p class="updatetime">更新时间：<?php echo \App\Vod\Extend\Common::ray_friend_date($obj['vod_addtime']); ?></p>
                    </div>
                </div>

            </div>
        </section>
    </div>
    <section class="you-like ys-recommend">
        <div class="container">
            <div class="new-up card-wrap detailplay">
                <div class="title">
                    <h2 class="theme clearfix"><span class="active">猜你喜欢</span></h2>
                    <div class="rolling-tips swiper-container">&nbsp;</div>
                </div>
                <div class="content clearfix">
                    <ul class="new-up-list lazy-load-list">
                        <?php $__TAG__ = '{"num":"16","type":"current","order":"desc","by":"hits_day"}';$tagVod=\App\Vod\Service\TagLibService::getInstance()->hook("tagVod",$__TAG__);if(is_array($tagVod) || is_object($tagVod) || $tagVod instanceof \think\Collection ): $key = 0; $__LIST__ = $tagVod;if( empty($__LIST__) ) : echo "" ;else: $key=0; foreach($__LIST__ as $index=>$vo): $mod = ($key % 2 );++$key;?>
                        <li class="item<?php if($key==7): ?> hidex-3<?php elseif($key==8): ?> showx-2 hide-0<?php endif; ?>">
                            <div class="item-con">
                                <span class="state"><em><?php if(empty($vo['vod_remarks']) || (($vo['vod_remarks'] instanceof \think\Collection || $vo['vod_remarks'] instanceof \think\Paginator ) && $vo['vod_remarks']->isEmpty())): ?><?php echo $vo['vod_serial']; else: ?><?php echo $vo['vod_remarks']; ?><?php endif; ?></em></span>
                                <a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" class="thumb"
                                   title="<?php echo $vo['vod_title']; ?> <?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?>" target="_blank"><img
                                        class="lazyload" data-original="<?php echo \App\Vod\Extend\Common::ray_url_img($vo['vod_pic']); ?>"
                                        alt="<?php echo $vo['vod_title']; ?>"><span
                                        class="hot"><b><?php echo \App\Vod\Extend\Common::ray_substring($vo['vod_hits_day'],2); ?></b><i>°C</i></span></a>
                                <h5 class="subject" title="<?php echo $vo['vod_title']; ?> <?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?>"><a
                                        href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>"
                                        target="_blank"><b><?php echo $vo['vod_title']; ?></b></a><span class="update"><?php echo \App\Vod\Extend\Common::ray_friend_date($vo['vod_addtime']); ?></span>
                                </h5>
                                <a href="<?php echo \App\Vod\Extend\Common::ray_url_vod_detail($vo); ?>" class="info-layer">
                                    <p class="tags" title="<?php echo $vo['vod_class']; ?>"><label>类型：</label><?php echo $vo['vod_class']; ?></p>
                                    <p class="year" title="<?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)"><label>上映：</label><?php echo date('Y-m-d',$vo['vod_addtime']); ?>(<?php echo $vo['vod_area']; ?>)
                                    </p>
                                    <p class="area" title="<?php echo $vo['vod_area']; ?>"><label>地区：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_area'],'未知'); ?>
                                    </p>
                                    <p class="director" title="<?php echo $vo['vod_director']; ?>"><label>导演：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_director'],'未知'); ?>
                                    </p>
                                    <p class="performer" title="<?php echo $vo['vod_actor']; ?>"><label>主演：</label><?php echo \App\Vod\Extend\Common::ray_default($vo['vod_actor'],'未知'); ?>
                                    </p>
                                </a>
                            </div>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="comment-wrap sbg">
        <div class="container">
            <div class="comment-list card-wrap">
                <h4 class="theme">精彩影评</h4>
                <div class="content">
                    <div class="ray_comment" data-id="<?php echo $obj['vod_id']; ?>" data-mid="<?php echo $raycms['mid']; ?>" style="padding: 0;">
                        <div class="skin_gray skin">
                            <div id="conn" style="text-align:center;">
                                <div class="comment_main">
                                    <div class="Input_Box ly_box">
                                        <textarea class="Input_text" placeholder="  来说两句吧..."></textarea>
                                        <div class="faceDiv"></div>
                                        <div class="Input_Foot"><a class="imgBtn" href="javascript:void(0);"></a><a
                                                class="postBtn ly_btn">确定</a></div>
                                    </div>
                                    <div class="hr"></div>
                                    <div class="comment_list">
                                    </div>
                                    <div class="ly_more more" data-cid="0">
                                        <span>查看更多</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
</main>
<footer class="footer">
    <div class="container">
        <div class="top layout-xs">
            郑重声明：<?php echo $raycms['site_name']; ?>所有播放资源均由机器人收集于互联网，本站不参与任何影视资源制作与存储，如若侵犯了您的权益请书面告知，我们会及时处理。站务邮箱<?php echo $raycms['site_email']; ?>
        </div>
        <div class="middle layout-xs">如果喜欢<?php echo $raycms['site_name']; ?>请分享给身边的朋友，站内广告是本站能持续为大家服务的立命之本还望顺手支持一下^_^</div>
        <div class="bottom">
            <p>Copyright © 2018~2019 · <a href="<?php echo $raycms['site_pc_url']; ?>" class="js-index-href" title="<?php echo $raycms['site_name']; ?>"><?php echo $raycms['site_name']; ?> <?php echo $raycms['site_pc_url']; ?></a></p>
            <div class="float-box">
                <i class="fa fa-angle-up" id="goTop" title="返回顶部"></i>
            </div>
        </div>
    </div>
</footer>
<script src="/static/js/layui/layui/layui.all.js"></script>
<script src="/static/admin/js/re.js"></script>
<script src="/static/admin/js/login.js"></script>
<script type="text/javascript">
    cre.comment.init({
        user: {
            avatar: "/static/images/face.png",
            unloginClickBtn: function unloginClickBtn() {
                login.config.path = {
                    registered: "/user/register/index",
                    retrieve_pass: "/user/register/findPass"
                };
                return login.render_login('', 'click').req_login(function (e) {
                    layer.msg('登录成功');
                    layer.closeAll();
                    location.reload();
                });
            }
        },
        comment_mid: <?php echo $raycms['mid']; ?>,
        comment_rid: <?php echo $obj['vod_id']; ?>,
    });
</script>
</body>
</html>