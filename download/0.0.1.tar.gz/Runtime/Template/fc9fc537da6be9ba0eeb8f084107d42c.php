<?php /*a:2:{s:59:"/var/wwwroot/rayswoole2.1/App/Admin/View/index/welcome.html";i:1606806930;s:59:"/var/wwwroot/rayswoole2.1/App/Admin/View/public/header.html";i:1606550842;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer"  content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content {
            display: inline-block;
            width: 30%;
        }

        .w-60 {
            width: 60% !important;
        }

        .xadmin-conn-height-500 {
            min-height: 500px !important;
        }

        .xform input {
            height: 38px !important;
            line-height: 38px !important;
        }

        .xform .layui-form-label {
            height: 20px !important;
            line-height: 20px !important;
        }

        .xform .layui-form-radio {
            margin-bottom: 6px !important;
        }

        .xform .layui-form-switch {
            margin-top: 8px !important;
        }

        .xform .layui-form-item {
            margin-bottom: 5px !important;
        }

        .xform .layui-form-item .layui-input-inline {
            display: inline-block;
            width: 260px;
        }

        .tips_text {
            padding-right: 6px;
            color: darkred !important;
            font-weight: bold;
        }

        #search {
            height: 31px;
            line-height: 31px;
        }

        .clear {
            width: 0;
            height: 0;
            clear: both;
        }

        .toolTable {
            padding-bottom: 10px;
        }

        .male-color {
            color: #1E9FFF;
            font-size: 14px;
        }

        .female-color {
            color: #ff6bc9;
            font-size: 14px;
        }

        .thumb_img {
            width: 30%;
            height: 80%;
        }

        .yes {
            color: #009688;
            font-weight: bold;
        }

        .no {
            color: #d6ae7b;
            font-weight: bold;
        }

        .pd-30-50 {
            padding: 30px 10px 50px 10px;
        }

        .layui-inline {
            margin-right: -10px !important;
        }

        .biaoqianyun {
            width: 100%;
            margin-left: 10px;
        }

        .biaoqianyun span {
            padding: 5px 15px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-20 {
            width: 20% !important;
        }

        .it {
            margin: 0 10px 0 5px;
            color: #666;
        }


        .tagcon {
            width: 100%;
            height: auto;
            border: 1px solid #e6e6e6;
            display: inline-block;
        }

        .tagcon input {
            height: 35px;
            border: none;
        }

        .tagcon .bq span {
            padding: 5px 15px;
            margin: 5px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
            display: inline-block;
            transition: all ease-in-out .5s;
            position: relative;
        }

        .tagcon .bq span:hover {
            padding-right: 25px;
        }

        .tagcon .bq span:hover:after {
            content: 'x';
            padding: 1px;
            position: absolute;
            top: 5px;
            right: 5px;
            border-radius: 50%;
            color: #fff;
        }


        .layui-form-item div.layui-upload-list {
            margin: 0 !important;
        }

        .layui-form-item div.layui-upload-list img {
            margin: 10px !important;
        }

        .form-conn {
            margin: 15px 0;
        }


        .xadmin-btn-6262 {
            background: #de6262;
        }

        .xadmin-btn-cea2 {
            background: #43cea2;
        }

        .xadmin-btn-5876 {
            background: #2b5876;
        }

        .xadmin-btn-076b {
            background: #aa076b;
        }

        .xadmin-btn-9966 {
            background: #ff9966;
        }

        .xadmn-btn-5f6d {
            background: #ff5f6d;
        }

        .xadmin-btn-cdac {
            background: #00cdac;
        }

        .xadmin-btn-3e50 {
            background: #2c3e50;
        }

        .xadmin-btn-4b6d {
            background: #734b6d;
        }

        .xadmin-btn-b1bf {
            background: #48b1bf;
        }

        .re_cookie {
            position: relative;
        }

        .re_cookie .re {
            position: absolute;
            right: 6px;
            top: 10px;
            cursor: pointer;
            color: #009688;
        }

        .layui-table-cell {
            /*height: auto !important;*/
        }
        .xa {
            display: none;
        }
    </style>
</head>
<body>

<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md6">
            <!--<div class="layui-card">
                <div class="layui-card-header">数据统计</div>
                <div class="layui-card-body ">
                    <ul class="layui-row layui-col-space10 layui-this x-admin-carousel x-admin-backlog">
                        <li class="layui-col-md3 layui-col-xs6">
                            <a href="javascript:;" class="x-admin-backlog-body">
                                <h3>视频量</h3>
                                <p>
                                    <cite><?php echo $vod_num; ?></cite></p>
                            </a>
                        </li>
                        <li class="layui-col-md3 layui-col-xs6">
                            <a href="javascript:;" class="x-admin-backlog-body">
                                <h3>文章量</h3>
                                <p>
                                    <cite><?php echo $artic_num; ?></cite></p>
                            </a>
                        </li>
                        <li class="layui-col-md3 layui-col-xs6">
                            <a href="javascript:;" class="x-admin-backlog-body">
                                <h3>会员量</h3>
                                <p>
                                    <cite><?php echo $master_num; ?></cite></p>
                            </a>
                        </li>
                        <li class="layui-col-md3 layui-col-xs6">
                            <a href="javascript:;" class="x-admin-backlog-body">
                                <h3>评论量</h3>
                                <p>
                                    <cite><?php echo $user_num; ?></cite></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>-->
            <div class="layui-card">
                <div class="layui-card-header">服务信息</div>
                <div class="layui-card-body ">
                    <table class="layui-table">
                        <tbody>
                        <tr>
                            <th>启动时间</th>
                            <td><?php echo date('Y-m-d H:i:s',$stats['start_time']); ?></td>
                        </tr>
                        <tr>
                            <th>接受请求次数</th>
                            <td><?php echo $stats['accept_count']; ?></td>
                        </tr>
                        <tr>
                            <th>响应请求次数</th>
                            <td><?php echo $stats['request_count']; ?></td>
                        </tr>
                        <tr>
                            <th>当前连接数量</th>
                            <td><?php echo $stats['connection_num']; ?></td>
                        </tr>
                        <tr>
                            <th>当前协程数量</th>
                            <td><?php echo $stats['coroutine_num']; ?></td>
                        </tr>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="layui-card">
                <div class="layui-card-header">进程信息</div>
                <div class="layui-card-body ">
                    <table class="layui-table">
                        <colgroup>
                            <col width="80">
                            <col width="">
                            <col width="80">
                            <col width="80">
                        </colgroup>
                        <thead>
                        <tr>
                            <th>PID</th>
                            <th>进程名称</th>
                            <th>分配内存</th>
                            <th>使用内存</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(is_array($process) || $process instanceof \think\Collection || $process instanceof \think\Paginator): $i = 0; $__LIST__ = $process;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <th><?php echo $vo['pid']; ?></th>
                            <td><?php echo $vo['name']; ?></td>
                            <td><?php echo $vo['memoryPeakUsage']; ?></td>
                            <td><?php echo $vo['memoryUsage']; ?></td>
                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>


            <div class="layui-card">
                <div class="layui-card-header">系统信息</div>
                <div class="layui-card-body ">
                    <table class="layui-table">
                        <tbody>
                        <tr>
                            <th>服务器地址</th>
                            <td><?php echo $server_addr; ?></td>
                        </tr>
                        <tr>
                            <th>操作系统</th>
                            <td><?php echo $system; ?></td>
                        </tr>
                        <tr>
                            <th>内核数量</th>
                            <td><?php echo swoole_cpu_num(); ?></td>
                        </tr>
                        <tr>
                            <th>运行环境</th>
                            <td><?php echo $server_info; ?></td>
                        </tr>
                        <tr>
                            <th>PHP版本</th>
                            <td><?php echo $phpinfo; ?></td>
                        </tr>
                        <tr>
                            <th>PHP运行方式</th>
                            <td><?php echo $phpmod; ?></td>
                        </tr>
                        <tr>
                            <th>MYSQL版本</th>
                            <td><?php echo $sql_info; ?></td>
                        </tr>
                        <tr>
                            <th>SWOOLE版本</th>
                            <td><?php echo $swoole_version; ?></td>
                        </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="layui-col-md6">

            <div class="layui-card">
                <div class="layui-card-body ">
                    <blockquote class="layui-elem-quote">欢迎管理员：<?php echo $username; ?>
                        <span class="x-red"></span>
                        <br> 上次登入时间：<?php echo $last_login_time; ?>
                    </blockquote>
                    <blockquote class="layui-elem-quote layui-quote-nm" id="version" style="display: none">
                    </blockquote>
                </div>
            </div>

            <div class="layui-card">
                <div class="layui-card-header">
                    新闻消息
                </div>
                <div class="layui-card-body ">
                    <table class="layui-table" lay-even lay-skin="nob">
                        <colgroup>
                            <col width="100">
                            <col>
                        </colgroup>
                        <tbody id="notice">
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="layui-card">
                <div class="layui-card-header">开发团队</div>
                <div class="layui-card-body ">
                    <table class="layui-table">
                        <tbody>
                        <tr>
                            <th>版权所有</th>
                            <td><a target="_blank" href="https://www.haoguangyun.com">浩光云科技 (访问公司网址)</a></td>
                        </tr>
                        <tr>
                            <th>系统官网</th>
                            <td><a target="_blank" href="https://www.ray7.cc">ray7.cc (访问系统官网)</a></td>
                        </tr>
                        <tr>
                            <th>开发团队</th>
                            <td>Ray7开发团队</td>
                        </tr>
                        <tr>
                            <th colspan="2" style="font-weight: bold">使用到的开源软件</th>
                        </tr>
                        <tr>
                            <th>swoole [Apache-2.0]</th>
                            <td>https://www.swoole.com</td>
                        </tr>
                        <tr>
                            <th>easyswoole [Apache-2.0]</th>
                            <td>https://www.easyswoole.com</td>
                        </tr>
                        <tr>
                            <th>think-orm [Apache-2.0]</th>
                            <td>https://www.thinkphp.cn</td>
                        </tr>
                        <tr>
                            <th>think-template [Apache-2.0]</th>
                            <td>https://www.thinkphp.cn</td>
                        </tr>
                        <tr>
                            <th>guzzle [MIT]</th>
                            <td>https://docs.guzzlephp.org</td>
                        </tr>
                        <tr>
                            <th>layui [MIT]</th>
                            <td>https://www.layui.com</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="layui-card">
                <div class="layui-card-header">版权声明</div>
                <div class="layui-card-body ">
                    <p>1、本公司(浩光云科技)拥有本软件著作权(除引用的开源软件除外)，未经允许，任何人不得声明本软件归其所有。</p>
                    <p>2、本公司授权任何个人、组织都可以免费使用本软件(包括商用)，但未经允许，不得修改、删除本公司的版权声明图形(含logo)、文字、链接。</p>
                    <p>3、本公司的版权声明图形、文字、链接位于命令行执行界面，以及后台管理界面的左上角、页面下方，面向用户的界面可自行处理(如所有权属第三方，须遵守所有权人的规定)。</p>
                </div>
            </div>
        </div>

    </div>
</div>
</div>
<script id="noticeTpl" type="text/html">
    {{#  layui.each(d, function(index, item){ }}
    <tr>
        <td>{{ item.time }}</td>
        <td><a target="_blank" href="{{ item.url }}">{{ item.title }}</a></td>
    </tr>
    {{#  }); }}
</script>
</body>
<script>
    layui.use(['layer', 'laytpl'], function () {
        var $ = layui.$,
            layer = layui.layer,
            laytpl = layui.laytpl;
        $.ajax({
            url: "<?php echo $center_api; ?>index/notice/version/<?php echo $version; ?>",
            dataType: "jsonp",
            jsonp: "jsonp",
            jsonpCallback: "callback",
            success: function (response){
                laytpl(document.getElementById('noticeTpl').innerHTML).render(response.notice, function(html){
                    document.getElementById('notice').innerHTML = html;
                });
                if (response.version.number !== '<?php echo $version; ?>'){
                    let version = document.getElementById('version');
                    version.style.display = '';
                    version.innerHTML = '<a class="layui-btn layui-btn-sm" href="<?php echo \rayswoole\Helper::url("update/index"); ?>">检测到有新的版本:' + response.version.number + ' 点击升级</a><br>' + response.version.desc;
                }
            }

        });
    });
</script>
</html>