<?php /*a:1:{s:66:"/var/wwwroot/rayswoole2.1/App/Document/View/admin/index/index.html";i:1607076304;}*/ ?>
<!doctype html>
<html class="x-admin-sm">
<head>
    <meta charset="UTF-8">
    <title>CMS_后台管理界面</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport"
          content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi"/>
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="stylesheet" href="/static/js/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/xadmin.css">
    <link rel="stylesheet" href="/static/js/xadmin/css/theme2474.min.css">
    <!-- <link rel="stylesheet" href="/static/js/xadmin/css/theme5.css"> -->
    <script src="/static/js/layui/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/admin/js/re.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="/static/js/html5shiv/html5.min.js"></script>
    <script src="/static/js/html5shiv/respond.min.js"></script>
    <![endif]-->
    <script>
        // var is_remember = false;
    </script>
    <style>
        .img-content {
            display: inline-block;
            width: 30%;
        }

        .w-60 {
            width: 60% !important;
        }

        .xadmin-conn-height-500 {
            min-height: 500px !important;
        }

        .xform input {
            height: 38px !important;
            line-height: 38px !important;
        }

        .xform .layui-form-label {
            height: 20px !important;
            line-height: 20px !important;
        }

        .xform .layui-form-radio {
            margin-bottom: 6px !important;
        }

        .xform .layui-form-switch {
            margin-top: 8px !important;
        }

        .xform .layui-form-item {
            margin-bottom: 5px !important;
        }

        .xform .layui-form-item .layui-input-inline {
            display: inline-block;
            width: 260px;
        }

        .tips_text {
            padding-right: 6px;
            color: darkred !important;
            font-weight: bold;
        }

        #search {
            height: 31px;
            line-height: 31px;
        }

        .clear {
            width: 0;
            height: 0;
            clear: both;
        }

        .toolTable {
            padding-bottom: 10px;
        }

        .male-color {
            color: #1E9FFF;
            font-size: 14px;
        }

        .female-color {
            color: #ff6bc9;
            font-size: 14px;
        }

        .thumb_img {
            width: 30%;
            height: 80%;
        }

        .yes {
            color: #009688;
            font-weight: bold;
        }

        .no {
            color: #d6ae7b;
            font-weight: bold;
        }

        .pd-30-50 {
            padding: 30px 10px 50px 10px;
        }

        .layui-inline {
            margin-right: -10px !important;
        }

        .biaoqianyun {
            width: 100%;
            margin-left: 10px;
        }

        .biaoqianyun span {
            padding: 5px 15px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
        }

        .w-50 {
            width: 50% !important;
        }

        .w-20 {
            width: 20% !important;
        }

        .it {
            margin: 0 10px 0 5px;
            color: #666;
        }


        .tagcon {
            width: 100%;
            height: auto;
            border: 1px solid #e6e6e6;
            display: inline-block;
        }

        .tagcon input {
            height: 35px;
            border: none;
        }

        .tagcon .bq span {
            padding: 5px 15px;
            margin: 5px;
            background: #a8e063;
            border-radius: 10px;
            color: #fff;
            font-size: 6px;
            cursor: pointer;
            display: inline-block;
            transition: all ease-in-out .5s;
            position: relative;
        }

        .tagcon .bq span:hover {
            padding-right: 25px;
        }

        .tagcon .bq span:hover:after {
            content: 'x';
            padding: 1px;
            position: absolute;
            top: 5px;
            right: 5px;
            border-radius: 50%;
            color: #fff;
        }


        .layui-form-item div.layui-upload-list {
            margin: 0 !important;
        }

        .layui-form-item div.layui-upload-list img {
            margin: 10px !important;
        }

        .form-conn {
            margin: 15px 0;
        }


        .xadmin-btn-6262 {
            background: #de6262;
        }

        .xadmin-btn-cea2 {
            background: #43cea2;
        }

        .xadmin-btn-5876 {
            background: #2b5876;
        }

        .xadmin-btn-076b {
            background: #aa076b;
        }

        .xadmin-btn-9966 {
            background: #ff9966;
        }

        .xadmn-btn-5f6d {
            background: #ff5f6d;
        }

        .xadmin-btn-cdac {
            background: #00cdac;
        }

        .xadmin-btn-3e50 {
            background: #2c3e50;
        }

        .xadmin-btn-4b6d {
            background: #734b6d;
        }

        .xadmin-btn-b1bf {
            background: #48b1bf;
        }

        .re_cookie {
            position: relative;
        }

        .re_cookie .re {
            position: absolute;
            right: 6px;
            top: 10px;
            cursor: pointer;
            color: #009688;
        }

        .layui-table-cell {
            /*height: auto !important;*/
        }

        .xa {
            display: none;
        }
    </style>
</head>
<body>
<style>
    .ygq {
        display: inline-block;
        width: 30px;
        height: 30px;
        background-image: url(/static/images/images/ygq.png);
        background-size: 100% 100%;
        position: absolute;
        right: -5px;
        top: -10px;
    }
</style>
<div class="x-nav">
          <span class="layui-breadcrumb">
            <a href="">首页</a>
            <a href="">文档中心</a>
            <a>
              <cite>文档列表</cite></a>
          </span>
    <a class="layui-btn layui-btn-small layui-btn-sm" style="float:right; margin-top: 5px;"
       onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style=""></i></a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-header toolTable">
                    <div class="search-con layui-card-body" style="float: left;display: none">
                        <div class="ctable-tool">
                            <input type="text" name="username" placeholder="Search..." autocomplete="off"
                                   class="layui-input" id="search"
                                   style="display: inline-block;width: auto;height: 30px;line-height: 30px;margin-top: 1px;">
                            <button class="layui-btn layui-btn-sm" data-type="search"
                                    style="margin-left: -5px;border-radius: 0 2px 2px 0;margin-top: -2px;">
                                <i class="layui-icon">&#xe615;</i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-conn layui-card-body ctable-tool" id="" style="float:left;">
                        <button class="layui-btn layui-btn-sm" data-type="create">
                            <i class="layui-icon"></i>添加数据
                        </button>
                        <button class="layui-btn layui-btn-sm layui-btn-danger" data-type="delete"><i
                                class="layui-icon"></i>批量删除
                        </button>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>

                <div class="layui-card-body ">
                    <table class="layui-hide" id="Ctableid" lay-filter="Ctable"></table>
                    <script type="text/html" id="status">
                        <input type="checkbox" name="close" value="{{d.doc_id}}" lay-skin="switch"
                               lay-text="启用|禁用" lay-filter="status" {{d.doc_status== 1 ? 'checked' : ''}} >
                    </script>
                    <script type="text/html" id="lastloginTime">
                        <span>{{d.user_lasttime === 0 ? '未登录' : layui.util.toDateString(d.doc_addtime*1000,'yyyy-MM-dd HH:mm')}}</span>
                    </script>
                    <script type="text/html" id="expiretime">
                        {{# if(d.user_expiretime*1000 < new Date().getTime()){ }}
                        <span>{{ layui.util.toDateString(d.user_expiretime*1000,'yyyy-MM-dd HH:mm:ss') }} <text
                                class="ygq"></text> </span>
                        {{#  } else { }}
                        <span>{{ layui.util.toDateString(d.user_expiretime*1000,'yyyy-MM-dd HH:mm:ss') }}</span>
                        {{#  } }}
                    </script>
                    <script type="text/html" id="sex">
                        <span>{{d.user_sex === 0 ? '女' : d.user_sex === 1 ? '男' : '保密'}}</span>
                    </script>
                    <script type="text/html" id="level">
                        <span>{{d.level_name ? d.level_name : '无'}}</span>
                    </script>
                    <script type="text/html" id="barDemo">
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="show" title="下属">
                            <i class="layui-icon">&#xe705;</i>
                        </a>
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="edit" title="编辑">
                            <i class="layui-icon">&#xe642;</i>
                        </a>
                        <a class="layui-btn layui-btn-xs layui-btn-primary" lay-event="delete" title="删除">
                            <i class="layui-icon">&#xe640;</i>
                        </a>
                    </script>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
<script>
    layui.use(['form', 'table', 'layer'], function () {
        var $ = layui.$, form = layui.form,
            table = layui.table,
            layer = layui.layer, xtable = table.render({
                elem: '#Ctableid'
                , url: '<?php echo \rayswoole\Helper::url("admin/index/read"); ?>'
                , title: '文档列表'
                , totalRow: false
                , loading: true
                , where: {
                    time: new Date()
                }
                , id: "CTableToUser"
                , even: true
                , skin: 'nob'
                , cols: [[
                    {type: 'checkbox', width: 80}
                    , {field: 'doc_id', title: 'ID', width: 80, unresize: true, sort: true}
                    , {field: 'doc_title', title: '名称', width: 120}
                    , {field: 'doc_content', title: '文档内容'}
                    , {
                        field: 'type_id', title: '所属类型', templet: function (item) {
                            if (item.type_id === 0) {
                                return '未指定分类'
                            }
                            return item.type_name;
                        }
                    }
                    , {
                        field: 'type_lang', title: '所属语言', sort: true, templet: function (item) {
                            if (item.type_lang == 1) {
                                return '<span style="color: #1ca38a">中文</span>';
                            } else if (item.type_lang == 2) {
                                return '<span style="color: #c7254e">英文</span>';
                            } else {
                                return '<span style="">其他</span>';
                            }
                        }
                    }
                    , {field: 'doc_keys', title: '关键字'}
                    , {field: 'doc_desc', title: '描述'}
                    , {field: 'doc_status', title: '文档状态', templet: '#status', minWidth: 120}
                    , {field: 'doc_addtime', title: '添加时间', templet: '#lastloginTime', minWidth: 150}
                    , {title: '操作', toolbar: '#barDemo', width: 200}
                ]],
                page: true,
                limit: 20,
                height: 'full-200'
            });


        table.on('tool(Ctable)', function (obj) {
            var data = obj.data,
                event = obj.event;
            if (event === 'show') {
                var url = '<?php echo \rayswoole\Helper::url("admin/index/show",["id"=>"_id"]); ?>'.replace("_id", data.doc_id);
                xadmin.open("查看", url, ($(window).width() * 0.7), ($(window).width() * 0.45), false, function (e) {
                    xtable.reload();
                });
            } else if (event === 'edit') {
                url = '<?php echo \rayswoole\Helper::url("admin/index/edit",["id"=>"_id"]); ?>'.replace("_id", data.doc_id);
                xadmin.open('编辑管理', url, ($(window).width() * 0.7), ($(window).width() * 0.45), false, function (e) {
                    xtable.reload();
                });
            } else if (event === 'delete') {
                layer.confirm('确定要删除数据吗?', {
                    btn: ['是的', '点错了'],
                    title: '删除提示'
                }, function (index) {
                    const l = layer.msg('正在删除中...', {
                        'xdata': data.doc_id,
                        'time': new Date().getTime()
                    });
                    cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/delete"); ?>', {
                        id: data.doc_id
                    }, function (before) {
                    }, function (res) {
                        layer.msg(res.msg);
                        layer.close(l);
                        xtable.reload();
                    }, function (error) {
                    });
                    layer.close(index);
                });
            }

        });

        var active = {
            create: function () {
                xadmin.open("添加会员", '<?php echo \rayswoole\Helper::url("admin/index/create"); ?>', ($(window).width() * 0.7), ($(window).width() * 0.45), false, function (e) {
                    xtable.reload();
                });
            }
            , delete: function () {
                var checkStatus = table.checkStatus("CTableToUser")
                    , data = checkStatus.data
                    , arr = [];
                layer.confirm('确定要删除数据吗?', {
                    btn: ['是的', '点错了'],
                    title: '删除提示'
                }, function (index) {
                    $.each(data, function (i, v) {
                        arr.push(v.doc_id);
                    });
                    var l = layer.msg('正在删除中...', {
                        'time': new Date().getTime()
                    });
                    cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/delete"); ?>', {
                        id: arr.join(',')
                    }, function (before) {
                    }, function (res) {
                        layer.msg(res.msg);
                        layer.close(l);
                        xtable.reload();
                    }, function (error) {
                    });
                    layer.close(index);
                });
            },
            search: function () {
                const search = $('#search');
                xtable.reload({
                    page: {
                        curr: 1
                    }
                    , where: {
                        key: {"searchName": search.val()}
                    }
                }, 'data');
            }
        };

        $(".ctable-tool .layui-btn").on('click', function () {
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });

        form.on('switch(status)', function (obj) {
            var st = (obj.elem.checked) ? 1 : 0;
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/update"); ?>', {
                id: this.value,
                value: st,
                time: new Date().getTime()
            }, function (before) {
            }, function (res) {
                layer.tips(res.msg, obj.othis);
            }, function (error) {
                console.log('请求失败');
            });
        });

        table.on('edit(Ctable)', function (obj) {
            var value = obj.value
                , data = obj.data
                , field = obj.field;
            cre.xpost('<?php echo \rayswoole\Helper::url("admin/index/update"); ?>', {
                id: data.doc_id,
                field: field,
                value: value,
                time: new Date().getTime()
            }, function (before) {
            }, function (res) {
                layer.tips(res.msg, obj.othis);
                xtable.reload();
            }, function (error) {
                console.log('请求失败');
            });
        });


    });
</script>
</html>