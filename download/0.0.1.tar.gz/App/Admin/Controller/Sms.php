<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Controller;


use App\Admin\Service\ConfigService;
use rayswoole\Helper;

class Sms extends Base
{

    public function index(): void
    {
        $data = ConfigService::getInstance()->get('sms');
        $this->assign($data ?? []);
        $this->fetch();
    }


    public function save(): bool
    {
        if ($this->isAjax()) {
            $param = $this->post('sms');
            $update = array_map(static function ($value) {
                return trim($value);
            }, $param);
            ConfigService::getInstance()->update('sms', $update);
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功,请点击右上角 “重启服务” ', 'data' => []]);
        }
        return false;
    }
}