<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Service;


use App\Admin\Model\NavModel;
use rayswoole\Service;

class NavService extends Service
{


    public function navList($where, $page = 0, $limit = 20): array
    {
        $model = new NavModel();
        if ($page > 0) {
            $data = $model->where($where)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->where($where)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }

    public function getNav($where): array
    {
        $model = new NavModel();
        if ($res = $model->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    public function getNavTree(): ?array
    {
        $model = new NavModel();
        $this->tree($model->select()->toArray(), 0, 0, $res);
        return $res;
    }

    public function tree($data, $pid, $level, &$res)
    {
        $items = array();
        foreach ($data as $v) {
            $items[$v['nav_id']] = $v;
        }
        foreach ($items as $k => $v) {
            if ($v['nav_pid'] === $pid) {
                $v['nav_name'] = str_repeat(" ├─  ", $level) . $v['nav_name'];
                $res[] = $v;
                $this->tree($items, $v['nav_id'], $level + 1, $res);
            }
        }
        return $res;
    }

    public function saveNav(array $data): bool
    {
        $model = new NavModel();
        if (!empty($data['nav_id'])) {
            $model = $model->find($data['nav_id']);
        }
        return $model->save($data);
    }

    public function deleteNav($data): bool
    {
        return NavModel::destroy($data);
    }

}