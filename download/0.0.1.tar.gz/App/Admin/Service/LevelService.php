<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Admin\Service;

use rayswoole\Helper;
use rayswoole\Service;
use rayswoole\orm\facade\Db;

class LevelService extends Service
{

    /**
     * 获取等级信息
     * @param array $param
     * @return array
     * @throws \rayswoole\orm\db\exception\DataNotFoundException
     * @throws \rayswoole\orm\db\exception\DbException
     * @throws \rayswoole\orm\db\exception\ModelNotFoundException
     * @author zhou
     * @time 2020/10/22
     */
    public function getLevelList(array $param): array
    {
        $page = isset($param['page']) ? (int)$param['page'] : 1;
        $limit = isset($param['limit']) ? (int)$param['limit'] : 10;
        $where = [];

        $order = 'level_id';
        if (isset($param['key'])) {
            $key = $param['key'];
            if (isset($key['searchName']) && $key['searchName']) {
                $v = $key['searchName'];
                $where[] = ['level_name', 'like', "%{$v}%"];
            }
        }
        $res = Db::name('user_level')
            ->where($where)
            ->limit($limit * ($page - 1),$limit)
            ->order('level_id','asc')
            ->select()->toArray();
        //$res = $this->getList($where, $order, 'ASC', '*', $page, $limit);
        return [
            'code' => 0,
            'msg' => '等级列表',
            'count' => count($res),
            'data' => $res
        ];
    }


    public function saveLevel(array $param):array
    {
        $data = [
            "level_name" => htmlspecialchars($param['level_name']),
            "level_money" => htmlspecialchars($param['level_money']),
            "level_weekprice" => htmlspecialchars($param['level_weekprice']),
            "level_monthprice" => htmlspecialchars($param['level_monthprice']),
            "level_periodprice" => htmlspecialchars($param['level_periodprice']),
            "level_yearprice" => htmlspecialchars($param['level_yearprice']),
            "level_integral" => htmlspecialchars($param['level_integral']),
            "level_status" => isset($param['level_status']) ? 1 : 0,
        ];
        if(!empty($param['edit_id'])){
            $data['level_id']=$param['edit_id'];
        }
        $res = Db::name('user_level')->save($data);

        return [
            'code' => 0,
            'msg' => '添加成功',
            'result' => $res,
        ];
    }



}