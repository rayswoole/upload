<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Vod\Service;

use rayswoole\utils\Validators;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class ActorService extends Service
{

    /**
     * 表单数据验证
     * @param array $param
     * @param array $data
     * @return array
     * @author zhou
     * @time 2020/11/5
     */
    public function checkVar(array &$param, array $data): array
    {
        foreach ($data as $k => $v) {
            if (empty($param[$k]) && !is_numeric($param[$k])) {
                if (!($v[2] ?? false)) {
                    return ['status' => false, 'msg' => $v[1]];
                }
                continue;
            }
            if (false === Validators::is($param[$k], $v[0])) {
                return ['status' => false, 'msg' => $v[1]];
            }
        }
        return ['status' => true, 'msg' => '验证通过'];
    }

    /**
     * 演员列表
     * @return array
     * @throws \rayswoole\orm\db\exception\DataNotFoundException
     * @throws \rayswoole\orm\db\exception\DbException
     * @throws \rayswoole\orm\db\exception\ModelNotFoundException
     * @author zhou
     * @time 2020/11/5
     */
    public function getActorList()
    {
        $actors = Db::name('actor')
            ->where(['actor_status'=>1])
            ->order('actor_id','asc')
            ->select()->toArray();
        return $actors;
    }















}