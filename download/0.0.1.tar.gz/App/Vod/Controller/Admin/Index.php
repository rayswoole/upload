<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Vod\Controller\Admin;

use rayswoole\Helper;
use App\Vod\Extend\Upload;
use rayswoole\orm\facade\Db;
use App\Admin\Controller\Base;
use App\Vod\Service\TypeService;
use App\Vod\Service\VodService;

class Index extends Base{

    /**
     * 列表
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/11/5
     */
    public function index(){
        //电影类型
        $type_tree=TypeService::getInstance()->get();
        //播放器列表
        $player_list=Helper::service('Player')->getPlayerList();

        $this->assign(['type_tree'=>$type_tree,'player_list'=>$player_list]);
        $this->fetch();
    }

    /**
     * 列表数据接口
     * @return bool
     * @throws \rayswoole\orm\db\exception\DataNotFoundException
     * @throws \rayswoole\orm\db\exception\DbException
     * @throws \rayswoole\orm\db\exception\ModelNotFoundException
     * @author zhou
     * @time 2020/11/5
     */
    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? intval($param['page']) : 1;
            $limit = isset($param['limit']) ? intval($param['limit']) : 10;
            $where = [];
            $ordey = 'vod_id';
            //搜索条件
            $where_like=[];
            if (isset($param['key'])) {
                $key = (array)json_decode($param['key']);
                if (isset($key['vod_cid']) && $key['vod_cid']) {
                    $where['type_id'] = intval($key['vod_cid']);
                }
                if (isset($key['vod_play_from']) && $key['vod_play_from']) {
                    $where['vod_play_from']  = "{$key['vod_play_from']}";
                }
                if (isset($key['vod_area']) && $key['vod_area']) {
                    $where['vod_area'] = $key['vod_area'];
                }
                if (isset($key['vod_star']) && $key['vod_star']) {
                    $where['vod_star'] = intval($key['vod_star']);
                }
                if (isset($key['vod_status']) && $key['vod_status']) {
                    $where['vod_status'] = intval($key['vod_status']);
                }
                if (isset($key['vod_title']) && $key['vod_title']) {
                    $v = $key['vod_title'];
                    $where_like[] = ['vod_title|vod_id','like',"%{$v}%"];
                }
            }
            $res=Db::name('vod')
                ->where($where)->where($where_like)
                ->order($ordey,'DESC')
                ->limit(($page-1)*$limit,$limit)
                ->select()->toArray();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '视频列表',
                'count' => Db::name('vod')->where($where)->count('vod_id'),
                'data' => $res
            ]);
        }
    }


    /**
     * 添加页面
     **/
    public function create()
    {
        //演员
        $actors = Helper::service('Actor')->getActorList();
        //播放器
        $player_list=Helper::service('Player')->getPlayerList();
        //电影分类
        $type_tree=TypeService::getInstance()->get();

        //设置分类
        $data=Db::name('config')->column('val','name');
        $arr_type['area']=explode(',',$data['vod_extend_area']);
        $arr_type['lang']=explode(',',$data['vod_extend_lang']);
        $arr_type['year']=explode(',',$data['vod_extend_year']);

        $this->assign(['actors' => json_encode($actors),'type_tree'=>$type_tree,'arr_type'=>$arr_type,'player_list'=>$player_list]);
        $this->fetch();
    }

    //修改
    public function edit()
    {
        $param = $this->get();

        $res=Db::name('vod')->where([ 'vod_id' => intval($param['edit_id'])])->find();

        if (!$res) {
            // 没有数据跳转到错误页面
            return false;
        }
        $res['vod_play_url']    = str_replace('#',"\n",$res['vod_play_url']);
        $res['vod_play_url']    = explode('$$$',$res['vod_play_url']);
        $res['vod_play_from']   = explode('$$$',$res['vod_play_from']);
        $res['vod_play_server'] = explode('$$$',$res['vod_play_server']);

        $playurl = [];
        foreach ($res['vod_play_url'] as $k=>$url){
            $playurl[] = [
                'vod_play_url'=>$url,
                'vod_play_from'=>$res['vod_play_from'][$k],
                'vod_play_server'=>$res['vod_play_server'][$k],
            ];
        }

        foreach ($res['vod_play_url'] as $_k=>$_url){
            $res['vod_play_url['.$_k.']'] = $_url;
        }
        foreach ($res['vod_play_from'] as $_k=>$_url){
            $res['vod_play_from['.$_k.']'] = $_url;
        }
        foreach ($res['vod_play_server'] as $_k=>$_url){
            $res['vod_play_server['.$_k.']'] = $_url;
        }

        //播放器
        $player_list=Helper::service('Player')->getPlayerList();

        //演员
        $actors = Helper::service('Actor')->getActorList();
        //电影分类
        $type_tree=TypeService::getInstance()->get();
        //分类
        $data=Db::name('config')->column('val','name');
        $arr_type['area']=explode(',',$data['vod_extend_area']);
        $arr_type['lang']=explode(',',$data['vod_extend_lang']);
        $arr_type['year']=explode(',',$data['vod_extend_year']);

        $this->assign([
            'object'=>Helper::enJson($res),
            'vod_data' => $res,
            'arr_type'=>$arr_type,
            'actors' => Helper::enJson($actors),
            'type_tree'=>$type_tree,
            'play_info'=>$playurl,
            'player_list'=>$player_list

        ]);
        $this->fetch();

    }

    //增加修改保存数据
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            if (!empty($param['vod_play_from'])) {
                $param['vod_play_from']   = implode('$$$', $param['vod_play_from']);
                $param['vod_play_server'] = implode('$$$', $param['vod_play_server']);
                $param['vod_play_url']    = implode('$$$', $param['vod_play_url']);
                $param['vod_play_url']    = preg_replace('/[\t\r\n]+/','#', $param['vod_play_url']);
            } else {
                $param['vod_play_from']   = '';
                $param['vod_play_server'] = '';
                $param['vod_play_url']    = '';
            }

            //字段校验
            $validate = Helper::service('Vod')->checkVar($param, [
                'vod_title'    => ['alchina:1..50', '标题长度不能超出50个字符'],
                'vod_letter'   => ['alpha:..1', '首字母只能为单个字符', true],
                'vod_total'    => ['number:1..999999', '总集数不能超出999999个字符', true],
                'vod_serial'   => ['number:1..999999', '连载数不能超出999999个字符', true],
                'vod_score'    => ['number:1..999999', '评分不能超出999999个字符', true],
                'vod_duration' => ['number:1..999999', '时长不能超出999999个字符', true],
                'vod_jumpurl'  => ['url', '跳转链接格式不正确', true],
                'vod_blurb'    => ['alchina :1..300', '简介长度不能超出300个字符', true],
                'vod_sort'     => ['number:1..999999999', '排序只能为数字,且长度不能超出999999999', true],
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }

            $type_list=TypeService::getInstance()->simpleGet();

            $data = [
                "type_id"       => intval($param['type_id']),
                "vod_star"      => intval($param['vod_star']),
                "vod_title"     => htmlspecialchars(trim($param['vod_title'])),
                "vod_color"     => htmlspecialchars(trim($param['vod_color'])),
                "vod_lang"      => htmlspecialchars($param['vod_lang']),
                "vod_score"     => intval($param['vod_score']),
                "vod_letter"    => htmlspecialchars($param['vod_letter']),
                "vod_year"      => htmlspecialchars($param['vod_year']),
                "vod_area"      => htmlspecialchars($param['vod_area']),
                "vod_total"     => intval($param['vod_total']),
                "vod_serial"    => intval($param['vod_serial']),
                "vod_remarks"   => '更新到'.intval($param['vod_serial']).'集',
                "vod_class"     => $type_list[intval($param['type_id'])],
                "vod_actor"     => htmlspecialchars(str_replace('创建-', '', $param['vod_actor'])),
                "vod_director"  =>htmlspecialchars($param['vod_director']),
                "vod_actor_val" => htmlspecialchars($param['vod_actor_val']),
                "vod_duration"  => htmlspecialchars($param['vod_duration']),
                "vod_jumpstatus"=> isset($param['vod_jumpstatus']) ? 1 : 0,
                "vod_jumpurl"   => htmlspecialchars($param['vod_jumpurl']),
                "vod_status"    => isset($param['vod_status']) ? 1 : 0,
                "vod_pic"       => htmlspecialchars($param['vod_pic']),
                "vod_pic_thumb" => htmlspecialchars($param['vod_pic_thumb']),
                "vod_blurb"     => htmlspecialchars($param['vod_blurb']),
                "vod_content"   => $param['vod_content'],
                "vod_hits"      => intval($param['vod_hits']),
                "vod_hits_month" => intval($param['vod_hits_month']),
                "vod_hits_week"  => intval($param['vod_hits_week']),
                "vod_hits_day"   => intval($param['vod_hits_day']),
                "vod_sort"       => intval($param['vod_sort']),
                'vod_play_from'  => trim($param['vod_play_from']),
                'vod_play_url'   => $param['vod_play_url'],
                'vod_play_server'=> trim($param['vod_play_server'])
            ];

            if (isset($param['vod_id'])) {
                $data['vod_id']=$param['vod_id'];
            }
            $data['vod_play_url'] = preg_replace('/([\r\n][\r\n]*)/', '#', $data['vod_play_url']);
            //删除多余的缩略图
            $vodimg     = substr($data['vod_pic'], -10);
            $vodthumb   = substr($data['vod_pic_thumb'], -10);
            $unlinksrc  = EASYSWOOLE_ROOT . '/public' . str_replace("image", "thumb", $data['vod_pic']);

            if ($vodimg !== $vodthumb) {
                if (file_exists($unlinksrc)) {
                    unlink($unlinksrc);
                }
            }

            //保存数据
            //Db::name('vod')->save($data);
            VodService::getInstance()->saveVod($data);
            if (isset($param['vod_id'])) {
                $id = $param['vod_id'];
            }else{
                $id = Db::name('vod')->getLastInsID();
            }

            //演员表数据
            $arr = [
                'actorName' => htmlspecialchars(str_replace('创建-', '', $param['vod_actor'])),
                'actorId'   => $param['vod_actor_val'],
                'vod_name'  => $param['vod_title'],
            ];
            //演员视频对应表
            if($id){
                Db::name('actor_vod')->where(['vod_id'=>$id])->delete();
            }
            $name   =explode(",",$arr['actorName']);
            $actorid=explode(",",$arr['actorId']);
            $arr = [];
            foreach($actorid as $k=>$v){
                array_push($arr, [
                    'actor_id'=>$v
                    ,'vod_id'=>$id
                    ,'actor_name'=>$name[$k]
                    ,'vod_name'=>$data['vod_title']
                ]);
            }
            $result = Db::name('actor_vod')->insertAll($arr);

            if (!(bool)$result) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'result' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'result' => []]);
        }
    }

    /*
      * [updateField 字段值更新]
      * @method POST
      * @author C.
      * @time 2020/2/3 上午2:18
      */
    public function update_file()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'vod_status';
            $res = Db::name('vod')->update([
                $field => $value, 'vod_id'=>$id
            ]);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '更新失败', 'result' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '更新成功', 'result' => []]);

        }
    }

    //演员数据
    public function actorapi()
    {
        $param=$this->post();
        if (isset($param['actorname'])) {
            $v = $param['actorname'];
            $where[] = ['actor_name','like',"%{$v}%"];
        }
        $where[]=['actor_status','=',1];
        $result =Db::name('actor')->where($where)->order('actor_id','DESC')->select()->toArray();

        return Helper::responseJson(['code' => 0, 'msg' => '返回成功', 'result' => $result]);
    }

    //删除
    public function delete()
    {
        $isSoft = true;
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id=explode(',',$id);
            if (!$isSoft) {
                Db::name('vod')->delete($id);
            } else {
                $res = Db::name('vod')->select($id);
                $err = 0;
                foreach ($res as $v) {
                    $id = $v['vod_id'];
                    $result = Db::name('vod_recycle')->insert($v);
                    unset($v['vod_id']);
                    if ($result) {
                        Db::name('vod')->delete($id);
                    } else {
                        $err += 1;
                    }
                }
            }
            if (!$result) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'result' => $result]);
            } else {
                return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'result' => $result]);
            }
        }
    }

    //视频回收站列表
    public function recycle()
    {
        $this->fetch();
    }

    //视频回收站列表数据
    public function recycle_read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? intval($param['page']) : 1;
            $limit = isset($param['limit']) ? intval($param['limit']) : 10;

            $where = [];
            if (isset($param['searchName'])) {
                if (isset($param['searchName']) && $param['searchName']) {
                    $v = $param['searchName'];
                    $where[] = ['vod_title','like',"%{$v}%" ];
                }
            }

            $res=Db::name('vod_recycle')->where($where)->order('vod_id','ASC')->limit(($page-1)*$limit,$limit)->select();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '视频列表',
                'count' => Db::name('vod_recycle')->where($where)->count('vod_id'),
                'data' => $res
            ]);
        }
    }


    /**
     * 数据恢复
     * @return bool
     * @throws \Throwable
     * @author zhou
     * @time 2020/7/25
     */
    public function recovery()
    {
        if ($this->isAjax()) {
            $param = $this->post('id');
            $id = is_numeric($param) ? intval($param) : $param;
            $id=explode(',',$id);
            $res = Db::name('vod_recycle')->select($id);
            $err = 0;
            foreach ($res as $v) {
                $id = $v['vod_id'];
                $x = Db::name('vod')->insert($v);
                unset($v['vod_id']);
                if ($x) {
                    $result=Db::name('vod_recycle')->delete($id);
                } else {
                    $err += 1;
                }
            }
            if (!$result) {
                return Helper::responseJson(['code' => 1, 'msg' => '恢复失败', 'result' => $result]);
            } else {
                return Helper::responseJson(['code' => 0, 'msg' => '恢复成功', 'result' => $result]);
            }
        }
    }


    /**
     * 删除回收站数据 真
     * @return bool
     * @throws
     * @author zhou
     * @time 2020/7/25
     */
    public function recycle_delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id=explode(',',$id);

            $res = Db::name('vod_recycle')->delete($id);
            var_dump($res);
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'result' => $res] );
            } else {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'result' => $res]);
            }
        }
    }

    //播放器开始
    public function player_ist()
    {

        $this->fetch("player_list");
    }

    // 播放器列表
    public function player_read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page  = isset($param['page']) ? intval($param['page']) : 1;
            $limit = isset($param['limit']) ? intval($param['limit']) : 20;
            $where = [];
            $by = 'player_sort,player_id';
            if (isset($param['player_name'])) {
                if (isset($param['player_name'])) {
                    $v = $param['player_name'];
                    $where[] = ['player_name', 'like',"%{$v}%"];
                }
            }
            $res = Db::name('vod_player')->where($where)->order($by, 'ASC')->limit(($page-1)*$limit, $limit)->select()->toArray();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '播放器列表',
                'count' => Db::name('vod_player')->where($where)->count('player_id'),
                'data' => $res
            ]);
        }
    }

    public function player_create()
    {
        $this->fetch();
    }


    public function player_edit()
    {
        $param = $this->get();

        $res = Db::name('vod_player')->where(['player_id' => intval($param['edit_id'])])->find();

        if (!$res) {
            return false;
        }
        $this->assign(['player_data' => $res]);
        $this->fetch();

    }


    public function player_save()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            //验证
            if (!$str = $this->post('player_name','','required')) {
                Helper::responseHtml('名称不能为空或多于20个字');
            }

            //字段校验
            $validate = Helper::service('Vod')->checkVar($param, [
                'player_from'  => ['alchina:1..50', '编码只能为中文\a-z\A-Z\0-9-_且长度不能超出50个字符'],
                'player_name'  => ['alchina:1..50', '名称只能为中文\a-z\A-Z\0-9-_且长度不能超出50个字符'],
                'player_desc'  => ['alchina:1..255', '备注只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符', true],
                'player_parse' => ['url', 'url格式不正确', true],
                'player_sort'  => ['number:1..999999999', '排序只能为数字,且长度不能超出999999999', true],
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }

            $data = [
                "player_status" => intval($param['player_status']),
                "player_from"   => htmlspecialchars(trim($param['player_from'])),
                "player_name"   => htmlspecialchars(trim($param['player_name'])),
                "player_desc"    => htmlspecialchars($param['player_desc']),
                "player_ps"     => intval($param['player_ps']),
                "player_parse"  => htmlspecialchars($param['player_parse']),
                "player_sort"   => intval($param['player_sort']),
                "player_code"   => htmlspecialchars($param['player_code']),
            ];
            if (isset($param['edit_id'])) {
                $data['player_id']=$param['edit_id'];
            }

            $res=Db::name('vod_player')->save($data);

            if (!(bool)$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'result' => []]);
            }else {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'result' => []]);
            }
        }
    }

    public function player_delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id=explode(',',$id);
            $res = Db::name('vod_player')->delete($id);

            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'result' => []]);
            } else {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'result' => []]);
            }
        }
    }

    /*
    * [updateField 字段值更新]
    * @method POST
    * @author C.
    * @time 2020/2/3 上午2:18
    */
    public function update_playfile()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'player_status';
            $res = Db::name('vod_player')->update([
                $field => $value,'player_id'=>$id
            ]);

            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '更新失败', 'result' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '更新成功', 'result' => []]);

        }
    }

    /**
     * 上传文件
     * @return bool
     * @author zhou
     * @time 2020/7/25
     */
    public function upload()
    {
        $param = $this->request()->getRequestParam();
        $field = 'image';
        $path = '/static/upload/vod/image/';
        $path2 = '/static/upload/vod/thumb/';
        if ($param) {
            switch ($param['type']) {
                case 'image':
                    $field = 'image';
                    $path = '/static/upload/vod/image/';
                    break;
                case 'thumb':
                    $field = 'thumb';
                    $path = '/static/upload/vod/thumb/';
                    break;
            }
        }
        $config = [
            'field' => $field,
            'notExistenceMsg' => '请选择要上传的图片',
            'size' => [
                'ext' => 1024 * 1024 * 5,
                'msg' => '图片不能大于5M'
            ],
            'type' => [
                'mediaType' => ['png', 'peng', 'jpg', 'jpeg', 'gif', 'jpeg', 'pem', 'ico'],
                'msg' => '文件类型不正确！'
            ],
            'path' => $path,
        ];

        $res = Upload::getInstance($this->request())->setConfig($config)->upload();

        //如果上传的是图片则自动生成一张缩略图
        if ($param['type'] == 'image2') {

            $date = date("Y-m-d", time());
            $thumbpath = EASYSWOOLE_ROOT . '/public' . $path2 . $date . '/';
            if (!is_dir($thumbpath)) {
                mkdir($thumbpath, 0777, true);
            }
            $thumbname = $thumbpath . $res['result']['name']; //缩略图名称
            $src = EASYSWOOLE_ROOT . '/public' . $res['result']['src']; //上传图片地址和名称

            $image = \think\Image::open($src);
            $image->thumb(300,300)->save($thumbname);
        }
        $res['result']['thumbsrc'] = $path2 . $date . '/' . $res['result']['name'];
        return Helper::responseJson(['code' => $res['code'], 'msg' => $res['msg'], 'data' => $res['result']]);
    }
}
