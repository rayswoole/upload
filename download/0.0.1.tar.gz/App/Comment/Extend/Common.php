<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Comment\Extend;


use EasySwoole\EasySwoole\ServerManager;
use rayswoole\Service;
use rayswoole\utils\Crypt;
use rayswoole\utils\Validators;

class Common extends Service
{
    public function checkVar(array &$param, array $data): array
    {
        foreach ($data as $k => $v) {
            if (empty($param[$k]) && !is_numeric($param[$k])) {
                if (!($v[2] ?? false)) {
                    return ['status' => false, 'msg' => $v[1]];
                }
                continue;
            }
            if (false === Validators::is($param[$k], $v[0])) {
                return ['status' => false, 'msg' => $v[1]];
            }
        }
        return ['status' => true, 'msg' => '验证通过'];
    }

    public function checkCookie(): array
    {
        $token_a = (($c = json_decode($this->request()->getCookieParams('ULTOKEN'), true)) ? $c : json_decode($this->request()->getHeaderLine('token'), true));
        $token = $token_a['token'] ?? '';
        $username = $token_a['user_name'] ?? '';
        $ip = $this->ray_get_client_ip();
        if ($token && $ip && $username) {
            $token_decrypt = Crypt::opensslDecode($token);
            $token_decrypt_res = explode('_', $token_decrypt);
            $token_decrypt_res_count = count($token_decrypt_res);
            if ($token_decrypt_res_count !== 5) {
                return [];
            }
            $token_time = $token_decrypt_res[$token_decrypt_res_count - 1];
            $token_ip = $token_decrypt_res[$token_decrypt_res_count - 2];
            if ($token_ip === $ip && ($token_time + 60 * 60) > time()) {
                return [
                    'user_id' => $token_decrypt_res[0],
                    'site_id' => $token_decrypt_res[1],
                    'level_id' => $token_decrypt_res[2],
                    'user_name' => $username
                ];
            }
        }
        return [];
    }

    public function ray_get_client_ip(): string
    {
        $ip = ServerManager::getInstance()->getSwooleServer()->connection_info($this->request()->getSwooleRequest()->fd)['remote_ip'];
        if ($ip === '127.0.0.1') {
            $ip = $this->request()->getHeaders()['x-real-ip'][0];
        }
        return $ip;
    }
}