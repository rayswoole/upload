<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Comment\Model;


use rayswoole\orm\Model;

class CommentModel extends Model
{
    protected $name = 'comment';
    protected $pk = 'comment_id';


    public function user(): \rayswoole\orm\model\relation\HasOne
    {
        return $this->hasOne('UserModel', 'user_id','user_id')->bind(['user_name']);
    }




}