<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Ads\Controller\Admin;

use App\Admin\Controller\Base;
use App\Ads\Extend\Common;
use App\Ads\Service\AdsService;
use App\Vod\Extend\Upload;
use rayswoole\orm\facade\Db;
use rayswoole\Helper;

class Index extends Base
{

    protected function actionNotFound(?string $action)
    {
        $this->response()->withStatus(404);
        $file = EASYSWOOLE_ROOT.'/vendor/easyswoole/easyswoole/src/Resource/Http/404.html';
        if(!is_file($file)){
            $file = EASYSWOOLE_ROOT.'/src/Resource/Http/404.html';
        }
        $this->response()->write(file_get_contents($file));
    }

    /*
     * [index 渲染首页]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:19
     */
    public function index()
    {
        // 渲染页面
        $this->fetch();
    }

    /*
     * [create 渲染创建页面]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:19
     */
    public function create()
    {
        //网站模板目录
        $temarry=Common::getDirarr();
        //广告位置
        $positarr = Helper::service('Ads')->getPositArr();

        $this->assign(['temarry' => $temarry,'positarr'=>$positarr]);
        $this->fetch();
    }

    /*
     * [edit 渲染编辑页]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:19
     */
    public function edit()
    {
        $param = $this->get();

        $res = Db::name('ads')->where(['ad_id'=>intval($param['edit_id'])])->find();
        if (!$res) {
            return false;
        }
        //前端模板目录
        $temarry=Common::getDirarr();

        //广告位置
        $positarr=AdsService::getInstance()->getPositArr();

        $this->assign(['data' => $res,'temarry' => $temarry,'positarr' => $positarr]);
        $this->fetch();
    }
    /*
         * [updateField 字段值更新]
         * @method POST
         * @author C.
         * @time 2020/2/3 上午2:18
         */
    public function update_field()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'ad_status';

            $res = Db::name('Ads')->update([
                $field => $value,'ad_id'=>$id
            ]);

            if (!$res) {
                return  Helper::responseJson(['code' => 1, 'msg' => '更新失败', 'result' => []]);
            }else{
                return  Helper::responseJson(['code' => 0, 'msg' => '更新成功', 'result' => []]);
            }

        }
    }

    /*
     * [delete 删除数据]
     * @method POST
     * @author C.
     * @date 2020/1/3 下午6:18
     */
    public function delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id = explode(',',$id);
            //$res = AdsModel::create()->deleteData($id);
            $res = Db::name('ads')->delete($id);

            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'result' => []]);
            } else {
                return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'result' => []]);
            }
        }
    }


    /*
     * [save 新增保存数据]
     * @method POST
     * @author C.
     * @date 2020/1/3 下午6:18
     */
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            //字段校验
            $validate = Common::checkVar($param, [
                'ad_title'  => ['alchina:1..255', '标题只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符'],
                'ad_posit'  => ['alchina:1..255', '请选择广告位置'],
                'ad_words'  => ['alchina:1..255', '文字一只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符', true],
                'ad_words2' => ['alchina:1..255', '文字二只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符', true],
                'ad_words3' => ['alchina:1..255', '文字三只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字', true],
                'ad_sort'   => ['number:1..999999999', '排序只能为数字,且长度不能超出999999999', true],
                'ad_jump_url'  => ['url', '条件链接只能为合法URL', true],
                'art_hits_day' => ['number:1..99999999', '天人气只能为数字,且长度不能超出99999999', true]

            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }

            $res = Helper::service('Ads')->saveAds($param);
            if (!(bool)$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'result' => []]);
            }else{
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'result' => []]);
            }

        }
    }

    /*
     * [read 读取数据]
     * @method GET
     * @author C.
     * @date 2020/1/3 下午6:17
     */
    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? intval($param['page']) : 1;
            $limit = isset($param['limit']) ? intval($param['limit']) : 10;
            $where = [];
            $where_like=[];
            //默认站点为1的是默认配置
            $where['site_id']=1;

            if (isset($param['ad_title']) && $param['ad_title']) {
                $v = $param['ad_title'];
                $where_like[] = ['ad_title','like',"%{$v}%"];
            }

            $res = Db::name('ads')->where($where)->where($where_like)->order('ad_id','DESC')->limit(($page-1)*$limit,$limit)->select()->toArray();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '广告列表',
                'count' => Db::name('ads')->where($where)->count('ad_id'),
                'data' => $res
            ]);
        }
    }

    /**
     *  //广告位置列表
     */
    public function positindex()
    {
        $this->fetch();
    }

    /**
     *   添加 修改 广告位置
     */
    public function positinfo()
    {
        $param = $this->get();
        $edit_id = isset($param['edit_id']) ? intval($param['edit_id']) : 0 ;

        if ($edit_id) {
            $res = Db::name('ad_posit')->where(['posit_id'=>intval($param['edit_id'])])->find();
            //$res = PositModel::create()->getData(['posit_id'=>intval($param['edit_id'])]);
            if (!$res) {
                // 没有数据跳转到错误页面
                return false;
            }
            $this->assign(['data' => $res]);
        }
        $this->fetch();
    }

    /**
     * 保存
     * @return bool
     * @throws \EasySwoole\ORM\Exception\Exception
     */
    public function positsave()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $edit_id = isset($param['posit_id']) ? intval($param['posit_id']) : 0 ;
            $data = [
                "posit_ssid" => htmlspecialchars($param['posit_ssid']),
                "posit_ad"   => htmlspecialchars($param['posit_ad']),
                "posit_addtime" => time(),
            ];
            if($edit_id){
                $data['posit_id']=$edit_id;
            }
            $res = Db::name('ad_posit')->save($data);

            if (!(bool)$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'result' => []]);
            }else{
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'result' => []]);
            }
        }

    }

    //删除
    public function positdelete()
    {
        if ($this->isAjax()) {
            $param = $this->post();;
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id = explode(',',$id);
            $res = Db::name('ad_posit')->delete($id);

            if (!(bool)$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'result' => []]);
            }else{
                return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'result' => []]);
            }

        }
    }

    /*
        * [adread 读取数据]
        * @method GET
        * @author C.
        * @date 2020/1/3 下午6:17
        */
    public function positread()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? intval($param['page']) : 1;
            $limit = isset($param['limit']) ? intval($param['limit']) : 10;
            $where = [];
            $where_like=[];
            if (isset($param['posit_ssid']) && $param['posit_ssid']) {
                $v = $param['posit_ssid'];
                $where[] = ['posit_ssid', 'like',"%{$v}%"];
            }
            $res = Db::name('ad_posit')
                ->where($where)
                ->where($where_like)
                ->order('posit_id','desc')
                ->limit(($page-1)*$limit,$limit)
                ->select()->toArray();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '广告位置列表',
                'count' => Db::name('ad_posit')->where($where)->count('posit_id'),
                'data' => $res
            ]);
        }
    }

    /*
        * [upload 上传文件]
        * @method POST
        * @author C.
        * @date 2020/1/18 上午10:42
        */
    public function upload()
    {
        $param = $this->request()->getRequestParam();
        $field = 'image';
        $path = '/Public/static/upload/advertising/image/';
        if ($param) {
            switch ($param['type']) {
                case 'image':
                    $field = 'image';
                    $path = '/static/upload/advertising/image/';
                    break;
                case 'thumb':
                    $field = 'thumb';
                    $path = '/static/upload/advertising/thumb/';
                    break;
            }
        }
        $config = [
            'field' => $field,
            'notExistenceMsg' => '请选择要上传的图片',
            'size' => [
                'ext' => 1024 * 1024 * 5,
                'msg' => '图片不能大于5M'
            ],
            'type' => [
                'mediaType' => ['png', 'peng', 'jpg', 'jpeg', 'gif', 'jpeg', 'pem', 'ico'],
                'msg' => '文件类型不正确！'
            ],
            'path' => $path,
        ];
        $res = Upload::getInstance($this->request())->setConfig($config)->upload();
        return Helper::responseJson(['code' => $res['code'], 'msg' => $res['msg'], 'data' => $res['result']]);

    }

}