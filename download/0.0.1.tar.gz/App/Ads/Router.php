<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
return [
    //'/'=>array(['GET'], '/index/index/index/index/'),
    //'/index.html'=>array(['GET'], '/index/index/index/index/'),
    '/ray/id/{id:\d+}[/{pid}[/{s:.+}]]'=>array(['GET'], 'index/test'),
    //'/rpc/id/{id:\d+}[/{nid}[/{mid}]]'=>array(['GET'], 'index/index')
];