<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-16 14:43
 ** ----------------------------------------------------------------------
 **/

namespace App\Index\Extend;


class Common extends \App\Art\Extend\Common
{
}