<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-08-07 09:49
 ** ----------------------------------------------------------------------
 **/

namespace App\Index\Model;

use rayswoole\orm\Model;
use rayswoole\orm\facade\Db;

class VodModel extends Model
{
    protected $name = 'vod';

    public function getTagList($tag):array
    {
        $data=$this->limit(10)->select()->toArray();

        return $data;

    }




}