<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-08-27 15:35
 ** ----------------------------------------------------------------------
 **/

namespace App\Index\Service;

use App\Index\Model\TestModel;
use rayswoole\Service;

class TestService extends Service
{
    public function dataList()
    {
        $testModel = new TestModel();
        return $testModel->cache(true)->select();
    }
}