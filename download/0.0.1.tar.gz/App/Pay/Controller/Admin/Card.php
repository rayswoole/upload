<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Pay\Controller\Admin;

use App\Admin\Controller\Base;
use rayswoole\orm\facade\Db;
use rayswoole\Helper;

class Card extends Base
{

    protected function actionNotFound(?string $action)
    {
        $this->response()->withStatus(404);
        $file = EASYSWOOLE_ROOT.'/vendor/easyswoole/easyswoole/src/Resource/Http/404.html';
        if(!is_file($file)){
            $file = EASYSWOOLE_ROOT.'/src/Resource/Http/404.html';
        }
        $this->response()->write(file_get_contents($file));
    }


    public function index()
    {
        return $this->fetch();
    }


    public function read(): ?bool
    {
        if ($this->isAjax()) {
            $param = (array)$this->get();

            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 10;
            $where = [];

            if (isset($param['key'])) {
                $key = $param['key'];
                if (isset($key['searchName']) && $key['searchName']) {
                    $v = $key['searchName'];
                    $where[] = ['card_no|card_money', 'like',"%{$v}%"];
                }
            }

            $res = Db::name('pay_card')->where($where)->order('card_id','ASC')->page(($page-1)*$limit,$limit)->select()->toArray();

            return Helper::responseJson([
                'code' => 0,
                'msg' => '充值卡列表',
                'count' => Db::name('pay_card')->where($where)->count('card_id'),
                'data' => $res
            ]);
        }
    }
    /**
     * 添加
     */
    public function create()
    {

        return $this->fetch();
    }

    /**
     * 新增保存数据
     * @return bool
     * @throws \Throwable
     * @author zhou
     * @time 2020/7/25
     */
    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            //字段校验
            $validate = Helper::service('Card')->checkVar($param, [
                'card_num'   => ['number:1..50', '排序只能为数字,且长度不能超出50个'],
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }

            $res = Helper::service('Card')->saveCard($param);
            return Helper::responseJson($res);

        }
    }

    /**
     * deleteData
     */
    public function delete()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = is_numeric($param['id']) ? intval($param['id']) : $param['id'];
            $id = explode(',',$id);
            $res = Db::name('pay_card')->delete($id);

            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '失败', 'result' => $res]);
            } else {
                return Helper::responseJson(['code' => 0, 'msg' => '成功', 'result' => $res]);
            }
        }
    }

    /**
     * 修改
     * @author zhou
     * @time 2020/7/25
     */
    public function edit()
    {
        $param = $this->get();
        $edit_id=$param['edit_id'] ?? '';
        if ($edit_id) {
            $res = CardModel::create()->getOneData([ 'cash_id' => intval($param['edit_id'])]);
            $this->assgin(['data' => $res]);
        }
        return $this->fetch();
    }

    /**
     * 字段值更新
     */
    public function update_field()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $field = $param['field'] ?? 'card_status';

            $res = Db::name('pay_card')->update([
                $field => $value,'card_id'=>$id
            ]);
            if (!$res) {
                return  Helper::responseJson(['code' => 1, 'msg' => '更新失败', 'result' => []]);
            }else{
                return  Helper::responseJson(['code' => 0, 'msg' => '更新成功', 'result' => []]);
            }
        }
    }




}