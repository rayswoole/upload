<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Controller;

use rayswoole\Helper;

class Login extends Base
{

    public function index()
    {

        return $this->fetch();
    }

    public function check(): bool
    {
        if ($this->isAjax()) {
            $username = $this->post('username', '', 'required|alchina:1..50');
            $password = $this->post('password', '', 'required:6..50');
            $res = Helper::service('User')->login($username, $password);
            return Helper::responseJson($res);
        }
        return false;
    }

    public function loginout()
    {
        Helper::response()->setCookie('ULTOKEN', '', time() - 1);
        return Helper::response()->redirect('/user/login/index');
    }

}