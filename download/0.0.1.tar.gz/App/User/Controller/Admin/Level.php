<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Controller\Admin;


use App\User\Extend\Common;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Level extends Base
{

    public function index()
    {
        $this->fetch();
    }

    public function read()
    {
        if ($this->isAjax()) {
            $param = $this->get();
            $page = isset($param['page']) ? (int)$param['page'] : 1;
            $limit = isset($param['limit']) ? (int)$param['limit'] : 20;
            $where = [];
            $order = 'level_id';
            if (!empty($param['key'])) {
                $key = $param['key'];
                if (!empty($key['searchName'])) {
                    $where[] = ['level_name', 'like', "%{$key['searchName']}%"];
                }
            }
            $res = Db::name('user_level')->where($where)->order($order)->page($page, $limit)->select()->toArray();
            $count = Db::name('user_level')->where($where)->count();
            return Helper::responseJson(['code' => 0, 'msg' => '数据查询', 'data' => $res, 'count' => $count]);
        }
    }

    public function create(): void
    {
        $this->fetch();
    }

    public function edit(): bool
    {
        $id = (int)$this->get('id');
        $res = Db::name('user_level')->where(['level_id' => $id])->find();
        if (!$res) {
            return Helper::responseJson(['msg' => '未找到数据']);
        }
        $this->assign(['edit' => $res]);
        $this->fetch();
        return false;
    }

    public function save()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $validate = Common::getInstance()->checkVar($param, [
                "level_name" => ['alchina:1..255', '名称只能为中文\a-z\A-Z\0-9-_且长度不能超出255个字符'],
            ]);
            if (false === $validate['status']) {
                return Helper::responseJson(['code' => 1, 'msg' => $validate['msg'], 'data' => []]);
            }

            $res = Helper::service('Level')->columnType();
            array_walk($param, static function (&$v, $k) use (&$res) {
                if (!empty($res[$k])) {
                    $v = in_array($res[$k]['data_type'], ['int', 'tinyint']) ? (int)$v : addslashes(trim($v, "/\\ \t\n\r\0\x0B"));
                }
            });
            $res = Helper::service('Level')->saveLevel($param);
            if ($res) {
                return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
            }
            return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
        }
    }


    public function update()
    {
        if ($this->isAjax()) {
            $param = $this->post();
            $id = (int)$param['id'];
            $field = $param['field'] ?? 'level_status';
            $value = is_numeric($param['value']) ? (int)$param['value'] : htmlspecialchars($param['value']);
            $res = Helper::service('Level')->saveLevel([
                $field => $value,
                'level_id' => $id
            ]);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '保存失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '保存成功', 'data' => []]);
        }
    }

    public function delete(): ?bool
    {
        if ($this->isAjax()) {
            $id = $this->post('id');
            $data = explode(',', $id);
            $res = Helper::service('Level')->deleteLevel($data);
            if (!$res) {
                return Helper::responseJson(['code' => 1, 'msg' => '删除失败', 'data' => []]);
            }
            return Helper::responseJson(['code' => 0, 'msg' => '删除成功', 'data' => []]);
        }
    }

}