<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Art\Controller;

use App\Art\Extend\Common;
use App\Art\Service\TypeService;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;

class Index extends Base
{
    public function index()
    {
        $param = Common::ray_param_url();
        $key = 'html_art@index/index/page/'.$param['page'];
        if ($this->siteConfig['art_cache_index'] > 10 && $html = Cache::getInstance()->get($key)){
            return Helper::responseHtml($html);
        }
        Context::set('obj',null);
        Context::set('param',$param);
        $html = $this->fetch('index/index', false);
        if ($this->siteConfig['art_cache_index'] > 10){
            Cache::getInstance()->set($key, $html, $this->siteConfig['art_cache_index']);
        }
        return Helper::responseHtml($html);

        $this->fetch('index/index');
    }
}