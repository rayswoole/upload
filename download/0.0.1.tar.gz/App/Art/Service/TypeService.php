<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-23 14:54
 ** ----------------------------------------------------------------------
 **/

namespace App\Art\Service;

use rayswoole\orm\facade\Db;
use rayswoole\Service;

class TypeService extends Service
{
    public function get(int $key = 0)
    {
        $result = Db::name('art_type')->where('type_status', 1)->order('type_pid','desc')->column('*','type_id');
        if (!empty($result)){
            foreach ($result as $_id=>$_result){
                if ($_result['type_pid'] > 0){
                    $result[$_id]['parent'] = $result[$_result['type_pid']];
                    if (isset($_result['type_child'])){
                        $result[$_result['type_pid']]['type_child'] = $_result['type_child'].','.$_result['type_id'];
                    } else {
                        $result[$_result['type_pid']]['type_child'] = ($result[$_result['type_pid']]['type_child'] ?? '').','.$_result['type_id'];
                    }
                } else {
                    $result[$_id]['parent'] = ['type_id'=>0];
                }
            }
        }
        if ($key === 0){
            return $result;
        }
        return $result[$key] ?? null;
    }

    public function simpleGet()
    {
        $data = $this->get();
        return array_map(function ($value){
            return $value['type_name'];
        }, $data);
    }
}