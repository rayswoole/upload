<?php
//自动生成,请勿修改

return array(
    ['0 */1 * * *', 'App\\Vod\\Cron\\CollectCron']
);