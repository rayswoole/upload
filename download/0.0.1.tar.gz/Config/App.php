<?php
return [
    'SERVER_NAME' => "rayswoole",
    'MAIN_SERVER' => [
        'LISTEN_ADDRESS' => '127.0.0.1',
        'PORT' => 9501,                                 //监听端口, 如果不是启动多个服务或端口已被使用不建议修改
        'SERVER_TYPE' => EASYSWOOLE_WEB_SERVER,         //服务类型, 不建议修改
        'SOCK_TYPE' => SWOOLE_TCP,                      //数据包解析方式, 不建议修改
        'RUN_MODEL' => SWOOLE_PROCESS,                  //运行模式, 不建议修改
        'SETTING' => [
            'worker_num' => swoole_cpu_num()>=4 ? swoole_cpu_num() : swoole_cpu_num()*2,
            'reload_async' => true,                     //设置为 true 时，将启用异步安全重启特性
            'max_wait_time'=>3,                         //设置 Worker 进程收到停止服务通知后最大等待时间
            //'dispatch_mode'=>1,                       //数据包分发策略
            'open_cpu_affinity'=>true,                  //启用 CPU 亲和性设置
            'tcp_fastopen'=>true,                       //开启 TCP 快速握手特性
            'upload_tmp_dir'=>RAY_ROOT.'/Runtime/Tmp/',  //$_FILES临时文件存放目录
            'pid_file'=>RAY_ROOT.'/Runtime/Temp/pid.pid',
            'log_file'=>RAY_ROOT.'/Runtime/Log/swoole.log',
            'log_level'=>SWOOLE_LOG_NONE,
        ],
        'TASK'=>[
            'workerNum'=>swoole_cpu_num(),
            'maxRunningNum'=>128,
            'timeout'=>15
        ],
        'PHP_PATH'=>'',             //自定义PHP环境的运行路径/usr/bin/php
    ],
    'SESSION' => [
        'type' => 'file',           //SESSION存储模式file、memcache、redis
        'expire' => 7200            //过期时间,秒
    ],
    'DEBUG' => true,                //开启调试模式
    'GLOBAL_PARAM' => false,        //开启全局变量兼容模式, 使$_GET $_POST $_FILES可用, 不支持$_SESSION
    'TEMP_DIR' => null,
    'LOG_DIR' => null,
    'CACHE_DIR' => null,
    'SUFFIX' => ['.php','.html','.htm']//支持路由的后缀
];