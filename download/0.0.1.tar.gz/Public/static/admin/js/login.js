"use strict";
!function (e) {
    var n = function n() {
        this.domain = "", this.config = {
            path: {
                login: "/user/api/login",
                registered: "/user/api/user_register",
                user_info: "/user/api/index",
                retrieve_pass: "/user/api/retrieve"
            },
            url: {
                login_check: this.domain + "/user/api/login_check",
                user_info: this.domain + "/user/api/user_info",
                point_annal: this.domain + "/user/api/annal_read",
                exchange_annal: this.domain + "/user/api/annal_list",
                point_cash: this.domain + "/user/api/upoint_list",
                level_up: this.domain + "/user/api/level_up",
                user_sublist: this.domain + "/user/api/sublist_read",
                user_promote: this.domain + "/user/api/promote_detailt",
                point_info: this.domain + "/user/api/point_info",
                registered_check: this.domain + "/user/api/register",
                _save_user_info: this.domain + "/user/api/save_user_info",
                _save_active_upoint: this.domain + "/user/api/save_active_upoint",
                _save_cash_rawal: this.domain + "/user/api/save_cash_rawal",
                _save_card_check: this.domain + "/user/api/save_card_check",
                _save_exchange_level: this.domain + "/user/api/save_exchange_level",
                find_pass: this.domain + "/user/api/findpass",
                set_pass: this.domain + "/user/api/setpassword"
            },
            nav: [{
                title: "用户中心",
                children: [{title: "用户信息", url: "", index: "user_info_at", event: "user_info"}]
            }, {
                title: "积分管理",
                children: [{title: "积分流水", url: "", index: "point_annal", event: "point_annal"}, {
                    title: "积分兑换",
                    url: "",
                    index: "exchange_annal",
                    event: "exchange_annal"
                }, {title: "积分提现", url: "", index: "point_cash", event: "point_cash"}]
            }, {
                title: "提现管理",
                children: [{title: "充值卡兑换", url: "", index: "exchange_card", event: "exchange_card"}, {
                    title: "等级升级",
                    url: "",
                    index: "level_up",
                    event: "level_up"
                }]
            }, {
                title: "推广管理",
                children: [{title: "下级列表", url: "", index: "user_sublist", event: "sub_list"}, {
                    title: "推广明细",
                    url: "",
                    index: "user_promote",
                    event: "user_promote"
                }]
            }],
            script: {
                step_js: this.domain + "/static/js/layui/layui_exts/",
                layui_js: this.domain + "/static/js/layui/layui/layui.all.js",
                layui_css: "https://www.layuicdn.com/layui-v2.5.6/css/layui.css"
            }
        }, "undefined" != typeof layer && "undefined" != typeof layui || this.getScript.load(this.config.script.layui_js, function () {
            layui.link(login.config.script.layui_css), console.log("ok")
        })
    };
    n.prototype.render_userinfo = function (e, n, i) {
        this.config = $.extend(this.config, i, {});
        var t = '<style>\n.user_info_conn {\nwidth: 100%;\nheight: 100%;\nmargin: 0;\npadding: 0;\nposition: relative;\n}\n.user_info_conn .user_info_nav {\nmargin-right: 20px;\npadding: 5px;\nfloat: left;\nheight: 100%;\nborder-right: 1px solid #cccccc;\nwidth: 220px;\n/*overflow-x: hidden;*/\noverflow-y: scroll;\n}\n.user_info_conn a, .user_info_conn span {\ntext-decoration: none;\ndisplay: inline-block;\ncolor: #000;\n}\n.user_info_conn .user_info_nav ul {\npadding-left: 20px;\n}\n.user_info_conn .user_info_nav li {\nlist-style: none;\ndisplay: inline-block;\npadding: 5px 10px;\n}\n.user_info_conn .user_info_nav li .title span {\nfont-size: 26px;\nmargin: 5px 0;\n}\n.user_info_conn .user_info_nav li .title2 span {\nfont-size: 16px;\nmargin: 5px 0;\n}\n.user_info_conn .user_info_nav .nav {\nfont-size: 16px;\n}\n.user_info_conn .user_info_nav .nav a {\nwidth: 100%;\nheight: 100%;\n}\n.user_info_conn .user_info_active a {\nfont-weight: bold;\ncolor: #1ca38a;\n}\n.user_info_conn .user_info_content {\nfloat: left;\nwidth: 70%;\nposition: absolute;\nleft: 230px;\ntop: 30px;\npadding: 0 0 0 35px;\n}\n.user_info_conn .user_info_content .user_info_item {\ndisplay: none;\n}\n.user_info_conn .user_info_content:after {\ncontent: ".";\ndisplay: block;\nheight: 0;\nclear: both;\nvisibility: hidden;\n}\n.scrollbar_df::-webkit-scrollbar {\nwidth: 5px;\nheight: 1px;\n}\n.scrollbar_df::-webkit-scrollbar-thumb {\nborder-radius: 5px;\n-webkit-box-shadow: inset 0 0 5px rgba(230, 230, 230, 0.2);\nbackground: #ccc;\n}\n.scrollbar_df::-webkit-scrollbar-track {\n-webkit-box-shadow: inset 0 0 5px rgba(255, 255, 255, 0.2);\nborder-radius: 5px;\nbackground: #fff;\n}\n</style><div class="user_info_conn">\n<div class="user_info_nav scrollbar_df">\n</div>\n<div class="user_info_content scrollbar_df">\n</div>\n</div>',
            a = this;
        "open" === n ? window.open(a.config.path.user_info) : "click" === n ? e ? $(document).on("click", e, function () {
            a.alert("用户中心", t), setTimeout(function () {
                a._nav()
            }, 100)
        }) : a.alert("用户中心", t) && setTimeout(function () {
            a._nav()
        }, 100) : (e && $(e).html("").html(t), setTimeout(function () {
            a._nav()
        }, 100)), setTimeout(function () {
            layui.form.render()
        }, 100);
    }, n.prototype.render_login = function (e, n, w, h, ty) {
        var i = this,
            t = ty === 'path' ? i.config.path.login : '<style>.login_conn{height:100%;overflow:hidden;}#u_login{margin-top:5%;}#u_login,.login_conn{position:relative;}.login_conn .login_move{display:inline-block;position:absolute;right:45px;top:51%;cursor:pointer;margin-top:12px;}.login_conn .login_move a{padding:3px 6px;}#u_login .login_item{padding:10px;position:relative;}#u_login .login_item .login_lavel{display:inline-block;text-align:right;width:20%;margin-right:10px;}#u_login .login_item .login_input{width:75%;display:inline-block;}#u_login .login_item .login_button{position:absolute;left:25%;margin-top:12px;}#u_login .login_item .login_button input{display:inline-block;padding:10px 25px;}#u_login .login_item .login_input input{text-indent:1em;width:100%;height:35px;line-height:35px}</style><div class="login_conn">' +
                '<form action="" id="u_login">\n' +
                '<div class="login_item"><label class="login_lavel">用户名</label><div class="login_input">' +
                '<input type="text" name="username" id="u_username" placeholder="用户名" style="">\n</div></div>' +
                '<div class="login_item"><label class="login_lavel">密码</label><div class="login_input">' +
                '<input type="password" name="password" id="u_password" placeholder="密码">\n</div></div>' +
                '<div class="login_item"><div class="login_button"><input  type="button" class="layui-btn"  id="sub" value="提交">\n</div></div></form><div class="login_move">' +
                '<a onclick="login.render_registered(\'\', \'open\');return false;">注册</a>' +
                '<a onclick="login.render_retrieve_pass(\'\',\'open\');return false;">找回密码</a>' +
                '</div></div>';
        w = w || 350;
        h = h || 350;
        return "open" === n ? window.open(i.config.path.login) : "click" === n ? e ? $(document).on("click", e, function () {
            i.alert("用户中心", t, ty === 'path' ? 2 : 1, w, h)
        }) : i.alert("用户中心", t, ty === 'path' ? 2 : 1, w, h) : e && $(e).html(t), setTimeout(function () {
            layui.form.render()
        }, 100), this
    }, n.prototype.req_login = function (n, i, t) {
        var a = this;
        n = n || function (e) {
            layer.msg(e.msg)
        }, i = i || function (e) {
            layer.msg(e.msg)
        }, t = t || function (e) {
            layer.msg(e.statusText)
        }, $(document).on("click", "#sub", function () {
            $.ajax({
                url: a.config.url.login_check,
                dataType: "jsonp",
                data: {username: $("#u_username").val(), password: $("#u_password").val()},
                jsonp: "callback",
                success: function (e) {
                    0 !== e.code ? i(e) : (a.setCookie("ULTOKEN", JSON.stringify(e.data.info)), "string" == typeof n ? window.location.href = (n || a.config.path.user_info) : n(e))
                },
                error: function (e) {
                    t(e)
                }
            })
        })
    }, n.prototype.render_registered = function (e, n, i) {
        var t = $.extend({url: this.config.path.retrieve_pass, target: "_blank"}, i, {}),
            a = '<div class="reg" style="width: 70%;margin: 35px auto;">\n<form class="layui-form" action="">\n<input type="hidden" name="uid" id="uid" value="' + this.queryVar("id") + '">\n<div class="layui-form-item">\n<label class="layui-form-label">账号</label>\n<div class="layui-input-block w-50">\n<input type="text" name="user_name" required lay-verify="required|user_name" placeholder="账号"\n   autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">密码</label>\n<div class="layui-input-block w-50">\n<input type="password" name="user_passwd" required lay-verify="password|user_passwd"\n   placeholder="密码" autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">昵称</label>\n<div class="layui-input-block w-50">\n<input type="text" name="user_nickname" required lay-verify="required|user_nickname"\n   placeholder="昵称" autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">电话</label>\n<div class="layui-input-block w-50">\n<input type="text" name="user_phone" required lay-verify="phone" placeholder="电话" autocomplete="off"\n   class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">邮箱</label>\n<div class="layui-input-block w-50">\n<input type="text" name="user_email" required lay-verify="email" placeholder="邮箱" autocomplete="off"\n   class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">性别</label>\n<div class="layui-input-block w-50">\n<label><span>男&nbsp;</span><input type="radio" name="user_sex" value="1" checked></label>\n<label><span>女&nbsp;</span><input type="radio" name="user_sex" value="0"></label>\n</div>\n</div>\n\n<div class="layui-form-item form-conn">\n<div class="layui-input-block">\n<button class="layui-btn" lay-filter="user_reg" lay-submit id="user_reg">立即提交</button>\n<button type="reset" class="layui-btn layui-btn-primary">重置</button>\n<span><a href="" id=\'retrieve\'>找回密码</a> </span>\n</div>\n</div>\n</form>\n</div>\n',
            l = this;
        return $(document).on("click", "#retrieve", function () {
            return "_blank" === t.target ? window.open(t.url) : l.alert("找回密码", t.url)
        }), "open" === n ? window.open(l.config.path.registered) : "click" === n ? e ? $(document).on("click", e, function () {
            l.alert("用户中心", a)
        }) : l.alert("用户中心", a) : e && $(e).html(a), setTimeout(function () {
            layui.form.render()
        }, 100), this
    }, n.prototype.req_registered = function (n, i, t) {
        var a = this;
        n = n || function (e) {
            layer.msg(e.msg)
        }, i = i || function (e) {
            layer.msg(e.msg)
        }, t = t || function (e) {
            layer.msg(e.statusText)
        }, setTimeout(function () {
            layui.form.on("submit(user_reg)", function (e) {
                return a.req_ajax(a.config.url.registered_check, e.field, function (e) {
                    0 !== e.code ? i(e) : "string" == typeof n ? window.location.href = (n || a.config.path.login) : n(e)
                }, function (e) {
                    t(e)
                }, "post"), !1
            })
        }, 100)
    }, n.prototype.render_retrieve_pass = function (e, n) {
        var i = '<div style="margin: 35px 0">\n<div class="layui-carousel" id="stepForm" lay-filter="stepForm" style="margin: 0 auto;">\n<div carousel-item>\n<div>\n<form class="layui-form" style="margin: 0 auto;max-width: 460px;padding-top: 40px;">\n<div class="layui-form-item">\n<label class="layui-form-label">账号</label>\n<div class="layui-input-block w-50">\n<input type="text" name="user_name" required lay-verify="user_name" placeholder="账号"\nautocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<div class="layui-inline">\n<label class="layui-form-label">问题</label>\n<div class="layui-input-inline">\n<select name="user_issue_one" lay-verify="required" lay-search="">\n<option value="1">你小学班主任叫什么名字</option>\n<option value="2">问题二</option>\n<option value="3">问题三</option>\n</select>\n</div>\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">答案</label>\n<div class="layui-input-block w-50">\n<input type="text" name="user_answer_one" required lay-verify="user_answer_one"\nvalue="" placeholder="答案" autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<div class="layui-input-block">\n<button class="layui-btn" lay-submit lay-filter="go_next">\n&emsp;下一步&emsp;\n</button>\n</div>\n</div>\n</form>\n</div>\n<div>\n<form class="layui-form" style="margin: 0 auto;max-width: 460px;padding-top: 40px;">\n<div class="layui-form-item">\n<label class="layui-form-label">密码</label>\n<div class="layui-input-block w-50">\n<input type="password" name="password" required lay-verify="password" placeholder="密码"\n   autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">确认密码</label>\n<div class="layui-input-block w-50">\n<input type="password" name="password2" required lay-verify="required|confirmPass"\nplaceholder="确认密码" autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item form-conn">\n<div class="layui-input-block">\n<button type="button" class="layui-btn layui-btn-primary pre">上一步</button>\n<button class="layui-btn" lay-submit lay-filter="set_pass">\n&emsp;确认修改&emsp;\n</button>\n</div>\n</div>\n</form>\n</div>\n<div>\n<div style="text-align: center;margin-top: 90px;">\n<i class="layui-icon layui-circle"\nstyle="color: white;font-size:30px;font-weight:bold;background: #52C41A;padding: 20px;line-height: 80px;">&#xe605;</i>\n<div style="font-size: 24px;color: #333;font-weight: 500;margin-top: 30px;">\n修改成功\n</div>\n<div style="font-size: 14px;color: #666;margin-top: 20px;">快去重新 <a href="' + this.config.path.login + '">登录</a> 吧～</div>\n</div>\n</div>\n</div>\n</div>\n</div>',
            t = this;
        return setTimeout(function () {
            layui.config({base: "/static/js/layui/layui_exts/"}), layui.use("step", function () {
                layui.step.render({
                    elem: "#stepForm",
                    filter: "stepForm",
                    width: "100%",
                    stepWidth: "750px",
                    height: "500px",
                    stepItems: [{title: "填写问题"}, {title: "修改密码"}, {title: "完成"}]
                }), layui.form.render()
            }), $(document).on("click", ".pre", function () {
                layui.step.pre("#stepForm")
            }), $(document).on("click", ".next", function () {
                layui.step.next("#stepForm")
            }), "open" === n ? window.open(t.config.path.retrieve_pass) : "click" === n ? e ? $(document).on("click", e, function () {
                t.alert("用户中心", i)
            }) : t.alert("用户中心", i) : e && $(e).html(i)
        }, 100), this
    }, n.prototype.req_retrieve_pass = function (n, i, t) {
        var a = this;
        n = n || function (e) {
            layui.step.next("#stepForm"), a.req_set_password(e.data.user_id)
        }, i = i || function (e) {
            layer.msg(e.msg)
        }, t = t || function (e) {
            layer.msg(e.statusText)
        }, setTimeout(function () {
            layui.form.on("submit(go_next)", function (e) {
                return a.req_ajax(a.config.url.find_pass, e.field, function (e) {
                    (0 !== e.code ? i : n)(e)
                }, function (e) {
                    t(e)
                }, "post"), !1
            })
        }, 100)
    }, n.prototype.req_set_password = function (n, i, t, a) {
        var l = this;
        i = i || function (e) {
            layer.msg(e.msg), layui.step.next("#stepForm")
        }, t = t || function (e) {
            layer.msg(e.msg)
        }, a = a || function (e) {
            layer.msg(e.statusText)
        }, setTimeout(function () {
            layui.form.on("submit(set_pass)", function (e) {
                return e.field.edit_id = n, l.req_ajax(l.config.url.set_pass, e.field, function (e) {
                    (0 !== e.code ? t : i)(e)
                }, function (e) {
                    a(e)
                }, "post"), !1
            })
        }, 100)
    }, n.prototype._nav = function () {
        var t = "<ul style='cursor: pointer;'>";
        $.each(this.config.nav, function (e, n) {
            t += "<li ><a class='title' " + (n.url ? "href=" + n.url : "") + "><span >" + n.title + "</span></a>", n.children && (t += "<ul>", $.each(n.children, function (e, n) {
                t += '<li class="nav user_nav_item" data-index="' + n.index + '" data-event="' + n.event + "\" '><a " + (n.url ? "href=" + n.url : "") + ">" + n.title + "</a></li>";
                var i = n.event + "()";
                new Function("login." + i)()
            }), t += "</ul></li>")
        }), t += "</ul>", $(".user_info_nav").html(t), $(document).on("click", ".user_nav_item", function () {
            $(".user_info_nav").find("li.user_nav_item").removeClass("user_info_active"), $(this).addClass("user_info_active");
            var e = $(this).data("index");
            $(this).data("event");
            $("." + e).css("display", "block").siblings().css("display", "none")
        }), setTimeout(function () {
            $(".user_nav_item:first").trigger("click")
        }, 100)
    }, n.prototype.alert = function (e, n, i, t, a, l, s) {
        e = e || !1, i = i || 1, n = n || "404.html", t = t || .9 * $(window).width(), a = a || $(window).height() - 50, s = s || function () {
        };
        var o = layer.open({
            type: i,
            area: [t + "px", a + "px"],
            fix: !1,
            maxmin: !0,
            shadeClose: !0,
            shade: .4,
            title: e,
            content: n,
            end: function (e) {
                s(e)
            }
        });
        l && layer.full(o)
    }, n.prototype.req_ajax = function (e, n, i, t, a, l) {
        i = i || function (e) {
            layer.msg(e.msg)
        }, t = t || function (e) {
            layer.msg(e.statusText)
        }, a = a || "get", l = l || "json", n = n || {}, $.ajax({
            url: e,
            dataType: l,
            type: a,
            data: n,
            headers: {token: this.getCookie("ULTOKEN")},
            success: function (e) {
                i(e)
            },
            error: function (e) {
                t(e)
            }
        })
    }, n.prototype.user_info = function (i) {
        i = i || "tpl";
        var t = this;
        this.req_ajax(this.config.url.user_info, {}, function (e) {
            if (0 === e.code) {
                if ("tpl" !== i) return e;
                t.push_scr('<div class="user_info_item user_info_at">\n<script id="user_info" type="text/html">\n<form class="layui-form" action="">\n<input type="hidden" name="user_id" value="{{d.user_id}}">\n<div class="layui-form-item">\n<label class="layui-form-label">用户名</label>\n<div class="layui-input-block ">\n<input type="text" name="user_name" required lay-verify="user_name" placeholder="用户名"\n   value="{{d.user_name}}" autocomplete="off" class="layui-input">\n</div>\n</div>\n\n<div class="layui-form-item">\n<label class="layui-form-label">昵称</label>\n<div class="layui-input-block ">\n<input type="text" name="user_nickname" lay-verify="user_nickname" placeholder="昵称"\n   value="{{d.user_nickname}}"\n   autocomplete="off" class="layui-input">\n</div>\n</div>\n\n<div class="layui-form-item">\n<label class="layui-form-label">邮箱</label>\n<div class="layui-input-block ">\n<input type="text" name="user_email" lay-verify="user_email" placeholder="邮箱"\n   value="{{d.user_email}}"\n   autocomplete="off" class="layui-input">\n</div>\n</div>\n\n<div class="layui-form-item">\n<label class="layui-form-label">手机号码</label>\n<div class="layui-input-block ">\n<input type="text" name="user_phone" lay-verify="user_phone" placeholder="手机号码"\n   value="{{d.user_phone}}"\n   autocomplete="off" class="layui-input">\n</div>\n</div>\n\n<div class="layui-form-item">\n<label class="layui-form-label">会员性别</label>\n<div class="layui-input-block">\n<input type="radio" name="user_sex" value="1" title="男" {{d.user_sex== 1 ? \'checked\' : \'\'}}>\n<input type="radio" name="user_sex" value="0" title="女" {{d.user_sex== 0 ? \'checked\' : \'\'}}>\n<input type="radio" name="user_sex" value="2" title="保密" {{d.user_sex== 2 ? \'checked\' : \'\'}}>\n</div>\n</div>\n\n<div class="layui-form-item form-conn">\n<div class="layui-input-block">\n<button class="layui-btn" lay-filter="user_info_form" lay-submit id="user_info_form">保存</button>\n<button type="reset" class="layui-btn layui-btn-primary">重置</button>\n</div>\n</div>\n</form>\n<\/script>\n<div id="view_user_info"></div>\n</div>');
                var n = document.getElementById("user_info").innerHTML;
                return layui.laytpl(n).render(e.data, function (e) {
                    document.getElementById("view_user_info").innerHTML = e
                }), layui.form.render(), t._save_user_info(), !0
            }
            layer.msg(e.msg)
        })
    }, n.prototype._save_user_info = function () {
        var n = this;
        layui.form.on("submit(user_info_form)", function (e) {
            return n.req_ajax(n.config.url._save_user_info, e.field, function (e) {
                layer.msg(e.msg)
            }, {}, "post"), !1
        })
    }, n.prototype.point_annal = function (e) {
        this.push_scr('<div class="user_info_item point_annal">\n<table class="layui-table" lay-data="{height:\'full-200\', url:\'' + this.config.url.point_annal + "', page:true, id:'CTableToUser',limit: 20}\" lay-filter=\"test\">\n<thead>\n<tr>\n<th lay-data=\"{field:'annal_id', width:80, sort: true}\">ID</th>\n<th lay-data=\"{field:'point_name', width:80}\">所用积分</th>\n<th lay-data=\"{field:'annal_datatype', width:80, sort: true, templet: '#datatype'}\">数据类型</th>\n<th lay-data=\"{field:'annal_bechange', sort: true}\">变更前总积分</th>\n<th lay-data=\"{field:'annal_afchange', sort: true}\">变更后总积分</th>\n<th lay-data=\"{field:'annal_available', sort: true}\">可用积分</th>\n<th lay-data=\"{field:'annal_withdraw', sort: true}\">可提现积分</th>\n<th lay-data=\"{field:'annal_addtime',templet: '#lastloginTime', minWidth: 150}\">时间</th>\n</tr>\n</thead>\n</table>\n</div>"), layui.table.init("test", {headers: {token: this.getCookie("ULTOKEN")}})
    }, n.prototype.exchange_annal = function (i) {
        i = i || "tpl";
        var t = this;
        this.req_ajax(this.config.url.exchange_annal, {}, function (e) {
            if (0 === e.code) {
                if ("tpl" !== i) return e;
                t.push_scr('<div class="user_info_item exchange_annal">\n<script id="exchange_annal" type="text/html">\n<form class="layui-form" action="">\n<div class="layui-form-item">\n<label class="layui-form-label">积分列表</label>\n<div class="layui-input-inline">\n<select lay-verify="required" lay-filter="point_id" name="point_id">\n<option value="">请选择兑换的积分</option>\n{{#  layui.each(d, function(index, item){ }}\n<option value="{{item.point_id}}"  >{{item.point_name}}</option>\n{{#  }); }}\n</select>\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">积分列表</label>\n<div class="layui-input-inline">\n<select lay-verify="required" lay-filter="point_id2" name="point_id2">\n<option value="">请选择兑换的积分</option>\n{{#  layui.each(d, function(index, item){ }}\n<option value="{{item.point_id}}"  >{{item.point_name}}</option>\n{{#  }); }}\n</select>\n</div>\n</div>\n<div class="layui-form-item" id="showexscale">\n<label class="layui-form-label">可换积分</label>\n<div class="layui-input-block w-50">\n<div class="layui-col-sm6">\n<p style="padding-left: 10px; height: 35px; line-height: 35px" id="exscale">--</p>\n</div>\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">数量</label>\n<div class="layui-input-block w-50">\n<input type="text" name="exchange_num"  lay-verify="required|number" placeholder="昵称" autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item form-conn">\n<div class="layui-input-block">\n<button class="layui-btn" lay-filter="exchange_annal_form" lay-submit id="exchange_annal_form">保存</button>\n<button type="reset" class="layui-btn layui-btn-primary">重置</button>\n</div>\n</div>\n</form>\n<\/script>\n<div id="view_exchange_annal"></div>\n</div>'), t.point_available();
                var n = document.getElementById("exchange_annal").innerHTML;
                return layui.laytpl(n).render(e.data, function (e) {
                    document.getElementById("view_exchange_annal").innerHTML = e
                }), layui.form.render(), t._s_exchange_annal(), !0
            }
            layer.msg(e.msg)
        })
    }, n.prototype._s_exchange_annal = function () {
        var n = this;
        layui.form.on("submit(exchange_annal_form)", function (e) {
            return n.req_ajax(n.config.url._save_active_upoint, e.field, function (e) {
                layer.msg(e.msg)
            }, {}, "post"), !1
        })
    }, n.prototype.point_available = function () {
        var i = this;
        layui.form.on("select(point_id)", function (e) {
            var n = e.value;
            return i.req_ajax(i.config.url.point_info, {id: n}, function (e) {
                e.code ? layer.msg(e.msg) : $("#exscale").html(e.data.upoint_available)
            }, {}, "post"), !1
        })
    }, n.prototype.point_cash = function (i) {
        i = i || "tpl";
        var t = this;
        this.req_ajax(this.config.url.point_cash, {}, function (e) {
            if (0 === e.code) {
                if ("tpl" !== i) return e;
                t.push_scr('<div class="user_info_item point_cash">\n<script id="point_cash" type="text/html">\n<form class="layui-form xform" action="">\n<div class="layui-form-item">\n<label class="layui-form-label">现有积分</label>\n<div class="layui-input-block w-50">\n<div class="layui-col-sm6">\n<p style="padding-left: 10px; height: 35px; line-height: 35px">{{d.upoint_withdraw}}</p>\n</div>\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">兑换比例</label>\n<div class="layui-input-block w-50">\n<div class="layui-col-sm6">\n<p style="padding-left: 10px; height: 35px; line-height: 35px">{{d.point_scale}}：1</p>\n<input type="hidden" name="dscale" value="{$data.point_scale}">\n</div>\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">所用积分</label>\n<div class="layui-input-block w-50">\n<input type="text" name="cash_integral" lay-verify="required|number" placeholder="所用积分" value=""\n   autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">提现途径</label>\n<div class="layui-input-inline">\n<select lay-verify="required" lay-search="" lay-filter="point_id" name="cash_type">\n<option value="微信">微信</option>\n<option value="支付宝">支付宝</option>\n<option value="银行卡">银行卡</option>\n</select>\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">账号</label>\n<div class="layui-input-block w-50">\n<input type="text" name="cash_account" lay-verify="required|cash_account" placeholder="账号" value=""\n   autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">账号户名</label>\n<div class="layui-input-block w-50">\n<input type="text" name="cash_cashier" lay-verify="required|cash_cashier" placeholder="账号户名"\n   value="" autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">银行名称</label>\n<div class="layui-input-block w-50">\n<input type="text" name="cash_backname" lay-verify="cash_backname" placeholder="提现到银行填写" value=""\n   autocomplete="off" class="layui-input">\n</div>\n</div>\n\n<div class="layui-form-item form-conn">\n<div class="layui-input-block">\n<button class="layui-btn" lay-filter="point_cash_form" lay-submit id="btn-point_cash_form">兑换</button>\n<button type="reset" class="layui-btn layui-btn-primary">重置</button>\n</div>\n</div>\n<div style="height: 100px;">\n\n</div>\n</form>\n<\/script>\n<div id="view_point_cash"></div>\n</div>');
                var n = document.getElementById("point_cash").innerHTML;
                return layui.laytpl(n).render(e.data, function (e) {
                    document.getElementById("view_point_cash").innerHTML = e
                }), layui.form.render(), t._s_point_cash(), !0
            }
            layer.msg(e.msg)
        })
    }, n.prototype._s_point_cash = function () {
        var n = this;
        layui.form.on("submit(point_cash_form)", function (e) {
            return n.req_ajax(n.config.url._save_cash_rawal, e.field, function (e) {
                layer.msg(e.msg)
            }, {}, "post"), !1
        })
    }, n.prototype.exchange_card = function (i) {
        i = i || "tpl";
        var t = this;
        this.req_ajax(this.config.url.point_cash, {}, function (e) {
            if (0 === e.code) {
                if ("tpl" !== i) return e;
                t.push_scr('<div class="user_info_item exchange_card">\n<script id="exchange_card" type="text/html">\n<form class="layui-form xform" action="">\n<div class="layui-form-item">\n<label class="layui-form-label">现有积分</label>\n<div class="layui-input-block w-50">\n<div class="layui-col-sm6">\n<p style="padding-left: 10px; height: 35px; line-height: 35px">{{d.upoint_available}}</p>\n</div>\n</div>\n</div>\n\n<div class="layui-form-item">\n<label class="layui-form-label">卡号</label>\n<div class="layui-input-block w-50">\n<input type="text" name="card_no"  lay-verify="required|card_no" placeholder="卡号" value="" autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">密码</label>\n<div class="layui-input-block w-50">\n<input type="text" name="card_pwd"  lay-verify="required|card_pwd" placeholder="密码" value="" autocomplete="off" class="layui-input">\n</div>\n</div>\n<div class="layui-form-item form-conn">\n<div class="layui-input-block">\n<button class="layui-btn" lay-filter="exchange_card_form" lay-submit id="exchange_card_form">兑换</button>\n<button type="reset" class="layui-btn layui-btn-primary">重置</button>\n</div>\n</div>\n<div style="height: 100px;">\n</div>\n</form>\n<\/script>\n<div id="view_exchange_card"></div>\n</div>');
                var n = document.getElementById("exchange_card").innerHTML;
                return layui.laytpl(n).render(e.data, function (e) {
                    document.getElementById("view_exchange_card").innerHTML = e
                }), layui.form.render(), t._s_exchange_card(), !0
            }
            layer.msg(e.msg)
        })
    }, n.prototype._s_exchange_card = function () {
        var n = this;
        layui.form.on("submit(exchange_card_form)", function (e) {
            return n.req_ajax(n.config.url._save_card_check, e.field, function (e) {
                layer.msg(e.msg)
            }, {}, "post"), !1
        })
    }, n.prototype.level_up = function (i) {
        i = i || "tpl";
        var t = this;
        this.req_ajax(this.config.url.level_up, {}, function (e) {
            if (0 === e.code) {
                if ("tpl" !== i) return e;
                t.push_scr('<div class="user_info_item level_up">\n<script id="level_up" type="text/html">\n<form class="layui-form xform" action="">\n<div class="layui-form-item">\n<label class="layui-form-label">可用积分</label>\n<div class="layui-input-block w-50">\n<div class="layui-col-sm6">\n<p style="padding-left: 10px; height: 35px; line-height: 35px">{{d.point.upoint_available}}</p>\n</div>\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">当前会员</label>\n<div class="layui-input-block w-50">\n<div class="layui-col-sm6">\n<p style="padding-left: 10px; height: 35px; line-height: 35px">{{d.level[d.point.level_id]}}</p>\n</div>\n</div>\n</div>\n<div class="layui-form-item">\n<label class="layui-form-label">会员兑换</label>\n<div class="layui-input-inline">\n<select lay-verify="required" lay-search="" lay-filter="point_id" name="level_id">\n<option value="">请选择兑换的会员</option>\n{{#  layui.each(d.level, function(index, item){ }}\n<option value="{{index}}"  >{{item}}</option>\n{{#  }); }}\n</select>\n</div>\n</div>\n\n<div class="layui-form-item" id="showprice" style="display: none;">\n<label class="layui-form-label">选择兑换</label>\n<div class="layui-input-block w-50">\n<p><input type="radio" name="levelprice" id="level_weekprice" value="level_weekprice">周：<span id="weekprice"></span></p>\n<p><input type="radio" name="levelprice" id="level_monthprice" value="level_monthprice">月：<span id="monthprice"></span></p>\n<p><input type="radio" name="levelprice" id="level_periodprice" value="level_periodprice">季度：<span id="periodprice"></span></p>\n<p><input type="radio" name="levelprice" id="level_yearprice" value="level_yearprice">年：<span id="yearprice"></span></p>\n</div>\n</div>\n<div class="layui-form-item form-conn">\n<div class="layui-input-block">\n<button class="layui-btn" lay-filter="level_up_form" lay-submit id="level_up_form">兑换</button>\n<button type="reset" class="layui-btn layui-btn-primary">重置</button>\n</div>\n</div>\n<div style="height: 100px;">\n\n</div>\n</form>\n<\/script>\n<div id="view_level_up"></div>\n</div>');
                var n = document.getElementById("level_up").innerHTML;
                return layui.laytpl(n).render(e.data, function (e) {
                    document.getElementById("view_level_up").innerHTML = e
                }), layui.form.render(), t._s_level_up(), !0
            }
            layer.msg(e.msg)
        })
    }, n.prototype._s_level_up = function () {
        var n = this;
        layui.form.on("submit(level_up_form)", function (e) {
            return n.req_ajax(n.config.url._save_exchange_level, e.field, function (e) {
                layer.msg(e.msg)
            }, {}, "post"), !1
        })
    }, n.prototype.sub_list = function (e) {
        this.push_scr('<div class="user_info_item user_sublist">\n<table class="layui-table" lay-data="{height:\'full-200\', url:\'' + this.config.url.user_sublist + "', page:true, id:'CTableToUser',limit: 20}\" lay-filter=\"sublist\">\n<thead>\n<tr>\n<th lay-data=\"{field:'user_id', width:80, sort: true}\">ID</th>\n<th lay-data=\"{field:'user_name', width:80}\">名称</th>\n<th lay-data=\"{field:'user_nickname', width:80, sort: true, templet: '#datatype'}\">昵称</th>\n<th lay-data=\"{field:'user_email', sort: true}\">邮箱</th>\n<th lay-data=\"{field:'user_phone', sort: true}\">手机</th>\n<th lay-data=\"{field:'user_sex', sort: true, templet: '#sex'}\">性别</th>\n<th lay-data=\"{field:'level_name', sort: true, templet: '#level'}\">等级</th>\n<th lay-data=\"{field:'user_status', templet: '#status', minWidth: 120}\">账号状态</th>\n<th lay-data=\"{field:'user_lasttime', templet: '#lastloginTime', minWidth: 150}\">最后登录时间</th>\n</tr>\n</thead>\n</table>\n</div>"), layui.table.init("sublist", {headers: {token: this.getCookie("ULTOKEN")}})
    }, n.prototype.user_promote = function (e) {
        this.push_scr('<div class="user_info_item user_promote">\n<div class="layui-row">\n<div class="layui-col-md7">\n<div class="qrcode_conn layui-inline">\n<div class="qrcode_text layui-inline">\n<span>推广二维码：</span>\n</div>\n<div class="qrcode_img layui-inline">\n<div id="qrcode_conn" style="margin-left: 10px;\nmargin-bottom: 10px;"></div>\n</div>\n<style>\n.qrcode_conn div {\npadding: 10px 10px 0 10px;\n}\n\n.promote_span {\ndisplay: inline-block;\nborder-bottom: 1px solid #f0fff4;\npadding: 25px 10px 0 10px;\n}\n\n.promote_span span {\ndisplay: block;\nfont-size: 24px;\n}\n</style><div class="qrcode_refresh layui-inline">\n<div class="layui-btn-group">\n<button type="button"\nclass="layui-btn layui-btn-primary  layui-btn-sm layui-hide"\nid="share" data-clipboard-target="#qrcode_src">\n<i class="layui-icon">&#xe641;</i>\n</button>\n<button type="button"\nclass="layui-btn  layui-btn-primary  layui-btn-sm"\ndata-type="refresh" id="refresh">\n<i class="layui-icon">&#xe669;</i>\n</button>\n</div>\n</div>\n</div>\n</div>\n<div class="layui-col-md5">\n<div class="promote_span">\n<span>人数：<text id="promote_num">0</text></span>\n<span>总推广所得积分：<text id="promote_point">0</text></span>\n</div>\n</div>\n</div>\n<div class="layui-row ">\n<div class="user_info_item user_sublist">\n<table class="layui-table"\nlay-data="{height:\'full-200\', url:\'' + this.config.url.user_promote + "', page:true, id:'CTableToUser',limit: 20}\"\nlay-filter=\"promote\">\n<thead>\n<tr>\n<th lay-data=\"{field:'annal_id', width:80, sort: true}\">ID</th>\n<th lay-data=\"{field:'user_name', width:80}\">名称</th>\n<th lay-data=\"{field:'user_pid', width:80, sort: true}\">上级ID</th>\n<th lay-data=\"{field:'point_name', sort: true}\">所用积分</th>\n<th lay-data=\"{field:'xxx', sort: true}\">推广所得积分</th>\n<th lay-data=\"{field:'annal_addtime', templet: '#lastloginTime', minWidth: 150}\">时间</th>\n</tr>\n</thead>\n</table>\n</div>\n</div>\n</div>"), login.QRcode.get("qrcode_conn", this.domain + "/user/index/index.html?uid=" + this.getUid()), $("#refresh").on("click", function () {
            login.QRcode.reload()
        }), layui.table.init("promote", {
            headers: {token: this.getCookie("ULTOKEN")}, parseData: function (e) {
                var i;
                0 === e.code && ($("#promote_num").html(e.data.length), i = 0, $.each(e.data, function (e, n) {
                    i += n.annal_afchange - n.annal_bechange
                }), $("#promote_point").html(i))
            }
        })
    }, n.prototype.push_scr = function (e) {
        $(".user_info_content").append(e)
    }, n.prototype.getScript = {
        isInclude: function (e) {
            for (var n = /js$/i.test(e), i = document.getElementsByTagName(n ? "script" : "link"), t = 0; t < i.length; t++) if (-1 !== i[t][n ? "src" : "href"].indexOf(e)) return !0;
            return !1
        }, isLoad: function (e) {
            return void 0 !== e
        }, load: function (e, i) {
            this.isInclude(e) || (i = i || new Function, $.getScript(e, function (e, n) {
                i(e, n)
            }))
        }, css: function (e) {
            var n = document.createElement("link");
            n.type = "text/css", n.rel = "stylesheet", n.href = e, document.getElementsByTagName("head")[0].appendChild(n)
        }
    }, n.prototype.QRcode = {
        get: function (e, n, i, t, a, l, s) {
            try {
                var o = this;
                login.getScript.load(login.domain + "/static/js/qrcode.min.js", function () {
                    return o.qrcode_test = n, o.qrcode = new QRCode(e, {
                        text: n,
                        width: i || 128,
                        height: t || 128,
                        colorDark: a || "#000000",
                        colorLight: l || "#ffffff",
                        correctLevel: s || QRCode.CorrectLevel.H
                    })
                })
            } catch (r) {
                layui.layer.msg(r.message)
            }
        }, reload: function () {
            null != this.qrcode && this.qrcode.makeCode(this.qrcode_test + (-1 !== this.qrcode_test.indexOf("?") ? "&" : "?&") + "_t=" + (new Date).getTime())
        }
    }, n.prototype.getToken = function () {
        return JSON.parse(this.getCookie("ULTOKEN")).token
    }, n.prototype.userName = function () {
        return JSON.parse(this.getCookie("ULTOKEN")).user_name
    }, n.prototype.getUid = function () {
        return JSON.parse(this.getCookie("ULTOKEN")).user_id || 0
    }, n.prototype.queryVar = function (e, n) {
        for (var i = window.location.search.substring(1).split("&"), t = [], a = 0; a < i.length; a++) {
            var l = i[a].split("=");
            if (l[0] === e) return unescape(l[1]);
            t.push(l)
        }
        return e && n !== undefined ? n : 0 < t.length && "" !== t[0][0] ? JSON.stringify(t) : ""
    }, n.prototype.setCookie = function (e, n, i, t) {
        var a = new Date;
        i = i || "/", t = t || null, a.setTime(a.getTime() + 60 * t * 60 * 1e3), document.cookie = e + "=" + escape(n) + ";path=" + i + (null === t ? "" : "; expires=" + a.toUTCString())
    }, n.prototype.getCookie = function (e) {
        var n = new RegExp("(^| )" + e + "=([^;]*)(;|$)");
        return document.cookie.match(n) ? unescape(document.cookie.match(n)[2]) : null
    }, n.prototype.removeCookie = function (e) {
        this.setCookie(e, "", -1)
    }, e.login = new n
}(window);