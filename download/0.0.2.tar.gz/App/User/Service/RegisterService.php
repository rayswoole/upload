<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\User\Service;

use rayswoole\Helper;
use rayswoole\orm\facade\Db;
use App\User\Extend\Common;
use rayswoole\Service;

class RegisterService extends Service
{



    /**
     * 注册
     * @param array $param
     * @return array
     * @throws \EasySwoole\ORM\Exception\Exception
     * @throws \Throwable
     */
    public function saveRegister(array $param): array
    {
        if(Helper::request()->getCookieParams('INVITE')){
            $session_invite=Helper::deJson(Helper::request()->getCookieParams('INVITE'));//获取INVITE 推广id
        }else{
            $session_invite['invite']=0;
        }

        $data = [
            'user_pid'  => $session_invite['invite'],
            'user_name' => htmlspecialchars($param['user_name']),
            'user_sex'  => (int)$param['user_sex'],
            'user_nickname' => htmlspecialchars($param['user_nickname']),
            'user_email'    => htmlspecialchars($param['user_email']),
            'user_phone'    => htmlspecialchars($param['user_phone']),
        ];

        $has = Db::name('user')->where(['user_name' => $param['user_name']])->find();

        if ($has) {
            return ['code' => 1, 'msg' => '用户名已注册', 'result' => []];
        }
        $data['user_passwd'] = password_hash($param['user_passwd'], PASSWORD_DEFAULT);
        $res = Db::name('user')->insert($data);

        //注册成功后添加积分到积分表
        $upoint_data=[
            'user_id'=>Db::name('user')->getLastInsID(),
            'level_id'=>1,
            'point_id'=>1,
        ];
        $point=Helper::service('Point')->saveUpoint($upoint_data);

//        if (!$param['session']['user_id']) {
//            //判断修改用户名是否重复
//            $has = Db::name('user')->where(['user_name' => $param['user_name']])->find();
//
//            if ($has) {
//                return ['code' => 1, 'msg' => '用户名已注册', 'result' => []];
//            }
//            $data['user_passwd'] = password_hash($param['user_passwd'], PASSWORD_DEFAULT);
//            $res = Db::name('user')->insert($data);
//
//        } else {
//            $res = $this->update($data, ['user_id' => $param['user_id']]);
//        }

        if (!(bool)$res) {
            return ['code' => 1, 'msg' => '保存失败', 'result' => []];
        }
        return ['code' => 0, 'msg' => '保存成功', 'result' => ['url' => Helper::url('/user/index/login') ]];
    }



    //找回密码
    public function checkAccount($data)
    {
        $where = [
            'user_name' => [$data['user_name']],
            'user_issue_one' => [$data['user_issue_one']],
            'user_answer_one' => [$data['user_answer_one']]
        ];
        $isdata2 = Db::name('user')->where($where)->find();

        return (array)$isdata2;
    }

    public function updateRegister(array $data, $id): bool
    {
        $where = [
            'user_id' => $id
        ];
        if (is_array($id)) {
            $where = $id;
        }
        $res = Db::name('user')->update($data, $where);
        return (bool)$res;
    }


}