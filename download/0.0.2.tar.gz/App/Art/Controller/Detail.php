<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-11-13 18:16
 ** ----------------------------------------------------------------------
 **/

namespace App\Art\Controller;


use App\Art\Extend\Common;
use App\Art\Service\ArticleService;
use App\Vod\Service\TypeService;
use App\Vod\Service\VodService;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;
use rayswoole\orm\facade\Db;

class Detail extends Base
{
    public function index()
    {
        $param = Common::ray_param_url();
        $key = 'html_art@detail/index/id/'.$param['id'];
        if ($this->siteConfig['art_cache_detail'] > 10 && $html = Cache::getInstance()->get($key)){
            return Helper::responseHtml($html);
        }

        $obj = ArticleService::getInstance()->getArt(['art_id'=>$param['id']]);
        $obj['type'] = TypeService::getInstance()->get($obj['type_id']);

        Context::set('obj',$obj);
        Context::set('param',$param);
        $this->assign([
            'param' => $param,
            'obj' => $obj
        ]);

        $html = $this->fetch('art/detail', false);
        if ($this->siteConfig['art_cache_detail'] > 10){
            Cache::getInstance()->set($key, $html, $this->siteConfig['art_cache_detail']);
        }
        return Helper::responseHtml($html);
    }

    protected function afterAction(?string $actionName): void
    {
        if ($actionName !== 'index') {
            return;
        }
        $obj = Context::get('obj');
        if (!is_null($obj)){
            Db::name('art')->where('art_id','=',$obj['art_id'])
                ->inc('art_hits',1)
                ->inc('art_hits_day',1)
                ->inc('art_hits_week',1)
                ->inc('art_hits_month',1)->update();
        }
    }
}