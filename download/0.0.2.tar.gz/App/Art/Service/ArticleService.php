<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc> 
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-01
 ** ----------------------------------------------------------------------
 **/
namespace App\Art\Service;


use App\Art\Model\ArticleModel;
use rayswoole\orm\facade\Db;
use rayswoole\Service;

class ArticleService extends Service
{


    public function artList($where, $order = "art_id asc", $page = 0, $limit = 20): array
    {
        $model = new ArticleModel();
        if ($page > 0) {
            $data = $model->where($where)->order($order)->page($page, $limit)->select()->toArray();
        } else {
            $data = $model->where($where)->order($order)->select()->toArray();
        }
        $count = $model->where($where)->count('*');
        return ['data' => $data, 'count' => $count];
    }


    public function getArt($where): array
    {
        $model = new ArticleModel();
        if ($res = $model->where($where)->find()) {
            return $res->toArray();
        }
        return [];
    }

    public function columnType(): array
    {
        return Db::table('information_schema.columns')
            ->where('table_name', 'ray_art')
            ->column('column_name,data_type', 'column_name');
    }

    public function saveArt(array $data): bool
    {
        $model = new ArticleModel();
        if (!empty($data['art_id'])) {
            $model = $model->find($data['art_id']);
        }
        return $model->save($data);
    }

    public function deleteArt($data): bool
    {
        return ArticleModel::destroy($data);
    }
}