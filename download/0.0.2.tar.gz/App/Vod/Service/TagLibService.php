<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-01 17:06
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Service;

use App\Vod\Extend\Common;
use App\Vod\Model\TypeModel;
use rayswoole\Cache;
use rayswoole\Context;
use rayswoole\Helper;
use rayswoole\Service;
use rayswoole\orm\facade\Db;
use rayswoole\utils\Arrays;


/**
 * Class TagService
 */
class TagLibService extends Service
{
    private $container = array();

    protected $tags = [
        'type' => ['attr' => 'start,number,pid,type,order,by,ids,cachetime'],
        'nav' => ['attr' => 'start,number,pid,type,order,by,ids,cachetime'],
        'art' => ['attr' => 'start,number,not,type,order,by,ids,level,addtime,hitsday,hitsweek,hitsmonth,hits,paging,cachetime'],
        'vod' => ['attr' => 'start,number,lang,area,type,order,by,ids,level,hitsday,hitsweek,hitsmonth,hits,paging,cachetime'],
        'for' => ['attr' => 'start,end,comparison,step,name'],
        'foreach' => ['attr' => 'id,key,length,offset,mod,empty'],
        'class' => ['attr' => 'tid,order,start,num'],
        'lang' => ['attr' => 'tid,order,start,num'],
        'area' => ['attr' => 'tid,order,start,num'],
        'year' => ['attr' => 'tid,order,start,num'],
        'state' => ['attr' => 'tid,order,start,num'],
        'letter' => ['attr' => 'tid,order,start,num'],
        'version' => ['attr' => 'tid,order,start,num'],
        'ads' => ['attr' => 'site_id,start,num,page,order,by']
    ];

    public function set($key, $obj,...$arg):void
    {
        /*
         * 注入的时候不做任何的类型检测与转换
         * 由于编程人员为问题，该注入资源并不一定会被用到
         */
        $this->container[$key] = array(
            "obj"=>$obj,
            "params"=>$arg,
        );
    }

    function delete($key):void
    {
        unset( $this->container[$key]);
    }

    function clear():void
    {
        $this->container = array();
    }
    /**
     * @param $key
     * @param null $defaultValue
     * @return null
     * @throws \Throwable
     * @author zhou
     * @time 2020/9/15
     */
    public function get($key, $defaultValue = null)
    {
        if(isset($this->container[$key])){
            $obj = $this->container[$key]['obj'];
            $params = $this->container[$key]['params'];
            if(is_object($obj) || is_callable($obj)){
                return $obj;
            }else if(is_string($obj) && class_exists($obj)){
                try{
                    $this->container[$key]['obj'] = new $obj(...$params);
                    return $this->container[$key]['obj'];
                }catch (\Throwable $throwable){
                    throw $throwable;
                }
            }elseif(is_array($obj)){
                $keys = explode('.',$key);
                switch (count($keys)){
                    case 1:
                        return $obj;
                        break;
                    case 2:
                        return $obj[$keys[0]] ?? null;
                        break;
                    case 3:
                        return isset($obj[$keys[0]]) && isset($obj[$keys[0]][$keys[1]]) ? $obj[$keys[0]][$keys[1]] : null;
                        break;
                    default:
                        return $defaultValue ?? null;
                        break;
                }
            }else{
                return $obj;
            }
        }else{
            return $defaultValue ?? null;
        }
    }

    /**
     * 翻页组装
     * @param $record_total
     * @param $page_size
     * @param $page_current
     * @param $page_url
     * @param int $page_half
     * @return array
     * @throws \Exception
     * @throws \Throwable
     * @author zhou
     * @time 2020/9/15
     */
    public function page_param($record_total, $page_size, $page_current, $page_url, $page_half = 5): array
    {
        $page_param = array();
        $page_num = array();

        if ($record_total === 0) {
            return ['record_total' => 0];
        }
        if (empty($page_half)) {
            $page_half = 5;
        }

        $page_param['record_total'] = $record_total;
        $page_param['page_current'] = $page_current;

        $page_total = $page_size > 0 ? ceil($record_total / $page_size) : 0;
        $page_param['page_total'] = $page_total;
        $page_param['page_sp'] = '_';

        $page_prev = $page_current - 1;
        if ($page_prev <= 0) {
            $page_prev = 1;
        }
        $page_next = $page_current + 1;
        if ($page_next > $page_total) {
            $page_next = $page_total;
        }
        $page_param['page_prev'] = $page_prev;
        $page_param['page_next'] = $page_next;

        if ($page_total <= $page_half) {
            for ($i = 1; $i <= $page_total; $i++) {
                $page_num[$i] = $i;
            }
        } else {
            $page_num_left = floor($page_half / 2);
            $page_num_right = $page_total - $page_half;

            if ($page_current <= $page_num_left) {
                for ($i = 1; $i <= $page_half; $i++) {
                    $page_num[$i] = $i;
                }
            } elseif ($page_current > $page_num_right) {
                for ($i = ($page_num_right + 1); $i <= $page_total; $i++) {
                    $page_num[$i] = $i;
                }
            } else {
                for ($i = ($page_current - $page_num_left); $i <= ($page_current + $page_num_left); $i++) {
                    $page_num[$i] = $i;
                }
            }
        }

        $page_param['page_num'] = $page_num;
        $page_param['page_url'] = $page_url;
        //$page_param['page_url'] = Helper::url($page_url, ['pg'=>'PAGELINK']+$this->request()->getQueryParams());
        return $page_param;
    }

    /**
     * 分类标签
     * @param $tag
     * @return array
     * @throws \Psr\SimpleCache\InvalidArgumentException
     */
    public function tagType($tag):array
    {
        $tags = json_decode($tag, true);
        $raycms = Context::get('raycms');
        if ($raycms['aid'] == 11 || $raycms['aid'] == 12) {
            $id = $raycms['type_id'];
        } else {
            $id = 0;
        }
        //是否输出组装好的tree结构
        $format = !empty($tags['format']) && $tags['format'] === 'tree';

        $limit = [0,99];
        $db = Db::name('type');
        //检查属性start
        if (isset($tags['start']) && is_numeric($tags['start']) && $tags['start'] > 0){
            $limit[] = (int)$tags['start'];
        }
        //检查属性num
        if (isset($tags['num']) && is_numeric($tags['num']) && $tags['num'] > 0){
            $limit[] = (int)$tags['num'];
        }
        if (!empty($limit)){
            $db->limit(...$limit);
        }
        if (isset($tags['ids'])){//检查属性ids
            switch ($tags['ids']){
                case 'parent':
                    $db->where('type_pid','=',0);
                    break;
                case 'child':
                    $db->where('type_pid','>',0);
                    break;
                case 'current':
                    if ($id > 0) {
                        $db->where('type_pid','=',$id);
                    }
                    break;
                default:
                    $ids = $this->numberFilter($tags['ids']);
                    if (!empty($ids)){
                        $db->where('type_id','IN',$ids);
                    }
                    break;
            }
        } elseif (isset($tags['parent'])) {//检查属性parent
            if ($tags['parent'] == 'current' && $id > 0){
                $result = TypeService::getInstance()->get($id);
                if ($result){
                    $db->where('type_pid','=',$result['type_pid']);
                }
            } else {
                $ids = $this->numberFilter($tags['parent']);
                if (!empty($ids)){
                    $db->where('type_pid','IN',$ids);
                }
            }
        }
        //检查属性mid和flag
        if (isset($tags['mid']) && in_array($tags['mid'], ['1', '2'])){
            $db->where('type_mid','=', $tags['mid']);
        } elseif (isset($tags['flag']) && in_array($tags['flag'], ['vod', 'art'])) {
            $flag = ['vod'=>1, 'art'=>2];
            $db->where('type_mid','=', $flag[$tags['flag']]);
        }
        //检查属性not
        if (isset($tags['not'])) {
            $ids = $this->numberFilter($tags['not']);
            if (!empty($ids)){
                $db->where('type_id','NOT IN', $ids);
            }
        }
        $db->where('type_status','=',1);
        //检查属性order
        $order = 'type_id';
        if (isset($tags['order']) && $tags['order'] === 'sort'){
            $order = 'type_sort';
        }
        //检查属性by
        $by = 'asc';
        if (isset($tags['by']) && strtolower($tags['by']) === 'desc'){
            $by = 'desc';
        }
        $db->order($order, $by);
        $result = $db->column('type_id');
        $data = [];
        if (!empty($result)){
            $all = TypeService::getInstance()->get();
            foreach ($result as $_result){
                $data[$_result] = $all[$_result];
            }
            if ($format){
                $data = Arrays::getTree($data, 'type_id','type_pid','child');
            }
        }
        return $data;
    }


    public function tagVod($tag):array
    {
        $tags   = json_decode($tag, true);
        $raycms = Context::get('raycms');
        $param  = Context::get('param');
        $id     = $param['id'];
        $page   = $param['page'];

        $time = time();
        $db = Db::name('Vod');
        $limit = [0,10];
        //检查属性num
        if (isset($tags['num']) && is_numeric($tags['num']) && $tags['num'] > 0){
            $limit[1] = (int)$tags['num'];
        }
        //检查属性paging
        if (isset($tags['paging']) && $tags['paging'] === 'yes') {
            $limit[0] = ($page-1)*$limit[1];

            $params = [];
            if (!empty($param['class'])){
                $params['class'] = $param['class'];
            }
            if (!empty($param['area'])){
                $params['area'] = $param['area'];
            }
            if (!empty($param['lang'])){
                $params['lang'] = $param['lang'];
            }
            if (!empty($param['year'])){
                $params['year'] = $param['year'];
            }
            if (!empty($param['wd'])){
                $params['wd'] = $param['wd'];
            }
            if (!empty($param['by'])){
                $params['order'] = $param['by'];
            }
            if (!isset($tags['type'])){
                $tags['type'] = 'current';
            }
            $tags = array_merge($tags, $params);
        } else {
            $page = 0;
        }
        //检查属性start
        if (isset($tags['start']) && is_numeric($tags['start']) && $tags['start'] > 0){
            $limit[0] = $limit[0] + (int)$tags['start'];
        }
        if (!empty($limit)){
            $db->limit(...$limit);
        }
        //检查属性ids
        if (isset($tags['ids']) && $tags['ids'] != 'all'){
            $ids = $this->numberFilter($tags['ids']);
            if (!empty($ids)){
                $db->where('vod_id','IN',$ids);
            }
        } elseif (isset($tags['type'])) {
            if ($tags['type']==='current' && $typeInfo = Context::get('obj')){
                $ids = isset($typeInfo['type_child'])
                    ? array_merge([$typeInfo['type_id']], $typeInfo['type_child'])
                    : $typeInfo['type_id'];
            } elseif ($tags['type']!=='all') {
                $ids = $this->numberFilter($tags['type']);
                if (isset($ids[0]) && !isset($ids[1])){
                    $result = TypeService::getInstance()->get($ids[0]);
                    if ($result && isset($result['type_child'])){
                        $ids = array_merge($ids, $result['type_child']);
                    }
                }
            }
            if (!empty($ids)){
                if (is_array($ids)){
                    $db->where('type_id','IN',$ids);
                } elseif (is_numeric($ids)) {
                    $db->where('type_id','=',$ids);
                }
            }
            if (isset($tags['wd'])){
                $db->where('vod_title|vod_actor','like','%'.$tags['wd'].'%');
            }
        }
        if (isset($tags['not'])) {//检查属性not
            $ids = $this->numberFilter($tags['not']);
            if (!empty($ids)){
                $db->where('vod_id','NOT IN', $ids);
            }
        }
        //检查属性class
        if (isset($tags['class'])) {
            $strs = $this->strFilter($tags['class']);
            if (!empty($strs)){
                $db->where('vod_class','IN', $strs);
            }
        }
        //检查属性area
        if (isset($tags['area'])) {
            $strs = $this->strFilter($tags['area']);
            if (!empty($strs)){
                $db->where('vod_area','IN', $strs);
            }
        }
        //检查属性area
        if (isset($tags['lang'])) {
            $strs = $this->strFilter($tags['lang']);
            if (!empty($strs)){
                $db->where('vod_lang','IN', $strs);
            }
        }
        //检查属性year
        if (isset($tags['year'])) {
            $strs = $this->strFilter($tags['year']);
            if (!empty($strs)){
                $db->where('vod_year','IN', $strs);
            }
        }
        //检查属性level
        if (isset($tags['level'])) {
            $ids = $this->numberFilter($tags['level']);
            if (!empty($ids)){
                $db->where('vod_star','IN', $ids);
            }
        }
        //检查属性time
        if (isset($tags['time']) && $timeAdd = strtotime($tags['time'],$time)) {
            if ($timeAdd = strtotime($tags['timeadd'],$time)){
                $db->where('vod_addtime','>=', $timeAdd);
            }
        }
        //检查属性timeadd
        elseif (isset($tags['timeadd']) && $timeAdd = strtotime($tags['timeadd'],$time)) {
            if ($timeAdd = strtotime($tags['timeadd'],$time)){
                $db->where('vod_addtime','>=', $timeAdd);
            }
        }
        //检查属性hitsmonth
        if (isset($tags['hitsmonth']) && $hitsmonth = $this->parseRange($tags['hitsmonth'])) {
            $db->where('vod_hits_month', ...$hitsmonth);
        }
        //检查属性hitsweek
        if (isset($tags['hitsweek']) && $hitsweek = $this->parseRange($tags['hitsweek'])) {
            $db->where('vod_hits_week', ...$hitsweek);
        }
        //检查属性hitsday
        if (isset($tags['hitsday']) && $hitsday = $this->parseRange($tags['hitsday'])) {
            $db->where('vod_hits_day', ...$hitsday);
        }
        //检查属性hits
        if (isset($tags['hits']) && $hits = $this->parseRange($tags['hits'])) {
            $db->where('vod_hits', ...$hits);
        }
        $db->withoutField('vod_play_from,vod_play_server,vod_play_url,vod_content');
        //检查属性order
        $order = 'vod_addtime';
        if (isset($tags['order']) && in_array($tags['order'], ['hits','time','score','id'])){
            $orders = ['id'=>'vod_id','hits'=>'vod_hits','time'=>'vod_addtime','score'=>'vod_hits_week'];
            $order = $orders[$tags['order']];
        }
        //检查属性by
        $by = 'desc';
        if (isset($tags['by']) && strtolower($tags['by']) === 'asc'){
            $by = 'asc';
        }
        $db->order($order, $by);
        $return['data'] = $db->select()->toArray();
        if ($page <= 0){
            return $return['data'];
        }
        $db->limit(1);
        $total = $db->count('vod_id');

        $aid = $raycms['aid'] ?? 0;
        $roles = array(
            1=>'vod@index/index',
            10=>'vod@index/index',
            11=>'vod@type/index',
            12=>'vod@show/index',
            13=>'vod@search/index'
        );
        if (isset($roles[$aid])){
            $pageurl = $roles[$aid];
            $half = isset($tags['half']) ? (int)$tags['half'] : 5;
            $return['page'] = $this->page_param($total,$limit[1],$page,$pageurl,$half);
        }
        return $return;
    }

    public function tagArt($tag):array
    {
        $tags   = json_decode($tag, true);
        $raycms = Context::get('raycms');
        $param  = Context::get('param');
        $id     = $param['id'];
        $page   = $param['page'];

        $time = time();
        $db = Db::name('Art');
        $limit = [0,10];
        //检查属性num
        if (isset($tags['num']) && is_numeric($tags['num']) && $tags['num'] > 0){
            $limit[1] = (int)$tags['num'];
        }
        //检查属性paging
        if (isset($tags['paging']) && $tags['paging'] === 'yes') {
            $limit[0] = ($page-1)*$limit[1];

            $params = [];
            if (!empty($param['wd'])){
                $params['wd'] = $param['wd'];
            }
            if (!empty($param['by'])){
                $params['order'] = $param['by'];
            }
            if (!isset($tags['type'])){
                $tags['type'] = 'current';
            }
            $tags = array_merge($tags, $params);
        } else {
            $page = 0;
        }
        //检查属性start
        if (isset($tags['start']) && is_numeric($tags['start']) && $tags['start'] > 0){
            $limit[] = $limit[0] + (int)$tags['start'];
        }
        if (!empty($limit)){
            $db->limit(...$limit);
        }
        //检查属性ids
        if (isset($tags['ids']) && $tags['ids'] != 'all'){
            $ids = $this->numberFilter($tags['ids']);
            if (!empty($ids)){
                $db->where('art_id','IN',$ids);
            }
        } elseif (isset($tags['type'])) {
            if ($tags['type']==='current' && $typeInfo = Context::get('obj')){
                $ids = isset($typeInfo['type_child'])
                    ? array_merge([$typeInfo['type_id']], $typeInfo['type_child'])
                    : $typeInfo['type_id'];
            } elseif ($tags['type']!=='all') {
                $ids = $this->numberFilter($tags['type']);
                if (isset($ids[0]) && !isset($ids[1])){
                    $result = TypeService::getInstance()->get($ids[0]);
                    if ($result && isset($result['type_child'])){
                        $ids = array_merge($ids, $result['type_child']);
                    }
                }
            }
            if (!empty($ids)){
                if (is_array($ids)){
                    $db->where('type_id','IN',$ids);
                } elseif (is_numeric($ids)) {
                    $db->where('type_id','=',$ids);
                }
            }
            if (isset($tags['wd'])){
                $db->where('art_title','like','%'.$tags['wd'].'%');
            }
        }
        if (isset($tags['not'])) {//检查属性not
            $ids = $this->numberFilter($tags['not']);
            if (!empty($ids)){
                $db->where('art_id','NOT IN', $ids);
            }
        }
        //检查属性level
        if (isset($tags['level'])) {
            $ids = $this->numberFilter($tags['level']);
            if (!empty($ids)){
                $db->where('art_star','IN', $ids);
            }
        }
        //检查属性time
        if (isset($tags['time']) && $timeAdd = strtotime($tags['time'],$time)) {
            if ($timeAdd = strtotime($tags['timeadd'],$time)){
                $db->where('art_addtime','>=', $timeAdd);
            }
        }
        //检查属性timeadd
        elseif (isset($tags['timeadd']) && $timeAdd = strtotime($tags['timeadd'],$time)) {
            if ($timeAdd = strtotime($tags['timeadd'],$time)){
                $db->where('art_addtime','>=', $timeAdd);
            }
        }
        //检查属性hitsmonth
        if (isset($tags['hitsmonth']) && $hitsmonth = $this->parseRange($tags['hitsmonth'])) {
            $db->where('art_hits_month', ...$hitsmonth);
        }
        //检查属性hitsweek
        if (isset($tags['hitsweek']) && $hitsweek = $this->parseRange($tags['hitsweek'])) {
            $db->where('art_hits_week', ...$hitsweek);
        }
        //检查属性hitsday
        if (isset($tags['hitsday']) && $hitsday = $this->parseRange($tags['hitsday'])) {
            $db->where('art_hits_day', ...$hitsday);
        }
        //检查属性hits
        if (isset($tags['hits']) && $hits = $this->parseRange($tags['hits'])) {
            $db->where('art_hits', ...$hits);
        }
        $db->withoutField('art_content');
        //检查属性order
        $order = 'art_addtime';
        if (isset($tags['order']) && in_array($tags['order'], ['hits','time','score','id'])){
            $orders = ['id'=>'art_id','hits'=>'art_hits','time'=>'art_addtime','score'=>'art_hits_week'];
            $order = $orders[$tags['order']];
        }
        //检查属性by
        $by = 'desc';
        if (isset($tags['by']) && strtolower($tags['by']) === 'asc'){
            $by = 'asc';
        }
        $db->order($order, $by);
        $return['data'] = $db->select()->toArray();
        if ($page <= 0){
            return $return['data'];
        }
        $db->limit(1);
        $total = $db->count('art_id');

        $aid = $raycms['aid'] ?? 0;
        $roles = array(
            0=>'vod@index/index',
            20=>'art@index/index',
            21=>'art@type/index',
            22=>'art@show/index',
            23=>'art@search/index'
        );
        if (isset($roles[$aid])){
            $pageurl = $roles[$aid];
            $half = isset($tags['half']) ? (int)$tags['half'] : 5;
            $return['page'] = $this->page_param($total,$limit[1],$page,$pageurl,$half);
        }
        return $return;
    }

    public function tagArt2($tag):array
    {
        $param=json_decode($tag, true);
        $where = [];
        $whereor=[];
        $wherelike=[];
        $page = !empty($param['page']) ? (int)$param['page'] : 1;
        $start = isset($param['start']) && is_numeric($param['start']) ? (int)$param['start'] : 0;
        $number = isset($param['num']) && is_numeric($param['num']) ? (int)$param['num'] : 10;

        // 日 周 月点击率
        if (!empty($param['hitsday'])) { // 日点击率
            $hitsday = $param['hitsday'];
            if (is_array($hitsday)) {
                if (count($hitsday) > 1) {
                    $whereor[] = ['hits_day','=',$hitsday[0]];
                    $whereor[] = ['hits_day','=',$hitsday[1]];

                } else {
                    $where[] = ['hits_day','>',$hitsday[0]];
                }
            } else {
                $t = explode(' ', $hitsday);
                if (count($t) > 1) {
                    $whereor[] = ['hits_day','=',$t[0]];
                    $whereor[] = ['hits_day','=',$t[1]];
                } else {
                    $where[] = ['hits_day', '>',$t];
                }
            }
        }
        if (!empty($param['hitsweek'])) { // 周点击率
            $hitsweek = $param['hitsweek'];
            if (is_array($hitsweek)) {
                if (count($hitsweek) > 1) {
                    $whereor[] = ['hits_week','=',$hitsweek[0]];
                    $whereor[] = ['hits_week','=',$hitsweek[1]];
                } else {
                    $where[] = ['hits_week','>',$hitsweek[0]];
                }
            } else {
                $t = explode(' ', $hitsweek);
                if (count($t) > 1) {
                    $whereor[] = ['hits_week','=',$t[0]];
                    $whereor[] = ['hits_week','=',$t[1]];
                } else {
                    $where[] = ['hits_week','>',$t];
                }
            }
        }
        if (!empty($param['hitsmonth'])) { // 月点击率
            $hitsmonth = $param['hitsmonth'];
            if (is_array($hitsmonth)) {
                if (count($hitsmonth) > 1) {
                    $whereor[] = ['hits_month','=',$hitsmonth[0]];
                    $whereor[] = ['hits_month','=',$hitsmonth[1]];
                } else {
                    $where[] = ['hits_month','>',$hitsmonth[0]];
                }
            } else {
                $t = explode(' ', $hitsmonth);
                if (count($t) > 1) {
                    $whereor[] = ['hits_month','=',$t[0]];
                    $whereor[] = ['hits_month','=',$t[1]];
                } else {
                    $where[] = ['hits_month', '>',$t];
                }
            }
        }
        if (!empty($param['hits'])) { // 总点击量
            $hits = $param['hits'];
            if (is_array($hits)) {
                if (count($hits) > 1) {
                    $whereor[] = ['hits','=',$hits[0]];
                    $whereor[] = ['hits','=',$hits[1]];
                } else {
                    $where[] = ['hits','>',$hits[0]];
                }
            } else {
                $t = explode(' ', $hits);
                if (count($t) > 1) {
                    $whereor[] = ['hits','=',$t[0]];
                    $whereor[] = ['hits','=',$t[1]];
                } else {
                    $where[] = ['hits','>',$t];
                }
            }
        }
/*点击量结束*/
        // 指定添加时间 一天前 -1 day，一周前-1 week，一月前-1 month，一小时前-1 hour
        if (!empty($param['addtime'])) {
            $w = (int)strtotime($param['addtime']);
            $where[] = ['addtime','>',$w];
        }
        // 指定推荐级别
        if (!empty($param['level']) && $param['level'] !== 'all' && $param['level'] !== 'a') {
            if (is_string($param['level'])) $w = explode(',', $param['level']);
            elseif (is_array($param['level'])) $w = $param['level'];
            else $w = [1, 2, 3, 4, 5, 6, 7, 8, 9];
            $where['art_star'] = $w;
        }


        //指定分类信息 全部分类 和子分类信息
        $typeModel=new TypeModel();
        $info=$typeModel->getDataAll(['type_status' => 1], 'type_id');
        $childs=$typeModel->getChildsType($param['id'] ?? '');

        if (!empty($param['type']) && $param['type'] !== 'all' && $param['type'] !== 'a') {
            $type = $param['type'];
            if ($type === 'current') {
                if ($info = C::getInstance()->get('info')) {
                    if (isset($info['childs']) && !empty($info['childs'])) {
                        $type = [$info['type_id']] + array_keys($info['childs']);
                    } else {
                        $type = $info['type_id'];
                    }
                    $where['type_id'] = is_int($type) ? $type : $type;
                }
            } else {
                if (!empty($ids)) {
                    $where['type_pid'] = $childs;
                }
            }
        }
        if (!empty($param['not'])) {
            if (is_string($param['not'])) $where[] = ['art_id', 'not in',explode(',', $param['not'])];
            elseif (is_array($param['not'])) $where[] = ['art_id', 'not in',$param['not']];
        }
        if (!empty($param['ids']) && $ids = $param['ids'] !== 'all') {
            $idsArr = explode(',',$param['ids']);
            $idsArr = array_filter($idsArr, function ($value){
                return is_numeric($value) && $value > 0;
            });
            $where['art_id'] = $idsArr;
        }

        if (!empty($param['wd'])) {
            $wherelike[] =['vod_title','like',"%".$param['wd']."%" ];
        }

        //分页
        $pageurl = !empty($param['pageurl']) ? $param['pageurl'] : 'art/type';
        if (!empty($param['paging']) && $param['paging'] === 'yes') {
            // 分页，检测所有过来的接收值
            if (!empty($paramUrl['wd'])) {
                $wherelike[] =['vod_title','like',"%".$paramUrl['wd']."%" ];
            }
            if (!empty($paramUrl['ids']) && $ids = $paramUrl['ids'] !== 'all') {
                switch ($ids) {
                    case is_string($ids):
                        $pid_arr = explode(',', $ids);
                        $where['art_id'] = $pid_arr;
                        break;
                    case is_array($ids = json_decode($ids, true)):
                        $where['art_id'] = $ids;
                        break;
                }
            }
            if (!empty($paramUrl['level']) && $paramUrl['level'] !== 'all' && $paramUrl['level'] !== 'a') {
                if (is_string($paramUrl['level'])) $w = explode(',', $paramUrl['level']);
                elseif (is_array($paramUrl['level'])) $w = $paramUrl['level'];
                else $w = [1, 2, 3, 4, 5, 6, 7, 8, 9];
                $where['art_star'] =$w;
            }
            $param['by'] = !empty($paramUrl['by']) ? $paramUrl['by'] : $param['by'];
            $param['order'] = !empty($paramUrl['order']) ? $paramUrl['order'] : $param['order'];
            $page = !empty($paramUrl['page']) ? (int)$paramUrl['page'] : $page;
            $number = !empty($paramUrl['num']) ? (int)$paramUrl['num'] : $number;
            $paramUrl['page'] = 'PAGELINK';
            if ($pageurl === 'art/type' || $pageurl === 'art/show') {
                $typeid = (int)C::getInstance()->get('type_id');
                //$typeList = ColumnModel::create()->cacheQuery($typeid, 'TYPE_LIST');
                $typeList = C::getInstance()->get('typeList');
                $typeInfo = $typeList['data'][$typeid] ?: [];
                $flag = $pageurl === 'art/show' ? 'show' : 'type';
                $pageurl = Common::getInstance()->ray_url_type($typeInfo, $paramUrl, $flag);
            } else {
                $pageurl = Common::getInstance()->ray_url($pageurl, $paramUrl);
            }
        }
        $by = !empty($param['by']) && in_array($param['by'], ['id', 'sort', 'addtime', 'cid', 'hits', 'hits_day', 'hits_week', 'hits_month', 'star']) ? $param['by'] : 'id';
        $order = !empty($param['order']) && in_array($param['order'], ['desc', 'asc']) ? strtoupper($param['order']) : 'DESC';
        if ($by === 'rnd') {
            $data_count = Db::name('art')->where($where)->where($wherelike)->whereOr($whereor)->count('*');
            $page_total = floor($data_count / $param['num']) + 1;
            if ($data_count < $param['num']) {
                $param['num'] = $data_count;
            }
            $randi = @random_int(1, $page_total);
            $page = $randi;
            $by = 'hits_week';
            $order = 'desc';
        }
        $where['art_status'] = 1;
        $by = 'art_' . $by;
        $half = (int)abs(!empty($param['half']) ? $param['half'] : 0);
        $total = Db::name('art')->where($where)->where($wherelike)->whereOr($whereor)->count();
        $field = !empty($param['field']) ? '*' : 'art_id,type_id,art_title,art_sub,art_star,art_author,art_from,art_status,art_hits,art_hits_day,art_hits_week,art_hits_month,art_color,art_blurb,art_pic,art_pic_thumb,art_jumpurl,art_jumpstatus,art_sort,art_addtime';

        $result['page'] = $page;
        $result['pagecount'] = $number !== 0 ? ceil($total / $number) : 0;
        $result['pageurl'] = $pageurl;
        $result['half'] = $half;
        $result['limit'] = $number;
        $result['total'] = $total;

        $result['data']=Db::name('art')
            ->field($field)
            ->where($where)
            ->where($wherelike)
            ->whereOr($whereor)
            ->order($by,$order)
            ->limit($number)
            ->select()->toArray();

        if (isset($tag['page']) || isset($tag['paging'])){
            $result['page'] = $this->page_param($total,$number,$page,'vod/index/art',$half);
            return $result;
        } else {
            return $result['data'];
        }

    }


    //广告标签
    public function tagAds($tag)
    {
        $param=json_decode($tag, true);
        $db=Db::name('ads');
        // 指定一组id
        if (!empty($param['ids']) && $ids = $param['ids'] !== 'all') {
            switch ($ids) {
                case is_string($ids):
                    $aid_arr = explode(',', $ids);
                    if ($aid_arr) {
                        $db->where('ad_id','in',$aid_arr);
                    }
                    break;
                case is_array($ids = json_decode($ids, true)):
                    if ($ids) {
                        $db->where('ad_id','in',$ids);
                    }
                    break;
            }
        }

        // 指定位置
        if (!empty($param['posit'])) {
            $posit = $param['posit'];
            if (is_string($posit)) $w = explode(',', $posit);
            elseif (is_array($posit)) $w = $posit;
            else $w = [1, 2, 3, 4, 5, 6, 7, 8, 9];
            $db->where('ad_posit','in',$w);
        }
        $by = !empty($param['by']) && in_array($param['by'], ['ad_id', 'ad_sort']) ? strtoupper($param['by']) : 'ad_sort';
        $order = !empty($param['order']) && in_array($param['order'], ['DESC', 'ASC']) ? strtoupper($param['order']) : 'DESC';
        $db->order($by,$order);

        if (isset($param['start']) && is_numeric($param['start']) && $param['start'] > 0){
            $limit[0] = (int)$param['start'];
        }
        //检查属性num
        if (isset($param['num']) && is_numeric($param['num']) && $param['num'] > 0){
            $limit[1] = (int)$param['num'];
            $db->limit($limit[1]);
        }
        $result=$db->select()->toArray();

        return $result;

    }

    //友情链接
    public function tagLink($tag)
    {
        $param=json_decode($tag, true);
        $db=Db::name('link');

        $limit=[0,10];
        if(!empty($param['type']) && $param['type']!='all'){
             $db->where('link_type','=',$param['type']);
        }

        $by = !empty($param['by']) && in_array($param['by'], ['link_id', 'link_sort']) ? strtoupper($param['by']) : 'link_sort';
        $order = !empty($param['order']) && in_array($param['order'], ['desc', 'asc']) ? strtoupper($param['order']) : 'DESC';

        $db->order($by,$order);
        if (isset($param['start']) && is_numeric($param['start']) && $param['start'] > 0){
            $limit[0] = (int)$param['start'];
            $db->limit($limit[0]);
        }
        //检查属性num
        if (isset($param['num']) && is_numeric($param['num']) && $param['num'] > 0){
            $limit[1] = (int)$param['num'];
            $db->limit($limit[1]);
        }
        $result=$db->select()->toArray();

        return $result;
    }


    /*
       * @param array $tag
       * @param string $content
       * @return string
       * @author C.
       * @date 2020/4/20 上午10:23
       */
    public function tagForeach($tag): array
    {
            $tag = json_decode($tag, true);
            $data=explode(',',$tag['name']);
            return $data;


    }


    public function funRayUrlPage()
    {

    }


    public function tagArea($tag)
    {
        $result = Helper::service('Config','Admin')->get('site.vod_extend_area');
        $data = explode(',',$result['val']);
        if (empty($data)){
            return [];
        }
        if (isset($tag['order']) && $tag['order'] === 'desc'){
            $data = array_reverse($data);
        }
        if (isset($tag['num']) && is_numeric($tag['num'])){
            $data = array_slice($data, 0, $tag['num']);
        }
        $obj = Context::get('obj');
        $param = Context::get('param');
        $return = [];
        foreach ($data as $_data)
        {
            $return[] = array(
                'area_name'=>$_data,
                'area_link'=>Common::ray_url_type($obj,['area'=>$_data,'lang'=>$param['lang'],'year'=>$param['year'],'class'=>$param['class'],'by'=>$param['by'] ],'show')
            );
        }
        return $return;
    }


    public function tagClass($tag)
    {
        $result = Helper::service('Config','Admin')->get('site.vod_extend_class');
        $data = explode(',',$result['val']);
        if (empty($data)){
            return [];
        }
        if (isset($tag['order']) && $tag['order'] === 'desc'){
            $data = array_reverse($data);
        }
        if (isset($tag['num']) && is_numeric($tag['num'])){
            $data = array_slice($data, 0, $tag['num']);
        }
        $obj = Context::get('obj');
        $param = Context::get('param');
        $return = [];
        foreach ($data as $_data)
        {
            $return[] = array(
                'class_name'=>$_data,
                'class_link'=>Common::ray_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'class'=>$_data,'by'=>$param['by'] ],'show')
            );
        }
        return $return;
    }


    public function tagLang($tag)
    {
        $result = Helper::service('Config','Admin')->get('site.vod_extend_lang');
        $data = explode(',',$result['val']);
        if (empty($data)){
            return [];
        }
        if (isset($tag['order']) && $tag['order'] === 'desc'){
            $data = array_reverse($data);
        }
        if (isset($tag['num']) && is_numeric($tag['num'])){
            $data = array_slice($data, 0, $tag['num']);
        }
        $obj = Context::get('obj');
        $param = Context::get('param');
        $return = [];
        foreach ($data as $_data)
        {
            $return[] = array(
                'lang_name'=>$_data,
                'lang_link'=>Common::ray_url_type($obj,['area'=>$param['area'],'lang'=>$_data,'year'=>$param['year'],'class'=>$param['class'],'by'=>$param['by'] ],'show')
            );
        }
        return $return;
    }


    public function tagYear($tag)
    {
        $result = Helper::service('Config','Admin')->get('site.vod_extend_year');
        $data = explode(',',$result['val']);
        if (empty($data)){
            return [];
        }
        if (isset($tag['order']) && $tag['order'] === 'desc'){
            $data = array_reverse($data);
        }
        if (isset($tag['num']) && is_numeric($tag['num'])){
            $data = array_slice($data, 0, $tag['num']);
        }
        $obj = Context::get('obj');
        $param = Context::get('param');
        $return = [];
        foreach ($data as $_data)
        {
            $return[] = array(
                'year_name'=>$_data,
                'year_link'=>Common::ray_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$_data,'class'=>$param['class'],'by'=>$param['by'] ],'show')
            );
        }
        return $return;
    }

    public function tagHot($tag)
    {
        $result = Helper::service('Config','Admin')->get('site.vod_search_hot');
        $data = explode(',',$result['val']);
        if (empty($data)){
            return [];
        }
        if (isset($tag['order']) && $tag['order'] === 'desc'){
            $data = array_reverse($data);
        }
        if (isset($tag['num']) && is_numeric($tag['num'])){
            $data = array_slice($data, 0, $tag['num']);
        }

        $return = [];
        foreach ($data as $_data)
        {
            $return[] = array(
                'hot_name'=>$_data,
            );
        }
        return $return;
    }
    /**
     * 对数字数组进行过滤8
     * @param $ids
     * @return array
     */
    private function numberFilter($ids):array
    {
        if (!is_array($ids)){
            $ids = explode(',',$ids);
        }
        $ids = array_map(function($value){
            return (int)trim($value);
        },$ids);
        $ids = array_filter($ids, function ($value){
            return is_numeric($value) && $value>0;
        });
        return $ids;
    }

    /**
     * 对字符串进行过滤
     * @param $str
     * @return array
     */
    private function strFilter($str):array
    {
        if (!is_array($str)){
            $str = explode(',',$str);
        }
        $str = array_map(function($value){
            return trim($value);
        },$str);
        return $str;
    }

    private function parseRange($str)
    {
        $str = strtolower($str);
        $arr = array_filter(explode(' ',$str), function ($value){
            return !empty($value);
        });
        if (!isset($arr[1]) || !in_array($arr[0], ['gt','lt','between'])){
            return null;
        }
        $return = [];
        $t = ['gt'=>'>=','lt'=>'<=','between'=>'between'];
        $return[] = $t[$arr[0]];
        $range = explode(',',$arr[1]);
        if (!isset($range[0]) || !is_numeric($range[0])){
            return null;
        }
        if ($arr[0] == 'between'){
            if (isset($range[1]) && is_numeric($range[1]) && $range[1] >= $range[0]){
                $return[] = array($range[0], $range[1]);
            } else {
                return null;
            }
        } else {
            $return[] = $range[0];
        }
        return $return;
    }

    private function cacheKey($prefix, $str){
        return md5(static::class.'/'.$prefix.'/'.$str);
    }
}