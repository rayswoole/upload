<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020-2021 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-09-23 14:54
 ** ----------------------------------------------------------------------
 **/

namespace App\Vod\Service;

use rayswoole\orm\facade\Db;
use rayswoole\Service;
use rayswoole\Helper;

class TypeService extends Service
{
    public function get(int $key = 0)
    {
        $siteConfig = Helper::service('Config','Admin')->get('vod') ?? [];
        $type_extend = array(
            'class' => explode(',', $siteConfig['vod_extend_class']['val']),
            'area'  => explode(',', $siteConfig['vod_extend_area']['val']),
            'lang'  => explode(',', $siteConfig['vod_extend_lang']['val']),
            'year'  => explode(',', $siteConfig['vod_extend_year']['val'])
        );
        $result = Db::name('type')->where('type_status', 1)->order('type_pid','desc')->column('*','type_id');
        if (!empty($result)){
            foreach ($result as $_id=>$_result){
                $result[$_id]['type_extend'] = $type_extend;
                if ($_result['type_pid'] > 0){
                    $result[$_id]['parent'] = &$result[$_result['type_pid']];
                    $result[$_result['type_pid']]['type_child'][] = $_result['type_id'];
                    if (isset($_result['type_child'])){
                        $result[$_result['type_pid']]['type_child'] =
                            array_merge($result[$_result['type_pid']]['type_child'],$_result['type_child']);
                    }
                } else {
                    $result[$_id]['parent'] = ['type_id'=>0,'type_id'=>0];
                }
            }
        }
        if ($key === 0){
            return $result;
        } else {
            return $result[$key] ?? null;
        }
    }

    public function simpleGet()
    {
        $data = $this->get();
        return array_map(function ($value){
            return $value['type_name'];
        }, $data);
    }

    //获取电影子分类
    public function getChildsType($pid = '')
    {
        $res = Db::name('type')
            ->field('type_id')
            ->where(['type_pid'=>$pid])
            ->order('type_id', 'ASC')
            ->select()->toArray();
        $childs[]=$pid;
        if ($res) {
            foreach ($res as $k => $v) {
                $childs[] = $v['type_id'];
            }
        }

        $child = implode(',', $childs);
        return (string)$child;
    }














}