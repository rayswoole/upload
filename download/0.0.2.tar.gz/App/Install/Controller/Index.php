<?php
/**
 ** RAY7 [ HIGH PERFORMANCE CMS BASED ON SWOOLE ]
 ** ----------------------------------------------------------------------
 ** Copyright © 2020 https://ray7.cc All rights reserved.
 ** ----------------------------------------------------------------------
 ** Author: ray7开发团队 <dev@ray7.cc>
 ** ----------------------------------------------------------------------
 ** Last-Modified: 2020-12-11
 ** ----------------------------------------------------------------------
 **/

namespace App\Install\Controller;


use rayswoole\HttpController;
use rayswoole\Vars;

class Index extends HttpController
{
    public function index()
    {
        $this->response()->write(Vars::get('ERROR'));
    }
}